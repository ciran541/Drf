from rest_framework import serializers
from .models import PurchaseOrder,Bill,PurchaseReceive,Package,Shipment,SalesReturn,RetainerInvoice

class RetainerInvoiceSerializer(serializers.ModelSerializer):
    class Meta:
        model = RetainerInvoice
        fields = '__all__'
        ref_name = 'InventoryPurchaseOrder'

class PurchaseOrderSerializer(serializers.ModelSerializer):
    class Meta:
        model = PurchaseOrder
        fields = '__all__'

class BillSerializer(serializers.ModelSerializer):
    class Meta:
        model = Bill
        fields = '__all__'

class PurchaseReceiveSerializer(serializers.ModelSerializer):
    class Meta:
        model = PurchaseReceive
        fields = '__all__'

class PackageSerializer(serializers.ModelSerializer):
    class Meta:
        model = Package
        fields = '__all__'

class ShipmentSerializer(serializers.ModelSerializer):
    class Meta:
        model = Shipment
        fields = '__all__'

class SalesReturnSerializer(serializers.ModelSerializer):
    class Meta:
        model = SalesReturn
        fields = '__all__'