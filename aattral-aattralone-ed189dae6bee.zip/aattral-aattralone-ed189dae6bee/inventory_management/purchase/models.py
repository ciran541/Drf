from django.db import models
from django.utils import timezone
from finance.Time_tracking.models import Project
from finance.Accountant.models import Document
from inventory_management.Inventory.models import Contacts,Item,Address,SalesPerson,ContactPerson,PaymentTerms

# Models for Sales Modules in Inventory_Management 


class RetainerInvoice(models.Model):
    # Unique identifier for the retainer invoice
    retainerinvoice_id = models.CharField(primary_key=True, max_length=255)
    
    # Number of the retainer invoice
    retainerinvoice_number = models.CharField(max_length=100)
    
    # Date of creation of the retainer invoice
    date = models.DateField()
    
    # Status of the retainer invoice (e.g., Sent, Draft, Paid)
    status = models.CharField(max_length=20, choices=[
        ('sent', 'Sent'),
        ('draft', 'Draft'),
        ('overdue', 'Overdue'),
        ('paid', 'Paid'),
        ('void', 'Void'),
        ('unpaid', 'Unpaid'),
        ('partially_paid', 'Partially Paid'),
        ('viewed', 'Viewed'),
    ])
    
    # Flag indicating whether the transaction is before July 1, 2017
    is_pre_gst = models.BooleanField()
    
    # Place where the goods/services are supplied (applicable only for India)
    place_of_supply = models.CharField(max_length=255)
    
    # ID and Name of the associated project
    project_id = models.ForeignKey(Project, related_name='purchase_Retainer_invoice', on_delete=models.SET_NULL, null=True, blank=True)
    
    # Last payment date of the retainer invoice
    last_payment_date = models.DateField()
    
    # Reference number of the retainer invoice
    reference_number = models.CharField(max_length=100)
    
    # ID and Name of the associated customer
    customer_id = models.ForeignKey(Contacts, on_delete=models.SET_NULL, null=True, blank=True)
    customer_name = models.CharField(max_length=100)
    
    # Currency details
    currency_id = models.CharField(max_length=255)
    currency_code = models.CharField(max_length=10)
    currency_symbol = models.CharField(max_length=10)
    exchange_rate = models.FloatField()
    
    # Viewed by client information
    is_viewed_by_client = models.BooleanField()
    client_viewed_time = models.DateTimeField(null=True, blank=True)
    
    # Inclusive tax flag
    is_inclusive_tax = models.BooleanField()
    
    product_name = models.ForeignKey(Item, related_name='purchase_RetainerInvoice_items', on_delete=models.CASCADE)

    # Financial details
    sub_total = models.FloatField()
    total = models.FloatField()
    payment_made = models.FloatField()
    payment_drawn = models.FloatField()
    balance = models.FloatField()
    allow_partial_payments = models.BooleanField()
    price_precision = models.IntegerField()
    
    # Email information
    is_emailed = models.BooleanField()
    
    # Timestamps and creator information
    created_time = models.DateTimeField()
    last_modified_time = models.DateTimeField()
    created_by_id = models.CharField(max_length=255)
    
    # Attachment and email sending details
    attachment_name = models.CharField(max_length=255)
    can_send_in_mail = models.BooleanField()
    invoice_url = models.URLField()
    
    def calculate_balance(self):
        """
        Method to calculate the balance amount for the retainer invoice.
        """
        return self.total - self.payment_made

    def is_overdue(self):
        """
        Method to check if the retainer invoice is overdue based on the last payment date.
        """
        return self.status == 'unpaid' and self.last_payment_date < timezone.now().date()

    def is_fully_paid(self):
        """
        Method to check if the retainer invoice is fully paid.
        """
        return self.balance == 0
    
    def __str__(self):
        return f"Retainer Invoice {self.retainerinvoice_number} for {self.customer_name}"
    

class SalesOrder(models.Model):
    # Primary key for Sales Order
    salesorder_id = models.CharField(primary_key=True, max_length=255)
    
    # ID and Name of the associated customer
    customer_id = models.ForeignKey(Contacts, on_delete=models.SET_NULL, null=True, blank=True)
    customer_name = models.CharField(max_length=100)

    # Many-to-Many relationship with Document model
    documents = models.ManyToManyField(Document, related_name='purchase_documents')

    # Indicates whether GST is applicable for transactions before July 1, 2017 (Indian context)
    is_pre_gst = models.BooleanField()

    # 15-digit GST identification number of the customer (Indian context)
    gst_no = models.CharField(max_length=15, null=True, blank=True)

    # GST treatment for the contact (Indian context)
    gst_treatment = models.CharField(max_length=50, null=True, blank=True)

    # Place where the goods/services are supplied to (Indian context or GCC countries)
    place_of_supply = models.CharField(max_length=50, null=True, blank=True)

    # VAT treatment for the sales order (UK context)
    vat_treatment = models.CharField(max_length=50, null=True, blank=True)

    # VAT treatment for the sales order (GCC, Mexico context)
    tax_treatment = models.CharField(max_length=50, null=True, blank=True)

    # Unique number for the sales order (Mandatory if auto number generation is disabled)
    salesorder_number = models.CharField(max_length=100, null=True, blank=True)

    # Date when the sales order is created
    date = models.DateField()

    # Status of the Sales Order
    status = models.CharField(max_length=50)

    # Shipping date of the sales order
    shipment_date = models.DateField(null=True, blank=True)

    # Reference Number of the Sales Order
    reference_number = models.CharField(max_length=100, null=True, blank=True)

    # Array of contact persons for whom sales order has to be sent
    contact_persons = models.JSONField(null=True, blank=True)

    # ID of the Currency in Sales Order
    currency_id = models.CharField(max_length=255)

    # Code of the Currency involved in the Sales Order
    currency_code = models.CharField(max_length=10)

    # Symbol of the Currency involved in the Sales Order
    currency_symbol = models.CharField(max_length=10)

    # Exchange rate of the currency
    exchange_rate = models.FloatField()

    # Discount amount applied to the sales order
    discount_amount = models.FloatField(null=True, blank=True)

    # Discount applied to the sales order (in percentage or amount)
    discount = models.CharField(max_length=50, null=True, blank=True)

    # Discount applied on amount
    discount_applied_on_amount = models.IntegerField(null=True, blank=True)

    # Used to specify whether the discount has to be applied before or after the calculation of tax
    is_discount_before_tax = models.BooleanField()

    # How the discount is specified (entity_level or item_level)
    discount_type = models.CharField(max_length=50, null=True, blank=True)

    # ID of the estimate from which the sales order is created
    estimate_id = models.CharField(max_length=255, null=True, blank=True)

    # Delivery method for the sales order
    delivery_method = models.CharField(max_length=255, null=True, blank=True)

    # ID of the delivery method for the sales order
    delivery_method_id = models.CharField(max_length=255, null=True, blank=True)

    # Used to specify whether the line item rates are inclusive or exclusive of tax
    is_inclusive_tax = models.BooleanField()

    # Line items of the sales order
    line_items = models.JSONField(null=True, blank=True)
    product_name = models.ForeignKey(Item, related_name='purchase_Sales_items', on_delete=models.CASCADE)

    # Shipping charge for the sales order
    shipping_charge = models.FloatField(null=True, blank=True)

    # Adjustment for the sales order
    adjustment = models.FloatField(null=True, blank=True)

    # Description of the adjustment for the sales order
    adjustment_description = models.CharField(max_length=255, null=True, blank=True)

    # Subtotal of the Sales Order
    sub_total = models.FloatField()

    # Tax total of the Sales Order
    tax_total = models.FloatField()

    # Total amount of the Sales Order
    total = models.FloatField()

    # Taxes applied to the Sales Order
    taxes = models.JSONField(null=True, blank=True)

    # Precision value on the price
    price_precision = models.IntegerField()

    # Check if the Sales Order is emailed to the customer
    is_emailed = models.BooleanField()

    # Billing address for the Sales Order
    billing_address = models.ForeignKey(Address, related_name='purchase_salesorder_billing_address', on_delete=models.CASCADE)

    # Shipping address for the Sales Order
    shipping_address = models.ForeignKey(Address, related_name='purchase_salesorder_shipping_address', on_delete=models.CASCADE)

    # Notes for the Sales Order
    notes = models.TextField(null=True, blank=True)

    # Terms for the Sales Order
    terms = models.TextField(null=True, blank=True)

    # Custom fields for the Sales Order
    custom_fields = models.JSONField(null=True, blank=True)

    # ID of the pdf template associated with the Sales Order
    template_id = models.CharField(max_length=255, null=True, blank=True)

    # Name of the template associated with the Sales Order
    template_name = models.CharField(max_length=255, null=True, blank=True)

    # Page width of the template
    page_width = models.CharField(max_length=50, null=True, blank=True)

    # Page height of the template
    page_height = models.CharField(max_length=50, null=True, blank=True)

    # Orientation of the template
    orientation = models.CharField(max_length=50, null=True, blank=True)

    # Type of the template
    template_type = models.CharField(max_length=50, null=True, blank=True)

    # Creation time of the Sales Order
    created_time = models.DateTimeField()

    # Last modification time of the Sales Order
    last_modified_time = models.DateTimeField()

    # ID of the user who created the Sales Order
    created_by_id = models.CharField(max_length=255)

    # Name of the file attachment associated with the Sales Order
    attachment_name = models.CharField(max_length=255, null=True, blank=True)

    # Can the file be sent in mail
    can_send_in_mail = models.BooleanField()

    # ID of the salesperson associated with the Sales Order
    salesperson_id = models.CharField(max_length=255, null=True, blank=True)

    # Name of the salesperson associated with the Sales Order
    salesperson_name = models.CharField(max_length=255, null=True, blank=True)

    # ID of the merchant associated with the Sales Order
    merchant_id = models.CharField(max_length=255, null=True, blank=True)

    # Name of the merchant associated with the Sales Order
    merchant_name = models.CharField(max_length=255, null=True, blank=True)

    def __str__(self):
        return f"Sales Order {self.salesorder_number} for {self.customer_name}"


class Invoices(models.Model):
    # Unique identifier for the invoice
    invoice_id = models.CharField(primary_key=True, max_length=255)

    # Flag to indicate whether ACH payment is initiated
    ach_payment_initiated = models.BooleanField()

    # Invoice number for searching and identification
    invoice_number = models.CharField(max_length=100, null=True, blank=True)

    # Flag to indicate whether GST is applicable for transactions before July 1, 2017 (Indian context)
    is_pre_gst = models.BooleanField()

    # Place where the goods/services are supplied to (Indian context or GCC countries)
    place_of_supply = models.CharField(max_length=50, null=True, blank=True)

    # GST identification number of the customer (Indian context)
    gst_no = models.CharField(max_length=15, null=True, blank=True)

    # GST treatment for the contact (Indian context)
    gst_treatment = models.CharField(max_length=50, null=True, blank=True)

    # CFDI usage for Mexican context
    cfdi_usage = models.CharField(max_length=50, null=True, blank=True)

    # CFDI reference type for Mexican context
    cfdi_reference_type = models.CharField(max_length=50, null=True, blank=True)

    # Associate the reference invoice for Mexican context
    reference_invoice_id = models.CharField(max_length=255, null=True, blank=True)

    # VAT treatment for invoices (UK context)
    vat_treatment = models.CharField(max_length=50, null=True, blank=True)

    # VAT treatment for invoices (GCC, Mexico context)
    tax_treatment = models.CharField(max_length=50, null=True, blank=True)

    # VAT registration number
    vat_reg_no = models.CharField(max_length=255, null=True, blank=True)

    # Invoice date for searching (Default date format is yyyy-mm-dd)
    date = models.DateField()

    # Status of the invoice
    status = models.CharField(max_length=50)

    # Payment terms in days
    payment_terms = models.IntegerField()

    # Label for payment terms
    payment_terms_label = models.CharField(max_length=100, null=True, blank=True)

    # Due date for searching (Default date format is yyyy-mm-dd)
    due_date = models.DateField(null=True, blank=True)

    # Expected payment date
    payment_expected_date = models.DateField(null=True, blank=True)

    # Last payment date of the invoice
    last_payment_date = models.DateField(null=True, blank=True)

    # Reference number of the invoice
    reference_number = models.CharField(max_length=100, null=True, blank=True)
    
    # ID and Name of the associated customer
    customer_id = models.ForeignKey(Contacts, on_delete=models.SET_NULL, null=True, blank=True)
    customer_name = models.CharField(max_length=100)

    # Array of contact persons for whom the invoice has to be sent
    contact_persons = models.JSONField(null=True, blank=True)

    # Currency ID of the invoice
    currency_id = models.CharField(max_length=255)

    # Currency code of the invoice
    currency_code = models.CharField(max_length=10)

    # Exchange rate of the currency
    exchange_rate = models.FloatField()

    # Discount applied to the invoice (in percentage or amount)
    discount = models.FloatField(null=True, blank=True)

    # Flag to specify how the discount has to be applied (before or after the calculation of tax)
    is_discount_before_tax = models.BooleanField()

    # How the discount is specified (entity_level or item_level)
    discount_type = models.CharField(max_length=50, null=True, blank=True)

    # Flag to specify whether the line item rates are inclusive or exclusive of tax
    is_inclusive_tax = models.BooleanField()

    # ID of the recurring invoice from which the invoice is created
    recurring_invoice_id = models.CharField(max_length=255, null=True, blank=True)

    # Flag to check if the invoice is viewed by the client
    is_viewed_by_client = models.BooleanField()

    # Flag to check if there is an attachment
    has_attachment = models.BooleanField()

    # Time when the client viewed the invoice
    client_viewed_time = models.CharField(max_length=255, null=True, blank=True)

    # Line items of the invoice
    line_items = models.JSONField(null=True, blank=True)

    # Shipping charges applied to the invoice
    shipping_charge = models.CharField(max_length=100, null=True, blank=True)

    # Adjustments made to the invoice
    adjustment = models.FloatField(null=True, blank=True)

    # Description for the adjustment made to the invoice
    adjustment_description = models.CharField(max_length=255, null=True, blank=True)

    # Subtotal of all items in the invoice
    sub_total = models.FloatField()

    # Total amount of tax levied in the invoice
    tax_total = models.FloatField()

    # Total amount to be paid in the invoice
    total = models.CharField(max_length=255)

    # List of taxes levied on the invoice
    taxes = models.JSONField(null=True, blank=True)

    # Flag to check if payment reminders are enabled
    payment_reminder_enabled = models.BooleanField()

    # Amount paid for the invoice
    payment_made = models.FloatField()

    # Credits applied to the invoice
    credits_applied = models.FloatField()

    # Tax amount which has been withheld
    tax_amount_withheld = models.FloatField()

    # Unpaid amount in the invoice
    balance = models.CharField(max_length=255)

    # Write-off amount in the invoice
    write_off_amount = models.FloatField()

    # Flag to check if partial payments are allowed for the contact
    allow_partial_payments = models.BooleanField()

    # Precision value on the price
    price_precision = models.IntegerField()

    # Payment options for the invoice
    payment_options = models.JSONField(null=True, blank=True)

    # Flag to check if the invoice has been emailed
    is_emailed = models.BooleanField()

    # Number of reminders sent
    reminders_sent = models.IntegerField()

    # Date when the last reminder email was sent
    last_reminder_sent_date = models.DateField(null=True, blank=True)

    # Billing address for the invoice
    billing_address = models.ForeignKey(Address, related_name='purchase_invoice_billing_address', on_delete=models.CASCADE)

    # Shipping address for the invoice
    shipping_address = models.ForeignKey(Address, related_name='purchase_invoice_shipping_address', on_delete=models.CASCADE)

    # Notes added to the invoice expressing gratitude or conveying information
    notes = models.TextField(null=True, blank=True)

    # Terms added to the invoice expressing gratitude or conveying information
    terms = models.TextField(null=True, blank=True)

    # Custom fields for the invoice
    custom_fields = models.JSONField(null=True, blank=True)

    # ID of the pdf template associated with the invoice
    template_id = models.CharField(max_length=255, null=True, blank=True)

    # Name of the pdf template associated with the invoice
    template_name = models.CharField(max_length=255, null=True, blank=True)

    # Time of creation of the invoice
    created_time = models.DateTimeField(auto_now_add=True)

    # Time of last modification of the invoice
    last_modified_time = models.DateTimeField(auto_now_add=True)

    # Name of the attachment in the invoice
    attachment_name = models.CharField(max_length=255, null=True, blank=True)

    # Flag to check if the file can be sent in mail
    can_send_in_mail = models.BooleanField()

    # ID of the salesperson associated with the invoice
    salesperson_id =  models.ForeignKey(SalesPerson, on_delete=models.SET_NULL, null=True, blank=True)

    # Name of the salesperson associated with the invoice
    salesperson_name = models.CharField(max_length=200, null=True, blank=True)

    # URL of the invoice
    invoice_url = models.CharField(max_length=255, null=True, blank=True)

    def calculate_remaining_days(self):
        """
        Method to calculate and return the remaining days until the due date.
        """
        remaining_days = (self.due_date - timezone.now().date()).days
        return max(remaining_days, 0)

    def is_overdue(self):
        """
        Method to check if the invoice is overdue based on the due date.
        """
        return self.due_date and self.due_date < timezone.now().date()

    def __str__(self):
        return f"Invoice {self.invoice_number} for {self.customer_name}"


class CreditNotes(models.Model):  # For Both Sales and Purchase Transactions .... 
    # Unique identifier for the credit note
    creditnote_id = models.CharField(primary_key=True, max_length=255)

    # Unique number generated for the credit note (starts with CN)
    creditnote_number = models.CharField(max_length=100)

    # Date on which the credit note is raised
    date = models.DateField()

    # Flag indicating applicability for transactions before July 1, 2017 (Indian context)
    is_pre_gst = models.BooleanField(blank=True)

    # Place where the goods/services are supplied to (Indian context or GCC countries)
    place_of_supply = models.CharField(max_length=50, null=True, blank=True)

    # VAT treatment for credit notes (UK context)
    vat_treatment = models.CharField(max_length=50, null=True, blank=True)

    # VAT registration number
    vat_reg_no = models.CharField(max_length=255, null=True, blank=True)

    # GST identification number of the customer (Indian context)
    gst_no = models.CharField(max_length=15, null=True, blank=True)

    # CFDI usage for Mexican context
    cfdi_usage = models.CharField(max_length=50, null=True, blank=True)

    # CFDI reference type for Mexican context
    cfdi_reference_type = models.CharField(max_length=50, null=True, blank=True)

    # GST treatment for the contact (Indian context)
    gst_treatment = models.CharField(max_length=50, null=True, blank=True)

    # VAT treatment for credit notes (GCC, Mexico context)
    tax_treatment = models.CharField(max_length=50, null=True, blank=True)

    # Status of the credit note (open, closed, or void)
    status = models.CharField(max_length=50,blank=True)

    # ID and Name of the associated customer
    customer_id = models.ForeignKey(Contacts, on_delete=models.SET_NULL, null=True, blank=True)
    customer_name = models.CharField(max_length=100)


    # Additional fields for the Credit-Notes
    custom_fields = models.JSONField(null=True, blank=True)

    # Reference number generated for the payment
    reference_number = models.CharField(max_length=100, null=True, blank=True)

    # Email address of the customer
    email = models.EmailField(null=True, blank=True)

    # Total credits raised in this credit note
    total = models.FloatField()

    # Unapplied credits in the credit note
    balance = models.FloatField()

    # Line items of the credit note
    line_items = models.JSONField(null=True, blank=True)

    # List of invoices for which the credit note has been raised
    invoices = models.JSONField(null=True, blank=True)

    # Taxes associated with the subscription
    taxes = models.JSONField(null=True, blank=True)

    # Customer's currency code
    currency_code = models.CharField(max_length=10,blank=True)

    # Customer's currency symbol
    currency_symbol = models.CharField(max_length=10,blank=True)

    # Billing address for the credit note
    billing_address = models.ForeignKey(Address, related_name='purchase_creditnote_billing_address', on_delete=models.CASCADE)

    # Shipping address for the credit note
    shipping_address = models.ForeignKey(Address, related_name='purchase_creditnote_shipping_address', on_delete=models.CASCADE)

    # ID of the salesperson associated with the invoice
    salesperson_id =  models.ForeignKey(SalesPerson, on_delete=models.SET_NULL, null=True, blank=True)

    # Time at which the credit note was created
    created_time = models.DateTimeField()

    # Time at which the credit note details were last updated
    updated_time = models.DateTimeField()

    # Unique ID of the credit note template
    template_id = models.CharField(max_length=255,blank=True)

    # Name of the default template of the credit note
    template_name = models.CharField(max_length=255,blank=True)

    # A short note for the credit note
    notes = models.TextField(max_length=5000, null=True, blank=True)

    # Terms & conditions to be displayed in the credit note
    terms = models.TextField(max_length=10000, null=True, blank=True)

    def calculate_remaining_days(self):
        """
        Method to calculate and return the remaining days until the due date.
        """
        remaining_days = (self.due_date - timezone.now().date()).days
        return max(remaining_days, 0)

    def is_overdue(self):
        """
        Method to check if the credit note is overdue based on the due date.
        """
        return self.due_date and self.due_date < timezone.now().date()

    def get_creditnote_age(self):
        """
        Method to calculate and return the age of the credit note in days.
        """
        current_date = timezone.now().date()
        creditnote_age = (current_date - self.date).days
        return max(creditnote_age, 0)


    def __str__(self):
        return f"Credit Note {self.creditnote_number} for {self.customer_name}"
    
class Package(models.Model):
    billing_address = models.ForeignKey(Address, related_name='purchase_billing_packages', on_delete=models.CASCADE)
    contact_persons = models.ForeignKey(ContactPerson, on_delete=models.CASCADE)  # Assuming each package has only one contact person
    created_time = models.DateTimeField(auto_now_add=True)
    customer_id = models.ForeignKey(Contacts, on_delete=models.SET_NULL, null=True, blank=True, related_name='purchase_package')
    customer_name = models.CharField(max_length=255)
    date = models.DateField()
    email = models.EmailField()
    is_emailed = models.BooleanField(default=False)
    last_modified_time = models.DateTimeField(auto_now=True)
    line_items = models.ForeignKey(Item, on_delete=models.SET_NULL, blank=True, null=True, related_name='packages')
    mobile = models.CharField(max_length=20, blank=True)
    notes = models.TextField(blank=True)
    package_id = models.BigIntegerField(primary_key=True)
    package_number = models.CharField(max_length=255)
    phone = models.CharField(max_length=20)
    salesorder_id = models.ForeignKey(SalesOrder, on_delete=models.SET_NULL, null=True, blank=True, related_name='packages')
    salesorder_number = models.CharField(max_length=255, blank=True)
    shipping_address = models.ForeignKey(Address, related_name='purchase_shipping_packages', on_delete=models.CASCADE)
    template_id = models.BigIntegerField(blank=True, null=True)
    template_name = models.CharField(max_length=255, blank=True)
    template_type = models.CharField(max_length=255, blank=True)
    total_quantity = models.PositiveIntegerField()

    def calculate_total_line_items(self):
        """
        Calculate the total number of line items in the package.
        """
        return self.line_items.count()

    def calculate_age(self):
        """
        Calculate the age of the package in days.
        """
        return (timezone.now() - self.created_time).days

    def calculate_sales_order_discount(self):
        """
        Calculate the total discount applied from associated sales orders.
        """
        if self.salesorder_id:
            return sum(order.discount_amount for order in self.salesorder_id)
        return 0

class Shipment(models.Model):
    salesorder_id = models.ForeignKey(SalesOrder, on_delete=models.SET_NULL, null=True, blank=True, related_name='shipment_salesorder')
    salesorder_number = models.CharField(max_length=255, blank=True)
    shipment_id = models.BigIntegerField(primary_key=True)
    shipment_number = models.CharField(max_length=255, blank=True)
    date = models.DateField(blank=True)
    status = models.CharField(max_length=255, blank=True)
    detailed_status = models.CharField(max_length=255, blank=True)
    status_message = models.CharField(max_length=255, blank=True)
    carrier = models.CharField(max_length=255, blank=True)
    service = models.CharField(max_length=255, blank=True)
    delivery_days = models.IntegerField(blank=True)
    delivery_guarantee = models.BooleanField(blank=True)
    reference_number = models.CharField(max_length=255, blank=True)
    customer_id = models.ForeignKey(Contacts, on_delete=models.SET_NULL, null=True, blank=True, related_name='shipment_customer')
    customer_name = models.CharField(max_length=255, blank=True)
    contact_persons = models.ForeignKey(ContactPerson, on_delete=models.CASCADE, related_name='shipment_contact', blank=True)  
    currency_id = models.BigIntegerField(blank=True)
    currency_code = models.CharField(max_length=10, blank=True)
    currency_symbol = models.CharField(max_length=10, blank=True)
    exchange_rate = models.FloatField(blank=True)
    discount_amount = models.FloatField(blank=True)
    discount = models.CharField(max_length=50, blank=True)
    is_discount_before_tax = models.BooleanField(blank=True)
    discount_type = models.CharField(max_length=50, blank=True)
    estimate_id = models.BigIntegerField(blank=True)
    delivery_method = models.CharField(max_length=255, blank=True)
    delivery_method_id = models.BigIntegerField(blank=True)
    tracking_number = models.CharField(max_length=255, blank=True)
    shipping_charge = models.FloatField(blank=True)
    sub_total = models.FloatField(blank=True)
    tax_total = models.FloatField(blank=True)
    total = models.FloatField(blank=True)
    price_precision = models.IntegerField(blank=True)
    is_emailed = models.BooleanField(blank=True)
    billing_address = models.ForeignKey(Address, related_name='shipping_billing_packages', on_delete=models.CASCADE, blank=True)
    shipping_address = models.ForeignKey(Address, related_name='shipping_shipping_packages', on_delete=models.CASCADE, blank=True)
    created_time = models.DateTimeField(blank=True)
    last_modified_time = models.DateTimeField(blank=True)

    def calculate_total_price(self):
        """
        Method to calculate the total price of the shipment.
        """
        return self.sub_total + self.tax_total + self.shipping_charge - self.discount_amount

    def calculate_delivery_days_left(self):
        """
        Method to calculate the number of days left for delivery.
        """
        from django.utils import timezone
        if self.delivery_days:
            return (self.date - timezone.now().date()).days + self.delivery_days
        else:
            return None

class SalesReturn(models.Model):
    salesreturn_id = models.BigIntegerField(primary_key=True)
    salesreturn_number = models.CharField(max_length=255)
    date = models.DateField()
    reason = models.CharField(max_length=255)
    salesreturn_status = models.CharField(max_length=255)
    salesorder_id = models.BigIntegerField()
    salesorder_number = models.CharField(max_length=255)
    line_items = models.ForeignKey(Item, on_delete=models.SET_NULL, blank=True, null=True, related_name='purchase_salesreturn')

    def calculate_total_returned_items(self):
        """
        Method to calculate the total number of returned items.
        """
        return self.line_items.count() if self.line_items else 0

# Models for Purchase  Modules in Inventory_Management 


class PurchaseOrder(models.Model):
    vendor = models.ForeignKey(Contacts, on_delete=models.CASCADE)                        
    order_number = models.CharField(unique=True, max_length=50)
    order_date = models.DateField()
    delivery_date = models.DateField(blank=True, null=True)
    shipping_address = models.ForeignKey(Address, related_name='purchaseorder_shipping_address', on_delete=models.CASCADE) # For extract customer Address
    terms_and_conditions = models.TextField(blank=True)
    total_amount = models.DecimalField(max_digits=10, decimal_places=2)
    status = models.CharField(max_length=20, default='draft')  # You can use choices for predefined statuses
    description = models.TextField(blank=True)
    unit_of_measure = models.CharField(max_length=20)
    quantity = models.PositiveIntegerField()
    unit_price = models.DecimalField(max_digits=10, decimal_places=2)
    discount_percentage = models.DecimalField(max_digits=5, decimal_places=2, blank=True, null=True)
    tax_rate = models.DecimalField(max_digits=5, decimal_places=2, blank=True, null=True)
    expected_delivery_date = models.DateField()
    payment_terms = models.ForeignKey(PaymentTerms,related_name='purchaseorder_payment_terms', on_delete=models.SET_NULL, null=True, blank=True)
    
    item = models.ForeignKey(Item, related_name='purchaseorder_items', on_delete=models.CASCADE)
    quantity = models.PositiveIntegerField()
    unit_price = models.DecimalField(max_digits=10, decimal_places=2)
    line_total = models.DecimalField(max_digits=10, decimal_places=2)
    
    def calculate_discounted_price(self):
        """
        Method to calculate the discounted price of the purchase order line.
        """
        if self.discount_percentage:
            discount_amount = (self.discount_percentage / 100) * self.unit_price
            discounted_price = self.unit_price - discount_amount
            return discounted_price
        else:
            return self.unit_price

    def calculate_tax_amount(self):
        """
        Method to calculate the tax amount of the purchase order line.
        """
        if self.tax_rate:
            tax_amount = (self.tax_rate / 100) * (self.unit_price * self.quantity)
            return tax_amount
        else:
            return 0

    def calculate_line_total(self):
        """
        Method to calculate the total amount of the purchase order line.
        """
        line_total = (self.unit_price * self.quantity) + self.calculate_tax_amount()
        return line_total

class Bill(models.Model):
    bill_id = models.AutoField(primary_key=True)
    vendor = models.ForeignKey(Contacts, on_delete=models.CASCADE)
    bill_date = models.DateField()
    due_date = models.DateField()
    bill_number = models.CharField(max_length=255, blank=True, null=True)
    purchase_order = models.ForeignKey(PurchaseOrder, on_delete=models.SET_NULL, blank=True, null=True)
    description = models.TextField(blank=True, null=True)
    currency = models.CharField(max_length=3)  # Assuming currency code like 'USD', 'EUR', etc.
    exchange_rate = models.DecimalField(max_digits=10, decimal_places=4, blank=True, null=True)
    tax_rate = models.DecimalField(max_digits=5, decimal_places=2, blank=True, null=True)
    total_amount = models.DecimalField(max_digits=15, decimal_places=2)
    paid_amount = models.DecimalField(max_digits=15, decimal_places=2, default=0)
    payment_terms = models.ForeignKey(PaymentTerms,related_name='bill_payment_terms', on_delete=models.SET_NULL, null=True, blank=True)

    item = models.ForeignKey(Item, related_name='purchase_bill_items', on_delete=models.CASCADE)
    quantity = models.PositiveIntegerField()
    unit_price = models.DecimalField(max_digits=10, decimal_places=2)
    line_total = models.DecimalField(max_digits=10, decimal_places=2)

    file_1 = models.FileField(upload_to='bill_attachments/', null=True, blank=True)
    file_2 = models.FileField(upload_to='bill_attachments/', null=True, blank=True)
    
    def calculate_line_total(self):
        """
        Method to calculate the line total for the bill line.
        """
        return self.quantity * self.unit_price

    def calculate_tax_amount(self):
        """
        Method to calculate the tax amount based on the tax rate.
        """
        if self.tax_rate is not None:
            return self.line_total * (self.tax_rate / 100)
        else:
            return 0

    def calculate_total_amount(self):
        """
        Method to calculate the total amount for the bill line.
        """
        return self.line_total + self.calculate_tax_amount()

    @property
    def outstanding_amount(self):
        return self.total_amount - self.paid_amount

    def __str__(self):
        return f"Bill {self.bill_id} - {self.vendor} - {self.total_amount} {self.currency}"  
    
class PurchaseReceive(models.Model):
    purchaseorder_id = models.ForeignKey(PurchaseOrder, on_delete=models.CASCADE)
    purchaseorder_number = models.CharField(max_length=255)
    receive_id = models.BigIntegerField(unique=True)
    receive_number = models.CharField(max_length=255)
    date = models.DateField()
    vendor_id = models.ForeignKey(Contacts, on_delete=models.CASCADE)
    vendor_name = models.CharField(max_length=255)
    contact_persons = models.ForeignKey(ContactPerson, on_delete=models.CASCADE, related_name='PurchaseReceive_contact', blank=True)  
    notes = models.TextField()
    line_items = models.ForeignKey(Item, related_name='PurchaseReceive_items', on_delete=models.CASCADE)
    billing_address = models.ForeignKey(Address, related_name='PurchaseReceive_billing_packages', on_delete=models.CASCADE, blank=True)
    shipping_address = models.ForeignKey(Address, related_name='PurchaseReceive_shipping_packages', on_delete=models.CASCADE, blank=True)
    created_time = models.DateTimeField(auto_now_add=True)
    last_modified_time = models.DateTimeField(auto_now=True)

    def get_line_items_total_quantity(self):
        """
        Method to calculate and return the total quantity of all line items.
        """
        return sum(item.quantity for item in self.line_items.all())

    def get_line_items_total_amount(self):
        """
        Method to calculate and return the total amount of all line items.
        """
        return sum(item.unit_price * item.quantity for item in self.line_items.all())

    def get_line_items_average_price(self):
        """
        Method to calculate and return the average price of all line items.
        """
        total_amount = self.get_line_items_total_amount()
        total_quantity = self.get_line_items_total_quantity()
        if total_quantity == 0:
            return 0
        else:
            return total_amount / total_quantity