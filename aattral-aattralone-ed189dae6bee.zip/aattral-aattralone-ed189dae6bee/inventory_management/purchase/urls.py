from django.urls import path, include
from rest_framework.routers import DefaultRouter
from .views import PurchaseOrderViewSet,SalesReturnViewSet,ShipmentViewSet,PackageViewSet,RetainerInvoiceViewSet

router = DefaultRouter()
router.register(r'retainer-invoices', RetainerInvoiceViewSet)
router.register(r'purchaseorder', PurchaseOrderViewSet)
router.register(r'packages', PackageViewSet)
router.register(r'shipments', ShipmentViewSet)
router.register(r'salesreturns', SalesReturnViewSet)

urlpatterns = [
    path('', include(router.urls)),
]
