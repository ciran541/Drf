from django.contrib import admin
from .models import Invoices, RetainerInvoice, SalesOrder,CreditNotes, Package, Shipment, SalesReturn, PurchaseOrder, Bill, PurchaseReceive

# Register the Invoices model
@admin.register(Invoices)
class InvoicesAdmin(admin.ModelAdmin):
    # Define the fields to be displayed in the admin interface
    list_display = ['invoice_number', 'customer_name', 'status', 'date', 'due_date', 'total']
    # Add filter options for easy searching
    list_filter = ['status', 'date', 'due_date']
    # Add search fields for quick searching by invoice number or customer name
    search_fields = ['invoice_number', 'customer_name']

# Register the RetainerInvoice model
@admin.register(RetainerInvoice)
class RetainerInvoiceAdmin(admin.ModelAdmin):
    # Define the fields to be displayed in the admin interface
    list_display = ['retainerinvoice_number', 'customer_name', 'status', 'date', 'last_payment_date', 'total']
    # Add filter options for easy searching
    list_filter = ['status', 'date', 'last_payment_date']
    # Add search fields for quick searching by invoice number or customer name
    search_fields = ['retainerinvoice_number', 'customer_name']

# Register the SalesOrder model
@admin.register(SalesOrder)
class SalesOrderAdmin(admin.ModelAdmin):
    # Define the fields to be displayed in the admin interface
    list_display = ['salesorder_number', 'customer_name', 'status', 'date', 'shipment_date', 'total']
    # Add filter options for easy searching
    list_filter = ['status', 'date', 'shipment_date']
    # Add search fields for quick searching by sales order number or customer name
    search_fields = ['salesorder_number', 'customer_name']

@admin.register(CreditNotes)
class CreditNotesAdmin(admin.ModelAdmin):
    list_display = ['creditnote_number', 'customer_name', 'date', 'total', 'status']
    search_fields = ['creditnote_number', 'customer_name']
    list_filter = ['status', 'date']

@admin.register(Package)
class PackageAdmin(admin.ModelAdmin):
    list_display = ['package_number', 'customer_name', 'date', 'total_quantity', 'is_emailed']
    search_fields = ['package_number', 'customer_name']
    list_filter = ['date', 'is_emailed']

@admin.register(Shipment)
class ShipmentAdmin(admin.ModelAdmin):
    list_display = ['shipment_number', 'customer_name', 'date', 'total', 'status']
    search_fields = ['shipment_number', 'customer_name']
    list_filter = ['status', 'date']

@admin.register(SalesReturn)
class SalesReturnAdmin(admin.ModelAdmin):
    list_display = ['salesreturn_number', 'salesorder_number', 'date', 'reason', 'salesreturn_status']
    search_fields = ['salesreturn_number', 'salesorder_number']
    list_filter = ['date', 'salesreturn_status']

@admin.register(PurchaseOrder)
class PurchaseOrderAdmin(admin.ModelAdmin):
    list_display = ['order_number', 'vendor', 'order_date', 'total_amount', 'status']
    search_fields = ['order_number', 'vendor']
    list_filter = ['status', 'order_date']

@admin.register(Bill)
class BillAdmin(admin.ModelAdmin):
    list_display = ['bill_number', 'vendor', 'bill_date', 'total_amount', 'paid_amount']
    search_fields = ['bill_number', 'vendor']
    list_filter = ['bill_date']

@admin.register(PurchaseReceive)
class PurchaseReceiveAdmin(admin.ModelAdmin):
    list_display = ['receive_number', 'purchaseorder_number', 'vendor_name', 'date']
    search_fields = ['receive_number', 'vendor_name']
    list_filter = ['date']