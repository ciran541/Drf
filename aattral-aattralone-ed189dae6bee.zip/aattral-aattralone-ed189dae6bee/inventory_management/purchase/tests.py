from django.test import TestCase
from datetime import date
from inventory_management.Inventory.models import Contacts, Item
from .models import Project, RetainerInvoice,SalesReturn
class RetainerInvoiceModelTest(TestCase):

    @classmethod
    def setUpTestData(cls):
        # Create sample data for testing
        cls.contact = Contacts.objects.create(name="Test Customer", email="test@example.com")
        cls.item = Item.objects.create(name="Test Item", price=100.00)
        cls.project = Project.objects.create(name="Test Project")

        RetainerInvoice.objects.create(
            retainerinvoice_id="INV001",
            retainerinvoice_number="INV001",
            date=date.today(),
            status='draft',
            is_pre_gst=True,
            place_of_supply="Test Place",
            project_id=cls.project,
            last_payment_date=date.today(),
            reference_number="REF001",
            customer_id=cls.contact,
            customer_name="Test Customer",
            currency_id="USD",
            currency_code="USD",
            currency_symbol="$",
            exchange_rate=1.0,
            is_viewed_by_client=False,
            is_inclusive_tax=False,
            product_name=cls.item,
            sub_total=100.00,
            total=100.00,
            payment_made=0.00,
            payment_drawn=0.00,
            balance=100.00,
            allow_partial_payments=True,
            price_precision=2,
            is_emailed=False,
            created_time=date.today(),
            last_modified_time=date.today(),
            created_by_id="admin",
            attachment_name="invoice.pdf",
            can_send_in_mail=False,
            invoice_url="https://example.com/invoice"
        )

    def test_retainer_invoice_creation(self):
        retainer_invoice = RetainerInvoice.objects.get(retainerinvoice_id="INV001")
        self.assertEqual(retainer_invoice.retainerinvoice_number, "INV001")
        self.assertEqual(retainer_invoice.status, "draft")
        self.assertTrue(retainer_invoice.is_pre_gst)
        self.assertEqual(retainer_invoice.place_of_supply, "Test Place")
        self.assertEqual(retainer_invoice.project_id, self.project)
        self.assertEqual(retainer_invoice.reference_number, "REF001")
        self.assertEqual(retainer_invoice.customer_id, self.contact)
        self.assertEqual(retainer_invoice.customer_name, "Test Customer")
        self.assertEqual(retainer_invoice.currency_id, "USD")
        self.assertEqual(retainer_invoice.currency_code, "USD")
        self.assertEqual(retainer_invoice.currency_symbol, "$")
        self.assertEqual(retainer_invoice.exchange_rate, 1.0)
        self.assertFalse(retainer_invoice.is_viewed_by_client)
        self.assertFalse(retainer_invoice.is_inclusive_tax)
        self.assertEqual(retainer_invoice.product_name, self.item)
        self.assertEqual(retainer_invoice.sub_total, 100.00)
        self.assertEqual(retainer_invoice.total, 100.00)
        self.assertEqual(retainer_invoice.payment_made, 0.00)
        self.assertEqual(retainer_invoice.payment_drawn, 0.00)
        self.assertEqual(retainer_invoice.balance, 100.00)
        self.assertTrue(retainer_invoice.allow_partial_payments)
        self.assertEqual(retainer_invoice.price_precision, 2)
        self.assertFalse(retainer_invoice.is_emailed)
        self.assertEqual(retainer_invoice.created_by_id, "admin")
        self.assertEqual(retainer_invoice.attachment_name, "invoice.pdf")
        self.assertFalse(retainer_invoice.can_send_in_mail)
        self.assertEqual(retainer_invoice.invoice_url, "https://example.com/invoice")


class ModelTestCase(TestCase):
    def setUp(self):
        # Create Item instance for testing
        self.item = Item.objects.create(
            item_id='123',
            item_type='product',
            name='Test Item',
            rate=10.00,
            sku='SKU123',
            product_type='Test Product',
            selling_price=15.00,
            sales_description='Test Sales Description',
            default_sales_tax_rate=5.00,
            cost_price=5.00,
            purchase_description='Test Purchase Description',
            purchase_information=True
        )

        # Create SalesReturn instance for testing
        self.sales_return = SalesReturn.objects.create(
            salesreturn_id=1,
            salesreturn_number='SRN001',
            date=date.today(),
            reason='Test Reason',
            salesreturn_status='Pending',
            salesorder_id=123,
            salesorder_number='SO123',
            line_items=self.item
        )

    def test_sales_return_creation(self):
        self.assertEqual(self.sales_return.salesreturn_id, 1)
        self.assertEqual(self.sales_return.salesreturn_number, 'SRN001')
        self.assertEqual(self.sales_return.reason, 'Test Reason')
        self.assertEqual(self.sales_return.salesreturn_status, 'Pending')
        self.assertEqual(self.sales_return.salesorder_id, 123)
        self.assertEqual(self.sales_return.salesorder_number, 'SO123')
        self.assertEqual(self.sales_return.line_items, self.item)

    def test_item_creation(self):
        self.assertEqual(self.item.item_id, '123')
        self.assertEqual(self.item.item_type, 'product')
        self.assertEqual(self.item.name, 'Test Item')
        self.assertEqual(self.item.rate, 10.00)
        self.assertEqual(self.item.sku, 'SKU123')
        self.assertEqual(self.item.product_type, 'Test Product')
        self.assertEqual(self.item.selling_price, 15.00)
        self.assertEqual(self.item.sales_description, 'Test Sales Description')
        self.assertEqual(self.item.default_sales_tax_rate, 5.00)
        self.assertEqual(self.item.cost_price, 5.00)
        self.assertEqual(self.item.purchase_description, 'Test Purchase Description')
        self.assertTrue(self.item.purchase_information)