from rest_framework import viewsets
from rest_framework.decorators import action
from rest_framework.response import Response
from .models import PurchaseOrder,Bill,PurchaseReceive,Package,SalesReturn,Shipment,RetainerInvoice
from .serializers import PurchaseOrderSerializer,BillSerializer,PurchaseReceiveSerializer,PackageSerializer,SalesReturnSerializer,ShipmentSerializer,RetainerInvoiceSerializer

class RetainerInvoiceViewSet(viewsets.ModelViewSet):
    queryset = RetainerInvoice.objects.all()
    serializer_class = RetainerInvoiceSerializer

    @action(detail=True, methods=['get'])
    def calculate_balance(self, request, pk=None):
        """
        Custom action to calculate the balance for a specific retainer invoice.
        """
        retainer_invoice = self.get_object()
        balance = retainer_invoice.calculate_balance()
        return Response({'balance': balance})

    @action(detail=True, methods=['get'])
    def is_overdue(self, request, pk=None):
        """
        Custom action to check if a specific retainer invoice is overdue.
        """
        retainer_invoice = self.get_object()
        overdue = retainer_invoice.is_overdue()
        return Response({'overdue': overdue})

    @action(detail=True, methods=['get'])
    def is_fully_paid(self, request, pk=None):
        """
        Custom action to check if a specific retainer invoice is fully paid.
        """
        retainer_invoice = self.get_object()
        fully_paid = retainer_invoice.is_fully_paid()
        return Response({'fully_paid': fully_paid})

class PurchaseOrderViewSet(viewsets.ModelViewSet):
    queryset = PurchaseOrder.objects.all()
    serializer_class = PurchaseOrderSerializer

    @action(detail=True, methods=['get'])
    def calculate_line_total(self, request, pk=None):
        """
        Custom action to calculate the line total for a specific purchase order line.
        """
        purchase_order = self.get_object()
        line_total = purchase_order.calculate_line_total()
        return Response({'line_total': line_total})

    @action(detail=True, methods=['get'])
    def calculate_discount_amount(self, request, pk=None):
        """
        Custom action to calculate the discount amount for a specific purchase order line.
        """
        purchase_order = self.get_object()
        discount_amount = purchase_order.calculate_discount_amount()
        return Response({'discount_amount': discount_amount})

    @action(detail=True, methods=['get'])
    def calculate_tax_amount(self, request, pk=None):
        """
        Custom action to calculate the tax amount for a specific purchase order line.
        """
        purchase_order = self.get_object()
        tax_amount = purchase_order.calculate_tax_amount()
        return Response({'tax_amount': tax_amount})

    @action(detail=True, methods=['get'])
    def calculate_total_amount(self, request, pk=None):
        """
        Custom action to calculate the total amount for a specific purchase order line.
        """
        purchase_order = self.get_object()
        total_amount = purchase_order.calculate_total_amount()
        return Response({'total_amount': total_amount})

class BillViewSet(viewsets.ModelViewSet):
    queryset = Bill.objects.all()
    serializer_class = BillSerializer

    @action(detail=True, methods=['get'])
    def calculate_line_total(self, request, pk=None):
        """
        Custom action to calculate the line total for a specific bill line.
        """
        bill = self.get_object()
        line_total = bill.calculate_line_total()
        return Response({'line_total': line_total})

    @action(detail=True, methods=['get'])
    def calculate_tax_amount(self, request, pk=None):
        """
        Custom action to calculate the tax amount for a specific bill line.
        """
        bill = self.get_object()
        tax_amount = bill.calculate_tax_amount()
        return Response({'tax_amount': tax_amount})

    @action(detail=True, methods=['get'])
    def calculate_total_amount(self, request, pk=None):
        """
        Custom action to calculate the total amount for a specific bill line.
        """
        bill = self.get_object()
        total_amount = bill.calculate_total_amount()
        return Response({'total_amount': total_amount})
    
class PurchaseReceiveViewSet(viewsets.ModelViewSet):
    queryset = PurchaseReceive.objects.all()
    serializer_class = PurchaseReceiveSerializer

    @action(detail=True, methods=['get'])
    def line_items_total_quantity(self, request, pk=None):
        """
        Custom action to calculate and return the total quantity of line items for a specific purchase receive.
        """
        purchase_receive = self.get_object()
        total_quantity = purchase_receive.get_line_items_total_quantity()
        return Response({'line_items_total_quantity': total_quantity})

    @action(detail=True, methods=['get'])
    def line_items_total_amount(self, request, pk=None):
        """
        Custom action to calculate and return the total amount of line items for a specific purchase receive.
        """
        purchase_receive = self.get_object()
        total_amount = purchase_receive.get_line_items_total_amount()
        return Response({'line_items_total_amount': total_amount})

    @action(detail=True, methods=['get'])
    def line_items_average_price(self, request, pk=None):
        """
        Custom action to calculate and return the average price of line items for a specific purchase receive.
        """
        purchase_receive = self.get_object()
        average_price = purchase_receive.get_line_items_average_price()
        return Response({'line_items_average_price': average_price})
    
class PackageViewSet(viewsets.ModelViewSet):
    queryset = Package.objects.all()
    serializer_class = PackageSerializer

    @action(detail=True, methods=['get'])
    def total_line_items(self, request, pk=None):
        """
        Calculate and return the total number of line items in the package.
        """
        package = self.get_object()
        total_line_items = package.calculate_total_line_items()
        return Response({'total_line_items': total_line_items})

    @action(detail=True, methods=['get'])
    def package_age(self, request, pk=None):
        """
        Calculate and return the age of the package in days.
        """
        package = self.get_object()
        package_age = package.calculate_age()
        return Response({'package_age': package_age})

    @action(detail=True, methods=['get'])
    def sales_order_discount(self, request, pk=None):
        """
        Calculate and return the total discount applied from associated sales orders.
        """
        package = self.get_object()
        sales_order_discount = package.calculate_sales_order_discount()
        return Response({'sales_order_discount': sales_order_discount})
    
class ShipmentViewSet(viewsets.ModelViewSet):
    queryset = Shipment.objects.all()
    serializer_class = ShipmentSerializer

    def get_total_price(self, request, pk=None):
        """
        Custom action to retrieve the total price of a specific shipment.
        """
        shipment = self.get_object()
        total_price = shipment.calculate_total_price()
        return Response({'total_price': total_price})

    def get_delivery_days_left(self, request, pk=None):
        """
        Custom action to retrieve the number of days left for delivery of a specific shipment.
        """
        shipment = self.get_object()
        delivery_days_left = shipment.calculate_delivery_days_left()
        return Response({'delivery_days_left': delivery_days_left})

class SalesReturnViewSet(viewsets.ModelViewSet):
    queryset = SalesReturn.objects.all()
    serializer_class = SalesReturnSerializer

    def get_total_returned_items(self, request, pk=None):
        """
        Custom action to retrieve the total number of returned items for a specific sales return.
        """
        sales_return = self.get_object()
        total_returned_items = sales_return.calculate_total_returned_items()
        return Response({'total_returned_items': total_returned_items})