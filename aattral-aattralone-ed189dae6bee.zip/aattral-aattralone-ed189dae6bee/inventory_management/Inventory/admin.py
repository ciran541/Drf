# admin.py

from django.contrib import admin
from .models import Address, BillingAddress, ShippingAddress, Organization, SalesPerson, PaymentTerms, ContactPerson, Contacts, Unit, Attribute, AttributeOption, Item, ItemGroup, CompositeItem, InventoryAdjustment, PriceBookItem, PriceBook, Warehouse, Picklist, PickedItem

@admin.register(Address)
class AddressAdmin(admin.ModelAdmin):
    pass

@admin.register(BillingAddress)
class BillingAddressAdmin(admin.ModelAdmin):
    pass

@admin.register(ShippingAddress)
class ShippingAddressAdmin(admin.ModelAdmin):
    pass

@admin.register(Organization)
class OrganizationAdmin(admin.ModelAdmin):
    pass

@admin.register(SalesPerson)
class SalesPersonAdmin(admin.ModelAdmin):
    pass

@admin.register(PaymentTerms)
class PaymentTermsAdmin(admin.ModelAdmin):
    pass

@admin.register(ContactPerson)
class ContactPersonAdmin(admin.ModelAdmin):
    pass

@admin.register(Contacts)
class ContactsAdmin(admin.ModelAdmin):
    pass

@admin.register(Unit)
class UnitAdmin(admin.ModelAdmin):
    pass

@admin.register(Attribute)
class AttributeAdmin(admin.ModelAdmin):
    pass

@admin.register(AttributeOption)
class AttributeOptionAdmin(admin.ModelAdmin):
    pass

@admin.register(Item)
class ItemAdmin(admin.ModelAdmin):
    pass

@admin.register(ItemGroup)
class ItemGroupAdmin(admin.ModelAdmin):
    pass

@admin.register(CompositeItem)
class CompositeItemAdmin(admin.ModelAdmin):
    pass

@admin.register(InventoryAdjustment)
class InventoryAdjustmentAdmin(admin.ModelAdmin):
    pass

@admin.register(PriceBookItem)
class PriceBookItemAdmin(admin.ModelAdmin):
    pass

@admin.register(PriceBook)
class PriceBookAdmin(admin.ModelAdmin):
    pass

@admin.register(Warehouse)
class WarehouseAdmin(admin.ModelAdmin):
    pass

@admin.register(Picklist)
class PicklistAdmin(admin.ModelAdmin):
    pass

@admin.register(PickedItem)
class PickedItemAdmin(admin.ModelAdmin):
    pass

