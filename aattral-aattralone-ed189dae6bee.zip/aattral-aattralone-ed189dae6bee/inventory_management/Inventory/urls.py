from django.urls import path, include
from rest_framework.routers import DefaultRouter
from .views import (
    AddressViewSet, BillingAddressViewSet, ShippingAddressViewSet,
    OrganizationViewSet, SalesPersonViewSet, PaymentTermsViewSet,
    ContactPersonViewSet, ContactsViewSet, UnitViewSet,
    AttributeOptionViewSet, AttributeViewSet, ItemViewSet,
    ItemGroupViewSet, CompositeItemViewSet, InventoryAdjustmentViewSet,
    PriceBookItemViewSet, PriceBookViewSet, WarehouseViewSet,
    PicklistViewSet, PickedItemViewSet
)

router = DefaultRouter()
router.register(r'addresses', AddressViewSet)
router.register(r'billingaddresses', BillingAddressViewSet)
router.register(r'shippingaddresses', ShippingAddressViewSet)
router.register(r'organizations', OrganizationViewSet)
router.register(r'salespersons', SalesPersonViewSet)
router.register(r'paymentterms', PaymentTermsViewSet)
router.register(r'contactpersons', ContactPersonViewSet)
router.register(r'contacts', ContactsViewSet)
router.register(r'units', UnitViewSet)
router.register(r'attributeoptions', AttributeOptionViewSet)
router.register(r'attributes', AttributeViewSet)
router.register(r'items', ItemViewSet)
router.register(r'itemgroups', ItemGroupViewSet)
router.register(r'compositeitems', CompositeItemViewSet)
router.register(r'inventoryadjustments', InventoryAdjustmentViewSet)
router.register(r'pricebookitems', PriceBookItemViewSet)
router.register(r'pricebooks', PriceBookViewSet)
router.register(r'warehouses', WarehouseViewSet)
router.register(r'picklists', PicklistViewSet)
router.register(r'pickeditems', PickedItemViewSet)

urlpatterns = [
    path('', include(router.urls)),
]


