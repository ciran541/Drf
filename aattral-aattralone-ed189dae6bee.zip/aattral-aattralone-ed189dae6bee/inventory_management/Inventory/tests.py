from django.test import TestCase
from .models import ContactPerson,Contacts,BillingAddress,ShippingAddress,Address,ItemGroup,Item,Unit
from finance.Tax.models import TaxExemption
from finance.Accountant.models import ChartOfAccounts
class ContactPersonTestCase(TestCase):

    def setUp(self):
        self.contact_person = ContactPerson.objects.create(
            salutation='Mr',
            first_name='John',
            last_name='Doe',
            email='john.doe@example.com',
            work_phone='1234567890',
            mobile='9876543210',
            designation='Manager',
            department='Sales',
            skype='john_doe_skype',
            is_primary_contact=True,
            enable_portal=True,
        )

    def test_contact_person_creation(self):
        """Test contact person creation"""
        self.assertEqual(self.contact_person.salutation, 'Mr')
        self.assertEqual(self.contact_person.first_name, 'John')
        self.assertEqual(self.contact_person.last_name, 'Doe')
        self.assertEqual(self.contact_person.email, 'john.doe@example.com')
        self.assertEqual(self.contact_person.work_phone, '1234567890')
        self.assertEqual(self.contact_person.mobile, '9876543210')
        self.assertEqual(self.contact_person.designation, 'Manager')
        self.assertEqual(self.contact_person.department, 'Sales')
        self.assertEqual(self.contact_person.skype, 'john_doe_skype')
        self.assertTrue(self.contact_person.is_primary_contact)
        self.assertTrue(self.contact_person.enable_portal)

class ContactsTestCase(TestCase):

    def setUp(self):
        # Create an Address instance
        self.address = Address.objects.create(
            attention='Attention',
            address_street1='123 Main St',
            city='City',
            state='State',
            zip_code='12345',
            phone='1234567890',
            fax_number='1234567890'
        )
        # Create BillingAddress and ShippingAddress instances
        self.billing_address = BillingAddress.objects.create(address=self.address)
        self.shipping_address = ShippingAddress.objects.create(address=self.address)
        # Create Contacts instance
        self.contact = Contacts.objects.create(
            contact_type='Customer',
            customer_sub_type='Business',
            salutation='Mr',
            first_name='John',
            last_name='Doe',
            company_name='ABC Company',
            customer_display_name='John Doe',
            customer_email='john@example.com',
            customer_phone='1234567890',
            attention='Attention',
            Billing_address=self.billing_address,
            Shipping_address=self.shipping_address,
            gst_treatment='GST Treatment',
            pan='123ABC', 
            place_of_supply='Place of Supply',
            gst_no='GST123',
            vat_treatment='VAT Treatment',
            tax_treatment='Tax Treatment',
            website='http://example.com',
            taxable=True,
            tax_exempt=False,
            currency='USD',
            opening_balance=1000.00,
            status='Active',
            payment_reminder_enabled=True,
            enable_portal=True,
            portal_access_allowed=True,
            portal_language='en',
            # Add other fields...
        )

    def test_contact_creation(self):
        """Test contact creation"""
        self.assertEqual(self.contact.contact_type, 'Customer')
        self.assertEqual(self.contact.customer_sub_type, 'Business')
        self.assertEqual(self.contact.salutation, 'Mr')
        self.assertEqual(self.contact.first_name, 'John')
        self.assertEqual(self.contact.last_name, 'Doe')
        self.assertEqual(self.contact.company_name, 'ABC Company')
        self.assertEqual(self.contact.customer_display_name, 'John Doe')
        self.assertEqual(self.contact.customer_email, 'john@example.com')
        self.assertEqual(self.contact.customer_phone, '1234567890')
        self.assertEqual(self.contact.attention, 'Attention')
        self.assertEqual(self.contact.gst_treatment, 'GST Treatment')
        self.assertEqual(self.contact.pan, '123ABC')
        self.assertEqual(self.contact.place_of_supply, 'Place of Supply')
        self.assertEqual(self.contact.gst_no, 'GST123')
        self.assertEqual(self.contact.vat_treatment, 'VAT Treatment')
        self.assertEqual(self.contact.tax_treatment, 'Tax Treatment')
        self.assertEqual(self.contact.website, 'http://example.com')
        self.assertTrue(self.contact.taxable)
        self.assertFalse(self.contact.tax_exempt)
        self.assertEqual(self.contact.currency, 'USD')
        self.assertEqual(self.contact.opening_balance, 1000.00)
        self.assertEqual(self.contact.status, 'Active')
        self.assertTrue(self.contact.payment_reminder_enabled)
        self.assertTrue(self.contact.enable_portal)
        self.assertTrue(self.contact.portal_access_allowed)
        self.assertEqual(self.contact.portal_language, 'en')

class ItemTestCase(TestCase):

    @classmethod
    def setUpTestData(cls):
        cls.unit = Unit.objects.create(unit_code='UN001', unit_name='Piece')
        cls.sales_account = ChartOfAccounts.objects.create(
            AccountCode='SA001',
            AccountName='Sales Account',
            AccountType='Sales Revenue'
        )
        cls.purchase_account = ChartOfAccounts.objects.create(
            AccountCode='PA001',
            AccountName='Purchase Account',
            AccountType='Cost of Goods Sold (COGS)'
        )
        cls.tax_exemption = TaxExemption.objects.create(reason='Test Reason', description='Test Description')
        cls.item_group = ItemGroup.objects.create(
            item_type='product',
            group_name='Test Group',
            brand='Test Brand',
            manufacturer='Test Manufacturer',
            unit=cls.unit,
            description='Test Description',
            tax_id=1,
            attribute_name1='Attribute 1',
            status='active'
        )

    def test_item_creation(self):
        item = Item.objects.create(
            item_group=self.item_group,
            item_id='IT001',
            item_type='product',
            name='Test Item',
            description='Test Description',
            rate=10.00,
            unit=self.unit,
            tax_id='T001',
            purchase_tax_rule_id='PTR001',
            sales_tax_rule_id='STR001',
            tax_name='Test Tax',
            hsn_or_sac='HSN001',
            sat_item_key_code='SAT001',
            unitkey_code='UK001',
            tax_percentage=5.00,
            tax_type='GST',
            sku='SKU001',
            product_type='Test Product',
            tax_exemption=self.tax_exemption,
            sales_information=True,
            selling_price=20.00,
            selling_currency='USD',
            sales_account=self.sales_account,
            sales_description='Sales Description',
            default_sales_tax_rate=5.00,
            purchase_information=True,
            cost_price=15.00,
            cost_currency='USD',
            purchase_account=self.purchase_account,
            purchase_description='Purchase Description',
            preferred_vendor='Preferred Vendor',
        )
        self.assertEqual(item.name, 'Test Item')
        self.assertEqual(item.item_type, 'product')
        self.assertEqual(item.unit, self.unit)
        self.assertEqual(item.tax_exemption, self.tax_exemption)
        self.assertTrue(item.sales_information)
        self.assertEqual(item.selling_price, 20.00)
        self.assertEqual(item.selling_currency, 'USD')
        self.assertEqual(item.sales_account, self.sales_account)
        self.assertEqual(item.sales_description, 'Sales Description')
        self.assertEqual(item.default_sales_tax_rate, 5.00)
        self.assertTrue(item.purchase_information)
        self.assertEqual(item.cost_price, 15.00)
        self.assertEqual(item.cost_currency, 'USD')
        self.assertEqual(item.purchase_account, self.purchase_account)
        self.assertEqual(item.purchase_description, 'Purchase Description')
        self.assertEqual(item.preferred_vendor, 'Preferred Vendor')
