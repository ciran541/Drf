# viewsets.py
from rest_framework import viewsets
from rest_framework.decorators import action
from rest_framework.response import Response
from .models import (
    Address, BillingAddress, ShippingAddress, Organization, SalesPerson,
    PaymentTerms, ContactPerson, Contacts, Unit, AttributeOption, Attribute, Item,
    ItemGroup, CompositeItem, InventoryAdjustment, PriceBookItem, PriceBook,
    Warehouse, Picklist, PickedItem
)
from .serializers import (
    AddressSerializer, BillingAddressSerializer, ShippingAddressSerializer,
    OrganizationSerializer, SalesPersonSerializer, PaymentTermsSerializer,
    ContactPersonSerializer, ContactsSerializer, UnitSerializer,
    AttributeOptionSerializer, AttributeSerializer, ItemSerializer,
    ItemGroupSerializer, CompositeItemSerializer, InventoryAdjustmentSerializer,
    PriceBookItemSerializer, PriceBookSerializer, WarehouseSerializer,
    PicklistSerializer, PickedItemSerializer
)

class AddressViewSet(viewsets.ModelViewSet):
    queryset = Address.objects.all()
    serializer_class = AddressSerializer

class BillingAddressViewSet(viewsets.ModelViewSet):
    queryset = BillingAddress.objects.all()
    serializer_class = BillingAddressSerializer

class ShippingAddressViewSet(viewsets.ModelViewSet):
    queryset = ShippingAddress.objects.all()
    serializer_class = ShippingAddressSerializer

class OrganizationViewSet(viewsets.ModelViewSet):
    queryset = Organization.objects.all()
    serializer_class = OrganizationSerializer

    @action(detail=False, methods=['get'])
    def search(self, request):
        query_params = request.query_params
        name = query_params.get('name')

        organizations = Organization.objects.all()
        if name:
            organizations = organizations.filter(name__icontains=name)

        serializer = OrganizationSerializer(organizations, many=True)
        return Response(serializer.data)

class SalesPersonViewSet(viewsets.ModelViewSet):
    queryset = SalesPerson.objects.all()
    serializer_class = SalesPersonSerializer

    @action(detail=False, methods=['get'])
    def search(self, request):
        query_params = request.query_params
        name = query_params.get('name')

        sales_people = SalesPerson.objects.all()
        if name:
            sales_people = sales_people.filter(name__icontains=name)

        serializer = SalesPersonSerializer(sales_people, many=True)
        return Response(serializer.data)
    
class PaymentTermsViewSet(viewsets.ModelViewSet):
    queryset = PaymentTerms.objects.all()
    serializer_class = PaymentTermsSerializer

    @action(detail=False, methods=['get'])
    def search(self, request):
        query_params = request.query_params
        term = query_params.get('term')

        payment_terms = PaymentTerms.objects.all()
        if term:
            payment_terms = payment_terms.filter(term__icontains=term)

        serializer = PaymentTermsSerializer(payment_terms, many=True)
        return Response(serializer.data)

class ContactPersonViewSet(viewsets.ModelViewSet):
    queryset = ContactPerson.objects.all()
    serializer_class = ContactPersonSerializer

    @action(detail=False, methods=['get'])
    def search(self, request):
        query_params = request.query_params
        name = query_params.get('name')

        contact_persons = ContactPerson.objects.all()
        if name:
            contact_persons = contact_persons.filter(name__icontains=name)

        serializer = ContactPersonSerializer(contact_persons, many=True)
        return Response(serializer.data)

class ContactsViewSet(viewsets.ModelViewSet):
    queryset = Contacts.objects.all()
    serializer_class = ContactsSerializer

    @action(detail=False, methods=['get'])
    def search(self, request):
        query_params = request.query_params
        name = query_params.get('name')
        email = query_params.get('email')

        contacts = Contacts.objects.all()
        if name:
            contacts = contacts.filter(name__icontains=name)
        if email:
            contacts = contacts.filter(email__icontains=email)

        serializer = ContactsSerializer(contacts, many=True)
        return Response(serializer.data)

class UnitViewSet(viewsets.ModelViewSet):
    queryset = Unit.objects.all()
    serializer_class = UnitSerializer

class AttributeOptionViewSet(viewsets.ModelViewSet):
    queryset = AttributeOption.objects.all()
    serializer_class = AttributeOptionSerializer

class AttributeViewSet(viewsets.ModelViewSet):
    queryset = Attribute.objects.all()
    serializer_class = AttributeSerializer

class ItemViewSet(viewsets.ModelViewSet):
    queryset = Item.objects.all()
    serializer_class = ItemSerializer

    @action(detail=False, methods=['get'])
    def search(self, request):
        query_params = request.query_params
        name = query_params.get('name')

        items = Item.objects.all()
        if name:
            items = items.filter(name__icontains=name)

        serializer = ItemSerializer(items, many=True)
        return Response(serializer.data)


class ItemGroupViewSet(viewsets.ModelViewSet):
    queryset = ItemGroup.objects.all()
    serializer_class = ItemGroupSerializer

    @action(detail=False, methods=['get'])
    def search(self, request):
        query_params = request.query_params
        name = query_params.get('name')

        item_groups = ItemGroup.objects.all()
        if name:
            item_groups = item_groups.filter(name__icontains=name)

        serializer = ItemGroupSerializer(item_groups, many=True)
        return Response(serializer.data)

class CompositeItemViewSet(viewsets.ModelViewSet):
    queryset = CompositeItem.objects.all()
    serializer_class = CompositeItemSerializer

    @action(detail=False, methods=['get'])
    def search(self, request):
        query_params = request.query_params
        name = query_params.get('name')

        composite_items = CompositeItem.objects.all()
        if name:
            composite_items = composite_items.filter(name__icontains=name)

        serializer = CompositeItemSerializer(composite_items, many=True)
        return Response(serializer.data)

class InventoryAdjustmentViewSet(viewsets.ModelViewSet):
    queryset = InventoryAdjustment.objects.all()
    serializer_class = InventoryAdjustmentSerializer

class PriceBookItemViewSet(viewsets.ModelViewSet):
    queryset = PriceBookItem.objects.all()
    serializer_class = PriceBookItemSerializer

class PriceBookViewSet(viewsets.ModelViewSet):
    queryset = PriceBook.objects.all()
    serializer_class = PriceBookSerializer

class WarehouseViewSet(viewsets.ModelViewSet):
    queryset = Warehouse.objects.all()
    serializer_class = WarehouseSerializer

class PicklistViewSet(viewsets.ModelViewSet):
    queryset = Picklist.objects.all()
    serializer_class = PicklistSerializer

class PickedItemViewSet(viewsets.ModelViewSet):
    queryset = PickedItem.objects.all()
    serializer_class = PickedItemSerializer
