# serializers.py
from rest_framework import serializers
from .models import (
    Address, BillingAddress, ShippingAddress, Organization, SalesPerson,
    PaymentTerms, ContactPerson, Contacts, Unit, AttributeOption, Attribute, Item,
    ItemGroup, CompositeItem, InventoryAdjustment, PriceBookItem, PriceBook,
    Warehouse, Picklist, PickedItem
)

class AddressSerializer(serializers.ModelSerializer):
    class Meta:
        model = Address
        fields = '__all__'
        ref_name = 'InventoryAddress'

class BillingAddressSerializer(serializers.ModelSerializer):
    address = AddressSerializer()

    class Meta:
        model = BillingAddress
        fields = '__all__'
        ref_name = 'billinginventoy'

class ShippingAddressSerializer(serializers.ModelSerializer):
    address = AddressSerializer()

    class Meta:
        model = ShippingAddress
        fields = '__all__'
        ref_name = 'shippinginventory'

class OrganizationSerializer(serializers.ModelSerializer):
    address = AddressSerializer()

    class Meta:
        model = Organization
        fields = '__all__'
        ref_name = 'InventoryOrganization'

class SalesPersonSerializer(serializers.ModelSerializer):
    class Meta:
        model = SalesPerson
        fields = '__all__'
        ref_name = 'InventorySalesPerson'

class PaymentTermsSerializer(serializers.ModelSerializer):
    class Meta:
        model = PaymentTerms
        fields = '__all__'
        ref_name = 'InventoryPaymentTerms'

class ContactPersonSerializer(serializers.ModelSerializer):
    class Meta:
        model = ContactPerson
        fields = '__all__'
        ref_name = 'InventoryContactPerson'

class ContactsSerializer(serializers.ModelSerializer):
    Billing_address = BillingAddressSerializer()
    Shipping_address = ShippingAddressSerializer()
    contact_persons = ContactPersonSerializer(many=True)

    class Meta:
        model = Contacts
        fields = '__all__'


class UnitSerializer(serializers.ModelSerializer):
    class Meta:
        model = Unit
        fields = '__all__'
        ref_name = 'InventoryUnit'

class AttributeOptionSerializer(serializers.ModelSerializer):
    class Meta:
        model = AttributeOption
        fields = '__all__'

class AttributeSerializer(serializers.ModelSerializer):
    options = AttributeOptionSerializer(many=True)

    class Meta:
        model = Attribute
        fields = '__all__'

class ItemSerializer(serializers.ModelSerializer):
    unit = UnitSerializer()
    tax_exemption_reason = serializers.SerializerMethodField()

    class Meta:
        model = Item
        fields = '__all__'
        ref_name = 'InventoryItem'

    def get_tax_exemption_reason(self, obj):
        return obj.tax_exemption_reason.reason if obj.tax_exemption_reason else None

class ItemGroupSerializer(serializers.ModelSerializer):
    items = ItemSerializer(many=True)
    attributes = AttributeSerializer(many=True)

    class Meta:
        model = ItemGroup
        fields = '__all__'

class CompositeItemSerializer(serializers.ModelSerializer):
    mapped_items = ItemSerializer(many=True)

    class Meta:
        model = CompositeItem
        fields = '__all__'

class InventoryAdjustmentSerializer(serializers.ModelSerializer):
    mapped_items = ItemSerializer(many=True)

    class Meta:
        model = InventoryAdjustment
        fields = '__all__'

class PriceBookItemSerializer(serializers.ModelSerializer):
    item_id = ItemSerializer()

    class Meta:
        model = PriceBookItem
        fields = '__all__'

class PriceBookSerializer(serializers.ModelSerializer):
    price_book_items = PriceBookItemSerializer(many=True)

    class Meta:
        model = PriceBook
        fields = '__all__'

class WarehouseSerializer(serializers.ModelSerializer):
    class Meta:
        model = Warehouse
        fields = '__all__'

class PicklistSerializer(serializers.ModelSerializer):
    class Meta:
        model = Picklist
        fields = '__all__'

class PickedItemSerializer(serializers.ModelSerializer):
    item = ItemSerializer()

    class Meta:
        model = PickedItem
        fields = '__all__'
