from django.db import models
from Authentication.models import CustomUser
from django.core.exceptions import ValidationError
from finance.Tax.models import TaxExemption
from finance.Accountant.models import ChartOfAccounts
from finance.Tax.models import Tax
import pycountry
# from Hr.Timesheet.models import Country


# Common Models --

class Address(models.Model):
    attention = models.CharField(max_length=50, blank=True, null=True)
    # country = models.ForeignKey(Country, on_delete=models.SET_NULL, null=True, blank=True, related_name = 'inventory_address')
    address_street1 = models.TextField()
    address_street2 = models.TextField(blank=True, null=True)
    city = models.CharField(max_length=50,blank=True)
    state = models.CharField(max_length=50,blank=True)
    zip_code = models.CharField(max_length=20,blank=True)
    phone = models.CharField(max_length=20,blank=True)
    fax_number = models.CharField(max_length=20, blank=True, null=True)

    def __str__(self):
        return f"{self.attention}, {self.address_street1}, {self.city}, {self.state}, {self.zip_code}"

class BillingAddress(models.Model):
    address = models.ForeignKey(Address, on_delete=models.CASCADE,blank=True)

    def __str__(self):
        return f"Billing Address for {self.address.attention}"

class ShippingAddress(models.Model):
    address = models.ForeignKey(Address, on_delete=models.CASCADE,blank=True)

    def __str__(self):
        return f"Shipping Address for {self.address.attention}"

# for country in pycountry.countries:
#     Country.objects.get_or_create(
#         code=country.alpha_3,
#         name=country.name
#     )

class Organization(models.Model):
    organization_id = models.CharField(max_length=255, unique=True)
    name = models.CharField(max_length=255,blank=True)
    is_logo_uploaded = models.BooleanField(default=False,blank=True)
    is_default_org = models.BooleanField(default=False,blank=True)
    user_role = models.CharField(max_length=255,blank=True)
    account_created_date = models.DateField(blank=True)
    time_zone = models.CharField(max_length=255,blank=True)
    language_code = models.CharField(max_length=10,blank=True)
    date_format = models.CharField(max_length=255,blank=True)
    field_separator = models.CharField(max_length=1,blank=True)
    fiscal_year_start_month = models.IntegerField(blank=True)
    tax_group_enabled = models.BooleanField(default=False)
    user_status = models.CharField(max_length=255,blank=True)
    contact_name = models.CharField(max_length=255,blank=True)
    industry_type = models.CharField(max_length=255,blank=True)
    address = models.ForeignKey(Address, related_name = 'Organization_address', on_delete=models.CASCADE)

class SalesPerson(models.Model):    # User/admin can add Salesperson ....
    name = models.CharField(max_length=100)
    email = models.EmailField(blank=True)
    phone = models.CharField(max_length=20,blank=True)

    def __str__(self):
        return self.name

class PaymentTerms(models.Model):   # User can add Payments terms For Example - Due on receipts... and then can use in forms where its needs .....
    name = models.CharField(max_length=50)
    description = models.TextField(blank=True, null=True)

    def __str__(self):
        return self.name

class ContactPerson(models.Model):
    MR = 'Mr'
    MRS = 'Mrs'
    MISS = 'Miss'
    MS = 'Ms'
    DR = 'Dr'
    REV = 'Rev'

    SALUTATION_CHOICES = [
        (MR, 'Mr'),
        (MRS, 'Mrs'),
        (MISS, 'Miss'),
        (MS, 'Ms'),
        (DR, 'Dr'),
        (REV, 'Rev'),
    ]
    
    contact_person_id = models.AutoField(primary_key=True)
    salutation = models.CharField(max_length=10, choices=SALUTATION_CHOICES, blank=True, null=True)
    first_name = models.CharField(max_length=100,blank=True)
    last_name = models.CharField(max_length=100,blank=True)
    email = models.EmailField()
    work_phone = models.CharField(max_length=20,blank=True)
    mobile = models.CharField(max_length=20,blank=True)
    designation = models.CharField(max_length=50, blank=True, null=True)
    department = models.CharField(max_length=50, blank=True, null=True)
    skype = models.CharField(max_length=100, blank=True, null=True)
    is_primary_contact = models.BooleanField(default=False,blank=True)
    enable_portal = models.BooleanField(default=False,blank=True)
    
    def __str__(self):
        return f"{self.first_name} {self.last_name}"
    
#  Model for Customer/Vendor ---

class Contacts(models.Model):
    MR = 'Mr'
    MRS = 'Mrs'
    MISS = 'Miss'
    MS = 'Ms'
    DR = 'Dr'
    REV = 'Rev'

    SALUTATION_CHOICES = [
        (MR, 'Mr'),
        (MRS, 'Mrs'),
        (MISS, 'Miss'),
        (MS, 'Ms'),
        (DR, 'Dr'),
        (REV, 'Rev'),
    ]
    contact_id = models.AutoField(primary_key=True)
    contact_type = models.CharField(max_length=20, choices=[('Customer', 'Customer'), ('Vendor', 'Vendor')])
    customer_sub_type = models.CharField(max_length=20, choices=[('Business', 'Business'), ('Individual', 'Individual')])
    salutation = models.CharField(max_length=10, choices=SALUTATION_CHOICES, blank=True, null=True)
    first_name = models.CharField(max_length=50,blank=True)
    last_name = models.CharField(max_length=50,blank=True)
    company_name = models.CharField(max_length=100, blank=True, null=True)
    customer_display_name = models.CharField(max_length=100, blank=True, null=True)
    customer_email = models.EmailField()
    customer_phone = models.CharField(max_length=20,blank=True)

    # Billing & Shipping Address
    attention = models.CharField(max_length=50, blank=True, null=True)
    Billing_address = models.ForeignKey(BillingAddress, on_delete=models.CASCADE,blank=True)
    Shipping_address = models.ForeignKey(ShippingAddress, on_delete=models.CASCADE,blank=True)

    # Contact Persons
    contact_persons = models.ManyToManyField(ContactPerson, blank=True)

    # Other Details
    custom_fields = models.TextField(blank=True, null=True)
    reporting_tags = models.CharField(max_length=100, blank=True, null=True)
    remarks = models.TextField(blank=True, null=True)
    gst_treatment = models.CharField(max_length=50, blank=True, null=True)
    pan = models.CharField(max_length=15, blank=True, null=True)
    place_of_supply = models.CharField(max_length=100, blank=True, null=True)
    gst_no = models.CharField(max_length=15, blank=True, null=True)
    vat_treatment = models.CharField(max_length=20, blank=True, null=True)
    tax_treatment = models.CharField(max_length=20, blank=True, null=True)
    website = models.URLField(blank=True, null=True)
    # Tax Preferences
    taxable = models.BooleanField(default=True,blank=True)
    tax_exempt = models.BooleanField(default=False,blank=True)
    currency = models.CharField(max_length=3, default='INR')

    # Financial Information
    opening_balance = models.DecimalField(max_digits=10, decimal_places=2, default=0.00,blank=True)
    payment_terms = models.ForeignKey(PaymentTerms, on_delete=models.SET_NULL, null=True, blank=True)
    price_list = models.CharField(max_length=50, blank=True, null=True)

    # Sales Person
    sales_person = models.ForeignKey(SalesPerson, on_delete=models.SET_NULL, null=True, blank=True)

    outstanding_receivable_amount = models.IntegerField(blank=True, null=True)
    outstanding_receivable_amount_bcy = models.IntegerField(blank=True, null=True)
    unused_credits_receivable_amount = models.IntegerField(blank=True, null=True)
    unused_credits_receivable_amount_bcy = models.IntegerField(blank=True, null=True)
    status = models.CharField(max_length=50, blank=True, null=True)
    payment_reminder_enabled = models.BooleanField(default=False,blank=True)
    custom_fields = models.TextField(blank=True, null=True)

    # Portal Settings
    enable_portal = models.BooleanField(default=False,blank=True)
    portal_access_allowed = models.BooleanField(default=False,blank=True)
    portal_language = models.CharField(max_length=10, blank=True, null=True)

    created_time = models.DateTimeField(auto_now_add=True)
    last_modified_time = models.DateTimeField(auto_now=True)

    def __str__(self):
        return self.customer_display_name or f"{self.first_name} {self.last_name}" 

# Items # 

class Unit(models.Model):
    unit_code = models.CharField(max_length=20, primary_key=True)
    unit_name = models.CharField(max_length=50)

    def __str__(self):
        return self.unit_name
    
class AttributeOption(models.Model):
    name = models.CharField(max_length=255)

class Attribute(models.Model):
    name = models.CharField(max_length=255)
    #options = models.ManyToManyField(AttributeOption)

class Item(models.Model):
    ITEM_TYPES = [
        ('product', 'Product'),
        ('service', 'Service'),
        ('bundle', 'Bundle'),
    ]

    STATUS_CHOICES = [
        ('active', 'Active'),
        ('inactive', 'Inactive'),
    ]
    item_group = models.ForeignKey('ItemGroup',on_delete=models.CASCADE,blank=True,related_name = 'Inventory_item_itemgroup')
    item_id = models.CharField(max_length=20, primary_key=True)
    item_type = models.CharField(max_length=20, choices=ITEM_TYPES)
    name = models.CharField(max_length=100)
    status = models.CharField(max_length=10, choices=STATUS_CHOICES, default='active')
    description = models.TextField(max_length=2000, blank=True, null=True)
    rate = models.DecimalField(max_digits=10, decimal_places=2)
    unit = models.ForeignKey(Unit, on_delete=models.CASCADE, blank=True, null=True)
    tax_id = models.CharField(max_length=20, blank=True, null=True)
    purchase_tax_rule_id = models.CharField(max_length=20, blank=True, null=True)
    sales_tax_rule_id = models.CharField(max_length=20, blank=True, null=True)
    tax_name = models.CharField(max_length=50, blank=True, null=True)
    hsn_or_sac = models.CharField(max_length=20, blank=True, null=True)
    sat_item_key_code = models.CharField(max_length=20, blank=True, null=True)
    unitkey_code = models.CharField(max_length=20, blank=True, null=True)
    tax_percentage = models.DecimalField(max_digits=5, decimal_places=2, blank=True, null=True)
    tax_type = models.CharField(max_length=20, blank=True, null=True)
    sku = models.CharField(max_length=50, unique=True)
    product_type = models.CharField(max_length=20)
    tax_exemption = models.BooleanField(default=False)
    tax_exemption_reason= models.ForeignKey(TaxExemption, on_delete=models.CASCADE,blank=True, null=True,related_name = 'Inventory_tax_exemption')

    # Sales Information
    sales_information = models.BooleanField(default=False)
    selling_price = models.DecimalField(max_digits=10, decimal_places=2, blank=True, null=True)
    selling_currency = models.CharField(max_length=3, default='INR')
    sales_account = models.ForeignKey(ChartOfAccounts, related_name = 'Inventory_COA',  on_delete=models.CASCADE)
    sales_description = models.TextField(max_length=2000, blank=True, null=True)
    default_sales_tax_rate = models.DecimalField(max_digits=5, decimal_places=2, blank=True, null=True)

    # Purchase Information
    purchase_information = models.BooleanField(default=False)
    cost_price = models.DecimalField(max_digits=10, decimal_places=2, blank=True, null=True)
    cost_currency = models.CharField(max_length=3, default='INR')
    purchase_account = models.ForeignKey(ChartOfAccounts, related_name = 'Inventory_COA_purchase',on_delete=models.CASCADE)
    purchase_description = models.TextField(max_length=2000, blank=True, null=True)
    preferred_vendor = models.CharField(max_length=50, blank=True, null=True) # Need To refer parent Vendor Table once we created ...
    

    def __str__(self):
        return self.name

    def clean(self):
        # Call the super clean method to ensure the model's built-in validation is also performed
        super().clean()
        
        # Custom validation
        errors = {}

        # Example custom validation: Ensure opening stock is not negative
        if self.opening_stock < 0:
            errors['opening_stock'] = ValidationError("Opening stock cannot be negative.")

        # Example custom validation: Ensure current stock is not negative
        if self.current_stock < 0:
            errors['current_stock'] = ValidationError("Current stock cannot be negative.")

        # Raise validation errors if any
        if errors:
            raise ValidationError(errors)

# ItemGroup # 
    
class ItemGroup(models.Model):
    ITEM_TYPES = [
        ('product', 'Product'),
        ('service', 'Service'),
        ('bundle', 'Bundle'),
    ]

    STATUS_CHOICES = [
        ('active', 'Active'),
        ('inactive', 'Inactive'),
    ]
    item_type = models.CharField(max_length=20, choices=ITEM_TYPES)
    group_name = models.CharField(max_length=255)
    brand = models.CharField(max_length=255)
    manufacturer = models.CharField(max_length=255)
    unit = models.CharField(max_length=50)
    description = models.TextField()
    tax_id = models.PositiveIntegerField()
    attribute_name1 = models.CharField(max_length=255)
    items = models.ManyToManyField(Item)
    attributes = models.ManyToManyField(Attribute)
    status = models.CharField(max_length=10, choices=STATUS_CHOICES, default='active')
    
# Composite Items # 
    
class CompositeItem(models.Model):
    name = models.CharField(max_length=255, unique=True)
    unit = models.CharField(max_length=20, null=True, blank=True)
    tax_id = models.PositiveIntegerField(null=True, blank=True)
    description = models.TextField(null=True, blank=True)
    purchase_account_id = models.PositiveIntegerField(null=True, blank=True)
    inventory_account_id = models.PositiveIntegerField(null=True, blank=True)
    status = models.CharField(max_length=10, choices=[
        ('active', 'Active'),
        ('inactive', 'Inactive'),
    ], default='active')
    is_combo_product = models.BooleanField(default=True)
    item_type = models.CharField(max_length=20, choices=[
        ('inventory', 'Inventory'),
        # Add more choices as needed
    ], default='inventory')
    rate = models.DecimalField(max_digits=10, decimal_places=2, null=True, blank=True)
    purchase_rate = models.DecimalField(max_digits=10, decimal_places=2, null=True, blank=True)
    reorder_level = models.PositiveIntegerField(null=True, blank=True)
    initial_stock = models.PositiveIntegerField(null=True, blank=True)
    initial_stock_rate = models.DecimalField(max_digits=10, decimal_places=2, null=True, blank=True)
    vendor_id = models.PositiveIntegerField(null=True, blank=True)
    vendor_name = models.CharField(max_length=255, null=True, blank=True)
    stock_on_hand = models.PositiveIntegerField(null=True, blank=True)
    asset_value = models.DecimalField(max_digits=5, decimal_places=2, null=True, blank=True)
    available_stock = models.PositiveIntegerField(null=True, blank=True)
    actual_available_stock = models.PositiveIntegerField(null=True, blank=True)
    sku = models.CharField(max_length=50, null=True, blank=True)
    upc = models.PositiveIntegerField(null=True, blank=True)
    ean = models.PositiveIntegerField(null=True, blank=True)
    isbn = models.CharField(max_length=50, null=True, blank=True)
    part_number = models.CharField(max_length=50, null=True, blank=True)
    image_id = models.PositiveIntegerField(null=True, blank=True)
    image_name = models.CharField(max_length=255, null=True, blank=True)
    purchase_description = models.TextField(null=True, blank=True)
    hsn_or_sac = models.PositiveIntegerField(null=True, blank=True)
    
    # Custom Fields
    vat_id = models.CharField(max_length=50, null=True, blank=True, verbose_name="VAT ID")

    # Mapped Items
    mapped_items = models.ManyToManyField(Item, related_name='CompositeItemDetail')

    # Item Tax Preferences
    item_tax_preferences = models.ManyToManyField(Tax, related_name='CompositeItemTaxPreference')

    def __str__(self):
        return self.name
    
class InventoryAdjustment(models.Model):
    inventory_adjustment_id = models.PositiveIntegerField(unique=True)
    date = models.DateField()
    reason = models.CharField(max_length=255)
    reason_id = models.PositiveIntegerField()
    description = models.TextField()
    reference_number = models.CharField(max_length=255)
    adjustment_type = models.CharField(max_length=10, choices=[('quantity', 'Quantity'), ('value', 'Value')])
    total = models.DecimalField(max_digits=10, decimal_places=2)

    # Mapped Items
    mapped_items = models.ManyToManyField(Item, related_name='InventoryAdjustment_items')

class PriceBookItem(models.Model):
    item_id = models.ForeignKey(Item,on_delete=models.CASCADE )
    pricebook_rate = models.DecimalField(max_digits=10, decimal_places=2)
    pricebook_item_id = models.PositiveIntegerField()

class PriceBook(models.Model):
    currency_code = models.CharField(max_length=10)
    currency_id = models.CharField(max_length=20)
    decimal_place = models.IntegerField()
    description = models.TextField()
    is_default = models.BooleanField()
    is_increase = models.BooleanField()
    name = models.CharField(max_length=255)
    percentage = models.IntegerField()
    pricebook_id = models.PositiveIntegerField()
    pricebook_items = models.ManyToManyField(PriceBookItem, related_name='price_book_items')
    pricebook_type = models.CharField(max_length=20, choices=[('per_item', 'Per Item'), ('fixed_percentage', 'Fixed Percentage')])
    rounding_type = models.CharField(max_length=30, choices=[
        ('no_rounding', 'No Rounding'),
        ('round_to_dollar', 'Round to Dollar'),
        ('round_to_dollar_minus_01', 'Round to Dollar Minus 0.1'),
        ('round_to_half_dollar', 'Round to Half Dollar'),
        ('round_to_half_dollar_minus_01', 'Round to Half Dollar Minus 0.1')
    ])
    sales_or_purchase_type = models.CharField(max_length=20, choices=[('sales', 'Sales'), ('purchases', 'Purchases')])
    status = models.CharField(max_length=20, choices=[('active', 'Active'), ('inactive', 'Inactive')])

    def __str__(self):
        return self.name
    


############################################################################################



# Warehouse # 
class Warehouse(models.Model):
    WAREHOUSE_TYPES = (
        ('primary', 'Primary'),
        ('secondary', 'Secondary'),
        ('fulfillment_center', 'Fulfillment Center'),
        # Add more types as needed
    )

    name = models.CharField(max_length=100, unique=True)
    address = models.TextField()
    country = models.CharField(max_length=100)
    state = models.CharField(max_length=100)
    city = models.CharField(max_length=100)
    zip_code = models.CharField(max_length=20)
    phone_number = models.CharField(max_length=20)
    email = models.EmailField()
    warehouse_type = models.CharField(max_length=20, choices=WAREHOUSE_TYPES)
    storage_capacity = models.DecimalField(max_digits=10, decimal_places=2)

    # Shipping Details
    default_shipping_method = models.CharField(max_length=100)
    default_shipping_rate = models.DecimalField(max_digits=10, decimal_places=2)

    # Picklists and Packing Slips
    picklist_customization = models.TextField()
    packing_slip_customization = models.TextField()

    # User Permissions
    # You may need to implement this with Django's built-in authentication system or a third-party library
    # This could involve creating a separate model for user permissions and associating it with warehouses

    # Advanced Features
    # Bin Management
    bin_management_enabled = models.BooleanField(default=False)

    # Cycle Counts
    cycle_count_enabled = models.BooleanField(default=False)

    # Kitting and Assembly
    kitting_assembly_enabled = models.BooleanField(default=False)

    # Warehouse Automation
    warehouse_automation_enabled = models.BooleanField(default=False)

    def __str__(self):
        return self.name
    
class Picklist(models.Model):
    WAREHOUSE_CHOICES = (
        ('Warehouse A', 'Warehouse A'),
        ('Warehouse B', 'Warehouse B'),
        ('Warehouse C', 'Warehouse C'),
        # Add more choices as needed
    )

    PRIORITY_CHOICES = (
        ('Urgent', 'Urgent'),
        ('Standard', 'Standard'),
        # Add more choices as needed
    )

    #sales_orders = models.ManyToManyField('SalesOrder')
    warehouse = models.CharField(max_length=100, choices=WAREHOUSE_CHOICES)
    assignee = models.ForeignKey(CustomUser, on_delete=models.CASCADE)
    priority = models.CharField(max_length=50, choices=PRIORITY_CHOICES)

    def __str__(self):
        return f'Picklist #{self.id}'

class PickedItem(models.Model):
    picklist = models.ForeignKey(Picklist, on_delete=models.CASCADE)
    item = models.ForeignKey('Item', on_delete=models.CASCADE)
    quantity = models.IntegerField(default=0)
    quantity_adjustment = models.IntegerField(default=0)  # Quantity adjustment compared to ordered quantity

    def __str__(self):
        return f'{self.quantity} x {self.item.name}'   

