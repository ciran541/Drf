from django.urls import path, include
from .views import ProductListCreate, ProductRetrieveUpdateDestroy

urlpatterns = [
    path('products/', ProductListCreate.as_view(), name='product-list-create'),
    path('products/<int:pk>/', ProductRetrieveUpdateDestroy.as_view(), name='product-detail'),
    path('inventory/', include('inventory_management.Inventory.urls')),
    path('purchase/', include('inventory_management.purchase.urls')),
]
