from django.db import models


'''
Data Collection Models : 

'''


class MachineSensor(models.Model):
    name = models.CharField(max_length=100, unique=True) # Name of the sensor (e.g., "Temperature Sensor A").
    location = models.CharField(max_length=255)  #  Location where the sensor is installed (e.g., "Production Line 1").
    description = models.TextField(blank=True)
    is_active = models.BooleanField(default=True)

    def __str__(self):
        return self.name

class SensorData(models.Model):
    sensor = models.ForeignKey(MachineSensor, related_name='sensor_data', on_delete=models.CASCADE)
    timestamp = models.DateTimeField(auto_now_add=True)
    temperature = models.DecimalField(max_digits=5, decimal_places=2, null=True, blank=True)
    pressure = models.DecimalField(max_digits=7, decimal_places=2, null=True, blank=True)
    speed = models.DecimalField(max_digits=6, decimal_places=2, null=True, blank=True)
    vibration = models.DecimalField(max_digits=6, decimal_places=2, null=True, blank=True)
    energy_consumption = models.DecimalField(max_digits=8, decimal_places=2, null=True, blank=True)
    cycle_time = models.DecimalField(max_digits=8, decimal_places=2, null=True, blank=True)

    class Meta:
        ordering = ['-timestamp']

    def __str__(self):
        return f'{self.sensor.name} - {self.timestamp}'


class PLCData(models.Model):
    machine_name = models.CharField(max_length=100)
    timestamp = models.DateTimeField(auto_now_add=True)
    machine_state = models.CharField(max_length=50)  # e.g., running, idle, stopped
    is_on = models.BooleanField(default=False)  # machine on/off status
    cycle_count = models.IntegerField(default=0)
    alarm_code = models.CharField(max_length=50, blank=True, null=True)
    error_code = models.CharField(max_length=50, blank=True, null=True)
    
    # Additional Fields
    temperature = models.FloatField(blank=True, null=True)  # Current machine temperature
    pressure = models.FloatField(blank=True, null=True)  # Current pressure in the system
    speed = models.FloatField(blank=True, null=True)  # Machine operating speed
    vibration = models.FloatField(blank=True, null=True)  # Vibration level
    
    # Production Metrics
    total_production = models.FloatField(default=0)  # Total units produced
    good_count = models.IntegerField(default=0)  # Number of good products
    reject_count = models.IntegerField(default=0)  # Number of rejected products
    
    # Process Parameters
    voltage = models.FloatField(blank=True, null=True)  # Operating voltage
    current = models.FloatField(blank=True, null=True)  # Current consumption
    humidity = models.FloatField(blank=True, null=True)  # Humidity level
    
    class Meta:
        ordering = ['-timestamp']

    def __str__(self):
        return f"{self.machine_name} - {self.timestamp}"
    
class ManualInput(models.Model):
    timestamp = models.DateTimeField(auto_now_add=True)
    operator_name = models.CharField(max_length=100)
    shift = models.CharField(max_length=20, choices=[('Day', 'Day'), ('Night', 'Night')])  # Shift selection
    machine_name = models.CharField(max_length=100)  # Name of the machine or equipment used
    product_code = models.CharField(max_length=50)  # Product code or identifier
    quantity_produced = models.PositiveIntegerField()  # Quantity of products produced
    is_approved = models.BooleanField(default=False)  # Approval status of the entry
    quality_inspection_result = models.CharField(max_length=200, blank=True, null=True)
    downtime_reason = models.TextField(blank=True, null=True)
    production_notes = models.TextField(blank=True, null=True)
    process_inputs = models.JSONField(blank=True, null=True)  # Store non-standard process inputs as JSON

    # Additional fields for capturing production metrics
    cycle_time = models.DurationField(blank=True, null=True)  # Duration for completing a cycle
    setup_time = models.DurationField(blank=True, null=True)  # Setup time required
    scrap_quantity = models.PositiveIntegerField(default=0)  # Quantity of scrapped items

    # Fields for tracking production order or job
    order_number = models.CharField(max_length=50, blank=True, null=True)  # Production order number
    job_number = models.CharField(max_length=50, blank=True, null=True)  # Job number or identifier

    def __str__(self):
        return f"ManualInput - {self.timestamp} by {self.operator_name}"
    

'''
Need to implement model for the given below Applications or integration

PLC (Programmable Logic Controller) Data: Integrate with PLC systems to capture operational data and control signals.
MES (Manufacturing Execution Systems) Integration: Pull data from MES systems that manage production processes.
ERP (Enterprise Resource Planning) Integration: Extract data from ERP systems for information on inventory, orders, and scheduling.

'''