from django.apps import AppConfig


class DataCollectionConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'MAS.Data_collection'
