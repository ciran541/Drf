# serializers.py
from rest_framework import serializers
from .models import ContactPerson, Unit, Item, ItemGroup, Order, OrderItem, Team, Role, Agent, Tag, Geofence, Vehicle

class ContactPersonSerializer(serializers.ModelSerializer):
    class Meta:
        model = ContactPerson
        fields = '__all__'
        ref_name = 'deliverycontact'

class ContactPersondetailSerializer(serializers.ModelSerializer):
    class Meta:
        model = ContactPerson
        fields = '__all__'
        ref_name = 'deliverydetailcontact'


class UnitSerializer(serializers.ModelSerializer):
    class Meta:
        model = Unit
        fields = '__all__'
        ref_name = 'deliveryunit'


class ItemSerializer(serializers.ModelSerializer):
    class Meta:
        model = Item
        fields = '__all__'
        ref_name = 'deliveryitem'


class ItemdetailSerializer(serializers.ModelSerializer):
    class Meta:
        model = Item
        fields = '__all__'
        ref_name = 'deliveryitemdetail'


class ItemGroupSerializer(serializers.ModelSerializer):
    class Meta:
        model = ItemGroup
        fields = '__all__'
        ref_name = 'deliveryitemgroup'


class ItemGroupdetailSerializer(serializers.ModelSerializer):
    class Meta:
        model = ItemGroup
        fields = '__all__'
        ref_name = 'deliveryitemgroupdetail'


class OrderSerializer(serializers.ModelSerializer):
    class Meta:
        model = Order
        fields = '__all__'
        ref_name = 'deliveryorder'


class OrderdetailSerializer(serializers.ModelSerializer):
    class Meta:
        model = Order
        fields = '__all__'
        ref_name = 'deliveryorderdetail'


class OrderItemSerializer(serializers.ModelSerializer):
    class Meta:
        model = OrderItem
        fields = '__all__'
        ref_name = 'deliveryItemser'


class TeamSerializer(serializers.ModelSerializer):
    class Meta:
        model = Team
        fields = '__all__'
        ref_name = 'deliveryteamser'


class RoleSerializer(serializers.ModelSerializer):
    class Meta:
        model = Role
        fields = '__all__'
        ref_name = 'deliveryrole'


class AgentSerializer(serializers.ModelSerializer):
    class Meta:
        model = Agent
        fields = '__all__'
        ref_name = 'deliveryagentser'


class AgentdetailSerializer(serializers.ModelSerializer):
    class Meta:
        model = Agent
        fields = '__all__'
        ref_name = 'deliveryagentdetailser'



class TagSerializer(serializers.ModelSerializer):
    class Meta:
        model = Tag
        fields = '__all__'
        ref_name = 'deliverytagser'


class GeofenceSerializer(serializers.ModelSerializer):
    class Meta:
        model = Geofence
        fields = '__all__'
        ref_name = 'deliverygeofence'


class VehicleSerializer(serializers.ModelSerializer):
    class Meta:
        model = Vehicle
        fields = '__all__'
        ref_name = 'deliveryvehicalser'

