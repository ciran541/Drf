from django.db import models
from django.core.exceptions import ValidationError
from Authentication.models import CustomUser
class ContactPerson(models.Model):
    MR = 'Mr'
    MRS = 'Mrs'
    MISS = 'Miss'
    MS = 'Ms'
    DR = 'Dr'
    REV = 'Rev'

    SALUTATION_CHOICES = [
        (MR, 'Mr'),
        (MRS, 'Mrs'),
        (MISS, 'Miss'),
        (MS, 'Ms'),
        (DR, 'Dr'),
        (REV, 'Rev'),
    ]
    
    contact_person_id = models.AutoField(primary_key=True)
    salutation = models.CharField(max_length=10, choices=SALUTATION_CHOICES, blank=True, null=True)
    first_name = models.CharField(max_length=100,blank=True)
    last_name = models.CharField(max_length=100,blank=True)
    email = models.EmailField()
    work_phone = models.CharField(max_length=20,blank=True)
    mobile = models.CharField(max_length=20,blank=True)
    designation = models.CharField(max_length=50, blank=True, null=True)
    department = models.CharField(max_length=50, blank=True, null=True)
    skype = models.CharField(max_length=100, blank=True, null=True)
    is_primary_contact = models.BooleanField(default=False,blank=True)
    enable_portal = models.BooleanField(default=False,blank=True)
    
    def __str__(self):
        return f"{self.first_name} {self.last_name}"

class Unit(models.Model):
    unit_code = models.CharField(max_length=20, primary_key=True)
    unit_name = models.CharField(max_length=50)

class Item(models.Model):
    ITEM_TYPES = [
        ('product', 'Product'),
        ('service', 'Service'),
        ('bundle', 'Bundle'),
    ]

    STATUS_CHOICES = [
        ('active', 'Active'),
        ('inactive', 'Inactive'),
    ]
    item_group = models.ForeignKey('ItemGroup',on_delete=models.CASCADE,blank=True,related_name = 'Inventory_item_itemgroup')
    item_id = models.CharField(max_length=20, primary_key=True)
    item_type = models.CharField(max_length=20, choices=ITEM_TYPES)
    name = models.CharField(max_length=100)
    status = models.CharField(max_length=10, choices=STATUS_CHOICES, default='active')
    description = models.TextField(max_length=2000, blank=True, null=True)
    rate = models.DecimalField(max_digits=10, decimal_places=2)
    unit = models.ForeignKey(Unit, on_delete=models.CASCADE, blank=True, null=True)
    tax_id = models.CharField(max_length=20, blank=True, null=True)
    purchase_tax_rule_id = models.CharField(max_length=20, blank=True, null=True)
    sales_tax_rule_id = models.CharField(max_length=20, blank=True, null=True)
    tax_name = models.CharField(max_length=50, blank=True, null=True)
    hsn_or_sac = models.CharField(max_length=20, blank=True, null=True)
    sat_item_key_code = models.CharField(max_length=20, blank=True, null=True)
    unitkey_code = models.CharField(max_length=20, blank=True, null=True)
    tax_percentage = models.DecimalField(max_digits=5, decimal_places=2, blank=True, null=True)
    tax_type = models.CharField(max_length=20, blank=True, null=True)
    sku = models.CharField(max_length=50, unique=True)
    product_type = models.CharField(max_length=20,blank=True)


    def __str__(self):
        return self.name

    def clean(self):
        # Call the super clean method to ensure the model's built-in validation is also performed
        super().clean()
        
        # Custom validation
        errors = {}

        # Example custom validation: Ensure opening stock is not negative
        if self.opening_stock < 0:
            errors['opening_stock'] = ValidationError("Opening stock cannot be negative.")

        # Example custom validation: Ensure current stock is not negative
        if self.current_stock < 0:
            errors['current_stock'] = ValidationError("Current stock cannot be negative.")

        # Raise validation errors if any
        if errors:
            raise ValidationError(errors)

# ItemGroup # 
    
class ItemGroup(models.Model):
    ITEM_TYPES = [
        ('product', 'Product'),
        ('service', 'Service'),
        ('bundle', 'Bundle'),
    ]

    STATUS_CHOICES = [
        ('active', 'Active'),
        ('inactive', 'Inactive'),
    ]
    item_type = models.CharField(max_length=20, choices=ITEM_TYPES,blank=True)
    group_name = models.CharField(max_length=255,blank=True)
    brand = models.CharField(max_length=255,blank=True)
    manufacturer = models.CharField(max_length=255,blank=True)
    unit = models.CharField(max_length=50,blank=True)
    description = models.TextField(blank=True)
    tax_id = models.PositiveIntegerField(blank=True,null=True)
    attribute_name1 = models.CharField(max_length=255,blank=True)
    items = models.ManyToManyField(Item,blank=True)
    status = models.CharField(max_length=10, choices=STATUS_CHOICES, default='active',blank=True,null=True)
    
    
class Order(models.Model):
    ORDER_STATUS_CHOICES = (
        ('PENDING', 'Pending'),
        ('PROCESSING', 'Processing'),
        ('SHIPPED', 'Shipped'),
        ('DELIVERED', 'Delivered'),
        ('CANCELLED', 'Cancelled'),
    )

    channel = models.CharField(max_length=100)  
    customer_name = models.CharField(max_length=255)
    customer_email = models.EmailField()
    customer_phone = models.CharField(max_length=20)
    delivery_address = models.JSONField(blank=True,null=True)
    payment_method = models.CharField(max_length=50, null=True, blank=True)
    transaction_id = models.CharField(max_length=100, null=True, blank=True)
    payment_status = models.CharField(max_length=20, null=True, blank=True)
    delivery_instructions = models.TextField(null=True, blank=True)
    delivery_date = models.DateField(null=True, blank=True)
    delivery_time = models.TimeField(null=True, blank=True)
    order_notes = models.TextField(null=True, blank=True)
    total_amount = models.DecimalField(max_digits=10, decimal_places=2)
    order_status = models.CharField(max_length=20, choices=ORDER_STATUS_CHOICES, default='PENDING')
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    def __str__(self):
        return f"Order #{self.id} - {self.customer_name}"
    
class OrderItem(models.Model):
    order = models.ForeignKey(Order, on_delete=models.CASCADE)
    item = models.ForeignKey(Item, on_delete=models.CASCADE)
    quantity = models.PositiveIntegerField()
    subtotal = models.DecimalField(max_digits=10, decimal_places=2)
    discount = models.DecimalField(max_digits=10, decimal_places=2, default=0)
    tax = models.DecimalField(max_digits=10, decimal_places=2, default=0)

    def __str__(self):
        return f"{self.quantity} x {self.item.name} (Order #{self.order_id})"
    

'''
The given below models Team,Role,Agent, Geofence used for managing the Agent (Delivery_driver)

'''

class Team(models.Model):
    name = models.CharField(max_length=255)

class Role(models.Model):
    name = models.CharField(max_length=255)

class Agent(CustomUser):
    AGENT_TYPE_CHOICES = [
        ('C', 'Captive'),
        ('F', 'Freelancer'),
    ]

    phone = models.CharField(max_length=20)
    tags = models.ManyToManyField('Tag', blank=True)
    team = models.ForeignKey(Team, on_delete=models.CASCADE, related_name='agents')
    role = models.ForeignKey(Role, on_delete=models.CASCADE, related_name='agents')
    home_address = models.TextField(blank=True)
    agent_type = models.CharField(max_length=1, choices=AGENT_TYPE_CHOICES)
    transport_type = models.CharField(max_length=255, blank=True)
    vehicle_details = models.JSONField(max_length=255, blank=True)
    vehicle = models.ForeignKey('Vehicle', on_delete=models.CASCADE, blank=True, null=True)
    is_available = models.BooleanField(default=True)  # Indicates if the agent is available for assignments
    current_location = models.CharField(max_length=255, blank=True)  # Store current location of the agent
    max_capacity = models.DecimalField(max_digits=6, decimal_places=2, null=True, blank=True)  # Maximum capacity for deliveries
    assigned_orders = models.ManyToManyField('Order', blank=True, related_name='assigned_agents')

class Tag(models.Model):
    name = models.CharField(max_length=255)

class Geofence(models.Model):
    name = models.CharField(max_length=255, unique=True)
    description = models.TextField(blank=True)
    latitude = models.DecimalField(max_digits=9, decimal_places=6, null=True, blank=True)
    longitude = models.DecimalField(max_digits=9, decimal_places=6, null=True, blank=True)
    radius = models.DecimalField(max_digits=6, decimal_places=2, help_text='Radius in kilometers', null=True, blank=True)
    active = models.BooleanField(default=True)

    def __str__(self):
        return self.name
    

class Vehicle(models.Model):
    capacity = models.IntegerField(blank=True, null=True)  # Vehicle capacity in terms of maximum orders it can carry
    fuel_efficiency = models.FloatField(blank=True, null=True)  # Fuel efficiency in kilometers per liter
    driver = models.CharField(max_length=100, blank=True)  # Name of the driver
    max_working_hours_per_day = models.IntegerField(blank=True, null=True)  # Maximum working hours allowed per day
    max_daily_driving_hours = models.IntegerField(blank=True, null=True)  # Maximum driving hours allowed per day
    rest_break_interval = models.IntegerField(blank=True, null=True)  # Interval between rest breaks in hours
    license_plate_number = models.CharField(max_length=20, blank=True)  # License plate number of the vehicle
    make = models.CharField(max_length=50, blank=True)  # Make/manufacturer of the vehicle
    model = models.CharField(max_length=50, blank=True)  # Model of the vehicle
    year = models.PositiveIntegerField(blank=True, null=True)  # Year of manufacture
    # current_location = models.ForeignKey('Location', on_delete=models.SET_NULL, null=True, blank=True)  # Current location of the vehicle
    last_service_date = models.DateField(null=True, blank=True)  # Date of the last service
    maintenance_interval = models.IntegerField(blank=True, null=True)  # Interval between maintenance checks in kilometers
    odometer_reading = models.FloatField(default=0.0,blank=True, null=True)  # Current odometer reading in kilometers

    def __str__(self):
        return f"{self.make} {self.model} ({self.license_plate_number})"
    

class Task(models.Model):
    TASK_TYPE_CHOICES = [
        ('PICKUP', 'Pickup'),
        ('DELIVERY', 'Delivery'),
    ]

    agent = models.ForeignKey(Agent, on_delete=models.CASCADE, blank=True, null=True, related_name='taskagent')
    order = models.ForeignKey(Order, on_delete=models.CASCADE)
    task_type = models.CharField(max_length=10, choices=TASK_TYPE_CHOICES)
    phone_number = models.IntegerField(blank=True,null=True)
    email = models.EmailField(blank=True, null=True)
    address = models.JSONField(blank=True,null=True)
    start_time = models.DateTimeField(blank=True, null=True)
    end_time = models.DateTimeField(blank=True, null=True)

    assigned_at = models.DateTimeField(auto_now_add=True)
    completed_at = models.DateTimeField(null=True, blank=True)


class Appointment(models.Model):
    appointment_type = models.CharField(max_length=20,blank=True)  # e.g., 'Pickup', 'Delivery', 'Meeting'
    agent = models.ForeignKey(Agent, on_delete=models.CASCADE,blank=True,null=True, related_name='appAgent')
    order = models.ForeignKey(Order, on_delete=models.CASCADE,blank=True,null=True)
    phone_number = models.IntegerField(blank=True,null=True)
    email = models.EmailField(blank=True, null=True)
    address = models.JSONField(blank=True,null=True)
    start_time = models.DateTimeField(blank=True, null=True)
    end_time = models.DateTimeField(blank=True, null=True)
    notes = models.TextField(blank=True)
    is_confirmed = models.BooleanField(default=False)
