from django.apps import AppConfig


class OrderPlacementConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'delivery_app.order_placement'
