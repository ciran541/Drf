# urls.py
from django.urls import path, include
from rest_framework.routers import DefaultRouter
from .views import (ContactPersonViewSet, UnitViewSet, ItemViewSet, ItemGroupViewSet,
OrderViewSet, OrderItemViewSet, TeamViewSet, RoleViewSet, AgentViewSet, TagViewSet, GeofenceViewSet, VehicleViewSet
)
router = DefaultRouter()
router.register(r'contact-persons', ContactPersonViewSet)
router.register(r'units', UnitViewSet)
router.register(r'items', ItemViewSet)
router.register(r'item-groups', ItemGroupViewSet)
router.register(r'orders', OrderViewSet)
router.register(r'order-items', OrderItemViewSet)
router.register(r'teams', TeamViewSet)
router.register(r'roles', RoleViewSet)
router.register(r'agents', AgentViewSet)
router.register(r'tags', TagViewSet)
router.register(r'geofences', GeofenceViewSet)
router.register(r'vehicles', VehicleViewSet)

urlpatterns = [
    path('', include(router.urls)),
]
