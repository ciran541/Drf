# views.py
from rest_framework import viewsets
from .models import ContactPerson, Unit, Item, ItemGroup, Order, OrderItem, Team, Role, Agent, Tag, Geofence, Vehicle
from .serializers import (ContactPersonSerializer, UnitSerializer, ItemSerializer, ItemGroupSerializer, OrderSerializer,ContactPersondetailSerializer,
OrderItemSerializer, TeamSerializer, RoleSerializer, AgentSerializer, TagSerializer, GeofenceSerializer, VehicleSerializer,ItemdetailSerializer,
ItemGroupdetailSerializer,OrderdetailSerializer,AgentdetailSerializer
)

class ContactPersonViewSet(viewsets.ModelViewSet):
    queryset = ContactPerson.objects.all()

    def get_serializer_class(self):
        if self.request.method in ['POST', 'PUT', 'PATCH']:
            return ContactPersonSerializer
        return ContactPersondetailSerializer

class UnitViewSet(viewsets.ModelViewSet):
    queryset = Unit.objects.all()
    serializer_class = UnitSerializer

class ItemViewSet(viewsets.ModelViewSet):
    queryset = Item.objects.all()

    def get_serializer_class(self):
        if self.request.method in ['POST', 'PUT', 'PATCH']:
            return ItemSerializer
        return ItemdetailSerializer

class ItemGroupViewSet(viewsets.ModelViewSet):
    queryset = ItemGroup.objects.all()

    def get_serializer_class(self):
        if self.request.method in ['POST', 'PUT', 'PATCH']:
            return ItemGroupSerializer
        return ItemGroupdetailSerializer

class OrderViewSet(viewsets.ModelViewSet):
    queryset = Order.objects.all()

    def get_serializer_class(self):
        if self.request.method in ['POST', 'PUT', 'PATCH']:
            return OrderSerializer
        return OrderdetailSerializer

class OrderItemViewSet(viewsets.ModelViewSet):
    queryset = OrderItem.objects.all()
    serializer_class = OrderItemSerializer

class TeamViewSet(viewsets.ModelViewSet):
    queryset = Team.objects.all()
    serializer_class = TeamSerializer

class RoleViewSet(viewsets.ModelViewSet):
    queryset = Role.objects.all()
    serializer_class = RoleSerializer

class AgentViewSet(viewsets.ModelViewSet):
    queryset = Agent.objects.all()

    def get_serializer_class(self):
        if self.request.method in ['POST', 'PUT', 'PATCH']:
            return AgentSerializer
        return AgentdetailSerializer

class TagViewSet(viewsets.ModelViewSet):
    queryset = Tag.objects.all()
    serializer_class = TagSerializer

class GeofenceViewSet(viewsets.ModelViewSet):
    queryset = Geofence.objects.all()
    serializer_class = GeofenceSerializer

class VehicleViewSet(viewsets.ModelViewSet):
    queryset = Vehicle.objects.all()
    serializer_class = VehicleSerializer
