from django.db import models

class Delivery(models.Model):
    destination = models.CharField(max_length=100)
    package_weight = models.FloatField()
    delivery_date = models.DateField()