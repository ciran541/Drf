"""
URL configuration for Aattral_one project.

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/4.2/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""

from django.urls import path
from rest_framework import permissions
from drf_yasg.views import get_schema_view
from drf_yasg import openapi
from rest_framework_simplejwt.authentication import JWTAuthentication

# Imports for Admin
from django.contrib import admin
from django.urls import path,include
from Hr.admin import hr_admin_site
from finance.admin import finance_admin_site
# from Asset_management.admin import asset_management_admin_site
# Swagger 

schema_view = get_schema_view(
   openapi.Info(
      title="AattralOne API",
      default_version='v1',
      description="API Description",
      terms_of_service="https://www.google.com/policies/terms/",
      contact=openapi.Contact(email="contact@yourapi.local"),
      license=openapi.License(name="BSD License"),
   ),
    public=True,
    permission_classes=(permissions.AllowAny,),
    authentication_classes=(JWTAuthentication,),
)


admin.site.site_header = 'AattralOne'
admin.site.site_title = 'AATTRAL-ONE'
admin.site.index_title = 'Welcome to TechbrainS AATTRAL-ONE'

urlpatterns = [
    path('swagger/', schema_view.with_ui('swagger', cache_timeout=0), name='schema-swagger-ui'),
    path('redoc/', schema_view.with_ui('redoc', cache_timeout=0), name='schema-redoc'),
    path('admin/', admin.site.urls),
    path('hr_admin/', hr_admin_site.urls),
    path('finance_admin/', finance_admin_site.urls),
    # path('asset_admin/', asset_management_admin_site.urls),
    path('api/auth/', include('Authentication.urls')),
    path('api/hr/', include('Hr.urls')),
    path('api/customer/', include('customer_support.urls')),
    path('api/delivery/', include('delivery_app.urls')),
    path('api/commerce/', include('E_commerce.urls')),
    path('api/erp/', include('ERP.urls')),
    path('api/finance/', include('finance.urls')),
    path('api/purchase/', include('material_purchase.urls')),
    path('api/payroll/', include('payroll.urls')),
    path('api/production/', include('production_planning.urls')),
    path('api/order/', include('order_management.urls')),
    path('api/qa/', include('QA_app.urls')),
    path('api/shopfloor/', include('shopfloor_monitoring.urls')),
    path('api/supplychain/', include('supply_chain_management.urls')),
    path('api/distributor/', include('distributor_app.urls')),
    path('api/inventory_management/', include('inventory_management.urls')),
    path('api/asset_management/', include('Asset_management.urls')),
    path('api/mes/', include('MES.urls')),
    path('api/crm/', include('CRM.urls')),

    #path('api/inventory_management/inventory/', include('inventory_management.Inventory.urls')),
    
]
