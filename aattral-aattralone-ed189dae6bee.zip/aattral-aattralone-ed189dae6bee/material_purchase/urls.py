from django.urls import path, include
from rest_framework.routers import DefaultRouter
from .views import MaterialPurchaseViewSet

router = DefaultRouter()
router.register(r'material_purchases', MaterialPurchaseViewSet)

urlpatterns = [
    path('', include(router.urls)),
]