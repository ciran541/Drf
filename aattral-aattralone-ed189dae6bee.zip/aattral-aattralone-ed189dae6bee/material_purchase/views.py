
from rest_framework import viewsets
from .models import MaterialPurchase
from .serializers import MaterialPurchaseSerializer

class MaterialPurchaseViewSet(viewsets.ModelViewSet):
    queryset = MaterialPurchase.objects.all()
    serializer_class = MaterialPurchaseSerializer