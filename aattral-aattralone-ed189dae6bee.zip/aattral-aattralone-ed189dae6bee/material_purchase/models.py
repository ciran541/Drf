from django.db import models

class MaterialPurchase(models.Model):
    material_name = models.CharField(max_length=100)
    quantity = models.IntegerField()



   