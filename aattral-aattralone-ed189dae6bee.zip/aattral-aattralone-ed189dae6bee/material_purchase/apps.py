from django.apps import AppConfig


class MaterialPurchaseConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'material_purchase'
