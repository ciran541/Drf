from django.test import TestCase
from django.contrib.auth import get_user_model
from django.urls import reverse
from rest_framework import status
from rest_framework.test import APIClient

from .models import CustomUser

UserModel = get_user_model()

class AuthenticationTestCase(TestCase):
    def setUp(self):
        self.client = APIClient()
        self.user = CustomUser.objects.create_user(
            username='testuser',
            email='test@example.com',
            password='testpassword',
            first_name='John',
            last_name='Doe'
        )

    def test_login(self):
        url = reverse('login')
        data = {'username': 'testuser', 'password': 'testpassword'}
        response = self.client.post(url, data, format='json')
        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertIn('access', response.data)
        self.assertIn('refresh', response.data)
        self.assertIn('user', response.data)
        self.assertEqual(response.data['user']['username'], 'testuser')
        self.assertEqual(response.data['user']['first_name'], 'John')
        self.assertEqual(response.data['user']['last_name'], 'Doe')
        # Add more assertions as needed

    def test_refresh_token(self):
        url = reverse('refresh_token')
        refresh_token = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTcwODUwMDY0MSwiaWF0IjoxNzA4NDE0MjQxLCJqdGkiOiI1MWJiN2ZiMjYxNTE0MDk0OTc3ZjQxMTM1ZGExMDRjMSIsInVzZXJfaWQiOjN9.xaZLwxmWYOPfauG_lBgceGjX1SnpZLY26JTsf-qdE3Y'
        data = {'refresh_token': refresh_token}
        response = self.client.post(url, data, format='json')
        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertIn('access', response.data)
        # Add more assertions as needed

    
    def test_login_invalid_credentials(self):
        url = reverse('login')
        data = {'username': 'invaliduser', 'password': 'invalidpassword'}
        response = self.client.post(url, data, format='json')
        self.assertEqual(response.status_code, status.HTTP_401_UNAUTHORIZED)

    def test_login_missing_credentials(self):
        url = reverse('login')
        data = {}  # No username or password provided
        response = self.client.post(url, data, format='json')
        self.assertEqual(response.status_code, status.HTTP_401_UNAUTHORIZED)  # Update assertion to expect 401

    def test_logout_missing_token(self):
        url = reverse('logout')
        data = {}  # No refresh token provided
        response = self.client.post(url, data, format='json')
        self.assertEqual(response.status_code, status.HTTP_401_UNAUTHORIZED)  # Update assertion to expect 401

    