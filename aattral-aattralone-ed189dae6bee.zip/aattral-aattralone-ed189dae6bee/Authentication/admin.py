from django.contrib import admin
from django.contrib.auth.admin import UserAdmin
from .models import CustomUser

class CustomUserAdmin(UserAdmin):
    model = CustomUser
    list_display = ('username', 'email','first_name', 'last_name', 'is_staff', 'is_active', 'get_role',)
    list_filter = ('is_staff', 'is_active', 'groups',)
    fieldsets = (
        (None, {'fields': ('username', 'password')}),
        ('Personal Info', {'fields': ('email','first_name', 'last_name')}),
        ('Permissions', {'fields': ('is_staff', 'is_active', 'groups')}),
    )
    add_fieldsets = (
        (None, {
            'classes': ('wide',),
            'fields': ('username', 'email','first_name', 'last_name', 'password1', 'password2', 'is_staff', 'is_active', 'groups')}
        ),
    )
    search_fields = ('username', 'email',)
    ordering = ('username',)

    def get_role(self, obj):
        if obj.groups.filter(name='Hr_manager').exists():
            return 'Hr_manager'
        elif obj.groups.filter(name='Hr_employee').exists():
            return 'Hr_employee'
        elif obj.groups.filter(name='Hr_intern').exists():
            return 'Hr_intern'
        elif obj.groups.filter(name='CS_manager').exists():
            return 'CS_manager'
        elif obj.groups.filter(name='CS_employee').exists():
            return 'CS_employee'
        elif obj.groups.filter(name='CS_intern').exists():
            return 'CS_intern'
        elif obj.groups.filter(name='DA_manager').exists():
            return 'DA_manager'
        elif obj.groups.filter(name='DA_employee').exists():
            return 'DA_employee'
        elif obj.groups.filter(name='DA_intern').exists():
            return 'DA_intern'
        elif obj.groups.filter(name='DBA_manager').exists():
            return 'DBA_manager'
        elif obj.groups.filter(name='DBA_employee').exists():
            return 'DBA_employee'
        elif obj.groups.filter(name='DBA_intern').exists():
            return 'DBA_intern'
        elif obj.groups.filter(name='EC_manager').exists():
            return 'EC_manager'
        elif obj.groups.filter(name='EC_employee').exists():
            return 'EC_employee'
        elif obj.groups.filter(name='EC_intern').exists():
            return 'EC_intern'
        elif obj.groups.filter(name='ERP_manager').exists():
            return 'ERP_manager'
        elif obj.groups.filter(name='ERP_employee').exists():
            return 'ERP_employee'
        elif obj.groups.filter(name='ERP_intern').exists():
            return 'ERP_intern'
        elif obj.groups.filter(name='FIN_manager').exists():
            return 'FIN_manager'
        elif obj.groups.filter(name='FIN_employee').exists():
            return 'FIN_employee'
        elif obj.groups.filter(name='FIN_intern').exists():
            return 'FIN_intern'
        elif obj.groups.filter(name='IM_manager').exists():
            return 'IM_manager'
        elif obj.groups.filter(name='IM_employee').exists():
            return 'IM_employee'
        elif obj.groups.filter(name='IM_intern').exists():
            return 'IM_intern'
        elif obj.groups.filter(name='OM_manager').exists():
            return 'OM_manager'
        elif obj.groups.filter(name='OM_employee').exists():
            return 'OM_employee'
        elif obj.groups.filter(name='OM_intern').exists():
            return 'OM_intern'
        elif obj.groups.filter(name='Payroll_manager').exists():
            return 'Payroll_manager'
        elif obj.groups.filter(name='Payroll_employee').exists():
            return 'Payroll_employee'
        elif obj.groups.filter(name='Payroll_intern').exists():
            return 'Payroll_intern'
        elif obj.groups.filter(name='PP_manager').exists():
            return 'PP_manager'
        elif obj.groups.filter(name='PP_employee').exists():
            return 'PP_employee'
        elif obj.groups.filter(name='PP_intern').exists():
            return 'PP_intern'
        elif obj.groups.filter(name='QA_manager').exists():
            return 'QA_manager'
        elif obj.groups.filter(name='QA_employee').exists():
            return 'QA_employee'
        elif obj.groups.filter(name='QA_intern').exists():
            return 'QA_intern'
        elif obj.groups.filter(name='SCM_manager').exists():
            return 'SCM_manager'
        elif obj.groups.filter(name='SCM_employee').exists():
            return 'SCM_employee'
        elif obj.groups.filter(name='SCM_intern').exists():
            return 'SCM_intern'
        elif obj.groups.filter(name='Mp_manager').exists():
            return 'Mp_manager'
        elif obj.groups.filter(name='Mp_employee').exists():
            return 'Mp_employee'
        elif obj.groups.filter(name='Mp_intern').exists():
            return 'Mp_intern'
        elif obj.groups.filter(name='SM_manager').exists():
            return 'SM_manager'
        elif obj.groups.filter(name='SM_employee').exists():
            return 'SM_employee'
        elif obj.groups.filter(name='SM_intern').exists():
            return 'SM_intern'
        else:
            return 'Unknown'

    get_role.short_description = 'Role'

# Register your custom user model with the admin site
admin.site.register(CustomUser, CustomUserAdmin)
