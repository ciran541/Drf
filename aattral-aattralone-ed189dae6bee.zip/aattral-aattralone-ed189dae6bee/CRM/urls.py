from django.urls import path, include

urlpatterns = [
    path('general/', include('CRM.general.urls')),
    path('process-management/', include('CRM.process_management.urls')),
    path('automation/', include('CRM.Automation.urls')),
    
]
