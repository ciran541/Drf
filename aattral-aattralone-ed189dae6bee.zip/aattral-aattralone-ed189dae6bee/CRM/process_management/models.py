from django.db import models
from django.contrib.contenttypes.models import ContentType
from django.contrib.contenttypes.fields import GenericForeignKey
from django.utils.translation import gettext_lazy as _


'''

The process management section is all about creating a visual representation (often flowcharts) of the specific steps your sales team (or other departments) 
take to move leads through your sales funnel, manage customer service interactions, or any other standardized business process.

'''

class Blueprint(models.Model):
    name = models.CharField(max_length=255,blank=True)
    content_type = models.ForeignKey(ContentType, on_delete=models.CASCADE)
    object_id = models.PositiveIntegerField(blank=True, null=True)
    module = GenericForeignKey('content_type', 'object_id')  # This is the id of models that we have defined ex: Leads,Contacts, Accounts ect...

    layout_choices = [
        ('standard', 'Standard'),
        ('custom', 'Custom'),
    ]
    layout = models.CharField(max_length=20, choices=layout_choices, default='standard')
    criteria = models.JSONField(blank=True, null=True, help_text=_('Define criteria for record association'))
    field_name = models.CharField(max_length=255,blank=True)  # Store the field name as a string


    def __str__(self):
        return self.name


    # -H "Content-Type: application/json" \
    # -d '{
    #     "name": "Leads Module Blueprint",
    #     "content_type": 1,
    #     "object_id": 1,
    #     "layout": "standard",
    #     "criteria": [
    #         {
    #             "field": "first_name",
    #             "condition": "contains",
    #             "value": "John"
    #         },
    #         {
    #             "field": "status",
    #             "condition": "is",
    #             "value": "Active"
    #         }
    #     ]
    # "fields": [
    #     {"field_name": "name"},
    #     {"field_name": "email"},
    #     {"field_name": "phone"}
    #   ]
          
    # }'

class ApprovalProcess(models.Model):
    module_choices = [
        ('Leads', 'Leads'),
        ('Contacts', 'Contacts'),
        # Add other module choices as needed
    ]
    module = models.CharField(max_length=50, choices=module_choices,blank=True)
    name = models.CharField(max_length=255,blank=True)
    description = models.TextField(blank=True)
    execute_choices = [
        ('creation', 'Record Creation'),
        ('edit', 'Record Edit'),
    ]
    when_to_execute = models.CharField(max_length=20, choices=execute_choices,blank=True)
    rules = models.ManyToManyField('ApprovalRule', related_name='approval_processes', blank=True)

    # GenericForeignKey fields
    content_type = models.ForeignKey(ContentType, on_delete=models.CASCADE,blank=True, null=True)
    object_id = models.PositiveIntegerField(blank=True, null=True)
    content_object = GenericForeignKey('content_type', 'object_id') # This is the id of models that we have defined ex: Leads,Contacts, Accounts ect...

    def __str__(self):
        return f'{self.module} Approval Process - {self.name}'
    

class ApprovalRule(models.Model):
    name = models.CharField(max_length=255,blank=True)
    description = models.TextField(blank=True)
    action = models.CharField(max_length=255,blank=True)  # Define the action or condition for the rule

    def __str__(self):
        return self.name
    

class ReviewProcess(models.Model):
    name = models.CharField(max_length=255,blank=True)
    description = models.TextField(blank=True)
    content_type = models.ForeignKey(ContentType, on_delete=models.CASCADE,null=True, blank=True)
    object_id = models.PositiveIntegerField(null=True, blank=True)
    module = GenericForeignKey('content_type', 'object_id')  # This is the id of models that we have defined ex: Leads,Contacts, Accounts ect...

    layout_choices = [
        ('standard', 'Standard'),
        ('custom', 'Custom'),
    ]
    layout = models.CharField(max_length=20, choices=layout_choices, default='standard',null=True, blank=True)
    condition = models.TextField(blank=True)  # Define the condition to initiate the review process

    def __str__(self):
        return self.name