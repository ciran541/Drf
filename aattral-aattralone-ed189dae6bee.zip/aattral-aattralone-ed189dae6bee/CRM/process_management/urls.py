# urls.py
from django.urls import path, include
from rest_framework.routers import DefaultRouter
from .views import BlueprintViewSet, ApprovalProcessViewSet, ApprovalRuleViewSet, ReviewProcessViewSet

router = DefaultRouter()
router.register(r'blueprints', BlueprintViewSet)
router.register(r'approval_processes', ApprovalProcessViewSet)
router.register(r'approval_rules', ApprovalRuleViewSet)
router.register(r'review_processes', ReviewProcessViewSet)

urlpatterns = [
    path('', include(router.urls)),
]
