from django.apps import AppConfig


class ProcessManagementConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'CRM.process_management'
