# serializers.py
from rest_framework import serializers
from .models import Blueprint, ApprovalProcess, ApprovalRule, ReviewProcess

class BlueprintSerializer(serializers.ModelSerializer):
    class Meta:
        model = Blueprint
        fields = '__all__'

class BlueprintDetailSerializer(serializers.ModelSerializer):
    class Meta:
        model = Blueprint
        fields = '__all__'

class BlueprintCreateUpdateSerializer(serializers.ModelSerializer):
    class Meta:
        model = Blueprint
        fields = '__all__'

class ApprovalProcessSerializer(serializers.ModelSerializer):
    class Meta:
        model = ApprovalProcess
        fields = '__all__'

class ApprovalProcessDetailSerializer(serializers.ModelSerializer):
    class Meta:
        model = ApprovalProcess
        fields = '__all__'

class ApprovalProcessCreateUpdateSerializer(serializers.ModelSerializer):
    class Meta:
        model = ApprovalProcess
        fields = '__all__'

class ApprovalRuleSerializer(serializers.ModelSerializer):
    class Meta:
        model = ApprovalRule
        fields = '__all__'

class ReviewProcessSerializer(serializers.ModelSerializer):
    class Meta:
        model = ReviewProcess
        fields = '__all__'

class ReviewProcessDetailSerializer(serializers.ModelSerializer):
    class Meta:
        model = ReviewProcess
        fields = '__all__'

class ReviewProcessCreateUpdateSerializer(serializers.ModelSerializer):
    class Meta:
        model = ReviewProcess
        fields = '__all__'
