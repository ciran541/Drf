# views.py
from rest_framework import viewsets
from .models import Blueprint, ApprovalProcess, ApprovalRule, ReviewProcess
from .serializers import BlueprintDetailSerializer, BlueprintCreateUpdateSerializer, ApprovalProcessDetailSerializer, ApprovalProcessCreateUpdateSerializer, ApprovalRuleSerializer, ReviewProcessDetailSerializer, ReviewProcessCreateUpdateSerializer

class BlueprintViewSet(viewsets.ModelViewSet):
    queryset = Blueprint.objects.all()

    def get_serializer_class(self):
        if self.request.method in ['POST', 'PUT', 'PATCH']:
            return BlueprintCreateUpdateSerializer
        return BlueprintDetailSerializer

class ApprovalProcessViewSet(viewsets.ModelViewSet):
    queryset = ApprovalProcess.objects.all()

    def get_serializer_class(self):
        if self.request.method in ['POST', 'PUT', 'PATCH']:
            return ApprovalProcessCreateUpdateSerializer
        return ApprovalProcessDetailSerializer

class ApprovalRuleViewSet(viewsets.ModelViewSet):
    queryset = ApprovalRule.objects.all()
    serializer_class = ApprovalRuleSerializer

class ReviewProcessViewSet(viewsets.ModelViewSet):
    queryset = ReviewProcess.objects.all()

    def get_serializer_class(self):
        if self.request.method in ['POST', 'PUT', 'PATCH']:
            return ReviewProcessCreateUpdateSerializer
        return ReviewProcessDetailSerializer
