from django.db import models
from django.contrib.contenttypes.fields import GenericForeignKey
from django.contrib.contenttypes.models import ContentType
from CRM.general.models import Contact,Account,Task
from django.utils.translation import gettext_lazy as _


class SalesSequence(models.Model):
    SEQUENCE_TYPES = (
        ('outbound', 'Outbound Sequence'),
        ('classic', 'Classic Sequence'),
        ('smart', 'Smart Sequence'),
    )

    name = models.CharField(max_length=100)
    sequence_type = models.CharField(max_length=20, choices=SEQUENCE_TYPES)
    contacts = models.ManyToManyField(Contact, blank=True)
    accounts = models.ManyToManyField(Account, blank=True)
    tasks = models.ManyToManyField(Task, blank=True)

    content_type = models.ForeignKey(ContentType, on_delete=models.CASCADE)
    object_id = models.PositiveIntegerField()
    content_object = GenericForeignKey('content_type', 'object_id')
    def __str__(self):
        return self.name
    
class WorkflowTrigger(models.Model):
    TRIGGER_TYPES = [
        ('record_creation', _('Record Creation')),
        ('field_value_update', _('Field Value Update')),
        ('scheduled_time', _('Scheduled Time')),
        ('campaign_entry_exit', _('Campaign Entry/Exit')),
        ('webform_submission', _('Webform Submission')),
    ]

    workflow = models.ForeignKey('Workflow', on_delete=models.CASCADE, related_name='triggers')
    trigger_type = models.CharField(max_length=20, choices=TRIGGER_TYPES)
    field_name = models.CharField(max_length=100, blank=True, null=True)
    new_field_value = models.CharField(max_length=100, blank=True, null=True)
    scheduled_time = models.DateTimeField(blank=True, null=True)
    campaign = models.CharField(max_length=100, blank=True, null=True)  # Assuming it's a campaign name

    def __str__(self):
        return f"{self.get_trigger_type_display()} Trigger for Workflow: {self.workflow}"


class WorkflowAction(models.Model):
    ACTION_TYPES = [
        ('email', _('Email')),
        ('task', _('Task')),
        ('sms', _('SMS')),
        ('update_field', _('Update Field')),
        ('webhook', _('Webhook')),
    ]

    workflow = models.ForeignKey('Workflow', on_delete=models.CASCADE, related_name='actions')
    action_type = models.CharField(max_length=20, choices=ACTION_TYPES)
    recipients = models.ManyToManyField(Contact, blank=True)
    task = models.ForeignKey(Task, on_delete=models.SET_NULL, blank=True, null=True)
    sms_content = models.TextField(blank=True)
    field_to_update = models.CharField(max_length=100, blank=True)
    new_field_value = models.CharField(max_length=100, blank=True)
    webhook_url = models.URLField(blank=True)

    def __str__(self):
        return f"{self.get_action_type_display()} Action for Workflow: {self.workflow}"


class Workflow(models.Model):
    name = models.CharField(max_length=100, blank=True)
    description = models.TextField(blank=True)
    work_flow_action = models.ForeignKey(WorkflowAction, on_delete=models.CASCADE, blank=True, null=True,related_name='workflowaction')
    work_flow_trigger = models.ForeignKey(WorkflowTrigger, on_delete=models.CASCADE, blank=True, null=True,related_name='triggerflow')

    content_type = models.ForeignKey(ContentType, on_delete=models.CASCADE)
    object_id = models.PositiveIntegerField()
    content_object = GenericForeignKey('content_type', 'object_id')

    def __str__(self):
        return self.name