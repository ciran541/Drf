# urls.py
from django.urls import path, include
from rest_framework.routers import DefaultRouter
from .views import SalesSequenceViewSet, WorkflowViewSet,WorkflowActionViewSet,WorkflowTriggerViewSet

router = DefaultRouter()
router.register(r'sales-sequences', SalesSequenceViewSet)
router.register(r'workflows', WorkflowViewSet)
router.register(r'workflow-actions', WorkflowActionViewSet)
router.register(r'workflow-triggers', WorkflowTriggerViewSet)

urlpatterns = [
    path('', include(router.urls)),
]
