# serializers.py
from rest_framework import serializers
from .models import SalesSequence, Workflow, WorkflowTrigger, WorkflowAction

class WorkflowTriggerSerializer(serializers.ModelSerializer):
    class Meta:
        model = WorkflowTrigger
        fields = '__all__'

class WorkflowActionSerializer(serializers.ModelSerializer):
    class Meta:
        model = WorkflowAction
        fields = '__all__'

class WorkflowDetailSerializer(serializers.ModelSerializer):
    triggers = WorkflowTriggerSerializer(many=True, read_only=True)
    actions = WorkflowActionSerializer(many=True, read_only=True)

    class Meta:
        model = Workflow
        fields = '__all__'

class WorkflowCreateUpdateSerializer(serializers.ModelSerializer):
    class Meta:
        model = Workflow
        fields = '__all__'

class SalesSequenceSerializer(serializers.ModelSerializer):
    class Meta:
        model = SalesSequence
        fields = '__all__'
