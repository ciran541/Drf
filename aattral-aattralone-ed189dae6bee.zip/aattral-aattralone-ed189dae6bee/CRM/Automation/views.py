# views.py
from rest_framework import viewsets
from .models import SalesSequence, Workflow,WorkflowAction, WorkflowTrigger
from .serializers import SalesSequenceSerializer, WorkflowDetailSerializer, WorkflowCreateUpdateSerializer,WorkflowActionSerializer, WorkflowTriggerSerializer


class SalesSequenceViewSet(viewsets.ModelViewSet):
    queryset = SalesSequence.objects.all()

    def get_serializer_class(self):
        if self.request.method in ['POST', 'PUT', 'PATCH']:
            return SalesSequenceSerializer
        return WorkflowDetailSerializer

class WorkflowViewSet(viewsets.ModelViewSet):
    queryset = Workflow.objects.all()

    def get_serializer_class(self):
        if self.request.method in ['POST', 'PUT', 'PATCH']:
            return WorkflowCreateUpdateSerializer
        return WorkflowDetailSerializer

class WorkflowActionViewSet(viewsets.ModelViewSet):
    queryset = WorkflowAction.objects.all()

    def get_serializer_class(self):
        if self.request.method in ['POST', 'PUT', 'PATCH']:
            return WorkflowActionSerializer
        return WorkflowActionSerializer

class WorkflowTriggerViewSet(viewsets.ModelViewSet):
    queryset = WorkflowTrigger.objects.all()

    def get_serializer_class(self):
        if self.request.method in ['POST', 'PUT', 'PATCH']:
            return WorkflowTriggerSerializer
        return WorkflowTriggerSerializer