from django.db import models
from Authentication.models import CustomUser
from django.utils import timezone
from django.contrib.contenttypes.fields import GenericForeignKey
from django.contrib.contenttypes.models import ContentType

'''
This modules are the foundation for organizing customer relationship management (CRM) data.
They act like folders or filing cabinets, categorizing different aspects of interactions with leads, contacts, deals, and more

'''


class Lead(models.Model):

    # Leads: Stores information about potential customers who have expressed interest in your products or services.

    # Lead Status
    STATUS_CHOICES = [
        ('None', 'None'),
        ('Acquired', 'Acquired'),
        ('Active', 'Active'),
        ('Market Failed', 'Market Failed'),
        ('Project Cancelled', 'Project Cancelled'),
        ('Shut Down', 'Shut Down'),
    ]


    # Lead Source
    LEAD_SOURCE_CHOICES = [
        ('None', 'None'),
        ('Advertisement', 'Advertisement'),
        ('Cold Call', 'Cold Call'),
        ('Employee Referral', 'Employee Referral'),
        ('External Referral', 'External Referral'),
        ('Online Store', 'Online Store'),
        ('Partner', 'Partner'),
        ('Public Relations', 'Public Relations'),
        ('Sales Email Alias', 'Sales Email Alias'),
        ('Seminar Partner', 'Seminar Partner'),
        ('Internal Seminar', 'Internal Seminar'),
        ('Trade Show', 'Trade Show'),
        ('Web Download', 'Web Download'),
        ('Web Research', 'Web Research'),
        ('Chat', 'Chat'),
        ('Twitter', 'Twitter'),
        ('Facebook', 'Facebook'),
        ('Google+', 'Google+'),
    ]

    # Industry
    INDUSTRY_CHOICES = [
        ('None', 'None'),
        ('ASP (Application Service Provider)', 'ASP (Application Service Provider)'),
        ('Data/Telecom OEM', 'Data/Telecom OEM'),
        ('ERP (Enterprise Resource Planning)', 'ERP (Enterprise Resource Planning)'),
        ('Government/Military', 'Government/Military'),
        ('Large Enterprise', 'Large Enterprise'),
        ('Management ISV', 'Management ISV'),
        ('MSP (Management Service Provider)', 'MSP (Management Service Provider)'),
        ('Network Equipment Enterprise', 'Network Equipment Enterprise'),
        ('Non-management ISV', 'Non-management ISV'),
        ('Optical Networking', 'Optical Networking'),
        ('Service Provider', 'Service Provider'),
        ('Small/Medium Enterprise', 'Small/Medium Enterprise'),
        ('Storage Equipment', 'Storage Equipment'),
        ('Storage Service Provider', 'Storage Service Provider'),
        ('Systems Integrator', 'Systems Integrator'),
        ('Wireless Industry', 'Wireless Industry'),
    ]
     
    # Lead Status
    LEAD_STATUS_CHOICES = [
        ('None', 'None'),
        ('Attempted to Contact', 'Attempted to Contact'),
        ('Contact in Future', 'Contact in Future'),
        ('Contacted', 'Contacted'),
        ('Junk Lead', 'Junk Lead'),
        ('Lost Lead', 'Lost Lead'),
        ('Not Contacted', 'Not Contacted'),
        ('Pre-Qualified', 'Pre-Qualified'),
        ('Not Qualified', 'Not Qualified'),
    ]

    # Basic Information
    name = models.CharField(max_length=255,blank=True)
    email = models.EmailField()
    phone_number = models.CharField(max_length=20, blank=True, null=True)
    website = models.URLField(blank=True, null=True)
    company = models.CharField(max_length=255, blank=True, null=True)
    # Social Information
    twitter = models.CharField(max_length=100,blank=True)
    skype_id = models.CharField(max_length=100,blank=True)
    secondary_email = models.EmailField(blank=True)
    
    status = models.CharField(max_length=50, choices=STATUS_CHOICES, default='None',blank=True)
    
    # Lead Qualification
    lead_status = models.CharField(max_length=50, choices=LEAD_STATUS_CHOICES, default='None',blank=True)
    lead_source = models.CharField(max_length=50, choices=LEAD_SOURCE_CHOICES, default='None',blank=True)
    industry = models.CharField(max_length=100, choices=INDUSTRY_CHOICES, default='None',blank=True)
    annual_revenue = models.DecimalField(max_digits=15, decimal_places=2,blank=True)  # Currency
    no_of_employees = models.IntegerField(blank=True)
    description = models.TextField(blank=True)
    lead_image = models.ImageField(upload_to='lead_images/', blank=True, null=True)
    
    # Additional Details
    address = models.JSONField(blank=True, null=True)
    job_title = models.CharField(max_length=100, blank=True, null=True)
    description = models.TextField(blank=True, null=True)

    # # Lead Conversion   Need to the model after creation 
    # converted_account = models.ForeignKey('Account', on_delete=models.SET_NULL, blank=True, null=True)
    # converted_contact = models.ForeignKey('Contact', on_delete=models.SET_NULL, blank=True, null=True)
    # converted_deal = models.ForeignKey('Deal', on_delete=models.SET_NULL, blank=True, null=True)

    # Ownership and Audit
    lead_owner = models.ForeignKey(CustomUser, on_delete=models.SET_NULL, related_name='owned_leads', blank=True, null=True)
    created_by = models.ForeignKey(CustomUser, on_delete=models.SET_NULL, related_name='leads_created', blank=True, null=True)
    modified_by = models.ForeignKey(CustomUser, on_delete=models.SET_NULL, related_name='leads_modified', blank=True, null=True)
    
    # Custom Fields (Example: Budget, Preferred Product)
    budget = models.DecimalField(max_digits=10, decimal_places=2, blank=True, null=True)
    preferred_product = models.CharField(max_length=100, blank=True, null=True)
    
    # Timestamps
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    
    def __str__(self):
        return self.name
    

class Contact(models.Model):

    # Contacts: Stores detailed information about individual contacts within your customer base.

    first_name = models.CharField(max_length=100)
    last_name = models.CharField(max_length=100)
    salutation = models.CharField(max_length=10, blank=True, null=True)
    email = models.EmailField()
    phone_number = models.CharField(max_length=20, blank=True, null=True)
    mobile_number = models.CharField(max_length=20, blank=True, null=True)
    job_title = models.CharField(max_length=100, blank=True, null=True)
    department = models.CharField(max_length=100, blank=True, null=True)
    reporting_to = models.ForeignKey('self', on_delete=models.SET_NULL, blank=True, null=True)
    fax = models.CharField(max_length=20, blank=True, null=True)
    website = models.URLField(blank=True, null=True)
    mailing_address = models.TextField(blank=True, null=True)
    social_linkedin = models.URLField(blank=True, null=True)
    social_twitter = models.URLField(blank=True, null=True)
    description = models.TextField(blank=True, null=True)

    # Custom Fields
    preferred_communication = models.CharField(max_length=50, blank=True, null=True)
    purchase_history = models.TextField(blank=True, null=True)
    birthday = models.DateField(blank=True, null=True)
    interests = models.TextField(blank=True, null=True)

    # Ownership and Audit
    contact_owner = models.ForeignKey(CustomUser, on_delete=models.SET_NULL, related_name='owned_contact', blank=True, null=True)
    created_by = models.ForeignKey(CustomUser, on_delete=models.SET_NULL, related_name='contact_created', blank=True, null=True)
    modified_by = models.ForeignKey(CustomUser, on_delete=models.SET_NULL, related_name='contact_modified', blank=True, null=True)

    # Relationships
    # account = models.ForeignKey('Account', on_delete=models.SET_NULL, blank=True, null=True)
    # deals = models.ManyToManyField('Deal', blank=True)

    class Meta:
        verbose_name = 'Contact'
        verbose_name_plural = 'Contacts'

    def __str__(self):
        return f"{self.first_name} {self.last_name}"
    

class Account(models.Model):

    # Accounts: Houses data about the companies or organizations you do business with.

    # Basic fields
    account_name = models.CharField(max_length=255, blank=True,verbose_name='Account Name')
    account_number = models.BigIntegerField(verbose_name='Account Number')
    account_owner = models.ForeignKey(CustomUser, on_delete=models.CASCADE,blank=True, null=True, verbose_name='Account Owner')
    account_site = models.CharField(max_length=255, blank=True, verbose_name='Account Site')
    account_type = models.CharField(max_length=100, verbose_name='Account Type')
    annual_revenue = models.DecimalField(max_digits=12, decimal_places=2, null=True, blank=True, verbose_name='Annual Revenue')
    billing_address = models.JSONField(blank=True, null=True)
    billing_country = models.CharField(max_length=100, blank=True, verbose_name='Billing Country')
    created_by = models.CharField(max_length=255, verbose_name='Created By')
    description = models.TextField(blank=True, verbose_name='Description')
    employees = models.IntegerField(null=True, blank=True, verbose_name='Employees')
    fax = models.CharField(max_length=50, blank=True, verbose_name='Fax')
    industry = models.CharField(max_length=100, blank=True, verbose_name='Industry')
    modified_by = models.CharField(max_length=255, verbose_name='Modified By')
    ownership = models.CharField(max_length=100, verbose_name='Ownership')
    parent_account = models.ForeignKey('self', on_delete=models.CASCADE, blank=True, null=True, related_name='child_accounts', verbose_name='Parent Account')
    phone = models.CharField(max_length=50, blank=True, verbose_name='Phone')
    rating = models.CharField(max_length=100, blank=True, verbose_name='Rating')
    shipping_address = models.JSONField(blank=True, null=True)
    shipping_country = models.CharField(max_length=100, blank=True, verbose_name='Shipping Country')
    sic_code = models.CharField(max_length=10, blank=True, verbose_name='SIC Code')
    ticker_symbol = models.CharField(max_length=50, blank=True, verbose_name='Ticker Symbol')
    website = models.URLField(max_length=200, blank=True, verbose_name='Website')


    def __str__(self):
        return self.account_name

    class Meta:
        verbose_name_plural = "Accounts"


class Deal(models.Model):

    # Deals: Tracks the sales pipeline, including opportunities (deals) in various stages.

    STAGE_CHOICES = [
        ('Prospecting', 'Prospecting'),
        ('Qualification', 'Qualification'),
        ('Negotiation', 'Negotiation'),
        ('Closed Won', 'Closed Won'),
        ('Closed Lost', 'Closed Lost'),
    ]

    TYPE_CHOICES = [
        ('New Business', 'New Business'),
        ('Upsell', 'Upsell'),
        ('Renewal', 'Renewal'),
        ('Other', 'Other'),
    ]

    LEAD_SOURCE_CHOICES = [
        ('None', 'None'),
        ('Advertisement', 'Advertisement'),
        ('Cold Call', 'Cold Call'),
        ('Employee Referral', 'Employee Referral'),
        ('External Referral', 'External Referral'),
        ('Online Store', 'Online Store'),
        ('Partner', 'Partner'),
        ('Public Relations', 'Public Relations'),
        ('Sales Email Alias', 'Sales Email Alias'),
        ('Seminar Partner', 'Seminar Partner'),
        ('Internal Seminar', 'Internal Seminar'),
        ('Trade Show', 'Trade Show'),
        ('Web Download', 'Web Download'),
        ('Web Research', 'Web Research'),
        ('Chat', 'Chat'),
        ('Twitter', 'Twitter'),
        ('Facebook', 'Facebook'),
        ('Google+', 'Google+'),
    ]

    deal_name = models.CharField(max_length=255, unique=True, blank=True)
    deal_owner = models.ForeignKey(CustomUser, on_delete=models.CASCADE, blank=True, null=True)
    account = models.ForeignKey('Account', on_delete=models.CASCADE, blank=True, null=True)
    contact = models.ForeignKey('Contact', on_delete=models.CASCADE, blank=True, null=True)
    potential_value = models.DecimalField(max_digits=12, decimal_places=2, blank=True, null=True)
    stage = models.CharField(max_length=20, choices=STAGE_CHOICES, blank=True)
    close_date = models.DateField(blank=True, null=True)
    probability = models.IntegerField(default=0, help_text='Probability of deal closure in percentage', blank=True, null=True)
    type = models.CharField(max_length=20, choices=TYPE_CHOICES, blank=True)
    lead_source = models.CharField(max_length=50, choices=LEAD_SOURCE_CHOICES, default='None',blank=True)
    description = models.TextField(blank=True)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    # Additional fields (can be customized based on your needs)
    # task_management = models.ManyToManyField('Task', related_name='deals', blank=True)
    email_integration_enabled = models.BooleanField(default=False,blank=True)
    web_forms_enabled = models.BooleanField(default=False,blank=True)
    forecasting_enabled = models.BooleanField(default=False,blank=True)
    workflow_automation_enabled = models.BooleanField(default=False,blank=True)
    reports_and_analytics_enabled = models.BooleanField(default=False,blank=True)

    class Meta:
        verbose_name = 'Deal'
        verbose_name_plural = 'Deals'

    def __str__(self):
        return self.deal_name
    

class Task(models.Model):
    STATUS_CHOICES = [
        ('Not Started', 'Not Started'),
        ('In Progress', 'In Progress'),
        ('Completed', 'Completed'),
        ('Deferred', 'Deferred'),
        ('Cancelled', 'Cancelled'),
    ]

    PRIORITY_CHOICES = [
        ('Low', 'Low'),
        ('Medium', 'Medium'),
        ('High', 'High'),
    ]

    REPEAT_CHOICES = [
        ('Daily', 'Daily'),
        ('Weekly', 'Weekly'),
        ('Monthly', 'Monthly'),
        ('Yearly', 'Yearly'),
    ]

    subject = models.CharField(max_length=255,blank=True)
    due_date = models.DateField(blank=True, null=True)
    task_owner = models.ForeignKey(CustomUser, on_delete=models.CASCADE,blank=True, null=True,related_name='crmtaskowner')  
    account = models.ForeignKey('Account', on_delete=models.CASCADE,blank=True, null=True,related_name='taskaccount')
    contact = models.ForeignKey('Contact', on_delete=models.CASCADE, blank=True, null=True,related_name='taskcontact') 
    lead = models.ForeignKey('Lead', on_delete=models.CASCADE, blank=True, null=True, related_name='tasks')
    status = models.CharField(max_length=20, choices=STATUS_CHOICES, default='Not Started',blank=True, null=True)
    priority = models.CharField(max_length=10, choices=PRIORITY_CHOICES, default='High',blank=True, null=True)
    reminder = models.DateTimeField(blank=True, null=True)
    repeat = models.CharField(max_length=20, choices=REPEAT_CHOICES, blank=True, null=True)
    description = models.TextField(blank=True)

    # Additional custom fields
    closed_time = models.DateTimeField(blank=True, null=True)
    created_by = models.CharField(max_length=255)
    modified_by = models.CharField(max_length=255)

    def is_overdue(self):
        """
        Method to check if the task is overdue based on the due date.
        """
        if self.due_date and self.status != 'Completed':
            return self.due_date < timezone.now().date()
        return False

    def is_closed(self):
        """
        Method to check if the task is closed.
        """
        return self.status == 'Completed' or self.closed_time is not None

    def is_assigned_to_me(self, user):
        """
        Method to check if the task is assigned to a specific user.
        """
        return self.task_owner == user

    def is_due_today(self):
        """
        Method to check if the task is due today.
        """
        return self.due_date == timezone.now().date()

    def is_due_tomorrow(self):
        """
        Method to check if the task is due tomorrow.
        """
        return self.due_date == (timezone.now() + timezone.timedelta(days=1)).date()

    def is_in_next_7_days(self):
        """
        Method to check if the task is due within the next 7 days.
        """
        if self.due_date:
            return timezone.now().date() <= self.due_date <= (timezone.now() + timezone.timedelta(days=7)).date()
        return False

    def __str__(self):
        return self.subject
    

class Meeting(models.Model):
    MEETING_REPEAT_CHOICES = [
        ('none', 'None'),
        ('daily', 'Daily'),
        ('weekly', 'Weekly'),
        ('monthly', 'Monthly'),
        ('yearly', 'Yearly'),
    ]

    MEETING_REMINDER_CHOICES = [
        (None, 'None'),
        (5, '5 minutes before'),
        (10, '10 minutes before'),
        (15, '15 minutes before'),
        (30, '30 minutes before'),
        (60, '1 hour before'),
    ]

    host = models.ForeignKey(CustomUser, on_delete=models.CASCADE, related_name='hosted_meetings')
    location = models.CharField(max_length=255)
    all_day = models.BooleanField(default=False)
    start_time = models.DateTimeField()
    end_time = models.DateTimeField()
    content_type = models.ForeignKey(ContentType, on_delete=models.CASCADE,null=True, blank=True)
    object_id = models.PositiveIntegerField(null=True, blank=True)
    related_to = GenericForeignKey('content_type', 'object_id')
    repeat = models.CharField(max_length=10, choices=MEETING_REPEAT_CHOICES, default='none')
    participants = models.ManyToManyField(Contact, related_name='meetings_attending', blank=True)
    reminder = models.IntegerField(choices=MEETING_REMINDER_CHOICES, null=True, blank=True)
    description = models.TextField(blank=True)

    def __str__(self):
        return f"Meeting {self.id} - {self.start_time.strftime('%d/%m/%Y %I:%M %p')}"
    
    '''To Sending a POST Request'''

    #     {
    #   "host": 1,
    #   "location": "Office",
    #   "all_day": false,
    #   "start_time": "2024-04-10T13:00:00",
    #   "end_time": "2024-04-10T14:00:00", 
    #   "content_type": 276,  // ID for Lead or Contact  ###  Lead_id = 276 , Contact_id = 277
    #   "object_id": 2,           // ID of the Lead or Contact
    #   "repeat": "none",
    #   "participants": [1, 2],
    #   "reminder": 15,
    #   "description": "Meeting about new opportunities"
    # }


class CallSchedule(models.Model):
    CALL_TYPE_CHOICES = [
        ('outbound', 'Outbound'),
        ('inbound', 'Inbound'),
    ]

    CALL_STATUS_CHOICES = [
        ('scheduled', 'Scheduled'),
        ('completed', 'Completed'),
        ('missed', 'Missed'),
        ('canceled', 'Canceled'),
    ]

    call_to_content_type = models.ForeignKey(ContentType, on_delete=models.CASCADE, related_name='call_to')
    call_to_object_id = models.PositiveIntegerField()
    call_to = GenericForeignKey('call_to_content_type', 'call_to_object_id')

    related_to = models.ForeignKey(Deal, on_delete=models.CASCADE, related_name='related_todeal')

    call_type = models.CharField(max_length=10, choices=CALL_TYPE_CHOICES)
    call_status = models.CharField(max_length=20, choices=CALL_STATUS_CHOICES, default='scheduled')
    call_start_time = models.DateTimeField()
    call_owner = models.ForeignKey(CustomUser, on_delete=models.CASCADE)
    subject = models.CharField(max_length=255)
    reminder = models.CharField(max_length=50, blank=True)
    call_purpose = models.CharField(max_length=255, blank=True)
    call_agenda = models.TextField(blank=True)

    def __str__(self):
        return f"Call Schedule ({self.call_to}) - {self.call_start_time.strftime('%d/%m/%Y %I:%M %p')}"
    

#     {
#   "call_to_content_type_id": 0,  // Content type ID for Contact ###  Lead_id = 276 , Contact_id = 277
#   "call_to_object_id": 1,          // ID of the Contact
#   "related_to_id": 1,              // ID of the related Deal
#   "call_type": "outbound",
#   "call_status": "scheduled",
#   "call_start_time": "2024-04-10T18:00:00",
#   "call_owner": 1,                 // User ID of the call owner
#   "subject": "Call scheduled with Kris Marrier",
#   "reminder": "None",
#   "call_purpose": "",
#   "call_agenda": ""
# }

class Campaign(models.Model):
    CAMPAIGN_TYPES = [
        ('conference', 'Conference'),
        ('webinar', 'Webinar'),
        ('trade_show', 'Trade Show'),
        ('public_relations', 'Public Relations'),
        ('partners', 'Partners'),
        ('referral_program', 'Referral Program'),
        ('advertisement', 'Advertisement'),
        ('banner_ads', 'Banner Ads'),
        ('direct_mail', 'Direct Mail'),
        ('telemarketing', 'Telemarketing'),
        ('other', 'Other')
    ]

    name = models.CharField(max_length=255,blank=True)
    description = models.TextField( blank=True)
    campaign_type = models.CharField(max_length=20, choices=CAMPAIGN_TYPES,null=True, blank=True)
    target_audience = models.ManyToManyField('Contact', related_name='campaigns', blank=True)
    start_date = models.DateTimeField(null=True, blank=True)
    end_date = models.DateTimeField(null=True, blank=True)
    budget = models.DecimalField(max_digits=10, decimal_places=2, null=True, blank=True)

    def __str__(self):
        return self.name
    
class Product(models.Model):
    # Basic Information
    product_name = models.CharField(max_length=255)
    product_owner = models.ForeignKey(CustomUser, on_delete=models.CASCADE)  # Assuming product owner is a user
    product_code = models.CharField(max_length=50)
    product_active = models.BooleanField(default=True)
    product_category = models.CharField(max_length=100, blank=True, null=True)
    
    # Dates
    sales_start_date = models.DateField(null=True, blank=True)
    sales_end_date = models.DateField(null=True, blank=True)
    support_start_date = models.DateField(null=True, blank=True)
    support_end_date = models.DateField(null=True, blank=True)
    
    # Price Information
    unit_price = models.DecimalField(max_digits=10, decimal_places=2)
    tax = models.CharField(max_length=100, blank=True)  # This could be a MultiSelectField if using a custom field
    taxable = models.BooleanField(default=False)
    commission_rate = models.DecimalField(max_digits=5, decimal_places=2, null=True, blank=True)
    
    # Stock Information
    usage_unit = models.CharField(max_length=100, blank=True)
    quantity_in_stock = models.DecimalField(max_digits=10, decimal_places=2, default=0)
    qty_ordered = models.DecimalField(max_digits=10, decimal_places=2, default=0)
    reorder_level = models.DecimalField(max_digits=10, decimal_places=2, null=True, blank=True)
    quantity_in_demand = models.DecimalField(max_digits=10, decimal_places=2, default=0)
    
    # Additional Information
    description = models.TextField(blank=True)
    product_image = models.ImageField(upload_to='product_images/', blank=True)
    vendor_name = models.CharField(max_length=255, blank=True)
    manufacturer = models.CharField(max_length=255, blank=True)
    
    # Audit Information
    created_by = models.ForeignKey(CustomUser, on_delete=models.SET_NULL, related_name='products_created', null=True, blank=True)
    modified_by = models.ForeignKey(CustomUser, on_delete=models.SET_NULL, related_name='products_modified', null=True, blank=True)

    def __str__(self):
        return self.product_name


class Case(models.Model):

    # Define choices 
    CASE_ORIGIN_CHOICES = (
        ('web', 'Web'),
        ('phone', 'Phone'),
        ('email', 'Email'),
        ('chat', 'Chat'),
        ('in_person', 'In Person'),
    )

    CASE_REASON_CHOICES = (
        ('sales_inquiry', 'Sales Inquiry'),
        ('technical_support', 'Technical Support'),
        ('billing_issue', 'Billing Issue'),
        ('general_question', 'General Question'),
    )

    PRIORITY_CHOICES = (
        ('low', 'Low'),
        ('medium', 'Medium'),
        ('high', 'High'),
    )

    STATUS_CHOICES = (
        ('new', 'New'),
        ('in_progress', 'In Progress'),
        ('resolved', 'Resolved'),
        ('closed', 'Closed'),
    )

    TYPE_CHOICES = (
        ('issue', 'Issue'),
        ('question', 'Question'),
        ('feature_request', 'Feature Request'),
    )
    account_name = models.ForeignKey('Account', on_delete=models.CASCADE)
    add_comment = models.TextField(blank=True, null=True)
    case_number = models.BigIntegerField(null=True, blank=True)
    case_origin = models.CharField(max_length=255, choices=CASE_ORIGIN_CHOICES,null=True, blank=True)
    case_owner = models.ForeignKey(CustomUser, on_delete=models.CASCADE,null=True, blank=True)
    case_reason = models.CharField(max_length=255, choices=CASE_REASON_CHOICES,null=True, blank=True)
    created_by = models.CharField(max_length=255, blank=True)
    deal_name = models.ForeignKey('Deal', on_delete=models.CASCADE,null=True, blank=True)
    description = models.TextField(blank=True, null=True)
    email = models.EmailField(blank=True, null=True)
    internal_comments = models.TextField(blank=True, null=True)
    modified_by = models.CharField(max_length=255, blank=True)
    no_of_comments = models.IntegerField(default=0,null=True, blank=True)
    phone = models.CharField(max_length=20, blank=True, null=True)
    priority = models.CharField(max_length=255, choices=PRIORITY_CHOICES,null=True, blank=True)
    product_name = models.ForeignKey('Product', on_delete=models.CASCADE,null=True, blank=True)
    reported_by = models.CharField(max_length=255,null=True, blank=True)
    solution = models.TextField(blank=True, null=True)
    status = models.CharField(max_length=255, choices=STATUS_CHOICES,null=True, blank=True)
    subject = models.CharField(max_length=255,blank=True)
    type = models.CharField(max_length=255, choices=TYPE_CHOICES,null=True, blank=True)

    def __str__(self):
        return f"Case {self.case_number} - {self.subject}"


class Solution(models.Model):
    STATUS_CHOICES = [
        ('Active', 'Active'),
        ('Discontinued', 'Discontinued'),
        ('On Sale', 'On Sale'),
    ]

    name = models.CharField(max_length=255, unique=True)
    solution_owner = models.ForeignKey(CustomUser, on_delete=models.CASCADE,null=True, blank=True,related_name='solutionowner')
    description = models.TextField(blank=True)
    product = models.ForeignKey(Product, on_delete=models.CASCADE,null=True, blank=True, related_name='productsolution')
    category = models.CharField(max_length=100)
    price = models.DecimalField(max_digits=10, decimal_places=2)
    cost_price = models.DecimalField(max_digits=10, decimal_places=2, blank=True, null=True)
    vendor = models.CharField(max_length=255, blank=True, null=True)
    tax_information = models.CharField(max_length=255, blank=True)
    status = models.CharField(max_length=20, choices=STATUS_CHOICES, default='Active')
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        verbose_name = 'Solution'
        verbose_name_plural = 'Solutions'

    def __str__(self):
        return self.name
    

'''

Need to add models relevent to inventory and sales or we can integrate the Finance App or Inventory App
Models like - Quotes,Sales Orders,Purchase Orders,Invoices,Campaigns,Vendors,Price Books
either in this module or in a new module.

'''