# views.py
from rest_framework import viewsets,status
from rest_framework.decorators import action
from rest_framework.response import Response
from django.db.models import Q
from django.utils import timezone
from django.shortcuts import get_object_or_404
from django.contrib.contenttypes.models import ContentType
from .models import Lead,Contact,Account,Deal,Task,Meeting,CallSchedule,Campaign, Product, Case, Solution
from .serializers import (LeadDetailSerializer, LeadCreateUpdateSerializer,ContactCreateUpdateSerializer,
ContactDetailSerializer,AccountCreateUpdateSerializer,AccountDetailSerializer,DealCreateUpdateSerializer,
DealDetailSerializer,TaskCreateUpdateSerializer,TaskDetailSerializer,MeetingSerializer,CallScheduleSerializer,
CampaignDetailSerializer, CampaignCreateUpdateSerializer,ProductDetailSerializer, ProductCreateUpdateSerializer,
CaseDetailSerializer, CaseCreateUpdateSerializer,SolutionDetailSerializer, SolutionCreateUpdateSerializer
)


class LeadViewSet(viewsets.ModelViewSet):
    queryset = Lead.objects.all()
    serializer_class = LeadDetailSerializer

    def get_serializer_class(self):
        if self.request.method in ['POST', 'PUT', 'PATCH']:
            return LeadCreateUpdateSerializer
        return LeadDetailSerializer

    @action(detail=False, methods=['GET'])
    def filter_leads(self, request):
        owner_id = request.query_params.get('owner_id')
        source = request.query_params.get('source')
        status = request.query_params.get('status')
        industry = request.query_params.get('industry')

        # Start with all leads queryset
        leads = Lead.objects.all()

        # Apply filters based on provided parameters
        if owner_id:
            leads = leads.filter(lead_owner_id=owner_id)
        if source:
            leads = leads.filter(lead_source=source)
        if status:
            leads = leads.filter(lead_status=status)
        if industry:
            leads = leads.filter(industry=industry)

        serializer = self.get_serializer(leads, many=True)
        return Response(serializer.data)
    

class ContactViewSet(viewsets.ModelViewSet):
    queryset = Contact.objects.all()

    def get_serializer_class(self):
        if self.request.method in ['POST', 'PUT', 'PATCH']:
            return ContactCreateUpdateSerializer
        return ContactDetailSerializer

    @action(detail=False, methods=['GET'])
    def filter_contacts(self, request):
        owner_id = request.query_params.get('owner_id')
        account_name = request.query_params.get('account_name')
        contact_name = request.query_params.get('contact_name')
        created_by_id = request.query_params.get('created_by_id')

        contacts = Contact.objects.all()

        if owner_id:
            contacts = contacts.filter(contact_owner_id=owner_id)
        if account_name:
            contacts = contacts.filter(account__name__icontains=account_name)
        if contact_name:
            contacts = contacts.filter(
                Q(first_name__icontains=contact_name) | 
                Q(last_name__icontains=contact_name)
            )
        if created_by_id:
            contacts = contacts.filter(created_by_id=created_by_id)

        serializer = self.get_serializer(contacts, many=True)
        return Response(serializer.data)
    

class AccountViewSet(viewsets.ModelViewSet):
    queryset = Account.objects.all()
    serializer_class = AccountDetailSerializer

    def get_serializer_class(self):
        if self.request.method in ['POST', 'PUT', 'PATCH']:
            return AccountCreateUpdateSerializer
        return AccountDetailSerializer

    @action(detail=False, methods=['GET'])
    def filter_accounts(self, request):
        name = request.query_params.get('name')
        number = request.query_params.get('number')
        owner_id = request.query_params.get('owner_id')
        site = request.query_params.get('site')

        # Start with all accounts queryset
        accounts = Account.objects.all()

        # Apply filters based on provided parameters
        if name:
            accounts = accounts.filter(account_name__icontains=name)
        if number:
            accounts = accounts.filter(account_number=number)
        if owner_id:
            accounts = accounts.filter(account_owner_id=owner_id)
        if site:
            accounts = accounts.filter(account_site__icontains=site)

        serializer = self.get_serializer(accounts, many=True)
        return Response(serializer.data)
    

class DealViewSet(viewsets.ModelViewSet):
    queryset = Deal.objects.all()
    serializer_class = DealDetailSerializer

    def get_serializer_class(self):
        if self.request.method in ['POST', 'PUT', 'PATCH']:
            return DealCreateUpdateSerializer
        return DealDetailSerializer

    @action(detail=False, methods=['GET'])
    def filter_deals(self, request):
        deal_owner_id = request.query_params.get('deal_owner_id')
        account_id = request.query_params.get('account_id')
        lead_source = request.query_params.get('lead_source')
        contact_id = request.query_params.get('contact_id')
        deal_type = request.query_params.get('type')

        # Start with all deals queryset
        deals = Deal.objects.all()

        # Apply filters based on provided parameters
        if deal_owner_id:
            deals = deals.filter(deal_owner_id=deal_owner_id)
        if account_id:
            deals = deals.filter(account_id=account_id)
        if lead_source:
            deals = deals.filter(lead_source=lead_source)
        if contact_id:
            deals = deals.filter(contact_id=contact_id)
        if deal_type:
            deals = deals.filter(type=deal_type)

        serializer = self.get_serializer(deals, many=True)
        return Response(serializer.data)
    
class TaskViewSet(viewsets.ModelViewSet):
    queryset = Task.objects.all()
    

    def get_serializer_class(self):
        if self.request.method in ['POST', 'PUT', 'PATCH']:
            return TaskCreateUpdateSerializer
        return TaskDetailSerializer
    
    # Custom action to create a Task for Lead 
    @action(detail=True, methods=['post'])
    def create_task_for_lead(self, request, pk=None):
        lead = get_object_or_404(Lead, pk=pk)
        serializer = self.get_serializer(data=request.data)
        if serializer.is_valid():
            serializer.save(lead=lead)
            return Response(serializer.data, status=201)
        return Response(serializer.errors, status=400)
    

    # Custom action to create a Task for Contact
    @action(detail=True, methods=['post'])
    def create_task_for_contact(self, request, pk=None):
        contact = get_object_or_404(Contact, pk=pk)
        serializer = self.get_serializer(data=request.data)
        if serializer.is_valid():
            serializer.save(contact=contact)
            return Response(serializer.data, status=201)
        return Response(serializer.errors, status=400)
    
    # Custom action to create a Task for Account
    @action(detail=True, methods=['post'])
    def create_task_for_Account(self, request, pk=None):
        contact = get_object_or_404(Account, pk=pk)
        serializer = self.get_serializer(data=request.data)
        if serializer.is_valid():
            serializer.save(contact=contact)
            return Response(serializer.data, status=201)
        return Response(serializer.errors, status=400)
    
    # Custom action to create a Task for Deal
    @action(detail=True, methods=['post'])
    def create_task_for_Deal(self, request, pk=None):
        contact = get_object_or_404(Deal, pk=pk)
        serializer = self.get_serializer(data=request.data)
        if serializer.is_valid():
            serializer.save(contact=contact)
            return Response(serializer.data, status=201)
        return Response(serializer.errors, status=400)
    
    @action(detail=False, methods=['get'])
    def get_queryset(self):
        user = self.request.user

        # Define query filters based on different query parameters
        if self.action == 'all_tasks':
            return Task.objects.all()
        elif self.action == 'closed_tasks':
            return Task.objects.filter(status='Completed')
        elif self.action == 'my_closed_tasks':
            return Task.objects.filter(Q(status='Completed') & Q(task_owner=user))
        elif self.action == 'my_next_7_days_overdue_tasks':
            return Task.objects.filter(Q(task_owner=user) & (Q(due_date__lte=timezone.now().date()) | Q(due_date__range=[timezone.now().date(), timezone.now().date() + timezone.timedelta(days=7)])))
        elif self.action == 'my_open_tasks':
            return Task.objects.filter(Q(task_owner=user) & ~Q(status='Completed'))
        elif self.action == 'my_overdue_tasks':
            return Task.objects.filter(Q(task_owner=user) & Q(due_date__lt=timezone.now().date()) & ~Q(status='Completed'))
        elif self.action == 'my_tasks':
            return Task.objects.filter(task_owner=user)
        elif self.action == 'my_today_overdue_tasks':
            return Task.objects.filter(Q(task_owner=user) & (Q(due_date__lt=timezone.now().date()) | Q(due_date=timezone.now().date())) & ~Q(status='Completed'))
        elif self.action == 'my_today_tasks':
            return Task.objects.filter(Q(task_owner=user) & Q(due_date=timezone.now().date()) & ~Q(status='Completed'))
        elif self.action == 'my_tomorrows_tasks':
            return Task.objects.filter(Q(task_owner=user) & Q(due_date=(timezone.now() + timezone.timedelta(days=1)).date()) & ~Q(status='Completed'))
        elif self.action == 'next_7_days_overdue_tasks':
            return Task.objects.filter(Q(due_date__lt=timezone.now().date()) | Q(due_date__range=[timezone.now().date(), timezone.now().date() + timezone.timedelta(days=7)]))
        elif self.action == 'open_tasks':
            return Task.objects.filter(~Q(status='Completed'))
        elif self.action == 'overdue_tasks':
            return Task.objects.filter(Q(due_date__lt=timezone.now().date()) & ~Q(status='Completed'))

        return super().get_queryset()

    # Method to GET closed tasks
    @action(detail=False, methods=['get'])
    def closed_tasks(self, request):
        queryset = self.get_queryset()
        serializer = self.get_serializer(queryset, many=True)
        return Response(serializer.data)
    
    # Method to filter the Task by the given fields 
    @action(detail=False, methods=['GET'])
    def filter_tasks(self, request):
        due_date = request.query_params.get('due_date')
        status = request.query_params.get('status')
        priority = request.query_params.get('priority')
        contact_id = request.query_params.get('contact')
        account_id = request.query_params.get('account')
        task_owner_id = request.query_params.get('task_owner')

        # Start with all tasks queryset
        tasks = Task.objects.all()

        # Apply filters based on provided parameters
        if due_date:
            tasks = tasks.filter(due_date=due_date)
        if status:
            tasks = tasks.filter(status=status)
        if priority:
            tasks = tasks.filter(priority=priority)
        if contact_id:
            tasks = tasks.filter(contact_id=contact_id)
        if account_id:
            tasks = tasks.filter(account_id=account_id)
        if task_owner_id:
            tasks = tasks.filter(task_owner_id=task_owner_id)

        serializer = self.get_serializer(tasks, many=True)
        return Response(serializer.data)
    
class MeetingViewSet(viewsets.ModelViewSet):
    queryset = Meeting.objects.all()
    serializer_class = MeetingSerializer

    def get_serializer_context(self):
        # Map each related model to its serializer class
        related_serializer_map = {
            Lead: LeadDetailSerializer,
            Contact: ContactDetailSerializer,
            # Add more mappings as needed for other related models
        }
        return {'related_serializer_map': related_serializer_map}

    def perform_create(self, serializer):
        related_to_data = self.request.data.get('related_to', None)

        if related_to_data:
            content_type_name = related_to_data.get('content_type', None)
            object_id = related_to_data.get('object_id', None)

            if content_type_name and object_id:
                try:
                    content_type = ContentType.objects.get(model=content_type_name)
                    serializer.save(content_type=content_type, object_id=object_id)
                    return Response(serializer.data, status=status.HTTP_201_CREATED)
                except ContentType.DoesNotExist:
                    return Response({"error": f"Invalid content type: {content_type_name}"}, status=status.HTTP_400_BAD_REQUEST)
            else:
                return Response({"error": "related_to must contain 'content_type' and 'object_id'"}, status=status.HTTP_400_BAD_REQUEST)

        # If no related_to data provided, proceed with default serializer save
        serializer.save()
        return Response(serializer.data, status=status.HTTP_201_CREATED)

    def perform_update(self, serializer):
        related_to_data = self.request.data.get('related_to', None)

        if related_to_data:
            content_type_name = related_to_data.get('content_type', None)
            object_id = related_to_data.get('object_id', None)

            if content_type_name and object_id:
                try:
                    content_type = ContentType.objects.get(model=content_type_name)
                    serializer.save(content_type=content_type, object_id=object_id)
                except ContentType.DoesNotExist:
                    return Response({"error": f"Invalid content type: {content_type_name}"}, status=status.HTTP_400_BAD_REQUEST)
            else:
                return Response({"error": "related_to must contain 'content_type' and 'object_id'"}, status=status.HTTP_400_BAD_REQUEST)

        # Proceed with default serializer save if no related_to data provided or valid
        serializer.save()
        return Response(serializer.data, status=status.HTTP_200_OK)

    @action(detail=False, methods=['GET'])
    def filter_meetings(self, request):
        host_id = request.query_params.get('host_id')
        location = request.query_params.get('location')
        related_to_type = request.query_params.get('related_to_type')
        related_to_id = request.query_params.get('related_to_id')
        participant_ids = request.query_params.getlist('participant_ids')

        # Start with all meetings queryset
        meetings = Meeting.objects.all()

        # Apply filters based on provided parameters
        if host_id:
            meetings = meetings.filter(host_id=host_id)
        if location:
            meetings = meetings.filter(location__icontains=location)
        if related_to_type and related_to_id:
            meetings = meetings.filter(related_to__content_type__model=related_to_type, related_to__object_id=related_to_id)
        if participant_ids:
            meetings = meetings.filter(participants__id__in=participant_ids)

        serializer = self.get_serializer(meetings, many=True)
        return Response(serializer.data)
    
class CallScheduleViewSet(viewsets.ModelViewSet):
    queryset = CallSchedule.objects.all()
    serializer_class = CallScheduleSerializer

    def get_serializer_context(self):
        # Map each related model to its serializer class
        related_serializer_map = {
            Lead: LeadDetailSerializer,  # Use appropriate serializer for Lead
            Contact: ContactDetailSerializer,  # Use appropriate serializer for Contact
            # Add more mappings as needed for other related models
        }
        return {'related_serializer_map': related_serializer_map}

    def perform_create(self, serializer):
        call_to_data = self.request.data.get('call_to', None)

        if call_to_data:
            content_type_name = call_to_data.get('content_type', None)
            object_id = call_to_data.get('object_id', None)

            if content_type_name and object_id:
                try:
                    content_type = ContentType.objects.get(model=content_type_name)
                    serializer.save(call_to_content_type=content_type, call_to_object_id=object_id)
                    return Response(serializer.data, status=status.HTTP_201_CREATED)
                except ContentType.DoesNotExist:
                    return Response({"error": f"Invalid content type: {content_type_name}"}, status=status.HTTP_400_BAD_REQUEST)
            else:
                return Response({"error": "call_to must contain 'content_type' and 'object_id'"}, status=status.HTTP_400_BAD_REQUEST)

        # Proceed with default serializer save if no call_to data provided or valid
        serializer.save()
        return Response(serializer.data, status=status.HTTP_201_CREATED)

    def perform_update(self, serializer):
        call_to_data = self.request.data.get('call_to', None)

        if call_to_data:
            content_type_name = call_to_data.get('content_type', None)
            object_id = call_to_data.get('object_id', None)

            if content_type_name and object_id:
                try:
                    content_type = ContentType.objects.get(model=content_type_name)
                    serializer.save(call_to_content_type=content_type, call_to_object_id=object_id)
                except ContentType.DoesNotExist:
                    return Response({"error": f"Invalid content type: {content_type_name}"}, status=status.HTTP_400_BAD_REQUEST)
            else:
                return Response({"error": "call_to must contain 'content_type' and 'object_id'"}, status=status.HTTP_400_BAD_REQUEST)

        # Proceed with default serializer save if no call_to data provided or valid
        serializer.save()
        return Response(serializer.data, status=status.HTTP_200_OK)
    

class CampaignViewSet(viewsets.ModelViewSet):
    queryset = Campaign.objects.all()

    def get_serializer_class(self):
        if self.request.method in ['POST', 'PUT', 'PATCH']:
            return CampaignCreateUpdateSerializer
        return CampaignDetailSerializer

class ProductViewSet(viewsets.ModelViewSet):
    queryset = Product.objects.all()

    def get_serializer_class(self):
        if self.request.method in ['POST', 'PUT', 'PATCH']:
            return ProductCreateUpdateSerializer
        return ProductDetailSerializer

class CaseViewSet(viewsets.ModelViewSet):
    queryset = Case.objects.all()

    def get_serializer_class(self):
        if self.request.method in ['POST', 'PUT', 'PATCH']:
            return CaseCreateUpdateSerializer
        return CaseDetailSerializer

class SolutionViewSet(viewsets.ModelViewSet):
    queryset = Solution.objects.all()

    def get_serializer_class(self):
        if self.request.method in ['POST', 'PUT', 'PATCH']:
            return SolutionCreateUpdateSerializer
        return SolutionDetailSerializer