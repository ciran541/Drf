from django.contrib import admin
from .models import Lead, Contact, Account, Deal, Task, Meeting

# Register your models here.

@admin.register(Lead)
class LeadAdmin(admin.ModelAdmin):
    list_display = ['name', 'email', 'phone_number', 'status']
    search_fields = ['name', 'email']
    list_filter = ['status']

@admin.register(Contact)
class ContactAdmin(admin.ModelAdmin):
    list_display = ['first_name', 'last_name', 'email', 'phone_number']
    search_fields = ['first_name', 'last_name', 'email']
    list_filter = []  # Update this according to your needs

@admin.register(Account)
class AccountAdmin(admin.ModelAdmin):
    list_display = ['account_name', 'account_number', 'account_owner']
    search_fields = ['account_name', 'account_number']
    list_filter = []  # Update this according to your needs

@admin.register(Deal)
class DealAdmin(admin.ModelAdmin):
    list_display = ['deal_name', 'account', 'contact', 'stage', 'potential_value']
    search_fields = ['deal_name']
    list_filter = ['stage', 'type']

@admin.register(Task)
class TaskAdmin(admin.ModelAdmin):
    list_display = ['subject', 'due_date', 'task_owner', 'status']
    search_fields = ['subject']
    list_filter = ['due_date', 'status']

@admin.register(Meeting)
class MeetingAdmin(admin.ModelAdmin):
    list_display = ['id', 'start_time', 'end_time', 'host', 'location']
    search_fields = ['id', 'location']
    list_filter = ['start_time', 'host']
