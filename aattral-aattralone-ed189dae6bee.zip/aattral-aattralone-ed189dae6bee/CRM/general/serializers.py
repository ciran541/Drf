# serializers.py
from rest_framework import serializers
from .models import Lead,Contact,Account,Deal,Task,Meeting,CallSchedule,Campaign, Product, Case, Solution
from Authentication.serializers import CustomUserSerializer

class LeadDetailSerializer(serializers.ModelSerializer):
    lead_owner = CustomUserSerializer()
    created_by = CustomUserSerializer()
    modified_by = CustomUserSerializer()
    class Meta:
        model = Lead
        fields = '__all__'
        ref_name = 'crmleadsdetail'

class LeadCreateUpdateSerializer(serializers.ModelSerializer):
    class Meta:
        model = Lead
        fields = '__all__'
        ref_name = 'crmleadscreate'

class ContactDetailSerializer(serializers.ModelSerializer):
    contact_owner = CustomUserSerializer()
    created_by = CustomUserSerializer()
    modified_by = CustomUserSerializer()

    class Meta:
        model = Contact
        fields = '__all__'
        ref_name = 'crmcontactdetail'

class ContactCreateUpdateSerializer(serializers.ModelSerializer):
    class Meta:
        model = Contact
        fields = '__all__'
        ref_name = 'crmcontactcreate'

class AccountDetailSerializer(serializers.ModelSerializer):
    account_owner = CustomUserSerializer()
    
    class Meta:
        model = Account
        fields = '__all__'
        ref_name = 'crmaccountdetail'

class AccountCreateUpdateSerializer(serializers.ModelSerializer):
    class Meta:
        model = Account
        fields = '__all__'
        ref_name = 'crmaccountcreateupdate'


class DealDetailSerializer(serializers.ModelSerializer):
    class Meta:
        model = Deal
        fields = '__all__'
        ref_name = 'dealdetailcrm'


class DealCreateUpdateSerializer(serializers.ModelSerializer):
    class Meta:
        model = Deal
        fields = '__all__'
        ref_name = 'crmdealcreate'


class TaskDetailSerializer(serializers.ModelSerializer):
    class Meta:
        model = Task
        fields = '__all__'
        ref_name = 'crmtask'

class TaskCreateUpdateSerializer(serializers.ModelSerializer):
    class Meta:
        model = Task
        fields = '__all__'
        ref_name = 'crmtask'

class MeetingSerializer(serializers.ModelSerializer):
    # Custom representation for related_to field
    related_to = serializers.SerializerMethodField()

    class Meta:
        model = Meeting
        fields = '__all__'

    def get_related_to(self, instance):
        # Retrieve the related_to object based on content_type and object_id
        related_object = instance.related_to

        if related_object:
            # Serialize the related_to object based on its content_type
            serializer = self.context.get('related_serializer_map').get(related_object.__class__)
            if serializer:
                return serializer(related_object, context=self.context).data
            else:
                return None
        else:
            return None
        
class CallScheduleSerializer(serializers.ModelSerializer):
    # Custom representation for related_to field
    related_to = serializers.SerializerMethodField()

    class Meta:
        model = CallSchedule
        fields = '__all__'

    def get_related_to(self, instance):
        # Retrieve the related_to object (e.g., Deal) based on the related_to foreign key
        related_object = instance.related_to

        if related_object:
            # Customize the serialization based on the related_to object's model
            serializer = self.context.get('related_serializer_map').get(related_object.__class__)
            if serializer:
                return serializer(related_object, context=self.context).data
            else:
                return None
        else:
            return None
        
class CampaignDetailSerializer(serializers.ModelSerializer):
    class Meta:
        model = Campaign
        fields = '__all__'

class CampaignCreateUpdateSerializer(serializers.ModelSerializer):
    class Meta:
        model = Campaign
        fields = '__all__'

class ProductDetailSerializer(serializers.ModelSerializer):
    class Meta:
        model = Product
        fields = '__all__'

class ProductCreateUpdateSerializer(serializers.ModelSerializer):
    class Meta:
        model = Product
        fields = '__all__'

class CaseDetailSerializer(serializers.ModelSerializer):
    class Meta:
        model = Case
        fields = '__all__'

class CaseCreateUpdateSerializer(serializers.ModelSerializer):
    class Meta:
        model = Case
        fields = '__all__'

class SolutionDetailSerializer(serializers.ModelSerializer):
    class Meta:
        model = Solution
        fields = '__all__'

class SolutionCreateUpdateSerializer(serializers.ModelSerializer):
    class Meta:
        model = Solution
        fields = '__all__'