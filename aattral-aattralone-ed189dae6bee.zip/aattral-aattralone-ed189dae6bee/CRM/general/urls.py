# urls.py
from django.urls import path, include
from rest_framework.routers import DefaultRouter
from .views import (LeadViewSet,ContactViewSet,AccountViewSet,DealViewSet,TaskViewSet,MeetingViewSet,
CallScheduleViewSet,CampaignViewSet, ProductViewSet, CaseViewSet, SolutionViewSet
)

router = DefaultRouter()
router.register(r'leads', LeadViewSet)
router.register(r'contacts', ContactViewSet)
router.register(r'accounts', AccountViewSet)
router.register(r'deals', DealViewSet)
router.register(r'tasks', TaskViewSet)
router.register(r'meeting', MeetingViewSet)
router.register(r'callschedules', CallScheduleViewSet, basename='callschedule')
router.register(r'campaigns', CampaignViewSet)
router.register(r'products', ProductViewSet)
router.register(r'cases', CaseViewSet)
router.register(r'solutions', SolutionViewSet)


urlpatterns = [
    path('', include(router.urls)),
]


# Example: /api/contacts/filter_contacts/?owner_id=<owner_id>&account_name=<account_name>&contact_name=<contact_name>&created_by_id=<created_by_id>
# Example: /api/leads/filter_leads/?owner_id=<owner_id>&source=<source>&status=<status>&industry=<industry>
# Example: /api/accounts/filter_accounts/?name=<name>&number=<number>&owner_id=<owner_id>&site=<site>

# To create a task for a specific lead, you can send a POST request to the custom action endpoint /tasks/{lead_pk}/create_task_for_lead/
# To create a task for a specific contact, you can send a POST request to the custom action endpoint /tasks/{contact_pk}/create_task_for_contact/:
# To create a task for a specific Account, you can send a POST request to the custom action endpoint /tasks/{Account_pk}/create_task_for_Account/:
# To create a task for a specific Deal, you can send a POST request to the custom action endpoint /tasks/{Deal_pk}/create_task_for_Deal/: