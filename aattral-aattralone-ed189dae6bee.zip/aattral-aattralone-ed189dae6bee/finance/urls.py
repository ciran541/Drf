from django.urls import path, include
from rest_framework.routers import DefaultRouter
from .views import TransactionViewSet

router = DefaultRouter()
router.register(r'transactions', TransactionViewSet)

urlpatterns = [
    path('', include(router.urls)),
    path('accounts/', include('finance.Accountant.urls')),
    path('timesheet/', include('finance.Time_tracking.urls')),
    path('sales/', include('finance.sales.urls')),
    path('tax/', include('finance.Tax.urls')),
    path('item/', include('finance.Item.urls')),
    
]