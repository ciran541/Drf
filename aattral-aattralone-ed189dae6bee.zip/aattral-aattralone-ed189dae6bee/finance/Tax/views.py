# viewsets.py
from rest_framework import viewsets
from .models import Tax, TaxGroup, TaxAuthority, TaxExemption, GSTConfiguration, TaxType, GSTRate
from .serializers import (
    TaxSerializer, TaxGroupSerializer, TaxAuthoritySerializer, TaxExemptionSerializer,
    GSTConfigurationSerializer, TaxTypeSerializer, GSTRateSerializer
)

class TaxViewSet(viewsets.ModelViewSet):
    queryset = Tax.objects.all()
    serializer_class = TaxSerializer

class TaxGroupViewSet(viewsets.ModelViewSet):
    queryset = TaxGroup.objects.all()
    serializer_class = TaxGroupSerializer

class TaxAuthorityViewSet(viewsets.ModelViewSet):
    queryset = TaxAuthority.objects.all()
    serializer_class = TaxAuthoritySerializer

class TaxExemptionViewSet(viewsets.ModelViewSet):
    queryset = TaxExemption.objects.all()
    serializer_class = TaxExemptionSerializer

class GSTConfigurationViewSet(viewsets.ModelViewSet):
    queryset = GSTConfiguration.objects.all()
    serializer_class = GSTConfigurationSerializer

class TaxTypeViewSet(viewsets.ModelViewSet):
    queryset = TaxType.objects.all()
    serializer_class = TaxTypeSerializer

class GSTRateViewSet(viewsets.ModelViewSet):
    queryset = GSTRate.objects.all()
    serializer_class = GSTRateSerializer
