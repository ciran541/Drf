from django.test import TestCase
from .models import Tax,TaxExemption,TaxAuthority,GSTConfiguration
from datetime import date
from Authentication.models import CustomUser
class TaxTestCase(TestCase):

    def setUp(self):
        self.tax = Tax.objects.create(
            tax_id='TAX001',
            tax_name='Sales Tax',
            tax_percentage=10.0,
            tax_type='tax',
            tax_factor='some_factor',
            tds_payable_account_id='some_account_id',
            tax_authority_id='some_authority_id',
            tax_authority_name='some_authority_name',
            is_value_added=False,
            tax_specific_type='specific_type',
            country='United States',
            country_code='US',
            purchase_tax_expense_account_id=123456
        )

    def test_tax_creation(self):
        """Test tax creation"""
        self.assertEqual(self.tax.tax_name, 'Sales Tax')
        self.assertEqual(self.tax.tax_percentage, 10.0)

    def test_tax_type_choices(self):
        """Test tax type choices"""
        valid_choices = ['tax', 'compound_tax']
        self.assertIn(self.tax.tax_type, valid_choices)

    def test_value_added_tax(self):
        """Test is_value_added field"""
        self.assertFalse(self.tax.is_value_added)

    def test_country_info(self):
        """Test country information"""
        self.assertEqual(self.tax.country, 'United States')
        self.assertEqual(self.tax.country_code, 'US')

class TaxAuthorityTestCase(TestCase):

    def setUp(self):
        self.tax_authority = TaxAuthority.objects.create(
            tax_authority_id='TA001',
            tax_authority_name='Example Tax Authority'
        )

    def test_tax_authority_creation(self):
        """Test tax authority creation"""
        self.assertEqual(self.tax_authority.tax_authority_id, 'TA001')
        self.assertEqual(self.tax_authority.tax_authority_name, 'Example Tax Authority')


class TaxExemptionTestCase(TestCase):

    def setUp(self):
        self.tax_exemption = TaxExemption.objects.create(
            reason='Example Reason',
            description='This is an example tax exemption'
        )

    def test_tax_exemption_creation(self):
        """Test tax exemption creation"""
        self.assertEqual(self.tax_exemption.reason, 'Example Reason')
        self.assertEqual(self.tax_exemption.description, 'This is an example tax exemption')

    def test_tax_exemption_string_representation(self):
        """Test string representation of tax exemption"""
        expected_string = f"Tax Exemption {self.tax_exemption.tax_exemption_id}"
        self.assertEqual(str(self.tax_exemption), expected_string)

class GSTConfigurationTestCase(TestCase):

    def setUp(self):
        self.user = CustomUser.objects.create(username='test_user')
        self.gst_config = GSTConfiguration.objects.create(
            user=self.user,
            gstin='123456789012345',
            business_legal_name='Test Business Legal Name',
            business_trade_name='Test Business Trade Name',
            gst_registered_on=date(2022, 1, 1),
            is_registered_for_composition_scheme=True,
            composition_scheme_percentage=2.5,
            digital_services_percentage=1.5,
            composition_scheme_category='manufacturers'
        )

    def test_gst_configuration_creation(self):
        """Test GST configuration creation"""
        self.assertEqual(self.gst_config.gstin, '123456789012345')
        self.assertEqual(self.gst_config.business_legal_name, 'Test Business Legal Name')
        self.assertEqual(self.gst_config.business_trade_name, 'Test Business Trade Name')
        self.assertEqual(self.gst_config.gst_registered_on, date(2022, 1, 1))
        self.assertTrue(self.gst_config.is_registered_for_composition_scheme)
        self.assertEqual(self.gst_config.composition_scheme_percentage, 2.5)
        self.assertEqual(self.gst_config.digital_services_percentage, 1.5)
        self.assertEqual(self.gst_config.composition_scheme_category, 'manufacturers')

    def test_gst_configuration_str_method(self):
        """Test __str__ method"""
        expected_string = f"GST Configuration for {self.user.username}"
        self.assertEqual(str(self.gst_config), expected_string)
