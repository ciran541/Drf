from django.contrib import admin
from .models import Tax, TaxGroup, TaxAuthority, TaxExemption, ItemTaxPreference, GSTConfiguration, TaxType, GSTRate

# @admin.register(Tax)
# class TaxAdmin(admin.ModelAdmin):
#     pass

@admin.register(TaxGroup)
class TaxGroupAdmin(admin.ModelAdmin):
    pass

@admin.register(TaxAuthority)
class TaxAuthorityAdmin(admin.ModelAdmin):
    pass

@admin.register(TaxExemption)
class TaxExemptionAdmin(admin.ModelAdmin):
    pass

@admin.register(ItemTaxPreference)
class ItemTaxPreferenceAdmin(admin.ModelAdmin):
    pass

@admin.register(GSTConfiguration)
class GSTConfigurationAdmin(admin.ModelAdmin):
    pass

@admin.register(TaxType)
class TaxTypeAdmin(admin.ModelAdmin):
    pass

@admin.register(GSTRate)
class GSTRateAdmin(admin.ModelAdmin):
    pass

# Custom Admin Functions

def calculate_total_tax(modeladmin, request, queryset):
    total_tax = sum(item.tax_percentage for item in queryset)
    modeladmin.message_user(request, f'Total Tax Percentage: {total_tax}')

calculate_total_tax.short_description = "Calculate Total Tax Percentage"

@admin.register(Tax)
class TaxAdmin(admin.ModelAdmin):
    list_display = ('tax_id', 'tax_name', 'tax_percentage', 'tax_type')
    actions = [calculate_total_tax]
