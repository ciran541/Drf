# urls.py
from django.urls import path, include
from rest_framework.routers import DefaultRouter
from .views import (
    TaxViewSet, TaxGroupViewSet, TaxAuthorityViewSet, TaxExemptionViewSet,
    GSTConfigurationViewSet, TaxTypeViewSet, GSTRateViewSet
)

router = DefaultRouter()
router.register(r'taxes', TaxViewSet)
router.register(r'taxgroups', TaxGroupViewSet)
router.register(r'taxauthorities', TaxAuthorityViewSet)
router.register(r'taxexemptions', TaxExemptionViewSet)
router.register(r'gstconfigurations', GSTConfigurationViewSet)
router.register(r'taxtypes', TaxTypeViewSet)
router.register(r'gstrates', GSTRateViewSet)

urlpatterns = [
    path('', include(router.urls)),
]
