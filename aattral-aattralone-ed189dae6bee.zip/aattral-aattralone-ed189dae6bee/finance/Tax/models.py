from django.db import models
from Authentication.models import CustomUser


class Tax(models.Model):
    tax_id = models.CharField(max_length=255, primary_key=True)
    tax_name = models.CharField(max_length=255,null=True, blank=True)
    tax_percentage = models.FloatField(null=True, blank=True)
    tax_type = models.CharField(max_length=20, choices=[('tax', 'Tax'), ('compound_tax', 'Compound Tax')],null=True, blank=True)
    tax_factor = models.CharField(max_length=20, null=True, blank=True)  # 🇲🇽 only
    tds_payable_account_id = models.CharField(max_length=255, null=True, blank=True)  # 🇲🇽 only
    tax_authority_id = models.CharField(max_length=255, null=True, blank=True)  # 🇺🇸 , 🇲🇽 only
    tax_authority_name = models.CharField(max_length=255, null=True, blank=True)
    is_value_added = models.BooleanField(default=False,null=True, blank=True)
    tax_specific_type = models.CharField(max_length=20, null=True, blank=True)  # 🇮🇳 , 🇲🇽 only
    country = models.CharField(max_length=255, null=True, blank=True)  # 🇬🇧 , Europe , 🌎 only
    country_code = models.CharField(max_length=2, null=True, blank=True)  # 🇬🇧 , Europe , GCC , 🌎 only
    purchase_tax_expense_account_id = models.BigIntegerField(null=True, blank=True)  # 🇦🇺 , 🇨🇦 only

    def __str__(self):
        return self.tax_name


class TaxGroup(models.Model):
    tax_group_id = models.AutoField(primary_key=True)
    # Add any other fields specific to TaxGroup

    def __str__(self):
        return f"Tax Group {self.tax_group_id}"


class TaxAuthority(models.Model):
    tax_authority_id = models.CharField(max_length=255, primary_key=True)
    tax_authority_name = models.CharField(max_length=255)
    # Add any other fields specific to TaxAuthority

    def __str__(self):
        return self.tax_authority_name


class TaxExemption(models.Model):
    tax_exemption_id = models.AutoField(primary_key=True)
    reason = models.CharField(max_length=255)
    description = models.TextField(blank=True, null=True)

    def __str__(self):
        return f"Tax Exemption {self.tax_exemption_id}"
    
class ItemTaxPreference(models.Model):
    TAX_SPECIFICATION_CHOICES = [
        ('intra_state', 'Intra State'),
        ('inter_state', 'Inter State'),
    ]

    name = models.CharField(max_length=255)
    tax_id = models.CharField(max_length=20)
    tax_specification = models.CharField(max_length=20, choices=TAX_SPECIFICATION_CHOICES)
    tax_rate = models.DecimalField(max_digits=5, decimal_places=2, default=18.00)

    def __str__(self):
        return f'Tax Preference for {self.item.name}'
    
# GST Configurations for indian bussines/User ....

class GSTConfiguration(models.Model):
    user = models.OneToOneField(CustomUser, on_delete=models.CASCADE)
    gstin = models.CharField(max_length=15, unique=True)  # GST Identification Number
    business_legal_name = models.CharField(max_length=255)
    business_trade_name = models.CharField(max_length=255)
    gst_registered_on = models.DateField()
    is_registered_for_composition_scheme = models.BooleanField(default=False)
    composition_scheme_percentage = models.DecimalField(
        max_digits=5, decimal_places=2, null=True, blank=True
    )
    digital_services_percentage = models.DecimalField(
        max_digits=5, decimal_places=2, null=True, blank=True
    )
    composition_scheme_category = models.CharField(
        max_length=50,
        choices=[
            ('traders_and_manufacturers', '1% - For Traders and Manufacturers'),
            ('manufacturers', '2% - For Manufacturers'),
            ('restaurant', '5% - For Restaurant sector'),
            ('services_or_mixed_suppliers', '6% - For Suppliers of Services or Mixed Suppliers'),
        ],
        null=True,
        blank=True
    )

    def __str__(self):
        return f"GST Configuration for {self.user.username}"
    
# The TaxType model allows you to define various GST rates that are applicable to different goods or services. 
# For example, you might have tax types like "5% GST," "12% GST," "18% GST," and "28% GST."
# For example, for a tax type named "18% GST," the rate field would be set to 18.00.
    
class TaxType(models.Model):
    name = models.CharField(max_length=255)
    description = models.TextField(blank=True, null=True)
    rate = models.DecimalField(max_digits=5, decimal_places=2)
    compounding = models.BooleanField(default=False)

    def __str__(self):
        return self.name
    
class GSTRate(models.Model):
    name = models.CharField(max_length=255)
    rate = models.DecimalField(max_digits=5, decimal_places=2,default=18.00)
    tax_type = models.ForeignKey(TaxType, on_delete=models.CASCADE,blank=True)


    def __str__(self):
        return f"{self.name} - {self.rate}%"
    
# We need to Discuss after creation of Forntend where can use different endpoint # 