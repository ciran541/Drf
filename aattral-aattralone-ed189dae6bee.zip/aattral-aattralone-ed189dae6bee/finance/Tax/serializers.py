# serializers.py
from rest_framework import serializers
from .models import Tax, TaxGroup, TaxAuthority, TaxExemption, GSTConfiguration, TaxType, GSTRate

class TaxSerializer(serializers.ModelSerializer):
    class Meta:
        model = Tax
        fields = '__all__'

class TaxGroupSerializer(serializers.ModelSerializer):
    class Meta:
        model = TaxGroup
        fields = '__all__'

class TaxAuthoritySerializer(serializers.ModelSerializer):
    class Meta:
        model = TaxAuthority
        fields = '__all__'

class TaxExemptionSerializer(serializers.ModelSerializer):
    class Meta:
        model = TaxExemption
        fields = '__all__'

class GSTConfigurationSerializer(serializers.ModelSerializer):
    class Meta:
        model = GSTConfiguration
        fields = '__all__'

class TaxTypeSerializer(serializers.ModelSerializer):
    class Meta:
        model = TaxType
        fields = '__all__'

class GSTRateSerializer(serializers.ModelSerializer):
    class Meta:
        model = GSTRate
        fields = '__all__'
