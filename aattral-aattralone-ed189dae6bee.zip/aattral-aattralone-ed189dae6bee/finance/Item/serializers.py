# serializers.py
from rest_framework import serializers
from .models import Unit, Item
from finance.Accountant.serializers import ChartOfAccountsSerializer

class UnitSerializer(serializers.ModelSerializer):
    class Meta:
        model = Unit
        fields = '__all__'
        ref_name = 'FinanceUnit'

# Serializer for creating and updating items
class ItemCreateUpdateSerializer(serializers.ModelSerializer):
    class Meta:
        model = Item
        fields = '__all__'
        ref_name = 'FinanceItemCreateUpdate'

# Serializer for retrieving item details
class ItemDetailSerializer(serializers.ModelSerializer):
    unit = UnitSerializer(read_only=True)
    sales_account = ChartOfAccountsSerializer(read_only=True)
    purchase_account = ChartOfAccountsSerializer(read_only=True)

    class Meta:
        model = Item
        fields = '__all__'
        ref_name = 'FinanceItemDetail'

    def to_representation(self, instance):
        from finance.sales.serializers import CustomerSerializer
        # Now you can use CustomerSerializer here
        preferred_vendor_data = instance.preferred_vendor
        preferred_vendor_serialized = CustomerSerializer(preferred_vendor_data).data
        representation = super().to_representation(instance)
        representation['preferred_vendor'] = preferred_vendor_serialized
        return representation

    class Meta:
        model = Item
        fields = '__all__'
        ref_name = 'FinanceItemDetail'
