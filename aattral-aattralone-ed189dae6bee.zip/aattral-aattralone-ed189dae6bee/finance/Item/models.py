from django.db import models
from finance.Tax.models import TaxExemption
from finance.Accountant.models import ChartOfAccounts
class Unit(models.Model):
    unit_code = models.CharField(max_length=20, primary_key=True)
    unit_name = models.CharField(max_length=50)

    def __str__(self):
        return self.unit_name
    
class Item(models.Model):
    ITEM_TYPES = [
        ('product', 'Product'),
        ('service', 'Service'),
        ('bundle', 'Bundle'),
    ]

    STATUS_CHOICES = [
        ('active', 'Active'),
        ('inactive', 'Inactive'),
    ]
    
    item_id = models.AutoField(primary_key=True)
    item_type = models.CharField(max_length=20, choices=ITEM_TYPES,blank=True)
    name = models.CharField(max_length=100,blank=True)
    status = models.CharField(max_length=10, choices=STATUS_CHOICES, default='active',blank=True)
    description = models.TextField(max_length=2000, blank=True, null=True)
    rate = models.DecimalField(max_digits=10, decimal_places=2,blank=True)
    unit = models.ForeignKey(Unit, on_delete=models.CASCADE, blank=True, null=True)
    tax_id = models.CharField(max_length=20, blank=True, null=True)
    purchase_tax_rule_id = models.CharField(max_length=20, blank=True, null=True)
    sales_tax_rule_id = models.CharField(max_length=20, blank=True, null=True)
    tax_name = models.CharField(max_length=50, blank=True, null=True)
    hsn_or_sac = models.CharField(max_length=20, blank=True, null=True)
    sat_item_key_code = models.CharField(max_length=20, blank=True, null=True)
    unitkey_code = models.CharField(max_length=20, blank=True, null=True)
    tax_percentage = models.DecimalField(max_digits=5, decimal_places=2, blank=True, null=True)
    tax_type = models.CharField(max_length=20, blank=True, null=True)
    sku = models.CharField(max_length=50, unique=True,blank=True)
    product_type = models.CharField(max_length=20,blank=True)
    tax_exemption = models.BooleanField(default=False,blank=True)
    tax_exemption_reason= models.ForeignKey(TaxExemption, on_delete=models.CASCADE,blank=True, null=True, related_name = 'item_tax_exemption')

    # Sales Information
    sales_information = models.BooleanField(default=False)
    selling_price = models.DecimalField(max_digits=10, decimal_places=2, blank=True, null=True)
    selling_currency = models.CharField(max_length=3, default='INR',blank=True)
    sales_account = models.ForeignKey(ChartOfAccounts, related_name= 'COA_of_sales',blank=True ,null=True, on_delete=models.CASCADE)
    sales_description = models.TextField(max_length=2000, blank=True, null=True)
    default_sales_tax_rate = models.DecimalField(max_digits=5, decimal_places=2, blank=True, null=True)

    # Purchase Information
    purchase_information = models.BooleanField(default=False)
    cost_price = models.DecimalField(max_digits=10, decimal_places=2, blank=True, null=True)
    cost_currency = models.CharField(max_length=3, default='INR')
    purchase_account = models.ForeignKey(ChartOfAccounts, related_name= 'COA_of_purchase', blank=True ,null=True,on_delete=models.CASCADE)
    purchase_description = models.TextField(max_length=2000, blank=True, null=True)
    preferred_vendor = models.ForeignKey('sales.Customer',related_name= 'item_preferred_vendor',on_delete=models.CASCADE,blank=True, null=True) 
    

    def calculate_markup_percentage(self):
        """
        Method to calculate and return the markup percentage based on cost and selling prices.
        """
        if self.cost_price and self.selling_price:
            markup_percentage = ((self.selling_price - self.cost_price) / self.cost_price) * 100
            return markup_percentage
        return None

    def is_tax_exempted(self):
        """
        Method to check if the item is tax-exempted based on the tax_exemption field.
        """
        return self.tax_exemption

    def get_tax_exemption_reason(self):
        """
        Method to get the reason for tax exemption.
        """
        if self.tax_exemption_reason:
            return self.tax_exemption_reason.reason
        return None

    def is_sales_info_complete(self):
        """
        Method to check if sales information is complete.
        """
        return self.sales_information and self.selling_price and self.sales_account

    def is_purchase_info_complete(self):
        """
        Method to check if purchase information is complete.
        """
        return self.purchase_information and self.cost_price and self.purchase_account

    def __str__(self):
        return self.name

