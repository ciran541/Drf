from django.test import TestCase
from .models import Item, Unit,ChartOfAccounts

class ItemTestCase(TestCase):

    def setUp(self):
        self.unit = Unit.objects.create(
            unit_code='unit1',
            unit_name='Piece'
        )

        self.sales_account = ChartOfAccounts.objects.create(
            AccountName='Sales Account',
            AccountType='Sales Revenue',
            IsActive=True
        )

        self.purchase_account = ChartOfAccounts.objects.create(
            AccountName='Purchase Account',
            AccountType='Operating Expenses',
            IsActive=True
        )

        self.item = Item.objects.create(
            item_id='item1',
            item_type='product',
            name='Test Item',
            rate=100.00,
            unit=self.unit,
            sku='SKU001',
            product_type='Type A',
            sales_information=True,
            selling_price=120.00,
            sales_account=self.sales_account,
            default_sales_tax_rate=10.00,
            purchase_information=True,
            cost_price=80.00,
            purchase_account=self.purchase_account
        )

    def test_item_creation(self):
        """Test item creation"""
        self.assertEqual(self.item.name, 'Test Item')
        self.assertEqual(self.item.rate, 100.00)
        self.assertEqual(self.item.sku, 'SKU001')
        self.assertEqual(self.item.product_type, 'Type A')

    def test_sales_information(self):
        """Test sales information"""
        self.assertTrue(self.item.sales_information)
        self.assertEqual(self.item.selling_price, 120.00)
        self.assertEqual(self.item.sales_account, self.sales_account)
        self.assertEqual(self.item.default_sales_tax_rate, 10.00)

    def test_purchase_information(self):
        """Test purchase information"""
        self.assertTrue(self.item.purchase_information)
        self.assertEqual(self.item.cost_price, 80.00)
        self.assertEqual(self.item.purchase_account, self.purchase_account)
