# viewsets.py
from rest_framework import viewsets
from .models import Unit, Item
from .serializers import UnitSerializer, ItemCreateUpdateSerializer,ItemDetailSerializer
from rest_framework.response import Response

class UnitViewSet(viewsets.ModelViewSet):
    queryset = Unit.objects.all()
    serializer_class = UnitSerializer

class ItemViewSet(viewsets.ModelViewSet):
    queryset = Item.objects.all()
    serializer_class = ItemDetailSerializer  # Default serializer for GET requests

    def get_serializer_class(self):
        if self.request.method == 'GET':
            return ItemDetailSerializer  # Use detail serializer for GET requests
        elif self.request.method in ['POST', 'PUT', 'PATCH']:
            return ItemCreateUpdateSerializer  # Use create/update serializer for POST, PUT, PATCH requests
        return self.serializer_class

    

    def calculate_markup_percentage(self, request, pk=None):
        """
        Custom action to calculate and retrieve the markup percentage of a specific item.
        """
        item = self.get_object()
        markup_percentage = item.calculate_markup_percentage()
        return Response({'markup_percentage': markup_percentage})

    def is_tax_exempted(self, request, pk=None):
        """
        Custom action to check if a specific item is tax-exempted.
        """
        item = self.get_object()
        tax_exempted = item.is_tax_exempted()
        return Response({'tax_exempted': tax_exempted})

    def get_tax_exemption_reason(self, request, pk=None):
        """
        Custom action to retrieve the tax exemption reason of a specific item.
        """
        item = self.get_object()
        exemption_reason = item.get_tax_exemption_reason()
        return Response({'tax_exemption_reason': exemption_reason})

    def is_sales_info_complete(self, request, pk=None):
        """
        Custom action to check if sales information of a specific item is complete.
        """
        item = self.get_object()
        sales_info_complete = item.is_sales_info_complete()
        return Response({'sales_info_complete': sales_info_complete})

    def is_purchase_info_complete(self, request, pk=None):
        """
        Custom action to check if purchase information of a specific item is complete.
        """
        item = self.get_object()
        purchase_info_complete = item.is_purchase_info_complete()
        return Response({'purchase_info_complete': purchase_info_complete})

