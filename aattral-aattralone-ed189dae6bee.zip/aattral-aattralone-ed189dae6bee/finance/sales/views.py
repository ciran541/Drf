# viewsets.py
from rest_framework import viewsets
from rest_framework.response import Response
from rest_framework.decorators import action
from django.utils import timezone
from rest_framework import status
from .models import (SalesPerson, PaymentTerms, ContactPerson, Customer, Quote,RetainerInvoice,SalesOrder,Invoices,
                     CreditNotes,Expenses,PurchaseOrder,Bill,RecurringExpense,RecurringBill,QuoteItem,PaymentMade,PaymentReceived)
from .serializers import (
    SalesPersonSerializer, PaymentTermsSerializer, ContactPersonSerializer,
     CustomerSerializer, QuoteDetailSerializer, InvoiceDetailSerializer, InvoiceCreateUpdateSerializer,
    CreditNotesDetailSerializer, CreditNotesCreateUpdateSerializer, ExpensesCreateUpdateSerializer,ExpensesDetailSerializer, BillCreateUpdateSerializer,
    BillDetailSerializer, PurchaseOrderCreateUpdateSerializer, PurchaseOrderDetailSerializer,RecurringBillDetailSerializer, RecurringBillCreateUpdateSerializer,
    CustomerDetailSerializer,QuoteCreateUpdateSerializer,QuoteItemCreateUpdateSerializer,QuoteItemDetailSerializer,SalesOrderDetailSerializer, 
    SalesOrderCreateUpdateSerializer, RetainerInvoiceCreateUpdateSerializer,RetainerInvoiceDetailSerializer, RecurringExpenseDetailSerializer, RecurringExpenseCreateUpdateSerializer,
    PaymentMadeCreateSerializer,PaymentMadeUpdateSerializer,PaymentReceivedCreateSerializer,PaymentReceivedUpdateSerializer

)

class SalesPersonViewSet(viewsets.ModelViewSet):
    queryset = SalesPerson.objects.all()
    serializer_class = SalesPersonSerializer

class PaymentTermsViewSet(viewsets.ModelViewSet):
    queryset = PaymentTerms.objects.all()
    serializer_class = PaymentTermsSerializer

class ContactPersonViewSet(viewsets.ModelViewSet):
    queryset = ContactPerson.objects.all()
    serializer_class = ContactPersonSerializer

# class CountryViewSet(viewsets.ModelViewSet):
#     queryset = Country.objects.all()
#     serializer_class = CountrySerializer

class CustomerViewSet(viewsets.ModelViewSet):
    queryset = Customer.objects.all()
    serializer_class = CustomerDetailSerializer

    def get_serializer_class(self):
        if self.request.method == 'GET':
            return CustomerDetailSerializer  # Use detail serializer for GET requests
        elif self.request.method in ['POST', 'PUT', 'PATCH']:
            return CustomerSerializer  # Use create/update serializer for POST, PUT, PATCH requests
        return self.serializer_class

class QuoteViewSet(viewsets.ModelViewSet):
    queryset = Quote.objects.all()
    serializer_class = QuoteDetailSerializer  # Default serializer for GET requests

    def get_serializer_class(self):
        if self.request.method in ['POST', 'PUT', 'PATCH']:
            return QuoteCreateUpdateSerializer  # Use create/update serializer for POST, PUT, PATCH requests
        return self.serializer_class
    

class QuoteItemViewSet(viewsets.ModelViewSet):
    queryset = QuoteItem.objects.all()

    def get_serializer_class(self):
        if self.request.method in ['POST', 'PUT', 'PATCH']:
            return QuoteItemCreateUpdateSerializer  # Use create/update serializer for POST, PUT, PATCH requests
        return QuoteItemDetailSerializer
class RetainerInvoiceViewSet(viewsets.ModelViewSet):
    queryset = RetainerInvoice.objects.all()

    def get_serializer_class(self):
        if self.request.method in ['POST', 'PUT', 'PATCH']:
            return RetainerInvoiceCreateUpdateSerializer
        return RetainerInvoiceDetailSerializer

class SalesOrderViewSet(viewsets.ModelViewSet):
    queryset = SalesOrder.objects.all()
    serializer_class = SalesOrderDetailSerializer  # Default serializer for GET requests

    def get_serializer_class(self):
        if self.request.method in ['POST', 'PUT', 'PATCH']:
            return SalesOrderCreateUpdateSerializer  # Use create/update serializer for POST, PUT, PATCH requests
        return self.serializer_class

# Viewset for Invoices model
class InvoicesViewSet(viewsets.ModelViewSet):
    queryset = Invoices.objects.all()
    serializer_class = InvoiceDetailSerializer  # Default serializer for GET requests

    def get_serializer_class(self):
        if self.request.method in ['POST', 'PUT', 'PATCH']:
            return InvoiceCreateUpdateSerializer  # Use create/update serializer for POST, PUT, PATCH requests
        return self.serializer_class

    def get_remaining_days(self, request, pk=None):
        """
        Custom action to retrieve the remaining days until the due date of a specific invoice.
        """
        invoice = self.get_object()
        remaining_days = invoice.calculate_remaining_days()
        return Response({'remaining_days': remaining_days})
    
    @action(detail=False, methods=['get'])
    def invoices_by_customer(self, request):
        """
        Custom action to retrieve invoices associated with a specific customer.
        """
        customer_id = request.query_params.get('customer_id')
        if customer_id is None:
            return Response({'error': 'Customer ID parameter is required.'}, status=400)
        
        invoices = Invoices.objects.filter(customer_id=customer_id)
        serializer = self.get_serializer(invoices, many=True)
        return Response(serializer.data)

    @action(detail=False, methods=['get'])
    def invoices_by_salesperson(self, request):
        """
        Custom action to retrieve invoices associated with a specific salesperson.
        """
        salesperson_id = request.query_params.get('salesperson_id')
        if salesperson_id is None:
            return Response({'error': 'Salesperson ID parameter is required.'}, status=400)
        
        invoices = Invoices.objects.filter(salesperson_id=salesperson_id)
        serializer = self.get_serializer(invoices, many=True)
        return Response(serializer.data)
    
    # Custom action to get Overdue Invoices for Dashboard 
    @action(detail=False, methods=['get'])
    def overdue_invoices_count(self, request):
        """
        Custom action to retrieve the count of overdue invoices based on the due date.
        """
        today = timezone.now().date()
        overdue_invoices_count = Invoices.objects.filter(due_date__lt=today, status='unpaid').count()
        return Response({'overdue_invoices_count': overdue_invoices_count})
    
    # Custom action to get Overdue bills for Dashboard 
    @action(detail=False, methods=['get'])
    def overdue_bills_count(self, request):
        """
        Custom action to retrieve the count of overdue bills based on the due date.
        """
        today = timezone.now().date()
        overdue_bills_count = Bill.objects.filter(due_date__lt=today, status='unpaid').count()
        return Response({'overdue_bills_count': overdue_bills_count})
    
    # Get unpaid_invoices_by_customer
    @action(detail=False, methods=['get'])
    def unpaid_invoices_by_customer(self, request):
        customer_id = request.query_params.get('customer_id')
        if not customer_id:
            return Response({'error': 'Customer ID is required'}, status=status.HTTP_400_BAD_REQUEST)
        
        try:
            customer = Customer.objects.get(contact_id=customer_id)
        except Customer.DoesNotExist:
            return Response({'error': 'Customer not found'}, status=status.HTTP_404_NOT_FOUND)
        
        unpaid_invoices = Invoices.objects.filter(customer=customer, status='unpaid')
        serializer = self.get_serializer(unpaid_invoices, many=True)
        return Response(serializer.data)
    

    # Post Mark invoices as paid 
    @action(detail=False, methods=['post'])
    def mark_invoices_as_paid(self, request):
        invoice_ids = request.data.get('invoice_ids', [])
        
        if not invoice_ids:
            return Response({'error': 'Please provide a list of invoice IDs'}, status=status.HTTP_400_BAD_REQUEST)
        
        try:
            invoices = Invoices.objects.filter(pk__in=invoice_ids, status='unpaid')
        except Invoices.DoesNotExist:
            return Response({'error': 'One or more specified invoices not found or already paid'}, status=status.HTTP_404_NOT_FOUND)
        
        # Update status to 'paid' for all selected invoices
        invoices.update(status='paid')
        
        return Response({'message': f'Successfully updated {len(invoices)} invoices to paid status'}, status=status.HTTP_200_OK)
    
# Viewset for CreditNotes model
class CreditNotesViewSet(viewsets.ModelViewSet):
    queryset = CreditNotes.objects.all()
    serializer_class = CreditNotesDetailSerializer  # Default serializer for GET requests

    def get_serializer_class(self):
        if self.request.method in ['POST', 'PUT', 'PATCH']:
            return CreditNotesCreateUpdateSerializer  # Use create/update serializer for POST, PUT, PATCH requests
        return self.serializer_class
    def get_remaining_days(self, request, pk=None):
        """
        Custom action to retrieve the remaining days until the due date of a specific credit note.
        """
        creditnote = self.get_object()
        remaining_days = creditnote.calculate_remaining_days()
        return Response({'remaining_days': remaining_days})

    def is_creditnote_overdue(self, request, pk=None):
        """
        Custom action to check if a specific credit note is overdue.
        """
        creditnote = self.get_object()
        overdue_status = creditnote.is_overdue()
        return Response({'is_overdue': overdue_status})

    def get_creditnote_age(self, request, pk=None):
        """
        Custom action to retrieve the age of a specific credit note in days.
        """
        creditnote = self.get_object()
        creditnote_age = creditnote.get_creditnote_age()
        return Response({'creditnote_age': creditnote_age})
    
# Viewset for Expenses model
class ExpensesViewSet(viewsets.ModelViewSet):
    queryset = Expenses.objects.all()
    serializer_class = ExpensesDetailSerializer  # Default serializer for GET requests

    def get_serializer_class(self):
        if self.request.method in ['POST', 'PUT', 'PATCH']:
            return ExpensesCreateUpdateSerializer  # Use create/update serializer for POST, PUT, PATCH requests
        return self.serializer_class
    @action(detail=False, methods=['post'])
    def record_mileage(self, request):
        # Handle mileage recording logic here
        # You can access request data using request.data

        # Example logic: Create a new expense with expense_category 'mileage'
        mileage_data = {
            'expense_date': request.data.get('date'),
            'vendor': request.data.get('vendor'),
            'expense_category': 'mileage',
            'description': 'Mileage Record',
            'amount': request.data.get('amount'),
            'payment_method': request.data.get('payment_method'),
            'payment_reference': request.data.get('payment_reference'),
            'payment_status': 'unpaid',  # You can set the initial payment status
        }

        serializer = ExpensesDetailSerializer(data=mileage_data)
        if serializer.is_valid():
            serializer.save()
            return Response(serializer.data, status=status.HTTP_201_CREATED)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)
    
# Viewset for PurchaseOrder model
class PurchaseOrderViewSet(viewsets.ModelViewSet):
    queryset = PurchaseOrder.objects.all()
    serializer_class = PurchaseOrderDetailSerializer  # Default serializer for GET requests

    def get_serializer_class(self):
        if self.request.method in ['POST', 'PUT', 'PATCH']:
            return PurchaseOrderCreateUpdateSerializer  # Use create/update serializer for POST, PUT, PATCH requests
        return self.serializer_class
    

    # Custom Action for Reports GET purchaseorder by Vendor, items, salesperson
    @action(detail=False, methods=['GET'])
    def by_vendor(self, request):
        vendor_id = request.query_params.get('vendor_id')
        if vendor_id is None:
            return Response({'error': 'Vendor ID parameter is required'}, status=400)

        purchase_orders = PurchaseOrder.objects.filter(vendor_id=vendor_id)
        serializer = self.serializer_class(purchase_orders, many=True)
        return Response(serializer.data)

    @action(detail=False, methods=['GET'])
    def by_items(self, request):
        item_name = request.query_params.get('item_name')
        if item_name is None:
            return Response({'error': 'Item name parameter is required'}, status=400)

        purchase_orders = PurchaseOrder.objects.filter(line_items__contains={'name': item_name})
        serializer = self.serializer_class(purchase_orders, many=True)
        return Response(serializer.data)

    @action(detail=False, methods=['GET'])
    def by_salesperson(self, request):
        salesperson_id = request.query_params.get('salesperson_id')
        if salesperson_id is None:
            return Response({'error': 'Salesperson ID parameter is required'}, status=400)

        purchase_orders = PurchaseOrder.objects.filter(salesperson_id=salesperson_id)
        serializer = self.serializer_class(purchase_orders, many=True)
        return Response(serializer.data)
# Viewset for Bill model
class BillViewSet(viewsets.ModelViewSet):
    queryset = Bill.objects.all()
    serializer_class = BillDetailSerializer  # Default serializer for GET requests

    def get_serializer_class(self):
        if self.request.method in ['POST', 'PUT', 'PATCH']:
            return BillCreateUpdateSerializer  # Use create/update serializer for POST, PUT, PATCH requests
        return self.serializer_class
    
    # Custom action to GET bills by vendor/Customer
    @action(detail=False, methods=['GET'])
    def by_vendor(self, request):

        """
        Custom action to retrieve the bills by vendor/Customer model
        """
        customer_id = request.query_params.get('customer_id')
        if customer_id is None:
            return Response({'error': 'Vendor ID parameter (vendor_id) is required.'}, status=400)

        bills = Bill.objects.filter(contact_id=customer_id)
        serializer = self.get_serializer(bills, many=True)
        return Response(serializer.data)
    
    # Custom action to get unpaid bills by customer
    @action(detail=False, methods=['GET'])
    def unpaid_bills_by_customer(self, request):
        customer_id = request.query_params.get('customer_id')
        if not customer_id:
            return Response({'error': 'Customer ID is required'}, status=status.HTTP_400_BAD_REQUEST)
        
        try:
            customer = Customer.objects.get(contact_id=customer_id)  # Assuming 'Customer' is your related model
        except Customer.DoesNotExist:
            return Response({'error': 'Customer not found'}, status=status.HTTP_404_NOT_FOUND)
        
        unpaid_bills = Bill.objects.filter(vendor=customer, status='unpaid')  # Assuming 'status' field indicates unpaid
        serializer = self.get_serializer(unpaid_bills, many=True)
        return Response(serializer.data)
    
    # Custom action to mark bills as paid
    @action(detail=False, methods=['POST'])
    def mark_bills_as_paid(self, request):
        bill_ids = request.data.get('bill_ids', [])
        
        if not bill_ids:
            return Response({'error': 'Please provide a list of bill IDs'}, status=status.HTTP_400_BAD_REQUEST)
        
        try:
            bills = Bill.objects.filter(pk__in=bill_ids, status='unpaid')  # Fetch bills with unpaid status
        except Bill.DoesNotExist:
            return Response({'error': 'One or more specified bills not found or already paid'}, status=status.HTTP_404_NOT_FOUND)
        
        # Update status to 'paid' for all selected bills
        bills.update(status='paid')  # Assuming 'status' field is a boolean indicating paid/unpaid
        
        return Response({'message': f'Successfully updated {len(bills)} bills to paid status'}, status=status.HTTP_200_OK)

# Viewset for RecurringExpense model
class RecurringExpenseViewSet(viewsets.ModelViewSet):
    queryset = RecurringExpense.objects.all()
    serializer_class = RecurringExpenseDetailSerializer  # Default serializer for GET requests

    def get_serializer_class(self):
        if self.request.method in ['POST', 'PUT', 'PATCH']:
            return RecurringExpenseCreateUpdateSerializer  # Use create/update serializer for POST, PUT, PATCH requests
        return self.serializer_class

    @action(detail=True, methods=['get'])
    def next_occurrence(self, request, pk=None):
        """
        Custom action to retrieve the next occurrence date for a specific recurring expense.
        """
        recurring_expense = self.get_object()
        next_occurrence = recurring_expense.calculate_next_occurrence()

        if next_occurrence:
            return Response({'next_occurrence': next_occurrence}, status=status.HTTP_200_OK)
        else:
            return Response({'detail': 'Recurring expense has ended or set to never expire'}, status=status.HTTP_400_BAD_REQUEST)
        
class RecurringBillViewSet(viewsets.ModelViewSet):
    queryset = RecurringBill.objects.all()
    serializer_class = RecurringBillDetailSerializer

    def get_serializer_class(self):
        if self.request.method in ['POST', 'PUT', 'PATCH']:
            return RecurringBillCreateUpdateSerializer
        return self.serializer_class
    @action(detail=True, methods=['get'])
    def is_active(self, request, pk=None):
        """
        Custom action to check if the recurring bill is currently active.
        """
        recurring_bill = self.get_object()
        return Response({'is_active': recurring_bill.is_active()})

    @action(detail=True, methods=['get'])
    def remaining_days(self, request, pk=None):
        """
        Custom action to calculate and return the remaining days until the next occurrence.
        """
        recurring_bill = self.get_object()
        return Response({'remaining_days': recurring_bill.remaining_days()})

    @action(detail=True, methods=['get'])
    def next_occurrence_date(self, request, pk=None):
        """
        Custom action to calculate and return the next occurrence date.
        """
        recurring_bill = self.get_object()
        return Response({'next_occurrence_date': recurring_bill.next_occurrence_date()})

    @action(detail=True, methods=['get'])
    def total_amount(self, request, pk=None):
        """
        Custom action to calculate and return the total amount for the recurring bill.
        """
        recurring_bill = self.get_object()
        return Response({'total_amount': recurring_bill.total_amount()})

    def list(self, request, *args, **kwargs):
        """
        Custom list view to include additional calculated fields in the response.
        """
        queryset = self.filter_queryset(self.get_queryset())
        serializer = self.get_serializer(queryset, many=True)
        data = serializer.data

        for item in data:
            recurring_bill = RecurringBill.objects.get(pk=item['recurring_bill_id'])
            item['is_active'] = recurring_bill.is_active()
            item['remaining_days'] = recurring_bill.remaining_days()
            item['next_occurrence_date'] = recurring_bill.next_occurrence_date()
            item['total_amount'] = recurring_bill.total_amount()

        return Response(data)
    
class PaymentMadeViewSet(viewsets.ModelViewSet):
    queryset = PaymentMade.objects.all()

    def get_serializer_class(self):
        if self.request.method in ['POST', 'PUT', 'PATCH']:
            return PaymentMadeCreateSerializer
        return PaymentMadeUpdateSerializer

class PaymentReceivedViewSet(viewsets.ModelViewSet):
    queryset = PaymentReceived.objects.all()

    def get_serializer_class(self):
        if self.request.method in ['POST', 'PUT', 'PATCH']:
            return PaymentReceivedCreateSerializer
        return PaymentReceivedUpdateSerializer
    
    