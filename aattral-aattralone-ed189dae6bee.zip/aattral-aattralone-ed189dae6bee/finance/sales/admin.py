from django.contrib import admin
from .models import SalesPerson, PaymentTerms, ContactPerson,RecurringBill,Customer, Quote,RecurringExpense,RetainerInvoice,SalesOrder,CreditNotes,Expenses,Invoices,PurchaseOrder,QuoteItem,Bill

class RecurringBillAdmin(admin.ModelAdmin):
    list_display = ('id', 'other', 'fields', 'you', 'want', 'to', 'display',)

    def remaining_days_action(self, request, queryset):
        """
        Custom admin action to calculate and return the remaining days until the next occurrence for selected recurring bills.
        """
        data = []
        for recurring_bill in queryset:
            data.append({'recurring_bill_id': recurring_bill.id, 'remaining_days': recurring_bill.remaining_days()})
        self.message_user(request, f"Remaining days for selected recurring bills: {data}")

    remaining_days_action.short_description = "Calculate Remaining Days"

    actions = [remaining_days_action]
    

admin.site.register(SalesPerson)
admin.site.register(PaymentTerms)
admin.site.register(ContactPerson)
admin.site.register(Customer)
admin.site.register(Quote)
admin.site.register(RetainerInvoice)
admin.site.register(SalesOrder)
admin.site.register(Invoices)
admin.site.register(CreditNotes)
admin.site.register(Expenses)
admin.site.register(PurchaseOrder)
admin.site.register(Bill)
admin.site.register(RecurringExpense)
admin.site.register(RecurringBill)
admin.site.register(QuoteItem)