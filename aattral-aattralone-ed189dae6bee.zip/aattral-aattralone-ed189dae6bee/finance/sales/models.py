'''This module is responsible for Sales and purchase Functions - 

Sales Module:
Create and manage customer profiles.
Generate quotes and estimates for potential sales.
Convert quotes and estimates into sales orders.
Process and manage sales orders, including creating invoices.
Generate invoices with detailed product or service information.
Record customer payments and track outstanding balances.
Generate reports on sales performance, revenue, customers, and more.

Purchase Module:
Create and manage vendor profiles.
Request quotes from vendors for products or services.
Create purchase orders based on approved quotes.
Receive and manage purchases, including recording bills and expenses.
Track and manage inventory levels, if applicable.
Automate recurring expenses.
Generate reports on purchasing activities, expenses, vendors, and more
'''

from django.db import models
from datetime import timedelta
import pycountry
# from Hr.Timesheet.models import Country
from finance.Time_tracking.models import Project
from finance.Item.models import Item
from finance.Accountant.models import Document
from django.utils import timezone
from Authentication.models import CustomUser
from finance.Accountant.models import ChartOfAccounts

# Common Models --

class Address(models.Model):
    attention = models.CharField(max_length=50, blank=True, null=True)
    # country = models.ForeignKey(Country, on_delete=models.SET_NULL, null=True, blank=True)
    address_street1 = models.TextField()
    address_street2 = models.TextField(blank=True, null=True)
    city = models.CharField(max_length=50)
    state = models.CharField(max_length=50)
    zip_code = models.CharField(max_length=20)
    phone = models.CharField(max_length=20)
    fax_number = models.CharField(max_length=20, blank=True, null=True)

    def __str__(self):
        return f"{self.attention}, {self.address_street1}, {self.city}, {self.state}, {self.zip_code}"

class BillingAddress(models.Model):
    address = models.ForeignKey(Address, on_delete=models.CASCADE,related_name='salesbilling')

    def __str__(self):
        return f"Billing Address for {self.address.attention}"

class ShippingAddress(models.Model):
    address = models.ForeignKey(Address, on_delete=models.CASCADE,related_name='salesshipping')

    def __str__(self):
        return f"Shipping Address for {self.address.attention}"

# for country in pycountry.countries:
#     Country.objects.get_or_create(
#         code=country.alpha_3,
#         name=country.name
#     )

class SalesPerson(models.Model):    # User/admin can add Salesperson ....
    name = models.CharField(max_length=100)
    email = models.EmailField()
    phone = models.CharField(max_length=20)

    def __str__(self):
        return self.name

class PaymentTerms(models.Model):   # User can add Payments terms For Example - Due on receipts... and then can use in forms where its needs .....
    name = models.CharField(max_length=50)
    description = models.TextField(blank=True, null=True)

    def __str__(self):
        return self.name

class ContactPerson(models.Model):
    MR = 'Mr'
    MRS = 'Mrs'
    MISS = 'Miss'
    MS = 'Ms'
    DR = 'Dr'
    REV = 'Rev'

    SALUTATION_CHOICES = [
        (MR, 'Mr'),
        (MRS, 'Mrs'),
        (MISS, 'Miss'),
        (MS, 'Ms'),
        (DR, 'Dr'),
        (REV, 'Rev'),
    ]
    
    contact_person_id = models.AutoField(primary_key=True)
    salutation = models.CharField(max_length=10, choices=SALUTATION_CHOICES, blank=True, null=True)
    first_name = models.CharField(max_length=100)
    last_name = models.CharField(max_length=100)
    email = models.EmailField()
    work_phone = models.CharField(max_length=20)
    mobile = models.CharField(max_length=20)
    designation = models.CharField(max_length=50, blank=True, null=True)
    department = models.CharField(max_length=50, blank=True, null=True)
    skype = models.CharField(max_length=100, blank=True, null=True)
    is_primary_contact = models.BooleanField(default=False)
    enable_portal = models.BooleanField(default=False)
    
    def __str__(self):
        return f"{self.first_name} {self.last_name}"

#  Model for Customer/Vendor ---

class Customer(models.Model):
    MR = 'Mr'
    MRS = 'Mrs'
    MISS = 'Miss'
    MS = 'Ms'
    DR = 'Dr'
    REV = 'Rev'

    SALUTATION_CHOICES = [
        (MR, 'Mr'),
        (MRS, 'Mrs'),
        (MISS, 'Miss'),
        (MS, 'Ms'),
        (DR, 'Dr'),
        (REV, 'Rev'),
    ]
    contact_id = models.AutoField(primary_key=True, blank=True)
    contact_type = models.CharField(max_length=20, choices=[('Customer', 'Customer'), ('Vendor', 'Vendor')], blank=True)
    customer_sub_type = models.CharField(max_length=20, choices=[('Business', 'Business'), ('Individual', 'Individual')],null=True, blank=True)
    salutation = models.CharField(max_length=10, choices=SALUTATION_CHOICES, blank=True, null=True)
    first_name = models.CharField(max_length=50, blank=True)
    last_name = models.CharField(max_length=50, blank=True)
    company_name = models.CharField(max_length=100, blank=True, null=True)
    customer_display_name = models.CharField(max_length=100, blank=True, null=True)
    customer_email = models.EmailField(blank=True)
    customer_phone = models.CharField(max_length=20, blank=True)

    # Billing & Shipping Address
    billing_address = models.JSONField(blank=True, null=True)
    shipping_address = models.JSONField(blank=True, null=True)
    # Contact Persons
    contact_persons = models.ManyToManyField(ContactPerson, blank=True)

    # Other Details
    custom_fields = models.TextField(blank=True, null=True)
    reporting_tags = models.CharField(max_length=100, blank=True, null=True)
    remarks = models.TextField(blank=True, null=True)
    gst_treatment = models.CharField(max_length=50, blank=True, null=True)
    pan = models.CharField(max_length=15, blank=True, null=True)
    place_of_supply = models.CharField(max_length=100, blank=True, null=True)
    gst_no = models.CharField(max_length=15, blank=True, null=True)
    vat_treatment = models.CharField(max_length=20, blank=True, null=True)
    tax_treatment = models.CharField(max_length=20, blank=True, null=True)
    website = models.CharField(blank=True, null=True)
    # Tax Preferences
    taxable = models.BooleanField(default=True)
    tax_exempt = models.BooleanField(default=False)
    currency = models.CharField(max_length=3, default='INR', blank=True)

    # Financial Information
    # opening_balance = models.DecimalField(max_digits=10, decimal_places=2, default=0.00, blank=True)
    # payment_terms = models.ForeignKey(PaymentTerms, on_delete=models.SET_NULL, null=True, blank=True)
    price_list = models.CharField(max_length=50, blank=True, null=True)

    # Sales Person
    # sales_person = models.ForeignKey(SalesPerson, on_delete=models.SET_NULL, null=True, blank=True)

    outstanding_receivable_amount = models.IntegerField(blank=True, null=True)
    outstanding_receivable_amount_bcy = models.IntegerField(blank=True, null=True)
    unused_credits_receivable_amount = models.IntegerField(blank=True, null=True)
    unused_credits_receivable_amount_bcy = models.IntegerField(blank=True, null=True)
    status = models.CharField(max_length=50, blank=True, null=True)
    payment_reminder_enabled = models.BooleanField(default=False)
    custom_fields = models.TextField(blank=True, null=True)

    # Portal Settings
    enable_portal = models.BooleanField(default=False)
    portal_access_allowed = models.BooleanField(default=False)
    portal_language = models.CharField(max_length=10, blank=True, null=True)

    created_time = models.DateTimeField(auto_now_add=True)
    last_modified_time = models.DateTimeField(auto_now=True)

    def __str__(self):
        return self.customer_display_name or f"{self.first_name} {self.last_name}"

    

    
# Estimate Model # 

class Quote(models.Model):
    quote_id = models.AutoField(primary_key=True)
    customer = models.ForeignKey(Customer, on_delete=models.CASCADE)
    quote_date = models.DateField(blank=True, null=True)
    validity_period = models.PositiveIntegerField(blank=True, null=True)
    expiry_date = models.DateField(blank=True, null=True)
    reference_number = models.CharField(blank=True)
    salesperson = models.ForeignKey(SalesPerson, on_delete=models.SET_NULL, null=True, blank=True)
    project = models.ForeignKey(Project, on_delete=models.SET_NULL, null=True, blank=True)
    subject = models.TextField(blank=True, null=True)
    total_amount = models.DecimalField(max_digits=10, decimal_places=2, default=0.00, blank=True)
    status = models.CharField(max_length=20, blank=True)
    product = models.ManyToManyField(Item, blank=True)
    line_items = models.JSONField(blank=True, null=True)
    notes = models.CharField(blank=True)
    terms = models.CharField(blank=True)
    tax_rate = models.DecimalField(max_digits=5, decimal_places=2, blank=True)
    sub_total = models.FloatField(blank=True,null=True)
    tax_total = models.FloatField(blank=True,null=True)
    def __str__(self):
        return f"Quote {self.quote_id} for {self.customer}"


class QuoteItem(models.Model):
    quote = models.ForeignKey(Quote, related_name='items', on_delete=models.CASCADE)
    product_name = models.ManyToManyField(Item, blank=True)
    quantity = models.PositiveIntegerField(blank=True, null=True)
    unit_price = models.DecimalField(max_digits=10, decimal_places=2, blank=True)
    line_total = models.DecimalField(max_digits=10, decimal_places=2, blank=True)

    # New fields
    expiry_date = models.DateField(null=True, blank=True)
    discount = models.DecimalField(max_digits=10, decimal_places=2, null=True, blank=True)
    is_discount_before_tax = models.BooleanField(default=True)
    discount_type = models.CharField(max_length=20, choices=[('entity_level', 'Entity Level'), ('item_level', 'Item Level')], default='entity_level')
    is_inclusive_tax = models.BooleanField(default=False)

    # Additional fields related to line items
    customer_notes = models.TextField(blank=True, null=True)
    sub_total = models.DecimalField(max_digits=10, decimal_places=2, default=0.00, blank=True)
    shipping_charges = models.DecimalField(max_digits=10, decimal_places=2, default=0.00, blank=True)
    apply_tax_on_shipping = models.BooleanField(default=False)
    adjustment = models.DecimalField(max_digits=10, decimal_places=2, default=0.00, blank=True)
    round_off = models.DecimalField(max_digits=10, decimal_places=2, default=0.00, blank=True)
    total_amount = models.DecimalField(max_digits=10, decimal_places=2, default=0.00, blank=True)
    terms_and_conditions = models.TextField(blank=True, null=True)
    
    # Additional fields for file attachments
    file_1 = models.FileField(upload_to='quote_attachments/', null=True, blank=True)
    file_2 = models.FileField(upload_to='quote_attachments/', null=True, blank=True)
    file_3 = models.FileField(upload_to='quote_attachments/', null=True, blank=True)
    file_4 = models.FileField(upload_to='quote_attachments/', null=True, blank=True)
    file_5 = models.FileField(upload_to='quote_attachments/', null=True, blank=True)

    # Retainer invoice related field
    create_retainer_invoice = models.BooleanField(default=False,blank=True)

    def save(self, *args, **kwargs):
        # Calculate line total
        self.line_total = self.quantity * self.unit_price
        
        # Calculate sub-total, total amount, etc.
        self.sub_total = self.line_total
        self.total_amount = (
            self.sub_total +
            self.shipping_charges -
            self.adjustment +
            self.round_off
        )
        
        super().save(*args, **kwargs)

    def __str__(self):
        return f"{self.quantity} {self.product_name} @ ${self.unit_price} each"
    

class RetainerInvoice(models.Model):
    # Unique identifier for the retainer invoice
    retainerinvoice_id = models.CharField(primary_key=True, max_length=255, blank=True)
    
    # Number of the retainer invoice
    retainerinvoice_number = models.CharField(max_length=100, blank=True)
    
    # Date of creation of the retainer invoice
    date = models.DateField(blank=True)
    
    # Status of the retainer invoice (e.g., Sent, Draft, Paid)
    status = models.CharField(max_length=20, choices=[
        ('sent', 'Sent'),
        ('draft', 'Draft'),
        ('overdue', 'Overdue'),
        ('paid', 'Paid'),
        ('void', 'Void'),
        ('unpaid', 'Unpaid'),
        ('partially_paid', 'Partially Paid'),
        ('viewed', 'Viewed'),
    ], blank=True)
    
    # Flag indicating whether the transaction is before July 1, 2017
    is_pre_gst = models.BooleanField(blank=True)
    
    # Place where the goods/services are supplied (applicable only for India)
    place_of_supply = models.CharField(max_length=255, blank=True)
    
    # ID and Name of the associated project
    project_id = models.ForeignKey(Project, related_name='Retainer_invoice', on_delete=models.SET_NULL, null=True, blank=True)
    
    # Last payment date of the retainer invoice
    last_payment_date = models.DateField(blank=True)
    
    # Reference number of the retainer invoice
    reference_number = models.CharField(max_length=100, blank=True)
    
    # ID and Name of the associated customer
    customer_id = models.ForeignKey(Customer, on_delete=models.SET_NULL, null=True, blank=True)
    customer_name = models.CharField(max_length=100, blank=True)
    
    # Currency details
    currency_id = models.CharField(max_length=255, blank=True)
    currency_code = models.CharField(max_length=10, blank=True)
    currency_symbol = models.CharField(max_length=10, blank=True)
    exchange_rate = models.FloatField(blank=True)
    
    # Viewed by client information
    is_viewed_by_client = models.BooleanField(blank=True)
    client_viewed_time = models.DateTimeField(null=True, blank=True)
    
    # Inclusive tax flag
    is_inclusive_tax = models.BooleanField(blank=True)
    
    product_name = models.ForeignKey(Item, related_name='RetainerInvoice_items', on_delete=models.CASCADE, blank=True)

    # Financial details
    sub_total = models.FloatField(blank=True)
    total = models.FloatField(blank=True)
    payment_made = models.FloatField(blank=True)
    payment_drawn = models.FloatField(blank=True)
    balance = models.FloatField(blank=True)
    allow_partial_payments = models.BooleanField(blank=True)
    price_precision = models.IntegerField(blank=True)
    
    # Email information
    is_emailed = models.BooleanField(blank=True)
    
    # Timestamps and creator information
    created_time = models.DateTimeField(blank=True)
    last_modified_time = models.DateTimeField(blank=True)
    created_by_id = models.CharField(max_length=255, blank=True)
    
    # Attachment and email sending details
    attachment_name = models.CharField(max_length=255, blank=True)
    can_send_in_mail = models.BooleanField(blank=True)
    invoice_url = models.URLField(blank=True)
    def __str__(self):
        return f"Retainer Invoice {self.retainerinvoice_number} for {self.customer_name}"
    

class SalesOrder(models.Model):
    # Primary key for Sales Order
    salesorder_id = models.AutoField(primary_key=True)
    
    # ID and Name of the associated customer
    customer = models.ForeignKey(Customer, on_delete=models.SET_NULL, null=True, blank=True)
    customer_name = models.CharField(max_length=100, blank=True)

    # Many-to-Many relationship with Document model
    documents = models.ManyToManyField(Document, blank=True)

    # Indicates whether GST is applicable for transactions before July 1, 2017 (Indian context)
    is_pre_gst = models.BooleanField(default=False, blank=True)

    # 15-digit GST identification number of the customer (Indian context)
    gst_no = models.CharField(max_length=15, null=True, blank=True)

    # GST treatment for the contact (Indian context)
    gst_treatment = models.CharField(max_length=50, null=True, blank=True)

    # Place where the goods/services are supplied to (Indian context or GCC countries)
    place_of_supply = models.CharField(max_length=50, null=True, blank=True)

    # VAT treatment for the sales order (UK context)
    vat_treatment = models.CharField(max_length=50, null=True, blank=True)

    # VAT treatment for the sales order (GCC, Mexico context)
    tax_treatment = models.CharField(max_length=50, null=True, blank=True)

    # Unique number for the sales order (Mandatory if auto number generation is disabled)
    salesorder_number = models.CharField(max_length=100, null=True, blank=True)

    # Date when the sales order is created
    date = models.DateField(blank=True,null=True)

    # Status of the Sales Order
    status = models.CharField(max_length=50, blank=True)

    # Shipping date of the sales order
    shipment_date = models.DateField(null=True, blank=True)

    # Reference Number of the Sales Order
    reference_number = models.CharField(max_length=100, null=True, blank=True)

    # Array of contact persons for whom sales order has to be sent
    contact_persons = models.JSONField(null=True, blank=True)

    # ID of the Currency in Sales Order
    currency_id = models.CharField(max_length=255, blank=True)

    # Code of the Currency involved in the Sales Order
    currency_code = models.CharField(max_length=10, blank=True)

    # Symbol of the Currency involved in the Sales Order
    currency_symbol = models.CharField(max_length=10, blank=True)

    # Exchange rate of the currency
    # exchange_rate = models.FloatField(blank=True)

    # Discount amount applied to the sales order
    discount_amount = models.FloatField(null=True, blank=True)

    # Discount applied to the sales order (in percentage or amount)
    discount = models.CharField(max_length=50, null=True, blank=True)

    # Discount applied on amount
    discount_applied_on_amount = models.IntegerField(null=True, blank=True)

    # Used to specify whether the discount has to be applied before or after the calculation of tax
    is_discount_before_tax = models.BooleanField(default=False, blank=True)

    # How the discount is specified (entity_level or item_level)
    discount_type = models.CharField(max_length=50, null=True, blank=True)

    # ID of the estimate from which the sales order is created
    estimate_id = models.CharField(max_length=255, null=True, blank=True)

    # Delivery method for the sales order
    delivery_method = models.CharField(max_length=255, null=True, blank=True)

    # ID of the delivery method for the sales order
    delivery_method_id = models.CharField(max_length=255, null=True, blank=True)

    # Used to specify whether the line item rates are inclusive or exclusive of tax
    is_inclusive_tax = models.BooleanField(default=False, blank=True)

    # Line items of the sales order
    line_items = models.JSONField(null=True, blank=True)
    # product_name = models.ForeignKey(Item, related_name='Sales_items', on_delete=models.CASCADE, blank=True)

    # Shipping charge for the sales order
    shipping_charge = models.FloatField(null=True, blank=True)

    # Adjustment for the sales order
    adjustment = models.FloatField(null=True, blank=True)

    # Description of the adjustment for the sales order
    adjustment_description = models.CharField(max_length=255, null=True, blank=True)

    # Subtotal of the Sales Order
    sub_total = models.FloatField(blank=True)

    # Tax total of the Sales Order
    tax_total = models.FloatField(blank=True)

    # Total amount of the Sales Order
    total = models.FloatField(blank=True)

    # Taxes applied to the Sales Order
    taxes = models.JSONField(null=True, blank=True)

    # # Precision value on the price
    # price_precision = models.IntegerField(blank=True)

    # Check if the Sales Order is emailed to the customer
    is_emailed = models.BooleanField(default=False, blank=True)

    # # Billing address for the Sales Order
    # billing_address = models.ForeignKey(Address, related_name='salesorder_billing_address', on_delete=models.CASCADE, blank=True,null=True)

    # # Shipping address for the Sales Order
    # shipping_address = models.ForeignKey(Address, related_name='salesorder_shipping_address', on_delete=models.CASCADE, blank=True,null=True)

    # Notes for the Sales Order
    notes = models.TextField(null=True, blank=True)

    # Terms for the Sales Order
    terms = models.TextField(null=True, blank=True)

    # Custom fields for the Sales Order
    custom_fields = models.JSONField(null=True, blank=True)

    # # ID of the pdf template associated with the Sales Order
    # template_id = models.CharField(max_length=255, null=True, blank=True)

    # # Name of the template associated with the Sales Order
    # template_name = models.CharField(max_length=255, null=True, blank=True)

    # # Page width of the template
    # page_width = models.CharField(max_length=50, null=True, blank=True)

    # # Page height of the template
    # page_height = models.CharField(max_length=50, null=True, blank=True)

    # # Orientation of the template
    # orientation = models.CharField(max_length=50, null=True, blank=True)

    # # Type of the template
    # template_type = models.CharField(max_length=50, null=True, blank=True)

    # # Creation time of the Sales Order
    # created_time = models.DateTimeField(blank=True)

    # # Last modification time of the Sales Order
    # last_modified_time = models.DateTimeField(blank=True)

    # # ID of the user who created the Sales Order
    # created_by_id = models.CharField(max_length=255, blank=True)

    # # Name of the file attachment associated with the Sales Order
    # attachment_name = models.CharField(max_length=255, null=True, blank=True)

    # # Can the file be sent in mail
    # can_send_in_mail = models.BooleanField(default=False, blank=True)

    # ID of the salesperson associated with the Sales Order
    salesperson_id = models.ForeignKey(SalesPerson, on_delete=models.CASCADE, null=True, blank=True)

    # Name of the salesperson associated with the Sales Order
    salesperson_name = models.CharField(max_length=255, null=True, blank=True)

    # ID of the merchant associated with the Sales Order
    merchant_id = models.CharField(max_length=255, null=True, blank=True)

    # Name of the merchant associated with the Sales Order
    merchant_name = models.CharField(max_length=255, null=True, blank=True)

    tax_rate = models.DecimalField(max_digits=5, decimal_places=2,blank=True)

    def __str__(self):
        return f"Sales Order {self.salesorder_number} for {self.customer_name}"



class Invoices(models.Model):
    # Unique identifier for the invoice
    invoice_id = models.AutoField(primary_key=True)

    # Invoice number for searching and identification
    invoice_number = models.CharField(max_length=100, null=True, blank=True)

    # Flag to indicate whether GST is applicable for transactions before July 1, 2017 (Indian context)
    is_pre_gst = models.BooleanField(blank=True,null=True)

    # Place where the goods/services are supplied to (Indian context or GCC countries)
    place_of_supply = models.CharField(max_length=50, null=True, blank=True)

    # GST identification number of the customer (Indian context)
    gst_no = models.CharField(max_length=15, null=True, blank=True)

    # GST treatment for the contact (Indian context)
    gst_treatment = models.CharField(max_length=50, null=True, blank=True)

    # Invoice date for searching (Default date format is yyyy-mm-dd)
    date = models.DateField(blank=True, null=True)

    # Status of the invoice
    status = models.CharField(max_length=50, blank=True)

    # Payment terms in days
    payment_terms = models.IntegerField(blank=True, null=True)

    # Label for payment terms
    payment_terms_label = models.CharField(max_length=100, null=True, blank=True)

    # Due date for searching (Default date format is yyyy-mm-dd)
    due_date = models.DateField(null=True, blank=True)

    # Expected payment date
    payment_expected_date = models.DateField(null=True, blank=True)

    # Last payment date of the invoice
    last_payment_date = models.DateField(null=True, blank=True)

    # Reference number of the invoice
    order_number = models.CharField(max_length=100, blank=True)
    
    tax_rate = models.DecimalField(max_digits=5, decimal_places=2,blank=True,null=True,)
    # ID and Name of the associated customer
    customer = models.ForeignKey(Customer, on_delete=models.SET_NULL, null=True, blank=True)
    customer_name = models.CharField(max_length=100, blank=True)

    # Array of contact persons for whom the invoice has to be sent
    contact_persons = models.JSONField(null=True, blank=True)

    # Currency code of the invoice
    currency_code = models.CharField(max_length=10, blank=True)

    # Exchange rate of the currency
    exchange_rate = models.FloatField(blank=True, null=True)

    # Discount applied to the invoice (in percentage or amount)
    discount = models.FloatField(null=True, blank=True)

    # Flag to specify how the discount has to be applied (before or after the calculation of tax)
    is_discount_before_tax = models.BooleanField(blank=True)

    # How the discount is specified (entity_level or item_level)
    discount_type = models.CharField(max_length=50, null=True, blank=True)

    # Flag to specify whether the line item rates are inclusive or exclusive of tax
    is_inclusive_tax = models.BooleanField(blank=True,null=True)

    # ID of the recurring invoice from which the invoice is created
    recurring_invoice_id = models.CharField(max_length=255, null=True, blank=True)

    # Flag to check if the invoice is viewed by the client
    is_viewed_by_client = models.BooleanField(blank=True)

    # Flag to check if there is an attachment
    has_attachment = models.BooleanField(blank=True)

    # Time when the client viewed the invoice
    client_viewed_time = models.CharField(max_length=255, null=True, blank=True)

    # Line items of the invoice
    line_items = models.JSONField(null=True, blank=True)

    address = models.JSONField(null=True, blank=True)

    # Shipping charges applied to the invoice
    shipping_charge = models.CharField(max_length=100, null=True, blank=True)

    # Adjustments made to the invoice
    adjustment = models.FloatField(null=True, blank=True)

    # Description for the adjustment made to the invoice
    adjustment_description = models.CharField(max_length=255, null=True, blank=True)

    # Subtotal of all items in the invoice
    sub_total = models.FloatField(blank=True)

    # Total amount of tax levied in the invoice
    tax_total = models.FloatField(blank=True)

    # Total amount to be paid in the invoice
    total = models.CharField(max_length=255, blank=True)

    # List of taxes levied on the invoice
    taxes = models.JSONField(null=True, blank=True)

    # Flag to check if payment reminders are enabled
    payment_reminder_enabled = models.BooleanField(blank=True)

    # Amount paid for the invoice
    payment_made = models.FloatField(blank=True)

    # Notes added to the invoice expressing gratitude or conveying information
    notes = models.TextField(null=True, blank=True)

    # Terms added to the invoice expressing gratitude or conveying information
    terms = models.TextField(null=True, blank=True)

    # Time of creation of the invoice
    created_time = models.DateTimeField(auto_now_add=True)

    # Time of last modification of the invoice
    last_modified_time = models.DateTimeField(auto_now_add=True,null=True, blank=True)

    # Name of the attachment in the invoice
    attachment_name = models.CharField(max_length=255, null=True, blank=True)


    # ID of the salesperson associated with the invoice
    salesperson_id =  models.ForeignKey(SalesPerson, on_delete=models.SET_NULL, null=True, blank=True)

    # URL of the invoice
    invoice_url = models.CharField(max_length=255, null=True, blank=True)



    def calculate_remaining_days(self):
        """
        Method to calculate and return the remaining days until the due date.
        """
        remaining_days = (self.due_date - timezone.now().date()).days
        return max(remaining_days, 0)

    def is_overdue(self):
        """
        Method to check if the invoice is overdue based on the due date.
        """
        return self.due_date and self.due_date < timezone.now().date()

    def __str__(self):
        return f"Invoice {self.invoice_number} for {self.customer_name}"


class PaymentReceived(models.Model):
    customer = models.ForeignKey(Customer, on_delete=models.CASCADE,blank=True, null=True)
    amount = models.DecimalField(max_digits=10, decimal_places=2)
    deposit_to = models.ForeignKey(ChartOfAccounts, on_delete=models.CASCADE, blank=True,null=True)
    invoice = models.ManyToManyField(Invoices, blank=True)
    date = models.DateField(blank=True, null=True)
    
    # Customizable Fields (optional and configurable through settings)
    payment_method = models.CharField(max_length=50, blank=True, null=True)
    reference_number = models.CharField(max_length=50, blank=True, null=True)
    notes = models.CharField(max_length=50, blank=True, null=True)

    # Other fields as needed

    def __str__(self):
        return f"Payment from {self.customer} of ${self.amount}"


class CreditNotes(models.Model):    # For Both Sales and Purchase Transactions .... 

    # Unique identifier for the credit note
    creditnote_id = models.CharField(primary_key=True, max_length=255, blank=True)

    # Unique number generated for the credit note (starts with CN)
    creditnote_number = models.CharField(max_length=100, blank=True)

    # Date on which the credit note is raised
    date = models.DateField(blank=True)

    # Flag indicating applicability for transactions before July 1, 2017 (Indian context)
    is_pre_gst = models.BooleanField(blank=True)

    # Place where the goods/services are supplied to (Indian context or GCC countries)
    place_of_supply = models.CharField(max_length=50, null=True, blank=True)

    # VAT treatment for credit notes (UK context)
    vat_treatment = models.CharField(max_length=50, null=True, blank=True)

    # VAT registration number
    vat_reg_no = models.CharField(max_length=255, null=True, blank=True)

    # GST identification number of the customer (Indian context)
    gst_no = models.CharField(max_length=15, null=True, blank=True)

    # CFDI usage for Mexican context
    cfdi_usage = models.CharField(max_length=50, null=True, blank=True)

    # CFDI reference type for Mexican context
    cfdi_reference_type = models.CharField(max_length=50, null=True, blank=True)

    # GST treatment for the contact (Indian context)
    gst_treatment = models.CharField(max_length=50, null=True, blank=True)

    # VAT treatment for credit notes (GCC, Mexico context)
    tax_treatment = models.CharField(max_length=50, null=True, blank=True)

    # Status of the credit note (open, closed, or void)
    status = models.CharField(max_length=50, blank=True)

    # ID and Name of the associated customer
    customer_id = models.ForeignKey(Customer, on_delete=models.SET_NULL, null=True, blank=True)
    customer_name = models.CharField(max_length=100, blank=True)


    # Additional fields for the Credit-Notes
    custom_fields = models.JSONField(null=True, blank=True)

    # Reference number generated for the payment
    reference_number = models.CharField(max_length=100, null=True, blank=True)

    # Email address of the customer
    email = models.EmailField(null=True, blank=True)

    # Total credits raised in this credit note
    total = models.FloatField(blank=True)

    # Unapplied credits in the credit note
    balance = models.FloatField(blank=True)

    # Line items of the credit note
    line_items = models.JSONField(null=True, blank=True)

    # List of invoices for which the credit note has been raised
    invoices = models.JSONField(null=True, blank=True)

    # Taxes associated with the subscription
    taxes = models.JSONField(null=True, blank=True)

    # Customer's currency code
    currency_code = models.CharField(max_length=10, blank=True)

    # Customer's currency symbol
    currency_symbol = models.CharField(max_length=10, blank=True)

    # Billing address for the credit note
    billing_address = models.ForeignKey(Address, related_name='creditnote_billing_address', on_delete=models.CASCADE, blank=True)

    # Shipping address for the credit note
    shipping_address = models.ForeignKey(Address, related_name='creditnote_shipping_address', on_delete=models.CASCADE, blank=True)

    # ID of the salesperson associated with the invoice
    salesperson_id = models.ForeignKey(SalesPerson, on_delete=models.SET_NULL, null=True, blank=True)

    # Time at which the credit note was created
    created_time = models.DateTimeField(blank=True)

    # Time at which the credit note details were last updated
    updated_time = models.DateTimeField(blank=True)

    # Unique ID of the credit note template
    template_id = models.CharField(max_length=255, blank=True)

    # Name of the default template of the credit note
    template_name = models.CharField(max_length=255, blank=True)

    # A short note for the credit note
    notes = models.TextField(max_length=5000, null=True, blank=True)

    # Terms & conditions to be displayed in the credit note
    terms = models.TextField(max_length=10000, null=True, blank=True)


    def calculate_remaining_days(self):
        """
        Method to calculate and return the remaining days until the due date.
        """
        remaining_days = (self.due_date - timezone.now().date()).days
        return max(remaining_days, 0)

    def is_overdue(self):
        """
        Method to check if the credit note is overdue based on the due date.
        """
        return self.due_date and self.due_date < timezone.now().date()

    def get_creditnote_age(self):
        """
        Method to calculate and return the age of the credit note in days.
        """
        current_date = timezone.now().date()
        creditnote_age = (current_date - self.date).days
        return max(creditnote_age, 0)


    def __str__(self):
        return f"Credit Note {self.creditnote_number} for {self.customer_name}"
    
# Models for Purchase ...    
    
class Expenses(models.Model):
    date = models.DateField(blank=True)
    vendor = models.ForeignKey(Customer, on_delete=models.CASCADE, blank=True, null=True) 
    expense_type = models.CharField(max_length=255, blank=True,null=True)
    description = models.TextField(blank=True,null=True)
    amount = models.DecimalField(max_digits=10, decimal_places=2, default=0.00, blank=True, null=True)
    payment_method = models.CharField(max_length=50, blank=True, null=True)
    payment_reference = models.CharField(max_length=255, blank=True, null=True)
    payment_status = models.CharField(max_length=50, choices=[('unpaid', 'Unpaid'), ('partially_paid', 'Partially Paid'), ('paid', 'Paid')], blank=True)
    attachment = models.FileField(upload_to='expense_attachments/', blank=True, null=True)
    # ID of the expense account
    expense_account = models.ForeignKey(ChartOfAccounts,on_delete=models.CASCADE, blank=True, null=True, related_name='expenseaccount')
    # Name of the expense account
    account_name = models.CharField(max_length=255, blank=True)
    employee = models.ForeignKey(CustomUser,on_delete=models.CASCADE, blank=True,null=True)
    distance_travelled = models.FloatField(blank=True,null=True)
    odometer_reading = models.FloatField(blank=True,null=True)
    invoice_number = models.CharField(max_length=255, blank=True, null=True)
    notes = models.TextField(blank=True, null=True)
    reporting_tags = models.CharField(max_length=255, blank=True, null=True)
    itemize = models.BooleanField(default=False, blank=True, null=True)
    line_items = models.JSONField(blank=True, null=True)
    paid_through = models.ForeignKey(ChartOfAccounts, on_delete=models.CASCADE, blank=True, null=True, related_name='expensespaid')

    # # Unique identifier for the expense
    # expense_id = models.CharField(primary_key=True, max_length=255)

    # # Transaction ID associated with the expense
    # transaction_id = models.CharField(max_length=255)

    # # Transaction type (expense)
    # transaction_type = models.CharField(max_length=255)

    # # GST identification number of the vendor (Indian context)
    # gst_no = models.CharField(max_length=15, null=True, blank=True)

    # # GST treatment for the contact (Indian context)
    # gst_treatment = models.CharField(max_length=50, null=True, blank=True)

    # # VAT treatment for the expense (GCC context)
    # tax_treatment = models.CharField(max_length=50, null=True, blank=True)

    # # Place where the goods/services are supplied to (Indian context)
    # destination_of_supply = models.CharField(max_length=255, null=True, blank=True)

    # # State to where goods/services are supplied (Indian context)
    # destination_of_supply_state = models.CharField(max_length=255, null=True, blank=True)

    # # Place of supply for GCC countries
    # place_of_supply = models.CharField(max_length=255, null=True, blank=True)

    # # Place from where the goods/services are supplied (Indian context)
    # source_of_supply = models.CharField(max_length=255, null=True, blank=True)

    # # Name of the account through which the payment is made
    # paid_through_account_name = models.CharField(max_length=255, null=True, blank=True)

    # # VAT registration number
    # vat_reg_no = models.CharField(max_length=255, null=True, blank=True)

    # # ID of the reverse charge tax
    # reverse_charge_tax_id = models.CharField(max_length=255, null=True, blank=True)

    # # Name of the reverse charge tax (Indian context)
    # reverse_charge_tax_name = models.CharField(max_length=255, null=True, blank=True)

    # # Percentage of the reverse charge tax (Indian context)
    # reverse_charge_tax_percentage = models.FloatField(null=True, blank=True)

    # # Amount of the reverse charge tax (Indian context)
    # reverse_charge_tax_amount = models.IntegerField(null=True, blank=True)

    # # Total tax amount
    # tax_amount = models.FloatField(null=True, blank=True)

    # # Flag to indicate itemized expense
    # is_itemized_expense = models.BooleanField()

    # # Applicable for transactions before July 1, 2017 (Indian context)
    # is_pre_gst = models.CharField(max_length=50, null=True, blank=True)

    # # ID of the trip associated with the expense
    # trip_id = models.CharField(max_length=255, null=True, blank=True)

    # # Trip number associated with the expense
    # trip_number = models.CharField(max_length=255, null=True, blank=True)

    # # Total reverse charge VAT for Indian context
    # reverse_charge_vat_total = models.FloatField(null=True, blank=True)

    # # Total acquisition VAT
    # acquisition_vat_total = models.FloatField(null=True, blank=True)

    # # Acquisition VAT summary
    # acquisition_vat_summary = models.JSONField(null=True, blank=True)

    # # Reverse charge VAT summary
    # reverse_charge_vat_summary = models.JSONField(null=True, blank=True)

    # # Taxes associated with the expense (Mexican context)
    # taxes = models.JSONField(null=True, blank=True)

    # # ID of the expense item
    # expense_item_id = models.CharField(max_length=255, null=True, blank=True)

    # # Date of the expense
    # date = models.DateField()

    # # ID of the tax associated with the expense
    # tax_id = models.CharField(max_length=255, null=True, blank=True)

    # # Name of the tax associated with the expense
    # tax_name = models.CharField(max_length=255, null=True, blank=True)

    # # Percentage of the tax associated with the expense
    # tax_percentage = models.FloatField(null=True, blank=True)

    # # Currency ID of the expense
    # currency_id = models.CharField(max_length=255)

    # # Currency code of the expense
    # currency_code = models.CharField(max_length=10)

    # # Exchange rate of the currency
    # exchange_rate = models.FloatField()

    # # Subtotal of the expense
    # sub_total = models.FloatField()

    # # Total amount of the expense
    # total = models.FloatField()

    # # BCY total of the expense
    # bcy_total = models.FloatField()

    # # Amount of the expense
    # amount = models.FloatField()

    # # Flag to indicate inclusive tax in the expense
    # is_inclusive_tax = models.BooleanField()

    # # Reference number of the expense
    # reference_number = models.CharField(max_length=100, null=True, blank=True)

    # # Description of the expense
    # description = models.CharField(max_length=100, null=True, blank=True)

    # # Flag to indicate whether the expense is billable
    # is_billable = models.BooleanField()

    # # Flag to indicate whether the expense is personal
    # is_personal = models.BooleanField()

    # # ID of the customer associated with the expense
    # customer_id = models.CharField(max_length=255, null=True, blank=True)

    # # Name of the customer associated with the expense
    # customer_name = models.CharField(max_length=100, null=True, blank=True)

    # # Name of the expense receipt
    # expense_receipt_name = models.CharField(max_length=255, null=True, blank=True)

    # # Type of the expense receipt
    # expense_receipt_type = models.CharField(max_length=255, null=True, blank=True)

    # # Last modified time of the expense
    # last_modified_time = models.DateTimeField()

    # # Status of the expense
    # status = models.CharField(max_length=255)

    # # ID of the associated invoice
    # invoice_id = models.CharField(max_length=255, null=True, blank=True)

    # # Invoice number associated with the expense
    # invoice_number = models.CharField(max_length=255, null=True, blank=True)

    # # ID of the project associated with the expense
    # project_id = models.CharField(max_length=255, null=True, blank=True)

    # # Name of the project associated with the expense
    # project_name = models.CharField(max_length=255, null=True, blank=True)

    # # Mileage rate for a particular mileage expense
    # mileage_rate = models.FloatField(null=True, blank=True)

    # # Type of mileage (non_mileage, odometer)
    # mileage_type = models.CharField(max_length=255, null=True, blank=True)

    # # Start reading of odometer for mileage expenses (when mileage_type is odometer)
    # start_reading = models.FloatField(null=True, blank=True)

    # # End reading of odometer for mileage expenses (when mileage_type is odometer)
    # end_reading = models.FloatField(null=True, blank=True)

    # def __str__(self):
    #     return f"Expense {self.expense_id} for {self.customer_name} on {self.date}"

class PurchaseOrder(models.Model):
    vendor = models.ForeignKey(Customer, on_delete=models.CASCADE, blank=True, null=True)
    order_number = models.CharField(unique=True, max_length=50, blank=True)
    order_date = models.DateField(blank=True, null=True)
    delivery_date = models.DateField(blank=True, null=True)
    delivery_to = models.ForeignKey(Customer, related_name='purchaseorder_delivery_to', on_delete=models.CASCADE, blank=True, null=True) # For extract customer Address
    terms_and_conditions = models.TextField(blank=True,null=True)
    total_amount = models.DecimalField(max_digits=10, decimal_places=2, blank=True, null=True)
    status = models.CharField(max_length=20, default='draft', blank=True)
    description = models.TextField(blank=True, null=True)
    unit_of_measure = models.CharField(max_length=20, blank=True)
    quantity = models.PositiveIntegerField(blank=True, null=True)
    unit_price = models.DecimalField(max_digits=10, decimal_places=2, blank=True, null=True)
    discount_percentage = models.DecimalField(max_digits=5, decimal_places=2, blank=True, null=True)
    tax_rate = models.DecimalField(max_digits=5, decimal_places=2, blank=True, null=True)
    expected_delivery_date = models.DateField(blank=True, null=True)
    payment_terms = models.ForeignKey(PaymentTerms,related_name='purchaseorder_payment_terms', on_delete=models.SET_NULL, null=True, blank=True)
    sub_total = models.DecimalField(max_digits=10, decimal_places=2, blank=True, null=True)
    line_items = models.JSONField(blank=True, null=True)
    notes = models.CharField(blank=True)
    salesperson = models.ForeignKey(SalesPerson, on_delete=models.CASCADE, blank=True, null=True)


class Bill(models.Model):
    bill_id = models.AutoField(primary_key=True)
    vendor = models.ForeignKey(Customer, on_delete=models.CASCADE, blank=True, null=True)
    bill_date = models.DateField(blank=True, null=True)
    due_date = models.DateField(blank=True, null=True)
    bill_number = models.CharField(max_length=255, unique=True, blank=True, null=True)
    order_number = models.CharField(max_length=255, unique=True, blank=True, null=True)
    # purchase_order = models.ForeignKey(PurchaseOrder, on_delete=models.SET_NULL, blank=True, null=True)
    description = models.TextField(blank=True, null=True)
    currency = models.CharField(max_length=3, blank=True, null=True)  # Assuming currency code like 'USD', 'EUR', etc.
    exchange_rate = models.DecimalField(max_digits=10, decimal_places=4, blank=True, null=True)
    tax_rate = models.DecimalField(max_digits=5, decimal_places=2, blank=True, null=True)
    total_amount = models.DecimalField(max_digits=15, decimal_places=2, blank=True, null=True)
    paid_amount = models.DecimalField(max_digits=15, decimal_places=2, default=0, blank=True, null=True)
    payment_terms = models.ForeignKey(PaymentTerms, related_name='bill_payment_terms', on_delete=models.SET_NULL, null=True, blank=True)

    # item = models.ForeignKey(Item, related_name='bill_items', on_delete=models.CASCADE, blank=True, null=True)
    # quantity = models.PositiveIntegerField(blank=True, null=True)
    # unit_price = models.DecimalField(max_digits=10, decimal_places=2, blank=True, null=True)
    # line_total = models.DecimalField(max_digits=10, decimal_places=2, blank=True, null=True)

    line_items = models.JSONField(blank=True, null=True)
    status = models.CharField(default='unpaid', blank=True, null=True)

    file_1 = models.FileField(upload_to='bill_attachments/', null=True, blank=True)
    file_2 = models.FileField(upload_to='bill_attachments/', null=True, blank=True)
    
    @property
    def outstanding_amount(self):
        return self.total_amount - self.paid_amount

    def __str__(self):
        return f"Bill {self.bill_id} - {self.vendor} - {self.total_amount} {self.currency}"  
    

class PaymentMade(models.Model):
    vendor = models.ForeignKey(Customer, on_delete=models.CASCADE,blank=True, null=True)
    amount = models.DecimalField(max_digits=10, decimal_places=2,blank=True)
    payment_date = models.DateField(blank=True)
    payment_mode = models.CharField(max_length=50, blank=True, null=True)
    reference_number = models.CharField(max_length=50, blank=True, null=True)
    bills = models.ManyToManyField(Bill,blank=True)
    paid_through = models.ForeignKey(ChartOfAccounts, on_delete=models.CASCADE, blank=True, null=True)    
    notes = models.CharField(blank=True,null=True)

class RecurringExpense(models.Model):
    RECURRENCE_FREQUENCY_CHOICES = [
        ('daily', 'Daily'),
        ('weekly', 'Weekly'),
        ('monthly', 'Monthly'),
        # Add more choices as needed
    ]

    recurring_expense_id = models.AutoField(primary_key=True)
    profile_name = models.CharField(max_length=255, blank=True)
    recurrence_frequency = models.CharField(max_length=10, choices=RECURRENCE_FREQUENCY_CHOICES, blank=True)
    repeat_every = models.PositiveIntegerField(blank=True)
    ends_on = models.DateField(null=True, blank=True)
    never_expires = models.BooleanField(default=False)
    expense_account = models.ForeignKey(ChartOfAccounts, related_name='re_COA', on_delete=models.CASCADE, blank=True)
    amount = models.DecimalField(max_digits=15, decimal_places=2, blank=True)
    paid_through = models.ForeignKey(ChartOfAccounts, on_delete=models.CASCADE, blank=True)
    expense_type = models.CharField(max_length=255, choices=[
        ('Goods', 'Goods'),
        ('Services', 'Services'),
    ], blank=True)
    sac_code = models.CharField(max_length=255, null=True, blank=True)
    vendor = models.ForeignKey(Customer, on_delete=models.CASCADE, blank=True)
    gst_treatment = models.CharField(max_length=255, blank=True)
    source_of_supply = models.CharField(max_length=255, blank=True)
    destination_of_supply = models.CharField(max_length=255, blank=True)
    reverse_charge = models.BooleanField(default=False)
    reverse_charge_applicable = models.BooleanField(default=False)
    tax = models.CharField(max_length=255, null=True, blank=True)
    notes = models.TextField(max_length=500, null=True, blank=True)
    customer_name = models.ForeignKey(Customer, related_name='re_customer', on_delete=models.CASCADE, blank=True)
    reporting_tags = models.CharField(max_length=255, null=True, blank=True)

    def calculate_next_occurrence(self):
        """
        Method to calculate the next occurrence date based on the recurrence frequency.
        """
        if not self.never_expires:
            current_date = timezone.now().date()

            if self.ends_on and self.ends_on < current_date:
                return None  # Recurring expense has ended

            # Calculate the next occurrence based on the recurrence frequency
            if self.recurrence_frequency and self.repeat_every and self.start_date:
                if self.recurrence_frequency == 'daily':
                    delta = timedelta(days=self.repeat_every)
                elif self.recurrence_frequency == 'weekly':
                    delta = timedelta(weeks=self.repeat_every)
                elif self.recurrence_frequency == 'monthly':
                    delta = timedelta(days=self.repeat_every * 30)  # Assuming monthly intervals
                else:
                    return None  # Invalid recurrence frequency

                next_occurrence = self.start_date + delta

                # Check if the next occurrence is within the specified end date
                if self.ends_on and next_occurrence > self.ends_on:
                    return None  # Recurring expense has ended

                return next_occurrence
        return None  # Recurring expense set to never expire

    def __str__(self):
        return f"Recurring Expense {self.recurring_expense_id} - {self.profile_name}"

class RecurringBill(models.Model):
    RECURRENCE_FREQUENCY_CHOICES = [
        ('daily', 'Daily'),
        ('weekly', 'Weekly'),
        ('monthly', 'Monthly'),
        # Add more choices as needed
    ]

    recurring_bill_id = models.AutoField(primary_key=True)
    vendor_id = models.ForeignKey(Customer, on_delete=models.CASCADE, blank=True, null=True)
    vendor_name = models.CharField(max_length=255, null=True, blank=True)
    status = models.CharField(max_length=20, default="active", null=True, blank=True)
    recurrence_name = models.CharField(max_length=255, null=True, blank=True)
    source_of_supply = models.CharField(max_length=50, null=True, blank=True)  
    destination_of_supply = models.CharField(max_length=50, null=True, blank=True)  
    profile_name = models.CharField(max_length=255, null=True, blank=True)  
    recurrence_frequency = models.CharField(max_length=10, choices=RECURRENCE_FREQUENCY_CHOICES, null=True, blank=True)
    repeat_every = models.PositiveIntegerField(null=True, blank=True) 
    never_expires = models.BooleanField(default=False, blank=True)
    start_date = models.DateField(blank=True, null=True)
    end_date = models.DateField(null=True, blank=True)
    source_of_supply = models.CharField(max_length=10, null=True, blank=True)
    place_of_supply = models.CharField(max_length=10, null=True, blank=True)
    destination_of_supply = models.CharField(max_length=10, null=True, blank=True)
    gst_treatment = models.CharField(max_length=20, null=True, blank=True)
    gst_no = models.CharField(max_length=15, null=True, blank=True)
    is_reverse_charge_applied = models.BooleanField(default=False, blank=True)
    is_inclusive_tax = models.BooleanField(default=False, blank=True)
    notes = models.TextField(null=True, blank=True)
    payment_terms = models.ForeignKey(PaymentTerms, related_name='Recurringbill_payment_terms', on_delete=models.SET_NULL, null=True, blank=True)
    payment_terms_label = models.CharField(max_length=20, default="Due on Receipt", null=True, blank=True)
    created_time = models.DateTimeField(auto_now_add=True, blank=True)
    discount = models.CharField(max_length=10, null=True, blank=True)
    item = models.ForeignKey(Item, related_name='Recuring_bill_items', on_delete=models.CASCADE, blank=True, null=True)
    quantity = models.PositiveIntegerField(blank=True, null=True)
    unit_price = models.DecimalField(max_digits=10, decimal_places=2, blank=True, null=True)
    line_total = models.DecimalField(max_digits=10, decimal_places=2, blank=True, null=True)
    file_1 = models.FileField(upload_to='bill_attachments/', null=True, blank=True)
    file_2 = models.FileField(upload_to='bill_attachments/', null=True, blank=True)
    #pricebook_id = models.ForeignKey('Pricebook', on_delete=models.SET_NULL, null=True, blank=True)
    #discount_account_id = models.ForeignKey('DiscountAccount', on_delete=models.SET_NULL, null=True, blank=True)

    def is_active(self):
        """
        Method to check if the recurring bill is currently active based on start and end dates.
        """
        current_date = timezone.now().date()
        return self.start_date <= current_date <= self.end_date if not self.never_expires else self.start_date <= current_date

    def remaining_days(self):
        """
        Method to calculate and return the remaining days until the next occurrence.
        """
        current_date = timezone.now().date()
        if not self.never_expires and current_date > self.end_date:
            return 0
        elif self.never_expires and current_date > self.start_date:
            days_since_start = (current_date - self.start_date).days
            return (self.repeat_every - (days_since_start % self.repeat_every)) % self.repeat_every
        return 0

    def next_occurrence_date(self):
        """
        Method to calculate and return the next occurrence date based on recurrence frequency.
        """
        current_date = timezone.now().date()
        if self.never_expires or current_date <= self.end_date:
            days_until_next_occurrence = self.remaining_days()
            return current_date + timezone.timedelta(days=days_until_next_occurrence)
        return None
                        
    def total_amount(self):
        """
        Method to calculate and return the total amount for the recurring bill.
        """
        # Add your logic here based on pricing, discounts, etc.
        return 0

    def __str__(self):
        return f"{self.recurrence_name} - {self.recurrence_frequency}"