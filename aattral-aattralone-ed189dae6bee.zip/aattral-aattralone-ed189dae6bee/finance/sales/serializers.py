from rest_framework import serializers
from .models import (SalesPerson, PaymentTerms, ContactPerson, Customer, Quote,RetainerInvoice,Address,BillingAddress,ShippingAddress,
                     SalesOrder,Invoices,CreditNotes,Expenses,PurchaseOrder,Bill,RecurringExpense,RecurringBill,QuoteItem,PaymentMade,PaymentReceived)
from finance.Time_tracking.serializers import ProjectDetailSerializer
from finance.Item.serializers import ItemDetailSerializer
from finance.Accountant.serializers import ChartOfAccountsSerializer
from Authentication.serializers import CustomUserSerializer

class AddressSerializer(serializers.ModelSerializer):
    class Meta:
        model = Address
        fields = '__all__'
        ref_name = 'SalesAddress'

class BillingAddressSerializer(serializers.ModelSerializer):
    address = AddressSerializer()

    class Meta:
        model = BillingAddress
        fields = '__all__'
        ref_name = 'billingsales'

class ShippingAddressSerializer(serializers.ModelSerializer):
    address = AddressSerializer()

    class Meta:
        model = ShippingAddress
        fields = '__all__'
        ref_name = 'shippingsales'
class SalesPersonSerializer(serializers.ModelSerializer):
    class Meta:
        model = SalesPerson
        fields = '__all__'
        ref_name = 'FinanceSalesPerson' 

class PaymentTermsSerializer(serializers.ModelSerializer):
    class Meta:
        model = PaymentTerms
        fields = '__all__'
        ref_name = 'FinancePaymentTerms'

class ContactPersonSerializer(serializers.ModelSerializer):
    class Meta:
        model = ContactPerson
        fields = '__all__'
        ref_name = 'FinanceContactPerson'

# class CountrySerializer(serializers.ModelSerializer):
#     class Meta:
#         model = Country
#         fields = '__all__'

class CustomerSerializer(serializers.ModelSerializer):
    class Meta:
        model = Customer
        fields = '__all__'
        ref_name = 'financecustomer'

class CustomerDetailSerializer(serializers.ModelSerializer):
    # contact_persons = ContactPersonSerializer(many=True,read_only =True)
    # Billing_address = BillingAddressSerializer(read_only =True)
    # Shipping_address = ShippingAddressSerializer(read_only =True)
    # payment_terms = PaymentTermsSerializer(read_only =True)
    # sales_person = SalesPersonSerializer(read_only=True)
    class Meta:
        model = Customer
        fields = '__all__'
        ref_name = 'financecustomerDetail'

# Serializer for creating and updating quotes
class QuoteCreateUpdateSerializer(serializers.ModelSerializer):
    class Meta:
        model = Quote
        fields = '__all__'
        ref_name = 'QuoteCreateUpdate'

# Serializer for retrieving quote details
class QuoteDetailSerializer(serializers.ModelSerializer):
    customer = CustomerDetailSerializer()
    salesperson = SalesPersonSerializer()
    # product = ItemDetailSerializer()
    
    class Meta:
        model = Quote
        fields = '__all__'
        ref_name = 'QuoteDetail'


# Serializer for creating and updating quote items
class QuoteItemCreateUpdateSerializer(serializers.ModelSerializer):
    class Meta:
        model = QuoteItem
        fields = '__all__'
        ref_name = 'QuoteItemCreateUpdate'

# Serializer for retrieving quote item details
class QuoteItemDetailSerializer(serializers.ModelSerializer):
    product_name = ItemDetailSerializer()
    
    class Meta:
        model = QuoteItem
        fields = '__all__'
        ref_name = 'QuoteItemDetail'


class RetainerInvoiceCreateUpdateSerializer(serializers.ModelSerializer):
    class Meta:
        model = RetainerInvoice
        fields = '__all__'
        ref_name = 'RetainerInvoiceCreateUpdate'


class RetainerInvoiceDetailSerializer(serializers.ModelSerializer):
    project_id = ProjectDetailSerializer()
    customer_id = CustomerDetailSerializer()
    product_name = ItemDetailSerializer()

    class Meta:
        model = RetainerInvoice
        fields = '__all__'
        ref_name = 'RetainerInvoiceDetail'

        


# Serializer for creating and updating sales orders
class SalesOrderCreateUpdateSerializer(serializers.ModelSerializer):
    class Meta:
        model = SalesOrder
        fields = '__all__'
        ref_name = 'SalesOrderCreateUpdate'


# Serializer for retrieving sales order details
class SalesOrderDetailSerializer(serializers.ModelSerializer):
    # billing_address = AddressSerializer()
    # shipping_address = AddressSerializer()
    # product_name = ItemDetailSerializer()
    customer = CustomerDetailSerializer()

    class Meta:
        model = SalesOrder
        fields = '__all__'
        ref_name = 'SalesOrderDetail'


# Serializer for creating and updating invoices
class InvoiceCreateUpdateSerializer(serializers.ModelSerializer):
    class Meta:
        model = Invoices
        fields = '__all__'
        ref_name = 'InvoiceCreateUpdate'

# Serializer for retrieving invoice details
class InvoiceDetailSerializer(serializers.ModelSerializer):
    customer = CustomerSerializer()
    salesperson_id = SalesPersonSerializer()
    # billing_address = AddressSerializer()  # You need to define AddressSerializer
    # shipping_address = AddressSerializer()  # You need to define AddressSerializer

    class Meta:
        model = Invoices
        fields = '__all__'
        ref_name = 'InvoiceDetail'

# Serializer for creating and updating credit notes
class CreditNotesCreateUpdateSerializer(serializers.ModelSerializer):
    class Meta:
        model = CreditNotes
        fields = '__all__'
        ref_name = 'CreditNotesCreateUpdate'  

# Serializer for retrieving credit note details
class CreditNotesDetailSerializer(serializers.ModelSerializer):
    customer_id = CustomerDetailSerializer()
    billing_address = AddressSerializer()
    shipping_address = AddressSerializer()
    salesperson_id = SalesPersonSerializer()

    class Meta:
        model = CreditNotes
        fields = '__all__'
        ref_name = 'CreditNotesDetail'

# Serializer for creating and updating expenses
class ExpensesCreateUpdateSerializer(serializers.ModelSerializer):
    class Meta:
        model = Expenses
        fields = '__all__'
        ref_name = 'ExpensesCreateUpdate'

# Serializer for retrieving expense details
class ExpensesDetailSerializer(serializers.ModelSerializer):
    vendor = CustomerDetailSerializer()
    expense_account = ChartOfAccountsSerializer()
    paid_through = ChartOfAccountsSerializer()

    class Meta:
        model = Expenses
        fields = '__all__'
        ref_name = 'ExpensesDetail'

# Serializer for creating and updating purchase orders
class PurchaseOrderCreateUpdateSerializer(serializers.ModelSerializer):
    class Meta:
        model = PurchaseOrder
        fields = '__all__'
        ref_name = 'PurchaseOrderCreateUpdate'

# Serializer for retrieving purchase order details
class PurchaseOrderDetailSerializer(serializers.ModelSerializer):
    vendor = CustomerDetailSerializer()
    delivery_to = CustomerDetailSerializer()
    payment_terms = PaymentTermsSerializer()
    salesperson = SalesOrderCreateUpdateSerializer
    class Meta:
        model = PurchaseOrder
        fields = '__all__'
        ref_name = 'PurchaseOrderDetail'

# Serializer for creating and updating bills
class BillCreateUpdateSerializer(serializers.ModelSerializer):
    class Meta:
        model = Bill
        fields = '__all__'
# Serializer for retrieving bill details
class BillDetailSerializer(serializers.ModelSerializer):
    vendor = CustomerDetailSerializer()
    # purchase_order = PurchaseOrderDetailSerializer()
    payment_terms = PaymentTermsSerializer()
    # item = ItemDetailSerializer()

    class Meta:
        model = Bill
        fields = '__all__'

# Serializer for creating and updating recurring expenses
class RecurringExpenseCreateUpdateSerializer(serializers.ModelSerializer):
    class Meta:
        model = RecurringExpense
        fields = '__all__'

# Serializer for retrieving recurring expense details
class RecurringExpenseDetailSerializer(serializers.ModelSerializer):
    expense_account = ChartOfAccountsSerializer()
    paid_through = ChartOfAccountsSerializer()
    vendor = CustomerSerializer()
    customer_name = CustomerSerializer()

    class Meta:
        model = RecurringExpense
        fields = '__all__'

class RecurringBillCreateUpdateSerializer(serializers.ModelSerializer):
    class Meta:
        model = RecurringBill
        fields = '__all__'
class RecurringBillDetailSerializer(serializers.ModelSerializer):
    vendor_id = CustomerSerializer()
    payment_terms = PaymentTermsSerializer()
    item = ItemDetailSerializer()

    class Meta:
        model = RecurringBill
        fields = '__all__'

class PaymentMadeCreateSerializer(serializers.ModelSerializer):
    class Meta:
        model = PaymentMade
        fields = '__all__'

class PaymentMadeUpdateSerializer(serializers.ModelSerializer):
    vendor = CustomerDetailSerializer()
    paid_through = ChartOfAccountsSerializer()
    bills = BillCreateUpdateSerializer(many=True)
    class Meta:
        model = PaymentMade
        fields = '__all__'


class PaymentReceivedCreateSerializer(serializers.ModelSerializer):
    class Meta:
        model = PaymentReceived
        fields = '__all__'

class PaymentReceivedUpdateSerializer(serializers.ModelSerializer):
    customer = CustomerSerializer()
    deposit_to = ChartOfAccountsSerializer()
    invoice = InvoiceCreateUpdateSerializer(many=True)
    class Meta:
        model = PaymentReceived
        fields = '__all__'
