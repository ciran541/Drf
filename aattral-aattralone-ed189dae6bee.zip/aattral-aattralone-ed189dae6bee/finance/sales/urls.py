# urls.py
from django.urls import path, include
from rest_framework.routers import DefaultRouter
from .views import (
    SalesPersonViewSet, PaymentTermsViewSet, ContactPersonViewSet,
    CustomerViewSet, QuoteViewSet,RetainerInvoiceViewSet,SalesOrderViewSet,InvoicesViewSet,CreditNotesViewSet,
    ExpensesViewSet,PurchaseOrderViewSet,BillViewSet,RecurringBillViewSet,PaymentMadeViewSet,PaymentReceivedViewSet
)

router = DefaultRouter()
router.register(r'salespersons', SalesPersonViewSet)
router.register(r'paymentterms', PaymentTermsViewSet)
router.register(r'contactpersons', ContactPersonViewSet)
# router.register(r'countries', CountryViewSet)
router.register(r'customers', CustomerViewSet)  # For both Customers and Vendor 
router.register(r'quotes', QuoteViewSet)
router.register(r'retainerinvoices', RetainerInvoiceViewSet)
router.register(r'salesorders', SalesOrderViewSet)
router.register(r'invoices', InvoicesViewSet, basename='invoices')
router.register(r'creditnotes', CreditNotesViewSet, basename='creditnotes') # For both 
# Pruchase: 
router.register(r'expenses', ExpensesViewSet, basename='expense')
router.register(r'purchase-orders', PurchaseOrderViewSet, basename='purchase-order')
router.register(r'bills', BillViewSet, basename='bill')
router.register(r'recurring-bill', RecurringBillViewSet, basename='recurring-bill')

router.register(r'payment-made', PaymentMadeViewSet, basename='record_paymentmade')
router.register(r'payment-received', PaymentReceivedViewSet, basename='record-paymentreceive')
urlpatterns = [
    path('', include(router.urls)),
]
