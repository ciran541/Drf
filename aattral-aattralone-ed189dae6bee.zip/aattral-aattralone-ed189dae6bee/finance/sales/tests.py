from django.test import TestCase
from .models import Address, Country,SalesPerson,ContactPerson,Customer,BillingAddress,ShippingAddress

class AddressTestCase(TestCase):

    def setUp(self):
        self.country = Country.objects.create(name='Test Country', code='TC')
        self.address = Address.objects.create(
            attention='John Doe',
            country=self.country,
            address_street1='123 Main St',
            address_street2='Apt 101',
            city='City',
            state='State',
            zip_code='12345',
            phone='123-456-7890',
            fax_number='987-654-3210'
        )

    def test_address_creation(self):
        """Test address creation"""
        self.assertEqual(self.address.attention, 'John Doe')
        self.assertEqual(self.address.country, self.country)
        self.assertEqual(self.address.address_street1, '123 Main St')
        self.assertEqual(self.address.address_street2, 'Apt 101')
        self.assertEqual(self.address.city, 'City')
        self.assertEqual(self.address.state, 'State')
        self.assertEqual(self.address.zip_code, '12345')
        self.assertEqual(self.address.phone, '123-456-7890')
        self.assertEqual(self.address.fax_number, '987-654-3210')

    def test_country_set_null(self):
        """Test country set to null"""
        address = Address.objects.create(
            attention='Jane Doe',
            country=None,
            address_street1='456 Elm St',
            city='City',
            state='State',
            zip_code='54321',
            phone='987-654-3210'
        )
        self.assertIsNone(address.country)

class SalesPersonTestCase(TestCase):

    def setUp(self):
        self.salesperson = SalesPerson.objects.create(
            name='John Doe',
            email='john.doe@example.com',
            phone='1234567890'
        )

    def test_salesperson_creation(self):
        """Test SalesPerson creation"""
        self.assertEqual(self.salesperson.name, 'John Doe')
        self.assertEqual(self.salesperson.email, 'john.doe@example.com')
        self.assertEqual(self.salesperson.phone, '1234567890')

    def test_salesperson_str_representation(self):
        """Test SalesPerson string representation"""
        self.assertEqual(str(self.salesperson), 'John Doe')

class ContactPersonTestCase(TestCase):

    def setUp(self):
        self.contact_person = ContactPerson.objects.create(
            salutation='Mr',
            first_name='John',
            last_name='Doe',
            email='john@example.com',
            work_phone='1234567890',
            mobile='9876543210',
            designation='Manager',
            department='IT',
            skype='john.doe.skype',
            is_primary_contact=True,
            enable_portal=True
        )

    def test_contact_person_creation(self):
        """Test contact person creation"""
        self.assertEqual(self.contact_person.salutation, 'Mr')
        self.assertEqual(self.contact_person.first_name, 'John')
        self.assertEqual(self.contact_person.last_name, 'Doe')
        self.assertEqual(self.contact_person.email, 'john@example.com')
        self.assertEqual(self.contact_person.work_phone, '1234567890')
        self.assertEqual(self.contact_person.mobile, '9876543210')
        self.assertEqual(self.contact_person.designation, 'Manager')
        self.assertEqual(self.contact_person.department, 'IT')
        self.assertEqual(self.contact_person.skype, 'john.doe.skype')
        self.assertTrue(self.contact_person.is_primary_contact)
        self.assertTrue(self.contact_person.enable_portal)

class CustomerTestCase(TestCase):

    def setUp(self):
        address = Address.objects.create(attention='Test Attention', address='123 Test St')
        billing_address = BillingAddress.objects.create(address=address)
        shipping_address = ShippingAddress.objects.create(address=address)

    def setUp(self):
        self.customer = Customer.objects.create(
            contact_type='Customer',
            customer_sub_type='Business',
            salutation=Customer.MR,
            first_name='John',
            last_name='Doe',
            company_name='ABC Inc.',
            customer_display_name='John Doe - ABC Inc.',
            customer_email='john.doe@example.com',
            customer_phone='1234567890',
            attention='Accounts Department',
            billing_address='123 Main St, Anytown, USA',
            shipping_address='456 Elm St, Othertown, USA',
            gst_treatment='Regular',
            pan='ABCDE1234F',
            gst_no='GSTIN123456789',
            website='https://www.example.com',
            taxable=True,
            currency='USD',
            opening_balance=1000.00,
            payment_terms=None,
            price_list='Standard',
            status='Active',
            enable_portal=True,
            portal_access_allowed=True,
            portal_language='en'
        )

    def test_customer_creation(self):
        """Test customer creation"""
        self.assertEqual(self.customer.contact_type, 'Customer')
        self.assertEqual(self.customer.customer_sub_type, 'Business')
        self.assertEqual(self.customer.salutation, Customer.MR)
        self.assertEqual(self.customer.first_name, 'John')
        self.assertEqual(self.customer.last_name, 'Doe')
        self.assertEqual(self.customer.company_name, 'ABC Inc.')
        self.assertEqual(self.customer.customer_display_name, 'John Doe - ABC Inc.')
        self.assertEqual(self.customer.customer_email, 'john.doe@example.com')
        self.assertEqual(self.customer.customer_phone, '1234567890')
        self.assertEqual(self.customer.attention, 'Accounts Department')
        self.assertEqual(self.customer.billing_address, '123 Main St, Anytown, USA')
        self.assertEqual(self.customer.shipping_address, '456 Elm St, Othertown, USA')
        self.assertEqual(self.customer.gst_treatment, 'Regular')
        self.assertEqual(self.customer.pan, 'ABCDE1234F')
        self.assertEqual(self.customer.gst_no, 'GSTIN123456789')
        self.assertEqual(self.customer.website, 'https://www.example.com')
        self.assertTrue(self.customer.taxable)
        self.assertEqual(self.customer.currency, 'USD')
        self.assertEqual(self.customer.opening_balance, 1000.00)
        self.assertIsNone(self.customer.payment_terms)
        self.assertEqual(self.customer.price_list, 'Standard')
        self.assertEqual(self.customer.status, 'Active')
        self.assertTrue(self.customer.enable_portal)
        self.assertTrue(self.customer.portal_access_allowed)
        self.assertEqual(self.customer.portal_language, 'en')