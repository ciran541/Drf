from django.contrib import admin
from .models import Task, Project, TimeEntry
from django.utils import timezone
@admin.register(Task)
class TaskAdmin(admin.ModelAdmin):
    pass

@admin.register(Project)
class ProjectAdmin(admin.ModelAdmin):
    list_display = ('Project_name', 'user', 'enable_time_tracking', 'billing_method', 'budget_type', 'get_remaining_budget')
    search_fields = ('Project_name', 'user__username')

@admin.register(TimeEntry)
class TimeEntryAdmin(admin.ModelAdmin):
    list_display = ('project', 'task', 'user', 'start_time', 'end_time', 'get_duration', 'billable_status')
    search_fields = ('project__Project_name', 'task__name', 'user__username')

    def save_model(self, request, obj, form, change):
        """
        Override save_model method to set end_time and timer if they're not set.
        """
        if not obj.end_time:
            obj.end_time = timezone.now()
        if not obj.timer:
            obj.timer = obj.end_time - obj.start_time
        super().save_model(request, obj, form, change)
