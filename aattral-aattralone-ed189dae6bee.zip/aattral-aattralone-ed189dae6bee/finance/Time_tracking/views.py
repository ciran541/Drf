from rest_framework import viewsets,status
from rest_framework.decorators import action
from rest_framework.response import Response
from .models import Project, Task, TimeEntry
from .serializers import ProjectDetailSerializer,ProjectCreateUpdateSerializer, TaskSerializer, TimeEntryDetailSerializer,TimeEntryCreateUpdateSerializer

# Viewset for Project model
class ProjectViewSet(viewsets.ModelViewSet):
    queryset = Project.objects.all()
    serializer_class = ProjectDetailSerializer  # Default serializer for GET requests

    def get_serializer_class(self):
        if self.request.method in ['POST', 'PUT', 'PATCH']:
            return ProjectCreateUpdateSerializer  # Use create/update serializer for POST, PUT, PATCH requests
        return self.serializer_class

class TaskViewSet(viewsets.ModelViewSet):
    queryset = Task.objects.all()
    serializer_class = TaskSerializer

# Viewset for TimeEntry model
class TimeEntryViewSet(viewsets.ModelViewSet):
    queryset = TimeEntry.objects.all()
    serializer_class = TimeEntryDetailSerializer  # Default serializer for GET requests

    def get_serializer_class(self):
        if self.request.method in ['POST', 'PUT', 'PATCH']:
            return TimeEntryCreateUpdateSerializer  # Use create/update serializer for POST, PUT, PATCH requests
        return self.serializer_class
    
    @action(detail=True, methods=['get'])
    def time_entry_duration(self, request, pk=None):
        """
        Custom action to retrieve the duration of a specific time entry.
        """
        time_entry = self.get_object()
        duration = time_entry.get_duration()
        return Response({'time_entry_duration': duration.total_seconds() / 3600})
    
    @action(detail=True, methods=['post'])
    def start_timer(self, request, pk=None):
        """
        Custom action to start a timer with specified details.
        """
        time_entry = self.get_object()
        project_id = request.data.get('project_id')
        task_id = request.data.get('task_id')
        billable = request.data.get('billable')
        notes = request.data.get('notes')

        try:
            project = Project.objects.get(id=project_id)
            task = Task.objects.get(id=task_id)
        except Project.DoesNotExist or Task.DoesNotExist:
            return Response({'error': 'Project or Task does not exist.'}, status=status.HTTP_400_BAD_REQUEST)

        time_entry.start_timer(project, task, billable, notes)
        serializer = self.get_serializer(time_entry)
        return Response(serializer.data)