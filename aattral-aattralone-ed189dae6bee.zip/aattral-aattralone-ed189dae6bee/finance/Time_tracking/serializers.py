# serializers.py

from rest_framework import serializers
from .models import Project, Task, TimeEntry
from Authentication.serializers import CustomUserSerializer


class TaskSerializer(serializers.ModelSerializer):
    class Meta:
        model = Task
        fields = '__all__'
        ref_name = 'FinanceTask'
# Serializer for creating and updating projects
class ProjectCreateUpdateSerializer(serializers.ModelSerializer):
    class Meta:
        model = Project
        fields = '__all__'
        ref_name = "ProjectCreateUpdate"

# Serializer for retrieving project details
class ProjectDetailSerializer(serializers.ModelSerializer):
    user = CustomUserSerializer()
    Task = TaskSerializer()

    class Meta:
        model = Project
        fields = '__all__'
        ref_name = "FinanceProjectDetail"


# Serializer for creating and updating time entries
class TimeEntryCreateUpdateSerializer(serializers.ModelSerializer):
    class Meta:
        model = TimeEntry
        fields = '__all__'

# Serializer for retrieving time entry details
class TimeEntryDetailSerializer(serializers.ModelSerializer):
    project = ProjectDetailSerializer()
    task = TaskSerializer()
    user = CustomUserSerializer()

    class Meta:
        model = TimeEntry
        fields = '__all__'
