# urls.py

from rest_framework import routers
from .views import ProjectViewSet, TaskViewSet, TimeEntryViewSet

router = routers.DefaultRouter()
router.register(r'project', ProjectViewSet)
router.register(r'tasks', TaskViewSet)
router.register(r'timeentries', TimeEntryViewSet)

urlpatterns = router.urls
