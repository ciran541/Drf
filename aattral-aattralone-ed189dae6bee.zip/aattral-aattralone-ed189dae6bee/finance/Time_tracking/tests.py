from django.test import TestCase
from .models import TimeEntry, Project, Task, CustomUser
from django.utils import timezone
from datetime import timedelta

class TimeEntryTestCase(TestCase):

    def setUp(self):
        self.user = CustomUser.objects.create(username='testuser', password='password')
        self.task = Task.objects.create(name='Test Task', description='Test Task Description')
        self.project = Project.objects.create(
            Project_name='Test Project',
            user=self.user,
            enable_time_tracking=True,
            billing_method='hourly',
            budget_type='hours',
            Task=self.task,
        )

    def test_get_duration(self):
        """Test get_duration method"""
        start_time = timezone.now()
        end_time = start_time + timedelta(hours=2)  # Simulate 2 hours of time entry
        time_entry = TimeEntry.objects.create(
            project=self.project,
            task=self.task,
            user=self.user,
            start_time=start_time,
            end_time=end_time,
            description='Test Description',
            billable_status=True,
            billing_method='hourly',
        )
        self.assertEqual(time_entry.get_duration(), timedelta(hours=2))

    def test_start_timer(self):
        """Test start_timer method"""
        time_entry = TimeEntry()
        time_entry.start_timer(self.project, self.task, True, 'Test Notes')
        self.assertIsNotNone(time_entry.start_time)

    def test_stop_timer(self):
        """Test stop_timer method"""
        start_time = timezone.now() - timedelta(hours=1)  # Simulate a started timer
        time_entry = TimeEntry.objects.create(
            project=self.project,
            task=self.task,
            user=self.user,
            start_time=start_time,
            end_time=start_time + timedelta(minutes=30),  # Simulate 30 minutes of elapsed time
            description='Test Description',
            billable_status=True,
            billing_method='hourly',
        )
        time_entry.stop_timer()
        self.assertIsNotNone(time_entry.end_time)
        self.assertIsNotNone(time_entry.timer)

    def test_get_elapsed_time(self):
        """Test get_elapsed_time method"""
        # Case when timer is started but not stopped
        start_time = timezone.now() - timedelta(hours=1)  # Simulate a started timer
        time_entry_started = TimeEntry.objects.create(
            project=self.project,
            task=self.task,
            user=self.user,
            start_time=start_time,
            description='Test Description',
            billable_status=True,
            billing_method='hourly',
        )
        self.assertGreater(time_entry_started.get_elapsed_time(), timedelta(seconds=0))

        # Case when timer is stopped
        time_entry_stopped = TimeEntry.objects.create(
            project=self.project,
            task=self.task,
            user=self.user,
            start_time=timezone.now() - timedelta(hours=2),  # Simulate a started and stopped timer
            end_time=timezone.now() - timedelta(hours=1),
            description='Test Description',
            billable_status=True,
            billing_method='hourly',
        )
        self.assertEqual(time_entry_stopped.get_elapsed_time(), timedelta(hours=1))