from django.db import models
from Authentication.models import CustomUser
from django.utils import timezone
from datetime import timedelta

BILLING_METHOD_CHOICES = [
    ('hourly', 'Hourly'),
    ('fixed_rate', 'Fixed Rate'),
    ('project_billing', 'Project Billing'),
    ('subscription', 'Subscription'),
]

class Task(models.Model):
    name = models.CharField(max_length=255, blank=True)
    description = models.TextField(blank=True)

class Project(models.Model):
    Project_name = models.CharField(max_length=255, blank=True)
    user = models.ForeignKey(CustomUser, on_delete=models.CASCADE, blank=True)
    enable_time_tracking = models.BooleanField(default=False)
    billing_method = models.CharField(max_length=50, blank=True)
    budget_type = models.CharField(max_length=50, blank=True)
    Task = models.ForeignKey(Task, on_delete=models.CASCADE, blank=True)
    customer = models.ManyToManyField('sales.Customer', blank=True)

    def get_total_time_entries_duration(self):
        """
        Method to calculate and return the total duration of time entries for the project.
        """
        total_duration = self.timeentry_set.aggregate(models.Sum('timer'))['timer__sum']
        return total_duration if total_duration else 0

    def get_remaining_budget(self):
        """
        Method to calculate and return the remaining budget for the project.
        """
        total_duration = self.get_total_time_entries_duration()
        if self.billing_method == 'hourly' and self.budget_type == 'hours':
            return self.task.budget_hours - total_duration.total_seconds() / 3600
        elif self.billing_method == 'fixed_rate' and self.budget_type == 'amount':
            return self.task.budget_amount - total_duration.total_seconds() / 3600
        else:
            return None

class TimeEntry(models.Model):
    project = models.ForeignKey(Project, on_delete=models.CASCADE, blank=True)
    task = models.ForeignKey(Task, on_delete=models.CASCADE, blank=True)
    user = models.ForeignKey(CustomUser, on_delete=models.CASCADE, blank=True)
    start_time = models.DateTimeField(blank=True)
    end_time = models.DateTimeField(blank=True)
    timer = models.DurationField(null=True, blank=True)
    description = models.TextField(blank=True)
    billable_status = models.BooleanField(default=False)
    billing_method = models.CharField(max_length=20, choices=BILLING_METHOD_CHOICES, blank=True)
    customer = models.ManyToManyField('sales.Customer', blank=True)

    def get_duration(self):
        """
        Method to calculate and return the duration of the time entry.
        """
        return self.end_time - self.start_time if self.end_time and self.start_time else timedelta()

    def start_timer(self, project, task, billable, notes):
        """
        Method to start a timer with specified details.
        """
        self.project = project
        self.task = task
        self.billable_status = billable
        self.description = notes
        self.start_time = timezone.now()
        self.save()

    def stop_timer(self):
        """
        Method to stop the timer.
        """
        self.end_time = timezone.now()
        self.timer = self.end_time - self.start_time
        self.save()

    def get_elapsed_time(self):
        """
        Method to get the elapsed time of the timer.
        """
        if self.start_time and not self.end_time:
            return timezone.now() - self.start_time
        elif self.start_time and self.end_time:
            return self.end_time - self.start_time
        else:
            return timedelta(seconds=0)
