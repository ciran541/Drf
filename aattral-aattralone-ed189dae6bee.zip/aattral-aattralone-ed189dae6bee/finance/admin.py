from django.contrib import admin
from django.contrib.admin import AdminSite, ModelAdmin
from finance.Accountant.models import ChartOfAccounts, ManualJournalEntry, Folder, Document, BankAccount
from finance.Item.models import Item,Unit
class FinanceAdminSite(AdminSite):
    site_header = 'FINANCE Administration'
    site_title = 'Welcome To AattralOne FINANCE'

# Define FinanceAdminSite instance
finance_admin_site = FinanceAdminSite(name='finance_admin')

# Define FinanceModelAdmin if needed
class FinanceModelAdmin(ModelAdmin):
    pass

# Register ChartOfAccounts with ChartOfAccountsAdmin
class ChartOfAccountsAdmin(admin.ModelAdmin):
    list_display = ('AccountID', 'AccountCode', 'AccountName', 'AccountType', 'Description', 'ParentAccountID', 'IsActive')
    search_fields = ['AccountName']  # Add search field for AccountName
    raw_id_fields = ['ParentAccountID']  # Use raw_id_fields for ParentAccountID

finance_admin_site.register(ChartOfAccounts, ChartOfAccountsAdmin)

# Register other models similarly using the @finance_admin_site.register decorator
class ManualJournalEntryAdmin(admin.ModelAdmin):
    list_display = ['date', 'journal_number', 'reference_number']
    search_fields = ['reference_number']

finance_admin_site.register(ManualJournalEntry,ManualJournalEntryAdmin)

class FolderAdmin(admin.ModelAdmin):
    pass

finance_admin_site.register(Folder,FolderAdmin)

class DocumentAdmin(admin.ModelAdmin):
    list_display = [ 'uploaded_by', 'upload_date']
    list_filter = ['uploaded_by']
    search_fields = ['document_name', 'tags']

finance_admin_site.register(Document,DocumentAdmin)
class BankAccountAdmin(admin.ModelAdmin):
    list_display = ['account_name', 'account_code', 'currency', 'bank_name', 'is_primary']
    list_filter = ['currency', 'is_primary']
    search_fields = ['account_name', 'bank_name']

    def required_fields_for_account_type(self, obj):
        return obj.get_required_fields()

    required_fields_for_account_type.short_description = 'Required Fields for Account Type'

finance_admin_site.register(BankAccount,BankAccountAdmin)


class UnitAdmin(admin.ModelAdmin):
    pass

finance_admin_site.register(Unit)


class ItemAdmin(admin.ModelAdmin):
    pass

finance_admin_site.register(Item)
