from django.test import TestCase
from Authentication.models import CustomUser
from .models import Organization,ChartOfAccounts,ManualJournalEntry,BankAccount,Document,Folder
from django.utils import timezone

class OrganizationTestCase(TestCase):

    def setUp(self):
        self.org1 = Organization.objects.create(
            organization_id='org1',
            name='Test Organization 1',
            contact_name='John Doe',
            email='john@example.com',
            is_default_org=False,
            language_code='en',
            fiscal_year_start_month=1,
            account_created_date=timezone.now(),
            time_zone='UTC',
            is_org_active=True,
            currency_id='USD',
            currency_code='USD',
            currency_symbol='$',
            currency_format='0.00',
            price_precision=2
        )
        self.org2 = Organization.objects.create(
            organization_id='org2',
            name='Test Organization 2',
            contact_name='Jane Doe',
            email='jane@example.com',
            is_default_org=True,
            language_code='en',
            fiscal_year_start_month=1,
            account_created_date=timezone.now(),
            time_zone='UTC',
            is_org_active=False,
            currency_id='EUR',
            currency_code='EUR',
            currency_symbol='€',
            currency_format='0,00',
            price_precision=2
        )

    def test_organization_creation(self):
        """Test organization creation"""
        self.assertEqual(self.org1.name, 'Test Organization 1')
        self.assertEqual(self.org2.name, 'Test Organization 2')

    def test_default_organization(self):
        """Test default organization flag"""
        self.assertFalse(self.org1.is_default_org)
        self.assertTrue(self.org2.is_default_org)

    def test_organization_active_status(self):
        """Test organization active status"""
        self.assertTrue(self.org1.is_org_active)
        self.assertFalse(self.org2.is_org_active)

class ChartOfAccountsTestCase(TestCase):

    def setUp(self):
        self.parent_account = ChartOfAccounts.objects.create(
            AccountName='Parent Account',
            AccountType='Equity',
            IsActive=True
        )
        self.child_account = ChartOfAccounts.objects.create(
            AccountName='Child Account',
            AccountType='Current Assets',
            ParentAccountID=self.parent_account,
            IsActive=True
        )

    def test_account_creation(self):
        """Test account creation"""
        self.assertEqual(self.parent_account.AccountName, 'Parent Account')
        self.assertEqual(self.child_account.AccountName, 'Child Account')

    def test_account_type_choices(self):
        """Test account type choices"""
        valid_choices = [
            'Current Assets',
            'Fixed Assetse',
            'Other Assets',
            'Current Liabilities',
            'Long-Term Liabilities',
            'Equity',
            'Other Revenue',
            'Sales Revenue',
            'Service Revenue',
            'Cost of Goods Sold (COGS)',
            'Operating Expenses',
            'Interest Expenses',
        ]
        self.assertIn(self.parent_account.AccountType, valid_choices)
        self.assertIn(self.child_account.AccountType, valid_choices)

    def test_parent_child_relationship(self):
        """Test parent-child relationship"""
        self.assertEqual(self.child_account.ParentAccountID, self.parent_account)

    def test_account_is_active(self):
        """Test account is active"""
        self.assertTrue(self.parent_account.IsActive)
        self.assertTrue(self.child_account.IsActive)


class ManualJournalEntryTestCase(TestCase):

    def setUp(self):
        # Create a chart of accounts for testing
        self.debit_account = ChartOfAccounts.objects.create(AccountName='Debit Account', AccountType='Current Assets')
        self.credit_account = ChartOfAccounts.objects.create(AccountName='Credit Account', AccountType='Current Liabilities')

        # Create a manual journal entry for testing
        self.entry = ManualJournalEntry.objects.create(
            date='2024-03-14',
            journal_number=1,
            reference_number='REF001',
            notes='Test journal entry',
            debit_account=self.debit_account,
            credit_account=self.credit_account,
            debit_amount=100.00,
            credit_amount=100.00,
            currency='USD',
            slug='test-journal-entry'
        )

    def test_journal_entry_creation(self):
        """Test manual journal entry creation"""
        self.assertEqual(self.entry.date, '2024-03-14')
        self.assertEqual(self.entry.journal_number, 1)
        self.assertEqual(self.entry.reference_number, 'REF001')
        self.assertEqual(self.entry.notes, 'Test journal entry')
        self.assertEqual(self.entry.debit_account, self.debit_account)
        self.assertEqual(self.entry.credit_account, self.credit_account)
        self.assertEqual(self.entry.debit_amount, 100.00)
        self.assertEqual(self.entry.credit_amount, 100.00)
        self.assertEqual(self.entry.currency, 'USD')
        self.assertEqual(self.entry.slug, 'test-journal-entry')

    def test_total_amount_calculation(self):
        """Test total amount calculation"""
        self.assertEqual(self.entry.get_total_amount(), 0.00)  # Total amount should be zero for balanced entry

    def test_difference_calculation(self):
        """Test difference calculation"""
        self.assertEqual(self.entry.get_difference(), 0.00)  # Difference should be zero for balanced entry

class BankAccountTestCase(TestCase):

    def setUp(self):
        self.bank_account_bank = BankAccount.objects.create(
            account_name='Bank Account 1',
            account_code='BA001',
            currency='USD',
            account_number='123456789',
            bank_name='Bank of America',
            description='This is a bank account',
            is_primary=True,
            account_type='Bank'
        )
        self.bank_account_credit_card = BankAccount.objects.create(
            account_name='Credit Card Account 1',
            account_code='CC001',
            currency='EUR',
            bank_name='Visa',
            description='This is a credit card account',
            is_primary=False,
            account_type='Credit Card'
        )

    def test_get_required_fields_bank_account(self):
        """Test get_required_fields method for bank account"""
        required_fields = self.bank_account_bank.get_required_fields()
        expected_fields = ['account_name', 'account_code', 'currency', 'account_number', 'bank_name', 'description']
        self.assertEqual(required_fields, expected_fields)

    def test_get_required_fields_credit_card_account(self):
        """Test get_required_fields method for credit card account"""
        required_fields = self.bank_account_credit_card.get_required_fields()
        expected_fields = ['account_name', 'account_code', 'currency', 'bank_name', 'description']
        self.assertEqual(required_fields, expected_fields)

class DocumentTestCase(TestCase):

    def setUp(self):
        # Create related instances for testing relationships
        self.user = CustomUser.objects.create(username='test_user')
        self.folder = Folder.objects.create(name='Test Folder')
        self.bank_account = BankAccount.objects.create(
            account_name='Bank Account 1',
            account_code='BA001',
            currency='USD',
            account_number='123456789',
            bank_name='Bank of America',
            description='This is a bank account',
            is_primary=True,
            account_type='Bank'
        )

    def test_document_creation(self):
        """Test document creation"""
        document = Document.objects.create(
            document_name='Test Document',
            file_type='.pdf',
            uploaded_by=self.user,
            folder=self.folder,
            file_size=1024,
            description='This is a test document',
            tags='test, document',
            version_number=1,
            bank_account=self.bank_account
        )
        self.assertEqual(document.document_name, 'Test Document')

    def test_document_folder_relationship(self):
        """Test document-folder relationship"""
        document = Document.objects.create(
            document_name='Test Document',
            file_type='.pdf',
            uploaded_by=self.user,
            folder=self.folder,
            file_size=1024,
            description='This is a test document',
            version_number=1
        )
        self.assertEqual(document.folder, self.folder)

    def test_document_bank_account_relationship(self):
        """Test document-bank account relationship"""
        document = Document.objects.create(
            document_name='Test Document',
            file_type='.pdf',
            uploaded_by=self.user,
            folder=self.folder,
            file_size=1024,
            description='This is a test document',
            version_number=1,
            bank_account=self.bank_account
        )
        self.assertEqual(document.bank_account, self.bank_account)
