# views.py
import calendar
from rest_framework import viewsets
from rest_framework.decorators import action
from rest_framework.response import Response
from rest_framework import status
from django.db.models import Sum, Value
from django.db.models.functions import Cast
from django.db.models import DecimalField, Case, When
from django.db.models.functions import Coalesce, Cast
from datetime import date
from .models import ChartOfAccounts,ManualJournalEntry,Folder,Document,BankAccount,Organization
from .serializers import (ChartOfAccountsSerializer,ManualJournalEntrygetSerializer,ManualJournalEntrycreateSerializer,
FolderSerializer,DocumentSerializer,BankAccountSerializer,OrganizationSerializer)
from decimal import Decimal


class OrganizationViewSet(viewsets.ModelViewSet):
    queryset = Organization.objects.all()
    serializer_class = OrganizationSerializer

class ChartOfAccountsViewSet(viewsets.ModelViewSet):
    queryset = ChartOfAccounts.objects.all()
    serializer_class = ChartOfAccountsSerializer

    @action(detail=True, methods=['get'])
    def sub_accounts(self, request, pk=None):
        """
        Custom action to retrieve the sub-accounts of a specific account.
        """
        account = self.get_object()
        sub_accounts = account.get_sub_accounts()
        serializer = self.get_serializer(sub_accounts, many=True)
        return Response(serializer.data)
    
    # # Custom action for Dashboard (For Total value of current assets(Total Receivables))
    # @action(detail=False, methods=['get'])
    # def get_total_current_assets(self, request):
    #     """
    #     Custom action to get the total value of current assets.
    #     """
    #     current_assets = ChartOfAccounts.objects.filter(AccountType='Current Assets')
    #     total_current_assets = current_assets.aggregate(total=Sum('Amount'))['total']
    #     return Response({'total_current_assets': total_current_assets})
    
    # # Custom action for Dashboard (For Total value of current liabilities (Total Payables))
    # @action(detail=False, methods=['get'])
    # def get_total_current_liabilities(self, request):
    #     """
    #     Custom action to get the total value of current liabilities.
    #     """
    #     current_liabilities = ChartOfAccounts.objects.filter(AccountType='Current Liabilities')
    #     total_current_liabilities = current_liabilities.aggregate(total=Sum('Amount'))['total']
    #     return Response({'total_current_liabilities': total_current_liabilities})

class ManualJournalEntryViewSet(viewsets.ModelViewSet):
    queryset = ManualJournalEntry.objects.all()
    serializer_class = ManualJournalEntrygetSerializer

    def get_serializer_class(self):
        if self.request.method == 'GET':
            return ManualJournalEntrygetSerializer  # Use detail serializer for GET requests
        elif self.request.method in ['POST', 'PUT', 'PATCH']:
            return ManualJournalEntrycreateSerializer  # Use create/update serializer for POST, PUT, PATCH requests
        return self.serializer_class

    @action(detail=True, methods=['get'])
    def total_amount(self, request, pk=None):
        """
        Custom action to retrieve the total amount for a specific manual journal entry.
        """
        entry = self.get_object()
        total_amount = sum(entry['amount'] for entry in entry.journal_entry)
        return Response({'total_amount': total_amount})
    
    @action(detail=True, methods=['get'])
    def difference(self, request, pk=None):
        """
        Custom action to retrieve the difference between debit and credit amounts for a specific manual journal entry.
        """
        entry = self.get_object()
        total_debit = sum(entry['amount'] for entry in entry.journal_entry if entry['debit'])
        total_credit = sum(entry['amount'] for entry in entry.journal_entry if entry['credit'])
        difference = total_debit - total_credit
        return Response({'difference': difference})
    
    # Custom action for Dashboard

    # Custom action for Dashboard (For Total value of current assets(Total Receivables))
    @action(detail=False, methods=['get'])
    def get_total_current_assets(self, request):
        """
        Custom action to get the total value of current assets (Total Receivables).
        """
        # Fetch all ManualJournalEntry instances
        entries = ManualJournalEntry.objects.all()

        total_current_assets = 0

        # Iterate over each ManualJournalEntry instance
        for entry in entries:
            # Check if the entry is related to 'Current Assets' in any of its journal entries
            if any(journal_entry.get('accountType') == 'Current Assets' for journal_entry in entry.journal_entry):
                # Add the amount from the main entry to total_current_assets
                total_current_assets += float(entry.amount)

        return Response({'total_current_assets': total_current_assets})
    
    # Custom action for Dashboard (For Total value of current liabilities (Total Payables))
    @action(detail=False, methods=['get'])
    def get_total_current_liabilities(self, request):
        """
        Custom action to get the total value of current liabilities.
        """
        # Fetch all ManualJournalEntry instances
        entries = ManualJournalEntry.objects.all()

        total_current_liabilities = 0

        # Iterate over each ManualJournalEntry instance
        for entry in entries:
            # Check if the entry is related to 'Current Liabilities' in any of its journal entries
            if any(journal_entry.get('accountType') == 'Current Liabilities' for journal_entry in entry.journal_entry):
                # Add the amount from the main entry to total_current_liabilities
                total_current_liabilities += float(entry.amount)

        return Response({'total_current_liabilities': total_current_liabilities})


    @action(detail=False, methods=['get'])
    def cash_flow_dashboard(self, request):
        """
        Custom action to generate a cash flow dashboard.
        """
        today = date.today()
        cash_flow_entries = ManualJournalEntry.objects.filter(date__lte=today)

        total_inflow = Decimal(0)
        total_outflow = Decimal(0)

        for entry in cash_flow_entries:
            # Add amount from 'amount' field
            total_inflow += entry.amount if entry.amount and entry.amount > Decimal(0) else Decimal(0)
            total_outflow += abs(entry.amount) if entry.amount and entry.amount < Decimal(0) else Decimal(0)

            # Add amount from 'journal_entry' field
            if entry.journal_entry:
                for journal in entry.journal_entry:
                    amount = Decimal(journal.get('amount', 0))
                    if journal.get('debit'):
                        total_outflow += amount
                    elif journal.get('credit'):
                        total_inflow += amount

        response_data = {
            'total_inflow': total_inflow,
            'total_outflow': total_outflow,
        }

        return Response(response_data)
    @action(detail=False, methods=['get'])
    def get_top_expenses(self, request):
        """
        Custom action to retrieve the top expenses entries.
        """
        top_expenses_entries = ManualJournalEntry.objects.filter(journal_entry__debit__isnull=False).order_by('-amount')[:5]
        serializer = self.get_serializer(top_expenses_entries, many=True)
        return Response(serializer.data)

    @action(detail=False, methods=['get'])
    def get_top_revenue(self, request):
        """
        Custom action to retrieve the top revenue entries.
        """
        top_revenue_entries = ManualJournalEntry.objects.filter(journal_entry__credit__isnull=False).annotate(
            total_amount=Sum('amount')
        ).order_by('-total_amount')[:5]

        serializer = self.get_serializer(top_revenue_entries, many=True)
        return Response(serializer.data)
    
    @action(detail=False, methods=['get'])
    def chart_data(self, request):
        """
        Custom action to generate chart data for all 12 months with zero values for missing months.
        """
        # Get current year and month names
        current_year = date.today().year
        month_names = [calendar.month_name[i] for i in range(1, 13)]  # List of all month names

        # Aggregate cash flow data for the current year
        cash_flow_data = ManualJournalEntry.objects.filter(date__year=current_year).values('date__month').annotate(
            total_cash_flow=Sum('amount')
        )

        # Create a dictionary to store cash flow data by month
        cash_flow_by_month = {item['date__month']: item['total_cash_flow'] for item in cash_flow_data}

        # Prepare chart data for all 12 months
        chart_data = []
        for month_num in range(1, 13):  # Iterate over all 12 months
            month_name = calendar.month_name[month_num]
            total_cash_flow = cash_flow_by_month.get(month_num, 0)  # Get total cash flow or default to 0 if no data

            chart_data.append({
                'month': month_name,
                'data': total_cash_flow
            })

        return Response(chart_data)
    
    @action(detail=False, methods=['get'])
    def chart_data_by_year(self, request):
        """
        Custom action to generate chart data grouped by year (filtered by client-specified year).
        """
        year_param = request.query_params.get('year')  # Get 'year' query parameter from request
        if not year_param:
            return Response({'error': 'Year parameter is required'}, status=status.HTTP_400_BAD_REQUEST)

        try:
            year = int(year_param)  # Convert year parameter to integer
        except ValueError:
            return Response({'error': 'Invalid year format'}, status=status.HTTP_400_BAD_REQUEST)

        # Filter cash flow data for the specified year
        cash_flow_data = ManualJournalEntry.objects.filter(date__year=year).values('date__month').annotate(
            total_cash_flow=Sum('amount')
        )

        cash_flow_by_month = {item['date__month']: item['total_cash_flow'] for item in cash_flow_data}

        # Prepare chart data for all 12 months of the specified year
        chart_data_by_year = []
        for month_num in range(1, 13):
            month_name = calendar.month_name[month_num]
            total_cash_flow = cash_flow_by_month.get(month_num, 0)

            chart_data_by_year.append({
                'month': month_name,
                'data': total_cash_flow
            })

        return Response(chart_data_by_year)
    

class FolderViewSet(viewsets.ModelViewSet):
    queryset = Folder.objects.all()
    serializer_class = FolderSerializer

class DocumentViewSet(viewsets.ModelViewSet):
    queryset = Document.objects.all()
    serializer_class = DocumentSerializer

class BankAccountViewSet(viewsets.ModelViewSet):
    queryset = BankAccount.objects.all()
    serializer_class = BankAccountSerializer

    def create(self, request, *args, **kwargs):
        serializer = self.get_serializer(data=request.data)
        serializer.is_valid(raise_exception=True)

        # Ensure that if is_primary is set to True, update other accounts for the user
        is_primary = request.data.get('is_primary', False)

        if is_primary:
            BankAccount.objects.filter(user=request.user).update(is_primary=False)

        self.perform_create(serializer)
        headers = self.get_success_headers(serializer.data)

        return Response(serializer.data, status=status.HTTP_201_CREATED, headers=headers)