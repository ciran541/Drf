
from django.contrib import admin
from .models import Organization, ChartOfAccounts, ManualJournalEntry, Folder, Document, BankAccount

@admin.register(Organization)
class OrganizationAdmin(admin.ModelAdmin):
    pass

class ChartOfAccountsAdmin(admin.ModelAdmin):
    list_display = ('AccountID', 'AccountCode', 'AccountName', 'AccountType', 'Description', 'ParentAccountID', 'IsActive')
    search_fields = ['AccountName']  # Add search field for AccountName
    raw_id_fields = ['ParentAccountID']  # Use raw_id_fields for ParentAccountID

admin.site.register(ChartOfAccounts, ChartOfAccountsAdmin)

@admin.register(ManualJournalEntry)
class ManualJournalEntryAdmin(admin.ModelAdmin):
    list_display = ['date', 'journal_number', 'reference_number']
    search_fields = ['reference_number']

@admin.register(Folder)
class FolderAdmin(admin.ModelAdmin):
    pass

@admin.register(Document)
class DocumentAdmin(admin.ModelAdmin):
    list_display = [ 'uploaded_by', 'upload_date']
    list_filter = ['uploaded_by']
    search_fields = ['document_name', 'tags']

@admin.register(BankAccount)
class BankAccountAdmin(admin.ModelAdmin):
    list_display = ['account_name', 'account_code', 'currency', 'bank_name', 'is_primary']
    list_filter = ['currency', 'is_primary']
    search_fields = ['account_name', 'bank_name']

    def required_fields_for_account_type(self, obj):
        return obj.get_required_fields()

    required_fields_for_account_type.short_description = 'Required Fields for Account Type'
