# urls.py

from django.urls import path, include
from rest_framework.routers import DefaultRouter
from .views import ChartOfAccountsViewSet,ManualJournalEntryViewSet,FolderViewSet,DocumentViewSet,BankAccountViewSet,OrganizationViewSet

router = DefaultRouter()
router.register(r'organizations', OrganizationViewSet)
router.register(r'chart-of-accounts', ChartOfAccountsViewSet)
router.register(r'manual-journal-entries', ManualJournalEntryViewSet, basename='manual-journal-entry')
router.register(r'folders', FolderViewSet)
router.register(r'documents', DocumentViewSet)
router.register(r'bank-accounts', BankAccountViewSet)

urlpatterns = [
    path('', include(router.urls)),
]

'''For manual journal entries'''
# GET /api/manual-journal-entries/: Retrieve a list of manual journal entries
# POST /api/manual-journal-entries/: Create a new manual journal entry
# GET /api/manual-journal-entries/{id}/: Retrieve details of a specific manual journal entry
# PUT /api/manual-journal-entries/{id}/: Update a specific manual journal entry
# PATCH /api/manual-journal-entries/{id}/: Partially update a specific manual journal entry
# DELETE /api/manual-journal-entries/{id}/: Delete a specific manual journal entry
# GET /api/manual-journal-entries/{id}/total_amount/: Retrieve the total amount for a specific manual journal entry
# GET /api/manual-journal-entries/{id}/difference/: Retrieve the difference between debit and credit amounts for a specific manual journal entry