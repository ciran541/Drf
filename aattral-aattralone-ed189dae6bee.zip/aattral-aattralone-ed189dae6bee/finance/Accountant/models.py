from django.db import models
from Authentication.models import CustomUser
'''
Assets:
Current Assets (e.g., cash, accounts receivable)
Fixed Assets (e.g., property, plant, equipment)
Other Assets (e.g., investments, intangible assets)

Liabilities:
Current Liabilities (e.g., accounts payable, short-term loans)
Long-Term Liabilities (e.g., long-term loans, bonds payable)

Equity:
Owner's Equity (for sole proprietorships/partnerships)
Shareholder's Equity (for corporations)

Income:
Sales Revenue
Service Revenue
Other Revenue

Expenses:
Cost of Goods Sold (COGS)
Operating Expenses (e.g., rent, utilities, salaries)
Depreciation and Amortization
Interest Expenses
Taxes
'''

class Organization(models.Model):
    organization_id = models.CharField(max_length=20, primary_key=True)
    name = models.CharField(max_length=255,blank=True)
    contact_name = models.CharField(max_length=255,blank=True)
    email = models.EmailField(blank=True)
    is_default_org = models.BooleanField(default=False)
    language_code = models.CharField(max_length=5,blank=True)
    fiscal_year_start_month = models.PositiveIntegerField(blank=True)
    account_created_date = models.DateField(auto_now=True)
    time_zone = models.CharField(max_length=50)
    is_org_active = models.BooleanField(default=True)
    currency_id = models.CharField(max_length=20,blank=True)
    currency_code = models.CharField(max_length=5,blank=True)
    currency_symbol = models.CharField(max_length=5,blank=True)
    currency_format = models.CharField(max_length=20,blank=True)
    price_precision = models.PositiveIntegerField(blank=True)

    def __str__(self):
        return self.name

CURRENCY_CHOICES = [
        ('USD', 'US Dollar'),
        ('EUR', 'Euro'),
        ('JPY', 'Japanese Yen'),
        ('GBP', 'British Pound'),
        ('AUD', 'Australian Dollar'),
        ('CAD', 'Canadian Dollar'),
        ('CHF', 'Swiss Franc'),
        ('CNY', 'Chinese Yuan'),
        ('SEK', 'Swedish Krona'),
        ('NZD', 'New Zealand Dollar'),
        # Add more currencies as needed
    ]

class ChartOfAccounts(models.Model):
    AccountID = models.AutoField(primary_key=True)
    AccountCode = models.CharField(max_length=20, blank=True, null=True)
    AccountName = models.CharField(max_length=255)
    AccountType = models.CharField(max_length=50, choices=[
        ('Current Assets', 'Current Assets'),
        ('Fixed Assetse', 'Fixed Assets'),
        ('Other Assets', 'Other Assets'),

        ('Current Liabilities', 'Current Liabilities'),
        ('Long-Term Liabilities', 'Long-Term Liabilities'),

        ('Equity', 'Equity'),

        ('Other Revenue', 'Other Revenue'),
        ('Sales Revenue', 'Sales Revenue'),
        ('Service Revenue', 'Service Revenue'),

        ('Cost of Goods Sold (COGS)', 'Cost of Goods Sold (COGS)'),
        ('Operating Expenses', 'Operating Expenses'),
        ('Interest Expenses', 'Interest Expenses'),


    ])
    Description = models.TextField(blank=True, null=True)
    ParentAccountID = models.ForeignKey('self', on_delete=models.CASCADE, null=True, blank=True)
    IsActive = models.BooleanField(default=True)

    def get_sub_accounts(self):
        """
        Method to get the sub-accounts of the current account.
        """
        return ChartOfAccounts.objects.filter(ParentAccountID=self)


    def __str__(self):
        return self.AccountName


class ManualJournalEntry(models.Model):

    
    date = models.DateField(blank=True,null=True)
    journal_number = models.AutoField(primary_key=True)
    reference_number = models.CharField(max_length=255, unique=True) 
    notes = models.TextField(max_length=500,blank=True,null=True)
    
    # # Separate Debit and Credit Accounts
    # debit_account = models.ForeignKey('ChartOfAccounts', on_delete=models.CASCADE, related_name='debit_entries',blank=True)
    # credit_account = models.ForeignKey('ChartOfAccounts', on_delete=models.CASCADE, related_name='credit_entries',blank=True)

    journal_entry = models.JSONField(blank=True,null =True)

    #  Add a Transaction Total Field
    amount = models.DecimalField(max_digits=10, decimal_places=2,blank=True,null=True)

    currency = models.CharField(max_length=3,choices=CURRENCY_CHOICES,blank=True)

    attachments = models.FileField(upload_to='documents/',blank=True,null=True)
    

    # we need to change attachments = models.FileField(upload_to='documents/',blank=True) from upload_to='documents refering the Documents table once we create 

class Folder(models.Model):
    name = models.CharField(max_length=255)
    # Add other folder-related fields as needed

class Document(models.Model):

    uploaded_by = models.ForeignKey(CustomUser, on_delete=models.CASCADE)
    upload_date = models.DateTimeField(auto_now_add=True)
    folder = models.ForeignKey(Folder, on_delete=models.CASCADE,blank=True,null=True)
    bank_account = models.ForeignKey('BankAccount', on_delete=models.SET_NULL, blank=True, null=True)
    attachments = models.FileField(upload_to='documents/',blank=True)
class BankAccount(models.Model):
    ACCOUNT_TYPE_CHOICES = [
        ('Bank', 'Bank'),
        ('Credit Card', 'Credit Card'),
    ]

    account_name = models.CharField(max_length=255)
    account_code = models.CharField(max_length=10)
    currency = models.CharField(max_length=3,choices=CURRENCY_CHOICES)  # Assuming currency code like USD, EUR, etc.
    account_number = models.CharField(max_length=255, blank=True, null=True)  # Encrypted or masked for security
    bank_name = models.CharField(max_length=255, blank=True, null=True)
    description = models.TextField(max_length=500, blank=True, null=True)
    is_primary = models.BooleanField(default=False)
    account_type = models.CharField(max_length=20, choices=ACCOUNT_TYPE_CHOICES)


    def get_required_fields(self):
        if self.account_type == 'Credit Card':
            return ['account_name', 'account_code', 'currency', 'bank_name', 'description']
        else:  # Assuming 'Bank'
            return ['account_name', 'account_code', 'currency', 'account_number', 'bank_name', 'description']