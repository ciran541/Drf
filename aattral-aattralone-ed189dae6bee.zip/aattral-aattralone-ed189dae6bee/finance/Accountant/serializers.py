# serializers.py
from rest_framework import serializers
from .models import ChartOfAccounts,ManualJournalEntry,Folder,Document,BankAccount,Organization

# serializers.py
class OrganizationSerializer(serializers.ModelSerializer):
    class Meta:
        model = Organization
        fields = '__all__'
        ref_name = 'FinanceOrganization'

class ChartOfAccountsSerializer(serializers.ModelSerializer):
    class Meta:
        model = ChartOfAccounts
        fields = '__all__'

    def __init__(self, *args, **kwargs):
        super(ChartOfAccountsSerializer, self).__init__(*args, **kwargs)

        # If 'request' is available in the context, fetch the AccountType
        account_type = None
        if 'request' in self.context:
            account_type = self.context['request'].data.get('AccountType')

        # Dynamically filter ParentAccountID queryset based on AccountType
        if account_type:
            self.fields['ParentAccountID'].queryset = ChartOfAccounts.objects.filter(AccountType=account_type)
        else:
            # If AccountType is not provided or if 'request' is not in context, exclude all choices
            self.fields['ParentAccountID'].queryset = ChartOfAccounts.objects.none()

    def validate_ParentAccountID(self, value):
        # Validate that the selected ParentAccountID has the same AccountType as the current instance
        if value and value.AccountType != self.validated_data['AccountType']:
            raise serializers.ValidationError("Parent account must have the same AccountType.")
        return value
    
    def to_representation(self, instance):
        # Override to_representation to customize the representation of the serializer
        representation = super(ChartOfAccountsSerializer, self).to_representation(instance)

        # If creating a new instance, dynamically filter ParentAccountID choices based on AccountType
        if not instance.pk:
            account_type = representation.get('AccountType')
            representation['ParentAccountID'] = ChartOfAccounts.objects.filter(AccountType=account_type).values('AccountID', 'AccountName')

        return representation
    
class ManualJournalEntrycreateSerializer(serializers.ModelSerializer):

    class Meta:
        model = ManualJournalEntry
        fields = '__all__'


class ManualJournalEntrygetSerializer(serializers.ModelSerializer):

    debit_account= ChartOfAccountsSerializer(read_only=True)
    credit_account = ChartOfAccountsSerializer(read_only=True)
    class Meta:
        model = ManualJournalEntry
        fields = '__all__'

class FolderSerializer(serializers.ModelSerializer):
    class Meta:
        model = Folder
        fields = '__all__'

class DocumentSerializer(serializers.ModelSerializer):
    class Meta:
        model = Document
        fields = '__all__'
        ref_name = 'FinanceDocument'
class BankAccountSerializer(serializers.ModelSerializer):
    class Meta:
        model = BankAccount
        fields = '__all__'

    def to_representation(self, instance):
        # Override to dynamically include/exclude fields based on account type
        required_fields = instance.get_required_fields()
        return {field: getattr(instance, field) for field in required_fields}