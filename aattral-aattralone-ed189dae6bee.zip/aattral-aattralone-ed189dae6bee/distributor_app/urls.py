from django.urls import path, include
from rest_framework.routers import DefaultRouter
from .views import DistributorViewSet

router = DefaultRouter()
router.register(r'distributors', DistributorViewSet)

urlpatterns = [
    path('', include(router.urls)),
]