from django.apps import AppConfig


class DistributorAppConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'distributor_app'
