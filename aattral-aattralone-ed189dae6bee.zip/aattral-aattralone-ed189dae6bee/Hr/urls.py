from django.urls import path, include
from rest_framework.routers import DefaultRouter
from .views import EmployeeViewSet

router = DefaultRouter()
router.register(r'employees', EmployeeViewSet)

urlpatterns = [
    path('', include(router.urls)),
    path('Onboarding/', include('Hr.Onboarding.urls')),
    path('employee_info/', include('Hr.employee_information.urls')),
    path('Attendance/', include('Hr.Attendance.urls')),
    path('leave_tracking/', include('Hr.Leave_management.urls')),
    path('timetracker/', include('Hr.Timesheet.urls')),
    path('performance/', include('Hr.performance_management.urls')),
    path('task/', include('Hr.Task.urls')),
    path('notification/', include('Hr.Notifications.urls')),
]
