from django.contrib import admin
from .models import Employee, Address, IdentityInformation, Location, Role, Designation, Department, EmployeeSkills, Language, EmployeeLanguageProficiency, TechnicalSkill, EmployeeTechnicalSkill, SoftSkill, EmployeeSoftSkill, IndustrySpecificSkill, EmployeeIndustrySpecificSkill

@admin.register(Employee)
class EmployeeAdmin(admin.ModelAdmin):
    pass

@admin.register(Address)
class AddressAdmin(admin.ModelAdmin):
    pass
@admin.register(IdentityInformation)
class IdentityInformationAdmin(admin.ModelAdmin):
    list_display = ('employee', 'date_of_birth', 'personal_email_address', 'personal_mobile_number', 'seating_location', 'date_of_joining', 'gender', 'employment_type', 'employee_status', 'marital_status', 'source_of_hire', 'added_time', 'modified_time')

@admin.register(Location)
class LocationAdmin(admin.ModelAdmin):
    list_display = ('name', 'country', 'state_province', 'city', 'postal_code', 'added_time', 'modified_time')

@admin.register(Role)
class RoleAdmin(admin.ModelAdmin):
    list_display = ('name',)

@admin.register(Designation)
class DesignationAdmin(admin.ModelAdmin):
    list_display = ('name', 'added_time', 'modified_time')

@admin.register(Department)
class DepartmentAdmin(admin.ModelAdmin):
    list_display = ('name', 'added_time', 'modified_time')

@admin.register(EmployeeSkills)
class EmployeeSkillsAdmin(admin.ModelAdmin):
    list_display = ('employee', 'degree_type', 'field_of_study', 'institution_attended', 'graduation_date', 'gpa')

@admin.register(Language)
class LanguageAdmin(admin.ModelAdmin):
    list_display = ('name',)

@admin.register(EmployeeLanguageProficiency)
class EmployeeLanguageProficiencyAdmin(admin.ModelAdmin):
    list_display = ('employee_skills', 'language', 'proficiency_level')

@admin.register(TechnicalSkill)
class TechnicalSkillAdmin(admin.ModelAdmin):
    list_display = ('name',)

@admin.register(EmployeeTechnicalSkill)
class EmployeeTechnicalSkillAdmin(admin.ModelAdmin):
    list_display = ('employee_skills', 'technical_skill', 'proficiency_level')

@admin.register(SoftSkill)
class SoftSkillAdmin(admin.ModelAdmin):
    list_display = ('name',)

@admin.register(EmployeeSoftSkill)
class EmployeeSoftSkillAdmin(admin.ModelAdmin):
    list_display = ('employee_skills', 'soft_skill', 'proficiency_description')

@admin.register(IndustrySpecificSkill)
class IndustrySpecificSkillAdmin(admin.ModelAdmin):
    list_display = ('name',)

@admin.register(EmployeeIndustrySpecificSkill)
class EmployeeIndustrySpecificSkillAdmin(admin.ModelAdmin):
    list_display = ('employee_skills', 'industry_specific_skill', 'proficiency_description')
