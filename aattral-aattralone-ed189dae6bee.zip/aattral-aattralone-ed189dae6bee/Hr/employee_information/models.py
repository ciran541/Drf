from django.db import models
from Authentication.models import CustomUser
class Employee(models.Model):
    # Identity Information
    employee_id = models.OneToOneField(CustomUser, primary_key=True, on_delete=models.CASCADE, db_column='id')

class Address(models.Model):
    address_line_1 = models.CharField(max_length=255)
    address_line_2 = models.CharField(max_length=255, blank=True, null=True)
    state = models.CharField(max_length=255)
    city = models.CharField(max_length=255)
    postal_code = models.CharField(max_length=20)
    country = models.CharField(max_length=255)
    added_time = models.DateTimeField(auto_now_add=True)
    modified_time = models.DateTimeField(auto_now=True)


class IdentityInformation(models.Model):
    GENDER_CHOICES = (
    ('male', 'Male'),
    ('female', 'Female'),
    ('non_binary', 'Non-Binary'),
    ('other', 'Other'),
)

    employee = models.OneToOneField('Employee', on_delete=models.CASCADE, primary_key=True)
    date_of_birth = models.DateField()
    personal_email_address = models.EmailField()
    personal_mobile_number = models.CharField(max_length=20)
    extension = models.CharField(max_length=10)
    photo = models.ImageField(upload_to='employee_photos/', blank=True, null=True)
    seating_location = models.CharField(max_length=255)
    date_of_joining = models.DateField()
    work_phone_number = models.CharField(max_length=20)
    about_me = models.TextField(blank=True, null=True)
    expertise = models.TextField(blank=True, null=True)
    date_of_exit = models.DateField(blank=True, null=True)
    gender = models.CharField(max_length=10, choices=GENDER_CHOICES)
    tags = models.CharField(max_length=255)
    employment_type = models.CharField(max_length=20)
    employee_status = models.CharField(max_length=20)
    marital_status = models.CharField(max_length=20)
    source_of_hire = models.CharField(max_length=255)
    current_experience = models.CharField(max_length=20)
    age = models.IntegerField()
    added_time = models.DateTimeField(auto_now_add=True)
    modified_time = models.DateTimeField(auto_now=True)
    onboarding_status = models.CharField(max_length=20, blank=True, null=True)
    total_experience = models.CharField(max_length=20)
    permanent_address = models.ForeignKey(Address, related_name='permanent_address', on_delete=models.CASCADE)
    present_address = models.ForeignKey(Address, related_name='present_address', on_delete=models.CASCADE)
    pan = models.CharField(max_length=20)
    uan = models.CharField(max_length=20)
    aadhaar = models.CharField(max_length=20)
    
    def __str__(self):
        return f'{self.employee.first_name} {self.employee.last_name} IdentityInformation'
    
class Location(models.Model):
    name = models.CharField(max_length=100)
    country = models.CharField(max_length=100)
    state_province = models.CharField(max_length=100)
    city = models.CharField(max_length=100)
    postal_code = models.CharField(max_length=20)
    address_line1 = models.TextField()
    address_line2 = models.TextField()
    time_zone = models.CharField(max_length=50)
    added_time = models.DateTimeField(auto_now_add=True)
    modified_time = models.DateTimeField(auto_now=True) 

class Role(models.Model):
    ROLE_CHOICES = [
        ('admin', 'Administrator'),
        ('manager', 'Manager'),
        ('employee', 'Employee'),
    ]

    name = models.CharField(max_length=255, choices=ROLE_CHOICES, unique=True)

    def __str__(self):
        return self.get_name_display()
class Designation(models.Model):
    DESIGNATION_CHOICES = [
        ('manager', 'Manager'),
        ('developer', 'Developer'),
        ('analyst', 'Analyst'),
        ('hr_manager', 'HR Manager'),
        # Add other designations as needed
    ]

    name = models.CharField(max_length=100, choices=DESIGNATION_CHOICES)
    added_time = models.DateTimeField(auto_now_add=True)
    modified_time = models.DateTimeField(auto_now=True)

    def __str__(self):
        return self.get_name_display()

class Department(models.Model):
    DEPARTMENT_CHOICES = [
        ('hr', 'Human Resources'),
        ('it', 'Information Technology'),
        ('finance', 'Finance'),
        ('marketing', 'Marketing'),
        # Add other departments as needed
    ]

    name = models.CharField(max_length=100, choices=DEPARTMENT_CHOICES)
    added_time = models.DateTimeField(auto_now_add=True)
    modified_time = models.DateTimeField(auto_now=True)

    def __str__(self):
        return self.get_name_display()   

PROFICIENCY_LEVEL_CHOICES = (
    ('beginner', 'Beginner'),
    ('intermediate', 'Intermediate'),
    ('advanced', 'Advanced'),
)

# Choices for certification status
CERTIFICATION_STATUS_CHOICES = (
    ('active', 'Active'),
    ('expired', 'Expired'),
)

class EmployeeSkills(models.Model):
    employee = models.OneToOneField("Employee", on_delete=models.CASCADE, related_name="skills")
    # Educational Background
    degree_type = models.CharField(max_length=100)
    field_of_study = models.CharField(max_length=100)
    institution_attended = models.CharField(max_length=255)
    graduation_date = models.DateField()
    gpa = models.FloatField(null=True, blank=True)
    
    def __str__(self):
        return f'{self.employee.first_name} {self.employee.last_name} EmployeeSkills'

class Language(models.Model):
    name = models.CharField(max_length=100)

    def __str__(self):
        return self.name

class EmployeeLanguageProficiency(models.Model):
    employee_skills = models.ForeignKey(EmployeeSkills, on_delete=models.CASCADE, related_name="language_proficiencies")
    language = models.ForeignKey(Language, on_delete=models.CASCADE)
    proficiency_level = models.CharField(max_length=20, choices=PROFICIENCY_LEVEL_CHOICES)
    
    def __str__(self):
        return f'{self.employee_skills.employee.first_name} {self.employee_skills.employee.last_name} {self.get_proficiency_level_display()} in {self.language}'

class TechnicalSkill(models.Model):
    name = models.CharField(max_length=100)

    def __str__(self):
        return self.name

class EmployeeTechnicalSkill(models.Model):
    employee_skills = models.ForeignKey(EmployeeSkills, on_delete=models.CASCADE, related_name="technical_skills")
    technical_skill = models.ForeignKey(TechnicalSkill, on_delete=models.CASCADE)
    proficiency_level = models.CharField(max_length=20, choices=PROFICIENCY_LEVEL_CHOICES)
    
    def __str__(self):
        return f'{self.employee_skills.employee.first_name} {self.employee_skills.employee.last_name} {self.get_proficiency_level_display()} in {self.technical_skill}'

class SoftSkill(models.Model):
    name = models.CharField(max_length=100)

    def __str__(self):
        return self.name

class EmployeeSoftSkill(models.Model):
    employee_skills = models.ForeignKey(EmployeeSkills, on_delete=models.CASCADE, related_name="soft_skills")
    soft_skill = models.ForeignKey(SoftSkill, on_delete=models.CASCADE)
    proficiency_description = models.TextField()
    
    def __str__(self):
        return f'{self.employee_skills.employee.first_name} {self.employee_skills.employee.last_name}: {self.proficiency_description} in {self.soft_skill}'

class IndustrySpecificSkill(models.Model):
    name = models.CharField(max_length=100)

    def __str__(self):
        return self.name

class EmployeeIndustrySpecificSkill(models.Model):
    employee_skills = models.ForeignKey(EmployeeSkills, on_delete=models.CASCADE, related_name="industry_specific_skills")
    industry_specific_skill = models.ForeignKey(IndustrySpecificSkill, on_delete=models.CASCADE)
    proficiency_description = models.TextField()
    
    def __str__(self):
        return f'{self.employee_skills.employee.first_name} {self.employee_skills.employee.last_name}: {self.proficiency_description} in {self.industry_specific_skill}' 



# # Models For Documents of Employee and Organisation
        
# class Orgfolder(models.Model):
#     name = models.CharField(max_length=255)
#     description = models.TextField(blank=True, null=True)

#     def __str__(self):
#         return self.name

# class Employeefolder(models.Model):
#     name = models.CharField(max_length=255)
#     description = models.TextField(blank=True, null=True)

#     def __str__(self):
#         return self.name

# class Document(models.Model):
#     document_name = models.CharField(max_length=255)
#     file_type = models.CharField(max_length=10)  # .pdf, .docx, .jpg, etc.
#     uploaded_by = models.ForeignKey(CustomUser, on_delete=models.CASCADE,related_name='Hr_employeeinfo_User')
#     upload_date = models.DateTimeField(auto_now_add=True)
#     org_folder = models.ForeignKey(Orgfolder, on_delete=models.CASCADE, blank=True, null=True, related_name='Hr_employeeinfo_org')
#     employee_folder = models.ForeignKey(Employeefolder, on_delete=models.CASCADE, blank=True, null=True, related_name='Hr_employeeinfo_employee')
