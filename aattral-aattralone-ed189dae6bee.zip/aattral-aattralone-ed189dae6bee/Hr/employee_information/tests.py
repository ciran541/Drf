from django.test import TestCase
from datetime import date
from django.core.files.uploadedfile import SimpleUploadedFile
from .models import Employee, Address, IdentityInformation,Employee, EmployeeSkills, Language, EmployeeLanguageProficiency, TechnicalSkill, EmployeeTechnicalSkill, SoftSkill, EmployeeSoftSkill, IndustrySpecificSkill, EmployeeIndustrySpecificSkill


class EmployeeModelsTestCase(TestCase):
    def setUp(self):
        # Create test data
        self.address_data = {
            'address_line_1': '123 Main St',
            'state': 'California',
            'city': 'Los Angeles',
            'postal_code': '90001',
            'country': 'USA',
        }

        self.permanent_address = Address.objects.create(**self.address_data)
        self.present_address = Address.objects.create(**self.address_data)

        self.employee_data = {
            'first_name': 'John',
            'last_name': 'Doe',
            'email_address': 'john.doe@example.com',
        }
        self.employee = Employee.objects.create(**self.employee_data)

        self.identity_data = {
            'employee': self.employee,
            'date_of_birth': date(1990, 1, 1),
            'personal_email_address': 'john.doe.personal@example.com',
            'personal_mobile_number': '1234567890',
            'extension': '123',
            'photo': SimpleUploadedFile("test.jpg", b"file_content", content_type="image/jpeg"),
            'seating_location': 'Desk A',
            'date_of_joining': date(2022, 1, 1),
            'work_phone_number': '9876543210',
            'gender': 'male',
            'tags': 'tag1, tag2',
            'employment_type': 'full_time',
            'employee_status': 'active',
            'marital_status': 'single',
            'source_of_hire': 'LinkedIn',
            'current_experience': '2 years',
            'age': 32,
            'onboarding_status': 'completed',
            'total_experience': '5 years',
            'permanent_address': self.permanent_address,
            'present_address': self.present_address,
            'pan': 'ABCDE1234F',
            'uan': '9876543210',
            'aadhaar': '1234 5678 9012',
        }
        self.identity = IdentityInformation.objects.create(**self.identity_data)

    def test_employee_creation(self):
        self.assertEqual(Employee.objects.count(), 1)

    def test_address_creation(self):
        self.assertEqual(Address.objects.count(), 2)

    def test_identity_creation(self):
        self.assertEqual(IdentityInformation.objects.count(), 1)
        self.assertEqual(self.identity.employee, self.employee)

    def test_employee_str_method(self):
        self.assertEqual(str(self.employee), 'John Doe')

    def test_identity_str_method(self):
        self.assertEqual(str(self.identity), 'John Doe IdentityInformation')


class EmployeeSkillsModelsTestCase(TestCase):
    def setUp(self):
        # Create test data
        self.employee_data = {
            'first_name': 'John',
            'last_name': 'Doe',
            'email_address': 'john.doe@example.com',
        }
        self.employee = Employee.objects.create(**self.employee_data)

        self.language = Language.objects.create(name='English')
        self.technical_skill = TechnicalSkill.objects.create(name='Programming')
        self.soft_skill = SoftSkill.objects.create(name='Communication')
        self.industry_specific_skill = IndustrySpecificSkill.objects.create(name='Finance')

        self.employee_skills_data = {
            'employee': self.employee,
            'degree_type': 'Bachelor',
            'field_of_study': 'Computer Science',
            'institution_attended': 'University XYZ',
            'graduation_date': date(2020, 5, 15),
            'gpa': 3.5,
        }
        self.employee_skills = EmployeeSkills.objects.create(**self.employee_skills_data)

        self.employee_language_proficiency_data = {
            'employee_skills': self.employee_skills,
            'language': self.language,
            'proficiency_level': 'advanced',
        }
        self.employee_language_proficiency = EmployeeLanguageProficiency.objects.create(**self.employee_language_proficiency_data)

        self.employee_technical_skill_data = {
            'employee_skills': self.employee_skills,
            'technical_skill': self.technical_skill,
            'proficiency_level': 'intermediate',
        }
        self.employee_technical_skill = EmployeeTechnicalSkill.objects.create(**self.employee_technical_skill_data)

        self.employee_soft_skill_data = {
            'employee_skills': self.employee_skills,
            'soft_skill': self.soft_skill,
            'proficiency_description': 'Good communicator',
        }
        self.employee_soft_skill = EmployeeSoftSkill.objects.create(**self.employee_soft_skill_data)

        self.employee_industry_specific_skill_data = {
            'employee_skills': self.employee_skills,
            'industry_specific_skill': self.industry_specific_skill,
            'proficiency_description': 'Expert in finance analysis',
        }
        self.employee_industry_specific_skill = EmployeeIndustrySpecificSkill.objects.create(**self.employee_industry_specific_skill_data)

    def test_employee_skills_creation(self):
        self.assertEqual(EmployeeSkills.objects.count(), 1)

    def test_language_proficiency_creation(self):
        self.assertEqual(EmployeeLanguageProficiency.objects.count(), 1)

    def test_technical_skill_creation(self):
        self.assertEqual(EmployeeTechnicalSkill.objects.count(), 1)

    def test_soft_skill_creation(self):
        self.assertEqual(EmployeeSoftSkill.objects.count(), 1)

    def test_industry_specific_skill_creation(self):
        self.assertEqual(EmployeeIndustrySpecificSkill.objects.count(), 1)

    def test_employee_skills_str_method(self):
        self.assertEqual(str(self.employee_skills), 'John Doe EmployeeSkills')

    def test_language_proficiency_str_method(self):
        self.assertEqual(str(self.employee_language_proficiency), 'John Doe Advanced in English')

    def test_technical_skill_str_method(self):
        self.assertEqual(str(self.employee_technical_skill), 'John Doe Intermediate in Programming')

    def test_soft_skill_str_method(self):
        self.assertEqual(str(self.employee_soft_skill), 'John Doe: Good communicator in Communication')

    def test_industry_specific_skill_str_method(self):
        self.assertEqual(str(self.employee_industry_specific_skill), 'John Doe: Expert in finance analysis in Finance')