# views.py
from rest_framework import viewsets
from rest_framework.decorators import action
from rest_framework.response import Response
from rest_framework.permissions import IsAuthenticated
from .models import (Address, Employee, IdentityInformation,Department, Language, EmployeeLanguageProficiency, TechnicalSkill, 
EmployeeTechnicalSkill, SoftSkill, EmployeeSoftSkill, IndustrySpecificSkill, EmployeeIndustrySpecificSkill, EmployeeSkills)
from .serializers import (AddressSerializer, EmployeeSerializer,DepartmentSerializer, IdentityInformationSerializer, 
                          LanguageSerializer, EmployeeLanguageProficiencySerializer, TechnicalSkillSerializer, 
                          EmployeeTechnicalSkillSerializer, SoftSkillSerializer, EmployeeSoftSkillSerializer, IndustrySpecificSkillSerializer, 
                          EmployeeIndustrySpecificSkillSerializer, EmployeeSkillsSerializer
)
class AddressViewSet(viewsets.ModelViewSet):
    permission_classes = [IsAuthenticated]
    queryset = Address.objects.all()
    serializer_class = AddressSerializer

class EmployeeViewSet(viewsets.ModelViewSet):
    permission_classes = [IsAuthenticated]
    queryset = Employee.objects.all()
    serializer_class = EmployeeSerializer

class IdentityInformationViewSet(viewsets.ModelViewSet):
    permission_classes = [IsAuthenticated]
    queryset = IdentityInformation.objects.all()
    serializer_class = IdentityInformationSerializer

class LanguageViewSet(viewsets.ModelViewSet):
    permission_classes = [IsAuthenticated]
    queryset = Language.objects.all()
    serializer_class = LanguageSerializer

class EmployeeLanguageProficiencyViewSet(viewsets.ModelViewSet):
    permission_classes = [IsAuthenticated]
    queryset = EmployeeLanguageProficiency.objects.all()
    serializer_class = EmployeeLanguageProficiencySerializer

class TechnicalSkillViewSet(viewsets.ModelViewSet):
    permission_classes = [IsAuthenticated]
    queryset = TechnicalSkill.objects.all()
    serializer_class = TechnicalSkillSerializer

class EmployeeTechnicalSkillViewSet(viewsets.ModelViewSet):
    permission_classes = [IsAuthenticated]
    queryset = EmployeeTechnicalSkill.objects.all()
    serializer_class = EmployeeTechnicalSkillSerializer

class SoftSkillViewSet(viewsets.ModelViewSet):
    permission_classes = [IsAuthenticated]
    queryset = SoftSkill.objects.all()
    serializer_class = SoftSkillSerializer

class EmployeeSoftSkillViewSet(viewsets.ModelViewSet):
    permission_classes = [IsAuthenticated]
    queryset = EmployeeSoftSkill.objects.all()
    serializer_class = EmployeeSoftSkillSerializer

class IndustrySpecificSkillViewSet(viewsets.ModelViewSet):
    permission_classes = [IsAuthenticated]
    queryset = IndustrySpecificSkill.objects.all()
    serializer_class = IndustrySpecificSkillSerializer

class EmployeeIndustrySpecificSkillViewSet(viewsets.ModelViewSet):
    permission_classes = [IsAuthenticated]
    queryset = EmployeeIndustrySpecificSkill.objects.all()
    serializer_class = EmployeeIndustrySpecificSkillSerializer

class EmployeeSkillsViewSet(viewsets.ModelViewSet):
    permission_classes = [IsAuthenticated]
    queryset = EmployeeSkills.objects.all()
    serializer_class = EmployeeSkillsSerializer

class DepartmentViewSet(viewsets.ModelViewSet):
    permission_classes = [IsAuthenticated]
    queryset = Department.objects.all()
    serializer_class = DepartmentSerializer

# class OrgfolderViewSet(viewsets.ModelViewSet):
#     queryset = Orgfolder.objects.all()
#     serializer_class = OrgfolderSerializer

# class EmployeefolderViewSet(viewsets.ModelViewSet):
#     queryset = Employeefolder.objects.all()
#     serializer_class = EmployeefolderSerializer

# class DocumentViewSet(viewsets.ModelViewSet):
#     queryset = Document.objects.all()
#     serializer_class = DocumentSerializer

#     @action(detail=False, methods=['get'])
#     def filter_by_employee(self, request):
#         employee_id = request.query_params.get('employee_id')
#         if employee_id:
#             documents = Document.objects.filter(employee_folder__id=employee_id)
#             serializer = self.get_serializer(documents, many=True)
#             return Response(serializer.data)
#         else:
#             return Response({'error': 'Please provide employee_id parameter in the query string.'}, status=400)

#     @action(detail=True, methods=['post'])
#     def add_to_orgfolder(self, request, pk=None):
#         document = self.get_object()
#         orgfolder_id = request.data.get('orgfolder_id')
#         orgfolder = Orgfolder.objects.get(pk=orgfolder_id)
#         document.org_folder = orgfolder
#         document.save()
#         return Response({'message': 'Document added to Orgfolder successfully'})

#     @action(detail=True, methods=['post'])
#     def add_to_employeefolder(self, request, pk=None):
#         document = self.get_object()
#         employeefolder_id = request.data.get('employeefolder_id')
#         employeefolder = Employeefolder.objects.get(pk=employeefolder_id)
#         document.employee_folder = employeefolder
#         document.save()
#         return Response({'message': 'Document added to Employeefolder successfully'})