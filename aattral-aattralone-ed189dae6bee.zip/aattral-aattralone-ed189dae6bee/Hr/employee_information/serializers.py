# serializers.py
from rest_framework import serializers
from .models import (Address, Employee, IdentityInformation, Language,Department, EmployeeLanguageProficiency,
TechnicalSkill, EmployeeTechnicalSkill, SoftSkill, EmployeeSoftSkill, IndustrySpecificSkill, EmployeeIndustrySpecificSkill, EmployeeSkills)
from Authentication.serializers import CustomUserSerializer
from Authentication.models import CustomUser
class AddressSerializer(serializers.ModelSerializer):
    class Meta:
        model = Address
        fields = '__all__'
        ref_name = 'EmployeeInformationAddress'

class EmployeeSerializer(serializers.ModelSerializer):

    employee_id = CustomUserSerializer()
    class Meta:
        model = Employee
        fields = '__all__'
        ref_name = 'EmployeeInfo'

    def to_representation(self, instance):
        data = super().to_representation(instance)
        return data['employee_id'] 

class IdentityInformationSerializer(serializers.ModelSerializer):
    class Meta:
        model = IdentityInformation
        fields = '__all__'

class LanguageSerializer(serializers.ModelSerializer):
    class Meta:
        model = Language
        fields = '__all__'

class EmployeeLanguageProficiencySerializer(serializers.ModelSerializer):
    class Meta:
        model = EmployeeLanguageProficiency
        fields = '__all__'

class TechnicalSkillSerializer(serializers.ModelSerializer):
    class Meta:
        model = TechnicalSkill
        fields = '__all__'

class EmployeeTechnicalSkillSerializer(serializers.ModelSerializer):
    class Meta:
        model = EmployeeTechnicalSkill
        fields = '__all__'

class SoftSkillSerializer(serializers.ModelSerializer):
    class Meta:
        model = SoftSkill
        fields = '__all__'

class EmployeeSoftSkillSerializer(serializers.ModelSerializer):
    class Meta:
        model = EmployeeSoftSkill
        fields = '__all__'

class IndustrySpecificSkillSerializer(serializers.ModelSerializer):
    class Meta:
        model = IndustrySpecificSkill
        fields = '__all__'

class EmployeeIndustrySpecificSkillSerializer(serializers.ModelSerializer):
    class Meta:
        model = EmployeeIndustrySpecificSkill
        fields = '__all__'

class EmployeeSkillsSerializer(serializers.ModelSerializer):
    languages = EmployeeLanguageProficiencySerializer(many=True)
    technical_skills = EmployeeTechnicalSkillSerializer(many=True)
    soft_skills = EmployeeSoftSkillSerializer(many=True)
    industry_specific_skills = EmployeeIndustrySpecificSkillSerializer(many=True)

    class Meta:
        model = EmployeeSkills
        fields = '__all__'

class DepartmentSerializer(serializers.ModelSerializer):
    class Meta:
        model = Department
        fields = '__all__'
        ref_name = 'DepartmentSerializer'

# class OrgfolderSerializer(serializers.ModelSerializer):
#     class Meta:
#         model = Orgfolder
#         fields = '__all__'
#         ref_name = 'Hr_OrgfolderSerializer'

# class EmployeefolderSerializer(serializers.ModelSerializer):
#     class Meta:
#         model = Employeefolder
#         fields = '__all__'
#         ref_name = 'Hr_EmployeefolderSerializer'


# class DocumentSerializer(serializers.ModelSerializer):
#     class Meta:
#         model = Document
#         fields = '__all__'
#         ref_name = 'Hr_DocumentSerializer'
