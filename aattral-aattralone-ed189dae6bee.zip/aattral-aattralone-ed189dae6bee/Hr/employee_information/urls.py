from rest_framework.routers import DefaultRouter
from django.urls import path, include
from .views import (AddressViewSet, EmployeeViewSet, IdentityInformationViewSet, LanguageViewSet, EmployeeLanguageProficiencyViewSet, 
                    TechnicalSkillViewSet,EmployeeTechnicalSkillViewSet, SoftSkillViewSet, EmployeeSoftSkillViewSet, IndustrySpecificSkillViewSet,DepartmentViewSet, 
                     EmployeeIndustrySpecificSkillViewSet, EmployeeSkillsViewSet)

router = DefaultRouter()
router.register(r'addresses', AddressViewSet)
router.register(r'employees', EmployeeViewSet)
router.register(r'identity_information', IdentityInformationViewSet)
router.register(r'languages', LanguageViewSet)
router.register(r'language_proficiencies', EmployeeLanguageProficiencyViewSet)
router.register(r'technical_skills', TechnicalSkillViewSet)
router.register(r'employee_technical_skills', EmployeeTechnicalSkillViewSet)
router.register(r'soft_skills', SoftSkillViewSet)
router.register(r'employee_soft_skills', EmployeeSoftSkillViewSet)
router.register(r'industry_specific_skills', IndustrySpecificSkillViewSet)
router.register(r'employee_industry_specific_skills', EmployeeIndustrySpecificSkillViewSet)
router.register(r'employee_skills', EmployeeSkillsViewSet)
router.register(r'departments', DepartmentViewSet)
# router.register(r'orgfolders', OrgfolderViewSet)
# router.register(r'employeefolders', EmployeefolderViewSet)
# router.register(r'documents', DocumentViewSet)

urlpatterns = [
    path('', include(router.urls)),
]