from rest_framework import serializers
from .models import Client,Project,Job,Timesheet,TimeLog,Country
from Hr.employee_information.serializers import EmployeeSerializer,DepartmentSerializer
class CountrySerializer(serializers.ModelSerializer):

    class Meta:
        model = Country
        fields = '__all__'
        ref_name = 'Hrcountry'

class ClientSerializer(serializers.ModelSerializer):
    country_details = CountrySerializer(source='country', read_only=True)
    class Meta:
        model = Client
        fields = '__all__'
        
class ProjectListSerializer(serializers.ModelSerializer):
    class Meta:
        model = Project
        fields = '__all__'


class JobListSerializer(serializers.ModelSerializer):
    class Meta:
        model = Job
        fields = '__all__'
class ProjectDetailSerializer(serializers.ModelSerializer):
    
    jobs = JobListSerializer(many=True, read_only=True)

    client = ClientSerializer()
    project_head = EmployeeSerializer(allow_null=True)
    project_manager = EmployeeSerializer(allow_null=True)
    project_users = EmployeeSerializer(many=True)
    departments = DepartmentSerializer(many=True)

    class Meta:
        model = Project
        fields = '__all__'

class JobDetailSerializer(serializers.ModelSerializer):
    project = ProjectDetailSerializer()
    assignees = EmployeeSerializer(many=True)
    departments = DepartmentSerializer(many=True)

    class Meta:
        model = Job
        fields = '__all__'


class TimesheetSerializer(serializers.ModelSerializer):
    class Meta:
        model = Timesheet
        fields = '__all__'

class TimeLogSerializer(serializers.ModelSerializer):
    class Meta:
        model = TimeLog
        fields = '__all__'

# class TimesheetNotificationSerializer(serializers.ModelSerializer):
#     class Meta:
#         model = TimesheetNotification
#         fields = '__all__'