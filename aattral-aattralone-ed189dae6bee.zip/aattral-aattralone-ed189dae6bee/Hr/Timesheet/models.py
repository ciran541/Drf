# models.py
from django.db import models
from Hr.employee_information.models import Employee, Department
import pycountry
from Authentication.models import CustomUser

class Country(models.Model):
    code = models.CharField(max_length=3, unique=True)
    name = models.CharField(max_length=255)

    def __str__(self):
        return self.name

# Populate the Country model with data from pycountry
for country in pycountry.countries:
    Country.objects.get_or_create(
        code=country.alpha_3,
        name=country.name
    )

class Client(models.Model):
    BILLING_METHOD_CHOICES = [
        ('hourly', 'Hourly'),
        ('fixed_rate', 'Fixed Rate'),
        ('project_billing', 'Project Billing'),
        ('subscription', 'Subscription'),
        ('custom', 'Custom'),
    ]
    CURRENCY_CHOICES = (
        ('USD', 'US Dollar'),
        ('EUR', 'Euro'),
        ('GBP', 'British Pound'),
        ('INR', 'Indian rupee')
    )
    name = models.CharField(max_length=255)
    currency = models.CharField(max_length=3, choices=CURRENCY_CHOICES)
    billing_method = models.CharField(max_length=255,blank=True)

    # Contacts
    email = models.EmailField(blank=True)
    first_name = models.CharField(max_length=255,blank=True)
    last_name = models.CharField(max_length=255,blank=True)
    phone = models.CharField(max_length=20,blank=True)
    mobile = models.CharField(max_length=20,blank=True)
    fax = models.CharField(max_length=20,blank=True)
    
    # Address Details
    street_address = models.CharField(max_length=255,blank=True)
    city = models.CharField(max_length=255,blank=True)
    state_province = models.CharField(max_length=255,blank=True)
    zip_code = models.CharField(max_length=20,blank=True)
    country = models.ForeignKey(Country, on_delete=models.SET_NULL, null=True, blank=True)

    # Additional Information
    industry = models.CharField(max_length=255,blank=True)
    company_size = models.PositiveIntegerField(default=0,blank=True)
    description = models.TextField(blank=True)

    billing_method = models.CharField(max_length=20, choices=BILLING_METHOD_CHOICES)

    def __str__(self):
        return self.name


class Project(models.Model):
    STATUS_CHOICES = [
        ('in_progress', 'In_progress'),
        ('completed', 'Completed'),
    ]
    name = models.CharField(max_length=255)
    client = models.ForeignKey(Client, on_delete=models.CASCADE)
    project_cost = models.DecimalField(max_digits=10, decimal_places=2)
    project_head = models.ForeignKey(Employee, related_name='head_projects', on_delete=models.SET_NULL, null=True, blank=True)
    rate = models.DecimalField(max_digits=10, decimal_places=2)
    project_manager = models.ForeignKey(Employee, related_name='manager_projects', on_delete=models.SET_NULL, null=True, blank=True)
    
    # Users and Departments
    project_users = models.ManyToManyField(Employee, related_name='project_jobs',blank=True)
    departments = models.ManyToManyField(Department,blank=True, related_name='project_department')
    
    description = models.TextField()
    status =models.CharField(max_length=20,choices=STATUS_CHOICES, default='in_progress' )

    def __str__(self):
        return self.name
    
class Job(models.Model):
    BILLABLE_CHOICES = [
        ('billable', 'Billable'),
        ('non_billable', 'Non-Billable'),
    ]
    STATUS_CHOICES = [
        ('in_progress', 'In_progress'),
        ('completed', 'Completed'),
    ]

    job_name = models.CharField(max_length=255)
    project = models.ForeignKey(Project,related_name='jobs', on_delete=models.CASCADE)
    start_date = models.DateField()
    end_date = models.DateField()
    hours = models.FloatField(null=True, blank=True)
    assignees = models.ManyToManyField(Employee, related_name='assigned_jobs')
    departments = models.ManyToManyField(Department,blank=True, related_name='assigned_jobs')
    rate_per_hour = models.DecimalField(max_digits=10, decimal_places=2,null=True, blank=True)
    description = models.TextField(null=True, blank=True)
    attachment = models.FileField(upload_to='job_attachments/', null=True, blank=True)
    has_reminder = models.BooleanField(default=False,null=True,)
    reminder_time = models.DateTimeField(null=True, blank=True)
    billable_status = models.CharField(max_length=20, choices=BILLABLE_CHOICES, default='billable')
    work_item = models.CharField(max_length=255,null=True, blank=True)
    status =models.CharField(max_length=20,choices=STATUS_CHOICES, default='in_progress' )

    def __str__(self):
        return self.job_name
    
class Timesheet(models.Model):
    PERIOD_CHOICES = [
        ('this_week', 'This Week'),
        ('this_month', 'This Month'),
        ('last_week', 'Last Week'),
        ('last_month', 'Last Month'),
        ('custom', 'Custom'),
    ]

    employee = models.ForeignKey(Employee, on_delete=models.CASCADE)
    period = models.CharField(max_length=20, choices=PERIOD_CHOICES)
    start_date = models.DateField()
    end_date = models.DateField()
    is_submitted = models.BooleanField(default=False)

    # Date Range
    from_date = models.DateField(null=True, blank=True)
    to_date = models.DateField(null=True, blank=True)

    # Filter options
    clients = models.ManyToManyField(Client, blank=True)
    projects = models.ManyToManyField(Project, blank=True)
    jobs = models.ManyToManyField(Job, blank=True)
    billable_status = models.BooleanField(default=False)

    # Period field
    period = models.CharField(max_length=20, choices=PERIOD_CHOICES)

    def __str__(self):
        return f"{self.employee.employee_id} - {self.start_date} to {self.end_date}"
    
class TimeLog(models.Model):
    job = models.ForeignKey(Job, on_delete=models.CASCADE)
    work_item = models.CharField(max_length=255)
    date = models.DateField()
    description = models.TextField()
    hours = models.FloatField()
    start_time = models.TimeField(null=True, blank=True)
    end_time = models.TimeField(null=True, blank=True)
    timer = models.DurationField(null=True, blank=True)
    billable_status = models.BooleanField(default=False)
    attachment = models.FileField(upload_to='time_logs/', null=True, blank=True)

    def __str__(self):
        return f"{self.job} - {self.date}"
    


# Settings Model #     

class GeneralSettings(models.Model):
    # Time Log View Options
    LOG_TIME_OPTIONS = [
        ('total_hours', 'Total hours'),
        ('start_end_time', 'Start and end time'),
        ('timer', 'Timer'),
    ]
    time_log_view = models.CharField(max_length=20, choices=LOG_TIME_OPTIONS, default='total_hours')

    # Timer Edit Permission
    timer_edit_permission = models.BooleanField(default=True)

    # Show Time Log Location
    show_time_log_location = models.BooleanField(default=True)

    # Restrict Time Log Settings
    restrict_based_on_estimated_hours = models.BooleanField(default=False)
    restrict_time_logs_to_24_hours = models.BooleanField(default=False)
    max_billable_hours_per_day = models.FloatField(null=True, blank=True)
    max_billable_hours_per_week = models.FloatField(null=True, blank=True)
    restrict_time_logs_within_attendance_hours = models.BooleanField(default=False)

    # Restrict Time Log Entries
    restrict_duration_00_00 = models.BooleanField(default=False)
    restrict_future_dates = models.BooleanField(default=False)
    restrict_past_dates = models.BooleanField(default=False)
    restrict_weekends = models.BooleanField(default=False)
    restrict_holidays = models.BooleanField(default=False)
    restrict_unpaid_leave = models.BooleanField(default=False)
    restrict_paid_leave_comp_off = models.BooleanField(default=False)

    # Restrict Time Log Dates based on Job's start and end date
    restrict_dates_based_on_job = models.BooleanField(default=False)
    restrict_present_date_based_on_job = models.BooleanField(default=False)

    # Time Entry Overlap Options
    TIME_ENTRY_OVERLAP_OPTIONS = [
        ('allow', 'Allow'),
        ('warn', 'Warn but allow'),
        ('restrict', 'Restrict'),
    ]
    time_entry_overlap = models.CharField(max_length=20, choices=TIME_ENTRY_OVERLAP_OPTIONS, default='allow')

    # Default Billing Status
    default_billing_status = models.BooleanField(default=False)

    # Default Work Item
    default_work_item = models.CharField(max_length=255, default='')

    def __str__(self):
        return "General Settings"
    
class TimesheetSettings(models.Model):
    # Creator
    creator = models.ForeignKey(CustomUser, on_delete=models.CASCADE, related_name='timesheet_creator')

    # Allowed period for timesheet
    allowed_start_date = models.DateField()
    allowed_end_date = models.DateField()

    # Timesheets with overlapping dates
    TIMESHEET_OVERLAP_OPTIONS = [
        ('restrict', 'Restrict'),
        ('allow', 'Allow'),
    ]
    timesheet_overlap = models.CharField(max_length=20, choices=TIMESHEET_OVERLAP_OPTIONS, default='restrict')

    # Time logs without Clients
    TIME_LOGS_CLIENT_OPTIONS = [
        ('exclude', 'Exclude'),
        ('include', 'Include'),
    ]
    time_logs_without_clients = models.CharField(max_length=20, choices=TIME_LOGS_CLIENT_OPTIONS, default='exclude')

    # Include time logs that are
    INCLUDE_TIME_LOGS_OPTIONS = [
        ('billable', 'Billable'),
        ('non_billable', 'Non-billable'),
        ('both', 'Both'),
    ]
    include_time_logs = models.CharField(max_length=20, choices=INCLUDE_TIME_LOGS_OPTIONS, default='both')

    # Minimum hours criteria for timesheet submission
    min_hours_criteria_enabled = models.BooleanField(default=False)
    min_hours_criteria = models.FloatField(null=True, blank=True)

    # Maximum hours criteria for timesheet submission
    max_hours_criteria_enabled = models.BooleanField(default=False)
    max_hours_criteria = models.FloatField(null=True, blank=True)

    # Display rate per hour for
    display_rate_admin = models.BooleanField(default=False)
    display_rate_approver = models.BooleanField(default=False)
    display_rate_reporting_manager = models.BooleanField(default=False)
    display_rate_employee = models.BooleanField(default=False)

    # Approver can edit time logs during approval
    approver_edit_time_logs = models.BooleanField(default=False)

    # Email notification for timesheet approval
    email_notification = models.BooleanField(default=True)

    # Customize email template (You might want to store email template details in a separate model)
    email_template = models.TextField(default="Default email template")

    def __str__(self):
        return f"Timesheet Settings for {self.creator.username}"
    


# class TimesheetNotification(models.Model):
#     recipient = models.ForeignKey(Employee, on_delete=models.CASCADE)
#     subject = models.CharField(max_length=100)
#     message = models.TextField()
#     timestamp = models.DateTimeField(auto_now_add=True)
#     read_status = models.BooleanField(default=False)