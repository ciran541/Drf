from django.apps import AppConfig


class TimesheetConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'Hr.Timesheet'

    def ready(self):
        import Hr.Timesheet.signal
