from django.test import TestCase
from .models import (Client, Country,Project, Client, Employee, Department,Job, Project, Employee,TimeLog,
Department,Timesheet, Employee, Client, Project, Job)

from django.core.files.uploadedfile import SimpleUploadedFile

from datetime import date, time, timedelta

class ClientModelTestCase(TestCase):
    def setUp(self):
        self.country = Country.objects.create(name='Test Country', code='TC')
        self.client = Client.objects.create(
            name='Test Client',
            currency='USD',
            email='test@example.com',
            first_name='John',
            last_name='Doe',
            phone='123456789',
            mobile='987654321',
            fax='111222333',
            street_address='123 Test St',
            city='Test City',
            state_province='Test State',
            zip_code='12345',
            country=self.country,
            industry='Test Industry',
            company_size=100,
            description='Test Description',
            billing_method='hourly'
        )

    def test_client_creation(self):
        self.assertEqual(self.client.name, 'Test Client')
        self.assertEqual(self.client.currency, 'USD')
        self.assertEqual(self.client.email, 'test@example.com')
        self.assertEqual(self.client.first_name, 'John')
        self.assertEqual(self.client.last_name, 'Doe')
        self.assertEqual(self.client.phone, '123456789')
        self.assertEqual(self.client.mobile, '987654321')
        self.assertEqual(self.client.fax, '111222333')
        self.assertEqual(self.client.street_address, '123 Test St')
        self.assertEqual(self.client.city, 'Test City')
        self.assertEqual(self.client.state_province, 'Test State')
        self.assertEqual(self.client.zip_code, '12345')
        self.assertEqual(self.client.country, self.country)
        self.assertEqual(self.client.industry, 'Test Industry')
        self.assertEqual(self.client.company_size, 100)
        self.assertEqual(self.client.description, 'Test Description')
        self.assertEqual(self.client.billing_method, 'hourly')

    def test_client_string_representation(self):
        self.assertEqual(str(self.client), 'Test Client')
    
    def test_client_billing_method_choices(self):
        # Test billing method choices
        billing_methods = dict(Client.BILLING_METHOD_CHOICES)
        for choice_key, choice_label in Client.BILLING_METHOD_CHOICES:
            self.assertIn(choice_key, billing_methods)
            self.assertEqual(billing_methods[choice_key], choice_label)

    def test_client_currency_choices(self):
        # Test currency choices
        currency_choices = dict(Client.CURRENCY_CHOICES)
        for choice_key, choice_label in Client.CURRENCY_CHOICES:
            self.assertIn(choice_key, currency_choices)
            self.assertEqual(currency_choices[choice_key], choice_label)

    def test_client_country_nullability(self):
        # Test setting country as NULL
        client_with_null_country = Client.objects.create(
            name='Client with Null Country',
            currency='USD',
            email='null@example.com'
        )
        self.assertIsNone(client_with_null_country.country)

class ProjectModelTestCase(TestCase):
    def setUp(self):
        self.client = Client.objects.create(name='Test Client', currency='USD', email='test@example.com')
        self.head_project_manager = Employee.objects.create(first_name='Head Manager', email_address='head@example.com')
        self.project_manager = Employee.objects.create(first_name='Project Manager', email_address='manager@example.com')
        self.project = Project.objects.create(
            name='Test Project',
            client=self.client,
            project_cost=1000.00,
            project_head=self.head_project_manager,
            rate=50.00,
            project_manager=self.project_manager,
            description='Test Description',
            status='in_progress'
        )

    def test_project_creation(self):
        self.assertEqual(self.project.name, 'Test Project')
        self.assertEqual(self.project.client, self.client)
        self.assertEqual(self.project.project_cost, 1000.00)
        self.assertEqual(self.project.project_head, self.head_project_manager)
        self.assertEqual(self.project.rate, 50.00)
        self.assertEqual(self.project.project_manager, self.project_manager)
        self.assertEqual(self.project.description, 'Test Description')
        self.assertEqual(self.project.status, 'in_progress')

    def test_project_string_representation(self):
        self.assertEqual(str(self.project), 'Test Project')

    def test_project_status_choices(self):
        # Test status choices
        status_choices = dict(Project.STATUS_CHOICES)
        for choice_key, choice_label in Project.STATUS_CHOICES:
            self.assertIn(choice_key, status_choices)
            self.assertEqual(status_choices[choice_key], choice_label)

    def test_project_users_and_departments(self):
        # Add some users and departments to the project
        department = Department.objects.create(name='Test Department')
        user1 = Employee.objects.create(first_name='User 1', email_address='user1@example.com')
        user2 = Employee.objects.create(first_name='User 2', email_address='user2@example.com')

        self.project.project_users.add(user1)
        self.project.project_users.add(user2)
        self.project.departments.add(department)

        self.assertIn(user1, self.project.project_users.all())
        self.assertIn(user2, self.project.project_users.all())
        self.assertIn(department, self.project.departments.all())

class JobModelTestCase(TestCase):
    def setUp(self):
        self.project = Project.objects.create(
            name='Test Project',
            client=Client.objects.create(name='Test Client', currency='USD', email='test@example.com'),
            project_cost=1000.00,
            project_head=Employee.objects.create(first_name='Head Manager', email_address='head@example.com'),
            rate=50.00,
            project_manager=Employee.objects.create(first_name='Project Manager', email_address='manager@example.com'),
            description='Test Description',
            status='in_progress'
        )
        self.employee = Employee.objects.create(first_name='Test', last_name='Employee', email_address='employee@example.com')
        self.department = Department.objects.create(name='Test Department')
        self.job = Job.objects.create(
            job_name='Test Job',
            project=self.project,
            start_date=date.today(),
            end_date=date.today(),
            hours=10.5,
            rate_per_hour=25.00,
            description='Test Description',
            billable_status='billable',
            work_item='Test Work Item',
            status='in_progress'
        )
        self.job.assignees.add(self.employee)
        self.job.departments.add(self.department)

    def test_job_creation(self):
        self.assertEqual(self.job.job_name, 'Test Job')
        self.assertEqual(self.job.project, self.project)
        self.assertEqual(self.job.start_date, date.today())
        self.assertEqual(self.job.end_date, date.today())
        self.assertEqual(self.job.hours, 10.5)
        self.assertEqual(self.job.rate_per_hour, 25.00)
        self.assertEqual(self.job.description, 'Test Description')
        self.assertTrue(self.job.billable_status, 'billable')
        self.assertEqual(self.job.work_item, 'Test Work Item')
        self.assertEqual(self.job.status, 'in_progress')

    def test_job_string_representation(self):
        self.assertEqual(str(self.job), 'Test Job')

    def test_job_billable_choices(self):
        # Test billable status choices
        billable_choices = dict(Job.BILLABLE_CHOICES)
        for choice_key, choice_label in Job.BILLABLE_CHOICES:
            self.assertIn(choice_key, billable_choices)
            self.assertEqual(billable_choices[choice_key], choice_label)

    def test_job_status_choices(self):
        # Test status choices
        status_choices = dict(Job.STATUS_CHOICES)
        for choice_key, choice_label in Job.STATUS_CHOICES:
            self.assertIn(choice_key, status_choices)
            self.assertEqual(status_choices[choice_key], choice_label)

    def test_job_assignees_and_departments(self):
        self.assertIn(self.employee, self.job.assignees.all())
        self.assertIn(self.department, self.job.departments.all())

class TimesheetModelTestCase(TestCase):
    def setUp(self):
        self.employee = Employee.objects.create(first_name='John', last_name='Doe', email_address='john@example.com')
        # Create a dummy client
        self.client = Client.objects.create(name='Test Client', currency='USD', email='test@example.com')
        self.project = Project.objects.create(name='Test Project', client=self.client, project_cost=0, rate=0)
        self.job = Job.objects.create(
            job_name='Test Job',
            project=self.project,
            start_date='2024-03-01',
            end_date='2024-03-07',
            billable_status='billable',
            status='in_progress'
        )
        self.timesheet = Timesheet.objects.create(
            employee=self.employee,
            period='this_week',
            start_date='2024-03-01',
            end_date='2024-03-07',
            is_submitted=False
        )

    def test_timesheet_creation(self):
        self.assertEqual(self.timesheet.employee, self.employee)
        self.assertEqual(self.timesheet.period, 'this_week')
        self.assertEqual(str(self.timesheet.start_date), '2024-03-01')
        self.assertEqual(str(self.timesheet.end_date), '2024-03-07')
        self.assertFalse(self.timesheet.is_submitted)

    def test_timesheet_string_representation(self):
        expected_string = f"{self.employee.employee_id} - 2024-03-01 to 2024-03-07"
        self.assertEqual(str(self.timesheet), expected_string)

    def test_timesheet_period_choices(self):
        # Test period choices
        period_choices = dict(Timesheet.PERIOD_CHOICES)
        for choice_key, choice_label in Timesheet.PERIOD_CHOICES:
            self.assertIn(choice_key, period_choices)
            self.assertEqual(period_choices[choice_key], choice_label)

    def test_timesheet_filter_options(self):
        # Add some clients, projects, and jobs to the timesheet
        client = Client.objects.create(name='Test Client', currency='USD', email='test@example.com')
        project = Project.objects.create(name='Test Project', client=self.client, project_cost=1000.00, rate=50.00)
        job = Job.objects.create(job_name='Test Job', project=project, start_date='2024-03-01', end_date='2024-03-07', billable_status='billable', status='in_progress')

        self.timesheet.clients.add(client)
        self.timesheet.projects.add(project)
        self.timesheet.jobs.add(job)

        self.assertIn(client, self.timesheet.clients.all())
        self.assertIn(project, self.timesheet.projects.all())
        self.assertIn(job, self.timesheet.jobs.all())

    def test_timesheet_period_field(self):
        # Ensure 'period' field is correctly defined
        self.assertEqual(self.timesheet.period, 'this_week')

class TimeLogModelTestCase(TestCase):
    def setUp(self):
        self.client = Client.objects.create(name='Test Client', currency='USD', email='test@example.com')
        self.project = Project.objects.create(name='Test Project',client=self.client, project_cost=0, rate=0)  # Ensure required fields for Project are filled
        self.job = Job.objects.create(
            job_name='Test Job',
            project=self.project,  # Assign a project to the job
            start_date=date.today(),  # Provide a start date
            end_date=date.today() + timedelta(days=5),  # Provide an end date
        )
        self.time_log = TimeLog.objects.create(
            job=self.job,
            work_item='Test Work Item',
            date=date.today(),
            description='Test Description',
            hours=5.5,
            start_time=time(9, 0),
            end_time=time(14, 30),
            billable_status=True,
            attachment=SimpleUploadedFile('test_file.txt', b'Test file content')
        )

    def test_time_log_creation(self):
        self.assertEqual(self.time_log.job, self.job)
        self.assertEqual(self.time_log.work_item, 'Test Work Item')
        self.assertEqual(self.time_log.date, date.today())
        self.assertEqual(self.time_log.description, 'Test Description')
        self.assertEqual(self.time_log.hours, 5.5)
        self.assertEqual(self.time_log.start_time, time(9, 0))
        self.assertEqual(self.time_log.end_time, time(14, 30))
        self.assertTrue(self.time_log.billable_status)
        self.assertIsNotNone(self.time_log.attachment)
