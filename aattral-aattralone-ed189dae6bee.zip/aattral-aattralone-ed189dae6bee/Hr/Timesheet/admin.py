# admin.py
from django.contrib import admin
from .models import GeneralSettings,TimesheetSettings,Client,Job, Project, TimeLog, Timesheet

@admin.register(GeneralSettings)
class GeneralSettingsAdmin(admin.ModelAdmin):
    list_display = ('id', 'time_log_view', 'timer_edit_permission', 'show_time_log_location', 'restrict_based_on_estimated_hours')


@admin.register(TimesheetSettings)
class TimesheetSettingsAdmin(admin.ModelAdmin):
    list_display = ('id', 'creator', 'allowed_start_date', 'allowed_end_date', 'timesheet_overlap', 'time_logs_without_clients', 'include_time_logs', 
                    'min_hours_criteria_enabled', 'max_hours_criteria_enabled', 
                    'display_rate_admin', 'display_rate_approver', 'display_rate_reporting_manager', 'display_rate_employee', 'approver_edit_time_logs', 
                    'email_notification')
    

# @admin.register(Country)
# class CountryAdmin(admin.ModelAdmin):
#     pass

@admin.register(Client)
class ClientAdmin(admin.ModelAdmin):
    pass

@admin.register(Project)
class ProjectAdmin(admin.ModelAdmin):
    pass

@admin.register(Job)
class JobAdmin(admin.ModelAdmin):
    pass

@admin.register(TimeLog)
class TimeLogAdmin(admin.ModelAdmin):
    pass

@admin.register(Timesheet)
class TimesheetAdmin(admin.ModelAdmin):
    pass
