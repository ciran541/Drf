from rest_framework import viewsets
from django.db.models import Q
from django.core.exceptions import ObjectDoesNotExist
from rest_framework.permissions import IsAuthenticated
from .models import Client,Project,Job,Timesheet,TimeLog,Country
from .serializers import ( ClientSerializer,ProjectListSerializer, ProjectDetailSerializer,JobListSerializer, 
                          JobDetailSerializer,TimesheetSerializer,TimeLogSerializer,CountrySerializer)
from rest_framework.response import Response
from rest_framework.decorators import action
from rest_framework import status
from Hr.employee_information.models import Employee

class CountryViewSet(viewsets.ModelViewSet):
    permission_classes = [IsAuthenticated]
    queryset = Country.objects.all()
    serializer_class = CountrySerializer

class ClientViewSet(viewsets.ModelViewSet):
    permission_classes = [IsAuthenticated]
    queryset = Client.objects.all()
    serializer_class = ClientSerializer

    @action(detail=False, methods=['get'])
    def search(self, request):
        query_params = request.query_params
        name = query_params.get('name')
        currency = query_params.get('currency')
        billing_method = query_params.get('billing_method')

        clients = Client.objects.all()
        if name:
            clients = clients.filter(name__icontains=name)
        if currency:
            clients = clients.filter(currency=currency)
        if billing_method:
            clients = clients.filter(billing_method=billing_method)

        serializer = ClientSerializer(clients, many=True)
        return Response(serializer.data)

class ProjectViewSet(viewsets.ModelViewSet):
    permission_classes = [IsAuthenticated]
    queryset = Project.objects.all()
    serializer_class = ProjectDetailSerializer

    def get_serializer_class(self):
        if self.request.method == 'GET':
            return ProjectDetailSerializer
        elif self.request.method == 'POST':
            return ProjectListSerializer
        elif self.request.method in ['PUT', 'PATCH']:
            return ProjectListSerializer

    def create(self, request, *args, **kwargs):
        serializer = self.get_serializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        self.perform_create(serializer)
        headers = self.get_success_headers(serializer.data)
        return Response(serializer.data, status=status.HTTP_201_CREATED, headers=headers)

    def update(self, request, *args, **kwargs):
        partial = kwargs.pop('partial', False)
        instance = self.get_object()
        serializer = self.get_serializer(instance, data=request.data, partial=partial)
        serializer.is_valid(raise_exception=True)
        self.perform_update(serializer)
        return Response(serializer.data)
    
    def get_queryset(self):
        queryset = super().get_queryset()

        client_id = self.request.query_params.get('client_id')
        if client_id:
            queryset = queryset.filter(client_id=client_id)

        project_manager_id = self.request.query_params.get('project_manager_id')
        if project_manager_id:
            queryset = queryset.filter(project_manager_id=project_manager_id)

        project_user_id = self.request.query_params.get('project_user_id')
        if project_user_id:
            queryset = queryset.filter(project_users__id=project_user_id)

        status = self.request.query_params.get('status')
        if status:
            queryset = queryset.filter(status=status)

        return queryset
    
    @action(detail=False, methods=['GET'])
    def projects_by_employee(self, request, pk=None):
        employee_id = request.query_params.get('employee_id')
        if not employee_id:
            return Response({"error": "Employee ID is required"}, status=status.HTTP_400_BAD_REQUEST)
        
        employee = Employee.objects.get(pk=employee_id)
        projects = Project.objects.filter(project_users=employee)
        serializer = self.get_serializer(projects, many=True)
        return Response(serializer.data)

    @action(detail=False, methods=['get'])
    def filter_projects(self, request):
        client_id = self.request.query_params.get('client_id')
        project_manager_id = self.request.query_params.get('project_manager_id')
        project_user_id = self.request.query_params.get('project_user_id')
        status = self.request.query_params.get('status')

        queryset = Project.objects.all()

        if client_id is not None:
            queryset = queryset.filter(client_id=client_id)

        if project_manager_id is not None:
            queryset = queryset.filter(project_manager__employee_id=project_manager_id)


        if status is not None:
            queryset = queryset.filter(status=status)

        serializer = self.get_serializer(queryset, many=True)
        return Response(serializer.data)

    @action(detail=True, methods=['post'])
    def update_status(self, request, pk=None):
        job = self.get_object()
        status = request.data.get('status')  # Get status from request data
        
        # Update job status based on the provided status value
        if status == 'completed':
            job.status = 'completed'
        elif status == 'in_progress':
            job.status = 'in_progress'
        else:
            return Response({"error": "Invalid status value provided"}, status=400)

        job.save()
        serializer = self.get_serializer(job)
        return Response(serializer.data)

    @action(detail=True, methods=['get'])
    def jobs(self, request, pk=None):
        project = self.get_object()
        jobs = project.jobs.all()  
        serializer = JobDetailSerializer(jobs, many=True)
        return Response(serializer.data)

    @action(detail=False, methods=['get'])
    def search(self, request):
        query_params = request.query_params
        name = query_params.get('name')
        client_name = query_params.get('client_name')

        projects = Project.objects.all()
        if name:
            projects = projects.filter(name__icontains=name)
        if client_name:
            projects = projects.filter(client__name__icontains=client_name)

        serializer = ProjectDetailSerializer(projects, many=True)
        return Response(serializer.data)

    def perform_update(self, serializer):
        serializer.save()

    def retrieve(self, request, *args, **kwargs):
        instance = self.get_object()
        serializer = self.get_serializer(instance)
        return Response(serializer.data)

class JobViewSet(viewsets.ModelViewSet):
    permission_classes = [IsAuthenticated]
    queryset = Job.objects.all()

    def get_serializer_class(self):
        if self.request.method == 'GET':
            return JobDetailSerializer
        elif self.request.method == 'POST':
            return JobListSerializer
        elif self.request.method == 'PUT' or self.request.method == 'PATCH':
            return JobListSerializer  # Use JobDetailSerializer for updates

    @action(detail=False, methods=['get'])
    def search(self, request):
        query_params = request.query_params
        job_name = query_params.get('job_name')
        project_name = query_params.get('project_name')

        jobs = Job.objects.all()
        if job_name:
            jobs = jobs.filter(job_name__icontains=job_name)
        if project_name:
            jobs = jobs.filter(project__name__icontains=project_name)

        serializer = JobDetailSerializer(jobs, many=True)  # Use JobDetailSerializer for GET
        return Response(serializer.data)
    
    @action(detail=False, methods=['GET'])
    def jobs_by_employee(self, request):
        employee_id = request.query_params.get('employee_id')
        if not employee_id:
            return Response({"error": "Employee ID is required"}, status=status.HTTP_400_BAD_REQUEST)

        try:
            employee = Employee.objects.get(pk=employee_id)
        except ObjectDoesNotExist:
            return Response({"error": "Employee with the provided ID does not exist"}, status=status.HTTP_404_NOT_FOUND)

        # Retrieve all jobs assigned to the given employee
        jobs = Job.objects.filter(assignees=employee)

        serializer = JobDetailSerializer(jobs, many=True)  # Assuming you have a serializer for Job
        return Response(serializer.data)


    @action(detail=False, methods=['get'])
    def filter_jobs(self, request):
        client_id = self.request.query_params.get('client_id')
        assignee_id = self.request.query_params.get('assignee_id')
        status = self.request.query_params.get('status')

        filters = Q()

        if client_id is not None:
            projects = Project.objects.filter(client_id=client_id)
            project_ids = [project.id for project in projects]
            filters &= Q(project__id__in=project_ids)

        if assignee_id is not None:
            # Filter jobs by assignee's id
            filters &= Q(assignees__employee_id=assignee_id)

        if status is not None:
            filters &= Q(status=status)

        queryset = Job.objects.filter(filters)

        serializer = self.get_serializer(queryset, many=True)
        return Response(serializer.data)

    @action(detail=True, methods=['put'])
    def update_status(self, request, pk=None):
        job = self.get_object()
        status = request.data.get('status')  # Get status from request data

        # Update job status based on the provided status value
        if status == 'completed':
            job.status = 'completed'
        elif status == 'in_progress':
            job.status = 'in_progress'
        else:
            return Response({"error": "Invalid status value provided"}, status=status.HTTP_400_BAD_REQUEST)

        job.save()
        serializer = JobDetailSerializer(job)  # Use JobDetailSerializer for GET
        return Response(serializer.data)

    # Define update method
    def update(self, request, *args, **kwargs):
        partial = kwargs.pop('partial', False)
        instance = self.get_object()
        serializer = self.get_serializer(instance, data=request.data, partial=partial)
        serializer.is_valid(raise_exception=True)
        self.perform_update(serializer)
        return Response(serializer.data)

    # Define perform_update method to customize update behavior if needed
    def perform_update(self, serializer):
        serializer.save()

    # Define retrieve method
    def retrieve(self, request, *args, **kwargs):
        instance = self.get_object()
        serializer = self.get_serializer(instance)
        return Response(serializer.data)
class TimesheetViewSet(viewsets.ModelViewSet):
    permission_classes = [IsAuthenticated]
    queryset = Timesheet.objects.all()
    serializer_class = TimesheetSerializer

class TimeLogViewSet(viewsets.ModelViewSet):
    permission_classes = [IsAuthenticated]
    queryset = TimeLog.objects.all()
    serializer_class = TimeLogSerializer

# class NotificationViewSet(viewsets.ModelViewSet):
#     permission_classes = [IsAuthenticated]
#     queryset = TimesheetNotification.objects.all()
#     serializer_class = TimesheetNotificationSerializer

    
#     @action(detail=False, methods=['get'])
#     def notifications_by_employee_id(self, request):
#         employee_id = request.query_params.get('employee_id')
#         if employee_id is None:
#             return Response("Employee ID is required in the query parameters", status=status.HTTP_400_BAD_REQUEST)

#         try:
#             notifications = TimesheetNotification.objects.filter(recipient__employee_id=employee_id)
#             serializer = self.get_serializer(notifications, many=True)
#             return Response(serializer.data)
#         except Employee.DoesNotExist:
#             return Response(f"No notifications found for employee ID {employee_id}", status=status.HTTP_404_NOT_FOUND)
        
#     @action(detail=True, methods=['post'])
#     def mark_as_read(self, request, pk=None):
#         try:
#             notification = TimesheetNotification.objects.get(pk=pk)
#             notification.read_status = True
#             notification.save()
#             return Response("Notification marked as read", status=status.HTTP_200_OK)
#         except TimesheetNotification.DoesNotExist:
#             return Response(f"Notification with ID {pk} does not exist", status=status.HTTP_404_NOT_FOUND)
        
#     @action(detail=False, methods=['get'])
#     def notifications_by_status(self, request):
#         read_status = request.query_params.get('read_status')  # 'true' or 'false'
#         if read_status is None:
#             return Response("Read status parameter is required in the query parameters", status=status.HTTP_400_BAD_REQUEST)
        
#         # Convert string 'true' or 'false' to boolean
#         read_status_bool = read_status.lower() == 'true'

#         notifications = TimesheetNotification.objects.filter(read_status=read_status_bool)
#         serializer = self.get_serializer(notifications, many=True)
#         return Response(serializer.data)

#     @action(detail=True, methods=['delete'])
#     def delete_notification(self, request, pk=None):
#         try:
#             notification = TimesheetNotification.objects.get(pk=pk)
#             notification.delete()
#             return Response("Notification deleted successfully", status=status.HTTP_204_NO_CONTENT)
#         except TimesheetNotification.DoesNotExist:
#             return Response(f"Notification with ID {pk} does not exist", status=status.HTTP_404_NOT_FOUND)
        