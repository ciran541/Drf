# signals.py
from django.db.models.signals import m2m_changed, post_save, pre_delete
from django.dispatch import receiver
from .models import Job, Project
from Hr.Notifications.models import Notification

# Notification for Job
@receiver(m2m_changed, sender=Job.assignees.through)
def notify_assigned_job(sender, instance, action, **kwargs):
    if action == 'post_add':
        employees_added = instance.assignees.all()
        message = f'You have been assigned to the job: {instance.job_name}'
        for employee in employees_added:
            Notification.objects.create(
                recipient=employee,
                subject='Job',  # Specify subject as 'Job'
                message=message
            )

@receiver(post_save, sender=Job)
def notify_job_update(sender, instance, created, **kwargs):
    if not created:
        message = f'The job {instance.job_name} has been updated.'
        recipients = instance.assignees.all()
        for recipient in recipients:
            Notification.objects.create(
                recipient=recipient,
                subject='Job',  # Specify subject as 'Job'
                message=message
            )

@receiver(pre_delete, sender=Job)
def notify_job_deletion(sender, instance, **kwargs):
    message = f'The job {instance.job_name} has been deleted.'
    recipients = instance.assignees.all()
    for recipient in recipients:
        Notification.objects.create(
            recipient=recipient,
            subject='Job',  # Specify subject as 'Job'
            message=message
        )

@receiver(post_save, sender=Job)
def notify_job_status_change(sender, instance, created, **kwargs):
    if not created:
        old_instance = Job.objects.get(pk=instance.pk)
        if old_instance.status != instance.status:
            message = f'The status of the job {instance.job_name} has been changed to {instance.get_status_display()}.'
            recipients = instance.assignees.all()
            for recipient in recipients:
                Notification.objects.create(
                    recipient=recipient,
                    subject='Job',  # Specify subject as 'Job'
                    message=message
                )

# Notification for Project
@receiver(m2m_changed, sender=Project.project_users.through)
def notify_assigned_project(sender, instance, action, **kwargs):
    if action == 'post_add':
        users_added = instance.project_users.all()
        message = f'You have been assigned to the project: {instance.name}'
        for user in users_added:
            Notification.objects.create(
                recipient=user,
                subject='Project',  # Specify subject as 'Project'
                message=message
            )

@receiver(post_save, sender=Project)
def notify_project_update(sender, instance, created, **kwargs):
    if not created:
        message = f'The project {instance.name} has been updated.'
        users = instance.project_users.all()
        for user in users:
            Notification.objects.create(
                recipient=user,
                subject='Project',  # Specify subject as 'Project'
                message=message
            )

@receiver(pre_delete, sender=Project)
def notify_project_deletion(sender, instance, **kwargs):
    message = f'The project {instance.name} has been deleted.'
    users = instance.project_users.all()
    for user in users:
        Notification.objects.create(
            recipient=user,
            subject='Project',  # Specify subject as 'Project'
            message=message
        )