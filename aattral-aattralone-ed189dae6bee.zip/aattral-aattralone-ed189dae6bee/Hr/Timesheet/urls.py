from django.urls import path, include
from rest_framework.routers import DefaultRouter
from .views import CountryViewSet, ClientViewSet,ProjectViewSet,JobViewSet,TimesheetViewSet,TimeLogViewSet

router = DefaultRouter()
router.register(r'countries', CountryViewSet)
router.register(r'clients', ClientViewSet)
router.register(r'projects', ProjectViewSet)
router.register(r'jobs', JobViewSet)
router.register(r'mytimesheet', TimesheetViewSet)
router.register(r'timelogs', TimeLogViewSet)
# router.register(r'notifications', NotificationViewSet)


urlpatterns = [
    path('', include(router.urls)),
]

# For search :
# timetracker/clients/search/?name={name} or currency, billing method
# timetracker/project/search/?name={name} or client_name
# timetracker/project/search/?name={job_name} or project_name
# For Filter in Project - /api/projects/filter_projects/?client_id=1&project_manager_id=2&project_user_id=3&status=in_progress
# For Job filter - GET /api/hr/timetracker/jobs/filter_jobs/?client_id=1&assignee_id=2&status=in_progress