# signals.py
from django.db.models.signals import m2m_changed, post_save, pre_delete
from django.dispatch import receiver
from Hr.Notifications.models import Notification
from .models import Task

# Signal handlers for Task model
        
@receiver(post_save, sender=Task)
def notify_task_creation(sender, instance, created, **kwargs):
    if created:
        # Assuming task_owner is a ForeignKey to CustomUser in Task model
        task_owner = instance.task_owner
        # Retrieve the corresponding Employee instance
        employee = task_owner.employee
        # Create notification for the task owner
        if employee:
            message = f'A new task "{instance.task_name}" has been assigned to you.'
            Notification.objects.create(
                recipient=employee,
                subject='Task',
                message=message
            )     

# Notification for task update

@receiver(post_save, sender=Task)
def notify_task_update(sender, instance, created, **kwargs):
    if not created:
        message = f'The task "{instance.task_name}" has been updated.'
        # Create notification for task owner
        employee = instance.task_owner.employee
        if employee:
            Notification.objects.create(
                recipient=employee,
                subject='Task',
                message=message
            )

# Notification for task deletion
@receiver(pre_delete, sender=Task)
def notify_task_deletion(sender, instance, **kwargs):
    message = f'The task "{instance.task_name}" has been deleted.'
    # Create notification for task owner
    employee = instance.task_owner.employee
    if employee:
        Notification.objects.create(
            recipient=employee,
            subject='Task',
            message=message
        )

# Notification for task becoming overdue
@receiver(post_save, sender=Task)
def notify_task_overdue(sender, instance, **kwargs):
    if instance.is_overdue():
        message = f'The task "{instance.task_name}" is overdue.'
        # Create notification for task owner
        employee = instance.task_owner.employee
        if employee:
            Notification.objects.create(
                recipient=employee,
                subject='Task',
                message=message
            )

# Notification for task completion
@receiver(post_save, sender=Task)
def notify_task_completion(sender, instance, **kwargs):
    if instance.status == 'Completed':
        message = f'Congratulations! The task "{instance.task_name}" has been completed.'
        # Create notification for task owner
        employee = instance.task_owner.employee
        if employee:
            Notification.objects.create(
                recipient=employee,
                subject='Task',
                message=message
            )