from rest_framework.routers import DefaultRouter
from .views import TaskViewSet

router = DefaultRouter()
router.register(r'tasks', TaskViewSet, basename='task')

urlpatterns = router.urls

# GET /api/tasks/: Retrieve a list of tasks
# POST /api/tasks/: Create a new task
# GET /api/tasks/{id}/: Retrieve details of a specific task
# PUT /api/tasks/{id}/: Update a specific task
# PATCH /api/tasks/{id}/: Partially update a specific task
# DELETE /api/tasks/{id}/: Delete a specific task
# GET /api/tasks/{id}/days_until_due/: Retrieve the number of days until a specific task is due
# GET /api/tasks/{id}/overdue/: Check if a specific task is overdue
# GET /api/tasks/{id}/due_soon/: Check if a specific task is due soon