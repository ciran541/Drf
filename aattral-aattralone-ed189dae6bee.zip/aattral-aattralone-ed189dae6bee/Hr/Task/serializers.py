from rest_framework import serializers
from .models import Task
from Authentication.serializers import CustomUserSerializer
class TaskCreateSerializer(serializers.ModelSerializer):
    class Meta:
        model = Task
        fields = '__all__'

class TaskDetailSerializer(serializers.ModelSerializer):
    task_owner = CustomUserSerializer()

    class Meta:
        model = Task
        fields = '__all__'