from django.db import models
from Authentication.models import CustomUser
from django.utils import timezone
class Task(models.Model):

    PRIORITY_CHOICES = [
        ('Low', 'Low'),
        ('Medium', 'Medium'),
        ('High', 'High'),
    ]

    STATUS_CHOICES = [
        ('Open', 'Open'),
        ('Completed', 'Completed'),
        
    ]


    task_owner = models.ForeignKey(CustomUser, on_delete=models.CASCADE, related_name='tasks_owned')
    task_name = models.CharField(max_length=255)
    description = models.TextField()
    start_date = models.DateField()
    due_date = models.DateField()
    reminder = models.DateTimeField()
    priority = models.CharField(max_length=20, choices=PRIORITY_CHOICES, default='Medium')
    status = models.CharField(max_length=20, choices=STATUS_CHOICES, default='Open')

    def __str__(self):
        return self.task_name
    
    def days_until_due(self):
        """
        Method to calculate and return the number of days until the task is due.
        """
        remaining_days = (self.due_date - timezone.now().date()).days
        return max(remaining_days, 0)

    def is_overdue(self):
        """
        Method to check if the task is overdue.
        """
        return self.days_until_due() < 0

    def is_due_soon(self, threshold_days=7):
        """
        Method to check if the task is due soon based on a given threshold in days.
        """
        return 0 <= self.days_until_due() <= threshold_days

    def __str__(self):
        return self.task_name
    
    