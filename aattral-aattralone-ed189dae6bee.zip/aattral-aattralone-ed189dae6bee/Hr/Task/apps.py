from django.apps import AppConfig


class TaskConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'Hr.Task'

    def ready(self):
        import Hr.Task.signal
