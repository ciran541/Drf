# admin.py

from django.contrib import admin
from .models import Task
from django.utils import timezone
@admin.register(Task)
class TaskAdmin(admin.ModelAdmin):
    list_display = ('task_name', 'task_owner', 'start_date', 'due_date', 'reminder', 'priority', 'status', 'days_until_due', 'is_overdue', 'is_due_soon')
    list_filter = ('priority', 'status')
    search_fields = ('task_name', 'description')
    date_hierarchy = 'due_date'

    def days_until_due(self, obj):
        """
        Method to calculate and return the number of days until the task is due.
        """
        remaining_days = (obj.due_date - timezone.now().date()).days
        return max(remaining_days, 0)
    days_until_due.short_description = 'Days Until Due'

    def is_overdue(self, obj):
        """
        Method to check if the task is overdue.
        """
        return obj.days_until_due() < 0
    is_overdue.boolean = True
    is_overdue.short_description = 'Overdue'

    def is_due_soon(self, obj):
        """
        Method to check if the task is due soon based on a given threshold in days.
        """
        return 0 <= obj.days_until_due() <= 7
    is_due_soon.boolean = True
    is_due_soon.short_description = 'Due Soon'
