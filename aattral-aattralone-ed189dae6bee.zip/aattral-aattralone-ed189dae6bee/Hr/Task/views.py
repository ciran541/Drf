from rest_framework import viewsets
from rest_framework.permissions import IsAuthenticated
from rest_framework.decorators import action
from rest_framework.response import Response
from .models import Task
from .serializers import TaskCreateSerializer, TaskDetailSerializer

class TaskViewSet(viewsets.ModelViewSet):
    permission_classes = [IsAuthenticated]
    queryset = Task.objects.all()
    serializer_class = TaskCreateSerializer

    def get_serializer_class(self):
        if self.action == 'create' or self.action == 'update':
            return TaskCreateSerializer
        else:
            return TaskDetailSerializer

    @action(detail=False, methods=['get'])
    def search(self, request):
        query_params = request.query_params
        job_name = query_params.get('task_name')
        project_name = query_params.get('task_owner')

        jobs = Task.objects.all()
        if job_name:
            jobs = jobs.filter(job_name__icontains=job_name)
        if project_name:
            jobs = jobs.filter(project__name__icontains=project_name)

        serializer = TaskCreateSerializer(jobs, many=True)
        return Response(serializer.data)
    
    @action(detail=True, methods=['put'])
    def update_status(self, request, pk=None):
        """
        Custom action to update the status of a task.
        """
        task = self.get_object()
        status = request.data.get('status', None)
        if status in ['Open', 'Completed']:
            task.status = status
            task.save()
            return Response({'status': task.status})
        else:
            return Response({'error': 'Invalid status value'}, status=400)

    @action(detail=True, methods=['get'])
    def days_until_due(self, request, pk=None):
        """
        Custom action to retrieve the number of days until the task is due.
        """
        task = self.get_object()
        remaining_days = task.days_until_due()
        return Response({'days_until_due': remaining_days})

    @action(detail=True, methods=['get'])
    def overdue(self, request, pk=None):
        """
        Custom action to check if the task is overdue.
        """
        task = self.get_object()
        return Response({'overdue': task.is_overdue()})

    @action(detail=True, methods=['get'])
    def due_soon(self, request, pk=None):
        """
        Custom action to check if the task is due soon.
        """
        task = self.get_object()
        return Response({'due_soon': task.is_due_soon()})

    @action(detail=False, methods=['get'])
    def tasks_by_owner(self, request):
        """
        Custom action to retrieve tasks by task owner.
        """
        query_params = request.query_params
        owner_username = query_params.get('task_owner')

        tasks = Task.objects.filter(task_owner__id=owner_username)
        serializer = TaskDetailSerializer(tasks, many=True)
        return Response(serializer.data)
    
    @action(detail=False, methods=['get'])
    def tasks_by_status(self, request):
        """
        Custom action to retrieve tasks by status.
        """
        query_params = request.query_params
        status = query_params.get('status')

        tasks = Task.objects.filter(status__iexact=status)
        serializer = TaskCreateSerializer(tasks, many=True)
        return Response(serializer.data)

    @action(detail=False, methods=['get'])
    def tasks_by_priority(self, request):
        """
        Custom action to retrieve tasks by priority.
        """
        query_params = request.query_params
        priority = query_params.get('priority')

        tasks = Task.objects.filter(priority__iexact=priority)
        serializer = TaskCreateSerializer(tasks, many=True)
        return Response(serializer.data)