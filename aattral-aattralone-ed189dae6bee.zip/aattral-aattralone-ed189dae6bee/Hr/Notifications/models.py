from django.db import models
from Hr.employee_information.models import Employee


class Notification(models.Model):
    recipient = models.ForeignKey(Employee, on_delete=models.CASCADE)
    subject = models.CharField(max_length=100)
    message = models.TextField()
    timestamp = models.DateTimeField(auto_now_add=True)
    read_status = models.BooleanField(default=False)