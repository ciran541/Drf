from rest_framework import viewsets, status
from rest_framework.response import Response
from rest_framework.decorators import action
from rest_framework.permissions import IsAuthenticated
from Hr.employee_information.models import Employee
from .models import Notification
from .serializers import NotificationSerializer

class NotificationViewSet(viewsets.ModelViewSet):
    permission_classes = [IsAuthenticated]
    queryset = Notification.objects.all()
    serializer_class = NotificationSerializer

    @action(detail=False, methods=['get'])
    def notifications_by_employee_id(self, request):
        employee_id = request.query_params.get('employee_id')
        if employee_id is None:
            return Response("Employee ID is required in the query parameters", status=status.HTTP_400_BAD_REQUEST)

        try:
            notifications = Notification.objects.filter(recipient__employee_id=employee_id)
            serializer = self.get_serializer(notifications, many=True)
            return Response(serializer.data)
        except Employee.DoesNotExist:
            return Response(f"No notifications found for employee ID {employee_id}", status=status.HTTP_404_NOT_FOUND)
        
    @action(detail=True, methods=['post'])
    def mark_as_read(self, request, pk=None):
        try:
            notification = Notification.objects.get(pk=pk)
            notification.read_status = True
            notification.save()
            return Response("Notification marked as read", status=status.HTTP_200_OK)
        except Notification.DoesNotExist:
            return Response(f"Notification with ID {pk} does not exist", status=status.HTTP_404_NOT_FOUND)
        
    @action(detail=False, methods=['get'])
    def notifications_by_status(self, request):
        read_status = request.query_params.get('read_status')  # 'true' or 'false'
        if read_status is None:
            return Response("Read status parameter is required in the query parameters", status=status.HTTP_400_BAD_REQUEST)
        
        # Convert string 'true' or 'false' to boolean
        read_status_bool = read_status.lower() == 'true'

        notifications = Notification.objects.filter(read_status=read_status_bool)
        serializer = self.get_serializer(notifications, many=True)
        return Response(serializer.data)
    
    @action(detail=False, methods=['get'])
    def notifications_by_employee_id_and_status(self, request):
        employee_id = request.query_params.get('employee_id')
        read_status = request.query_params.get('read_status')  # 'true' or 'false'
        
        if employee_id is None or read_status is None:
            return Response("Both employee ID and read status parameters are required in the query parameters", status=status.HTTP_400_BAD_REQUEST)
        
        read_status_bool = read_status.lower() == 'true'

        try:
            notifications = Notification.objects.filter(recipient__employee_id=employee_id, read_status=read_status_bool)
            serializer = self.get_serializer(notifications, many=True)
            return Response(serializer.data)
        except Employee.DoesNotExist:
            return Response(f"No notifications found for employee ID {employee_id}", status=status.HTTP_404_NOT_FOUND)

    @action(detail=True, methods=['delete'])
    def delete_notification(self, request, pk=None):
        try:
            notification = Notification.objects.get(pk=pk)
            notification.delete()
            return Response("Notification deleted successfully", status=status.HTTP_204_NO_CONTENT)
        except Notification.DoesNotExist:
            return Response(f"Notification with ID {pk} does not exist", status=status.HTTP_404_NOT_FOUND)
        