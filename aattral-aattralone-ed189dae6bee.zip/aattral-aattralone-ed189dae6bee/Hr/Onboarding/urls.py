from rest_framework.routers import DefaultRouter
from .views import (CandidateViewSet,OnboardingFlowViewSet, EmployeeOnboardingFlowViewSet, CandidateOnboardingFlowViewSet,
                    WelcomeAbroadPageViewSet, ProfilePageViewSet, FormsPageViewSet, ChecklistPageViewSet, ReportViewSet)

router = DefaultRouter()
router.register(r'candidates', CandidateViewSet, basename='candidate')
router.register(r'onboardingflows', OnboardingFlowViewSet, basename='onboardingflow')
router.register(r'employeeonboardingflows', EmployeeOnboardingFlowViewSet, basename='employeeonboardingflow')
router.register(r'candidateonboardingflows', CandidateOnboardingFlowViewSet, basename='candidateonboardingflow')
router.register(r'welcomeabroadpages', WelcomeAbroadPageViewSet, basename='welcomeabroadpage')
router.register(r'profilepages', ProfilePageViewSet, basename='profilepage')
router.register(r'formspages', FormsPageViewSet, basename='formspage')
router.register(r'checklistpages', ChecklistPageViewSet, basename='checklistpage')
# router.register(r'documentspoliciespages', DocumentsPoliciesPageViewSet, basename='documentspoliciespage')
router.register(r'report', ReportViewSet, basename='report')
# router.register(r'FormTemplate', FormTemplateViewSet, basename='FormTemplate')

urlpatterns = router.urls
