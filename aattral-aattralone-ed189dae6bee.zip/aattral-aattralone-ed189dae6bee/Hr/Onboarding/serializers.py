from rest_framework import serializers
from .models import (Candidate,OnboardingFlow, EmployeeOnboardingFlow, CandidateOnboardingFlow, WelcomeAbroadPage, ProfilePage, 
                     FormsPage, ChecklistPage,BaseOnboardingPage,Report)

class CandidateSerializer(serializers.ModelSerializer):
    class Meta:
        model = Candidate
        fields = '__all__'

class OnboardingFlowSerializer(serializers.ModelSerializer):
    class Meta:
        model = OnboardingFlow
        fields = '__all__'

class EmployeeOnboardingFlowSerializer(serializers.ModelSerializer):
    class Meta:
        model = EmployeeOnboardingFlow
        fields = '__all__'

class CandidateOnboardingFlowSerializer(serializers.ModelSerializer):
    class Meta:
        model = CandidateOnboardingFlow
        fields = '__all__'

class BaseOnboardingPageSerializer(serializers.ModelSerializer):
    class Meta:
        model = BaseOnboardingPage
        fields = '__all__'

class WelcomeAbroadPageSerializer(serializers.ModelSerializer):
    class Meta:
        model = WelcomeAbroadPage
        fields = '__all__'

class ProfilePageSerializer(serializers.ModelSerializer):
    class Meta:
        model = ProfilePage
        fields = '__all__'

class FormsPageSerializer(serializers.ModelSerializer):
    class Meta:
        model = FormsPage
        fields = '__all__'

class ChecklistPageSerializer(serializers.ModelSerializer):
    class Meta:
        model = ChecklistPage
        fields = '__all__'

class ReportSerializer(serializers.ModelSerializer):
    class Meta:
        model = Report
        fields = '__all__'

class FormTemplateSerializer(serializers.ModelSerializer):
    class Meta:
        model = Report
        fields = '__all__'