from rest_framework import viewsets
from rest_framework.permissions import IsAuthenticated
from django.shortcuts import render
from .models import (Candidate,OnboardingFlow, EmployeeOnboardingFlow, CandidateOnboardingFlow, WelcomeAbroadPage,
                     ProfilePage, FormsPage, ChecklistPage,Report)
from .serializers import (CandidateSerializer,OnboardingFlowSerializer, EmployeeOnboardingFlowSerializer, CandidateOnboardingFlowSerializer, FormTemplateSerializer,
                          WelcomeAbroadPageSerializer, ProfilePageSerializer, FormsPageSerializer, ChecklistPageSerializer,ReportSerializer)

class CandidateViewSet(viewsets.ModelViewSet):
    permission_classes = [IsAuthenticated]
    queryset = Candidate.objects.all()
    serializer_class = CandidateSerializer

class OnboardingFlowViewSet(viewsets.ModelViewSet):
    permission_classes = [IsAuthenticated]
    queryset = OnboardingFlow.objects.all()
    serializer_class = OnboardingFlowSerializer

class EmployeeOnboardingFlowViewSet(viewsets.ModelViewSet):
    permission_classes = [IsAuthenticated]
    queryset = EmployeeOnboardingFlow.objects.all()
    serializer_class = EmployeeOnboardingFlowSerializer

class CandidateOnboardingFlowViewSet(viewsets.ModelViewSet):
    permission_classes = [IsAuthenticated]
    queryset = CandidateOnboardingFlow.objects.all()
    serializer_class = CandidateOnboardingFlowSerializer

class WelcomeAbroadPageViewSet(viewsets.ModelViewSet):
    permission_classes = [IsAuthenticated]
    queryset = WelcomeAbroadPage.objects.all()
    serializer_class = WelcomeAbroadPageSerializer

class ProfilePageViewSet(viewsets.ModelViewSet):
    permission_classes = [IsAuthenticated]
    queryset = ProfilePage.objects.all()
    serializer_class = ProfilePageSerializer

class FormsPageViewSet(viewsets.ModelViewSet):
    permission_classes = [IsAuthenticated]
    queryset = FormsPage.objects.all()
    serializer_class = FormsPageSerializer

class ChecklistPageViewSet(viewsets.ModelViewSet):
    permission_classes = [IsAuthenticated]
    queryset = ChecklistPage.objects.all()
    serializer_class = ChecklistPageSerializer



class ReportViewSet(viewsets.ModelViewSet):
    permission_classes = [IsAuthenticated]
    queryset = Report.objects.all()
    serializer_class = ReportSerializer

# class FormTemplateViewSet(viewsets.ModelViewSet):
#     queryset = FormTemplate.objects.all()
#     serializer_class = FormTemplateSerializer

def dashboard_view(request):
    successful_onboarded_count = Report.get_successful_onboarded_count()
    in_progress_count = Report.get_in_progress_count()

    context = {
        'successful_onboarded_count': successful_onboarded_count,
        'in_progress_count': in_progress_count,
    }

    return render(request, 'dashboard.html', context)