from django.db import models
from Authentication.models import CustomUser
from django.core.exceptions import ValidationError
from datetime import timezone
import json
from Hr.employee_information.models import Role
#Candidate InFo # 
ONBOARDING_STATUS_CHOICES = [
        ('Pending', 'Pending'),
        ('In Progress', 'In Progress'),
        ('Completed', 'Completed'),
    ]
    

SOURCE_OF_HIRE_CHOICES = [
        ('Internal Referral', 'Internal Referral'),
        ('External Job Portal', 'External Job Portal'),
        ('Recruitment Agency', 'Recruitment Agency'),
        ('Direct Application', 'Direct Application'),
    ]
    

DEPARTMENT_CHOICES = [
        ('HR', 'Human Resources'),
        ('IT', 'Information Technology'),
        ('Finance', 'Finance'),
        # Add more departments as needed
    ]
    

LOCATION_CHOICES = [
        ('USA', 'United States'),
        ('IND', 'India'),
        # Add more countries as needed
    ]

class Candidate(models.Model):
    first_name = models.CharField(max_length=100)
    last_name = models.CharField(max_length=100)
    candidate_id = models.CharField(max_length=50, unique=True)
    email_id = models.EmailField(unique=True)
    official_email = models.EmailField()
    onboarding_status = models.CharField(max_length=50, choices=ONBOARDING_STATUS_CHOICES)
    department = models.CharField(max_length=100, choices=DEPARTMENT_CHOICES)
    source_of_hire = models.CharField(max_length=100, choices=SOURCE_OF_HIRE_CHOICES)
    pan_card_number = models.CharField(max_length=20, unique=True)
    aadhaar_card_number = models.CharField(max_length=20, unique=True)
    present_address = models.TextField()
    photo = models.ImageField(upload_to='candidate_photos/', null=True, blank=True)
    phone = models.CharField(max_length=20)
    skill_set = models.TextField()
    experience = models.PositiveIntegerField()
    permanent_address = models.TextField()
    highest_qualification = models.CharField(max_length=100)
    location = models.CharField(max_length=100, choices=LOCATION_CHOICES)
    tentative_joining_date = models.DateField()
    offer_letter = models.FileField(upload_to='offer_letters/', null=True, blank=True)
    title = models.CharField(max_length=100)
    current_salary = models.DecimalField(max_digits=10, decimal_places=2)
    additional_information = models.TextField()
    added_by = models.ForeignKey(CustomUser, on_delete=models.CASCADE, related_name='candidates_added')
    added_time = models.DateTimeField(auto_now_add=True)
    modified_by = models.ForeignKey(CustomUser, on_delete=models.CASCADE, related_name='candidates_modified')
    modified_time = models.DateTimeField(auto_now=True)

    def clean(self):
        if self.tentative_joining_date and self.tentative_joining_date < timezone.now().date():
            raise ValidationError({'tentative_joining_date': 'Joining date must be in the future.'})

    def save(self, *args, **kwargs):
        self.full_clean()  # Run full validation before saving
        super().save(*args, **kwargs)

    def __str__(self):
        return f"{self.first_name} - {self.candidate_id}"
    
# class Location(models.Model):
#     name = models.CharField(max_length=100)
#     country = models.CharField(max_length=100)
#     state_province = models.CharField(max_length=100)
#     city = models.CharField(max_length=100)
#     postal_code = models.CharField(max_length=20)
#     address_line1 = models.TextField()
#     address_line2 = models.TextField()
#     mail_alias = models.CharField(max_length=50)
#     time_zone = models.CharField(max_length=50)
#     added_time = models.DateTimeField(auto_now_add=True)
#     modified_time = models.DateTimeField(auto_now=True) 

# class Designation(models.Model):
#     name = models.CharField(max_length=100)
#     mail_alias = models.CharField(max_length=50)
#     added_time = models.DateTimeField(auto_now_add=True)
#     modified_time = models.DateTimeField(auto_now=True)

# class Department(models.Model):
#     name = models.CharField(max_length=100)
#     mail_alias = models.CharField(max_length=50)
#     added_time = models.DateTimeField(auto_now_add=True)
#     modified_time = models.DateTimeField(auto_now=True)

# Form Template #      
# class FormTemplate(models.Model):
#     name = models.CharField(max_length=255)
#     description = models.TextField()
#     fields = models.JSONField()

#     def __str__(self):
#         return self.name

#     def clean(self):
#         try:
#             # Ensure fields is a valid JSON array
#             if not isinstance(self.fields, list):
#                 raise ValidationError({'fields': 'Fields must be a valid JSON array.'})

#             # Additional custom validations for each field
#             for field in self.fields:
#                 self.validate_field(field)

#         except json.JSONDecodeError:
#             raise ValidationError({'fields': 'Invalid JSON format for fields.'})

#     def validate_field(self, field):
#         # Validate common fields
#         required_fields = ['name', 'type', 'required']
#         for req_field in required_fields:
#             if req_field not in field:
#                 raise ValidationError({'fields': f'Missing required field "{req_field}" in one of the form fields.'})

#         # Additional validations based on field type
#         field_type = field.get('type')
#         if field_type == 'dropdown' or field_type == 'lookup' or field_type == 'radio' or field_type == 'multi_select':
#             options = field.get('options')
#             if not options or not isinstance(options, list):
#                 raise ValidationError({'fields': f'Field "{field["name"]}" of type "{field_type}" must have a valid list of options.'})

#     def save(self, *args, **kwargs):
#         self.full_clean()  # Run full validation before saving
#         super().save(*args, **kwargs)

# # Example JSON data for fields
# json_data = [
#     {"name": "Single Line", "type": "text", "required": True},
#     {"name": "Multi Line", "type": "textarea", "required": True},
#     {"name": "Email ID", "type": "email", "required": True},
#     {"name": "Number", "type": "number", "required": True},
#     {"name": "Currency", "type": "currency", "required": True},
#     {"name": "Add Notes", "type": "notes", "required": False},
#     {"name": "Dropdown", "type": "dropdown", "options": ["Option 1", "Option 2"], "required": True},
#     {"name": "Blood Group", "type": "blood_group", "required": True},
#     {"name": "Image", "type": "image", "required": True},
#     {"name": "Phone", "type": "phone", "required": True},
#     {"name": "Date", "type": "date", "required": True},
#     {"name": "Formula", "type": "formula", "required": True},
#     {"name": "Date - Time", "type": "datetime", "required": True},
#     {"name": "Url", "type": "url", "required": True},
#     {"name": "File upload", "type": "file", "required": True},
#     {"name": "Gender", "type": "gender", "options": ["Male", "Female", "Other"], "required": True},
#     {"name": "Decimal", "type": "decimal", "required": True},
#     {"name": "Lookup", "type": "lookup", "options": ["Option 1", "Option 2"], "required": True},
#     {"name": "Radio", "type": "radio", "options": ["Option 1", "Option 2"], "required": True},
#     {"name": "Country", "type": "country", "required": True},
#     {"name": "Decision box", "type": "decision_box", "required": True},
#     {"name": "Multi-select", "type": "multi_select", "options": ["Option 1", "Option 2"], "required": True},
#     {"name": "Address", "type": "address", "required": True}
#     # Add more fields as needed
# ]

# # Create a FormTemplate instance with the JSON data
# form_template = FormTemplate.objects.create(
#     name="Example Form Template",
#     description="This is an example form template",
#     fields=json_data
# )


#Onboarding# 
class OnboardingFlow(models.Model):
    name = models.CharField(max_length=255)
    applicable_locations = models.CharField(max_length=255)
    expiration_date = models.DateField(null=True, blank=True)

    def clean(self):
        if self.expiration_date and self.expiration_date < timezone.now().date():
            raise ValidationError({'expiration_date': 'Expiration date must be in the future.'})

    def save(self, *args, **kwargs):
        self.full_clean()  # Run full validation before saving
        super().save(*args, **kwargs)


class EmployeeOnboardingFlow(models.Model):
    flow = models.ForeignKey(OnboardingFlow, on_delete=models.CASCADE)
    name = models.CharField(max_length=255)

    def clean(self):
        if not self.flow:
            raise ValidationError({'flow': 'EmployeeOnboardingFlow must have a valid OnboardingFlow.'})

    def save(self, *args, **kwargs):
        self.full_clean()  # Run full validation before saving
        super().save(*args, **kwargs)


class CandidateOnboardingFlow(models.Model):
    flow = models.ForeignKey(OnboardingFlow, on_delete=models.CASCADE)
    name = models.CharField(max_length=255)

    def clean(self):
        if not self.flow:
            raise ValidationError({'flow': 'CandidateOnboardingFlow must have a valid OnboardingFlow.'})

    def save(self, *args, **kwargs):
        self.full_clean()  # Run full validation before saving
        super().save(*args, **kwargs)

class BaseOnboardingPage(models.Model):
    flow = models.ForeignKey(OnboardingFlow, on_delete=models.CASCADE)
    
    class Meta:
        abstract = True

class WelcomeAbroadPage(BaseOnboardingPage):
    video_url = models.URLField()
    welcome_message = models.TextField()
    additional_field = models.CharField(max_length=255)

class ProfilePage(BaseOnboardingPage):
    first_name = models.CharField(max_length=255)
    last_name = models.CharField(max_length=255)
    job_title = models.CharField(max_length=255)
    additional_field = models.CharField(max_length=255)

class FormsPage(BaseOnboardingPage):
    Description = models.TextField()

class ChecklistPage(BaseOnboardingPage):
    form_name = models.CharField(max_length=255)
    checklist_name = models.CharField(max_length=255)

    def __str__(self):
        return f"{self.form_name} - {self.checklist_name}"

# class DocumentsPoliciesPage(BaseOnboardingPage):

#     FORM_TYPE_CHOICES = [
#         ('Leave', 'Leave Tracker'),
#         ('Time Tracker', 'Clients'),
#         ('Time Tracker', 'Projects'),
#         ('Time Tracker', 'Jobs'),
#         ('Performance', 'Self Appraisal'),
#         ('Performance', 'Performance Appraisal'),
#         ('Performance', 'Goals'),
#         ('Performance', 'Employee Salary'),
#         ('Performance', 'Multi-rater Review'),
#         ('Organization', 'Employee'),
#         ('Organization', 'Exit Details'),
#         ('Organization', 'Vaccination Status'),
#         ('Organization', 'Employee Health Data'),
#         ('Travel', 'Travel Request'),
#         ('Travel', 'Travel Expense'),
#         ('Tasks', 'Task'),
#         ('HR Letters', 'Address Proof'),
#         ('HR Letters', 'Bonafide Letter'),
#         ('HR Letters', 'Experience Letter'),
#         ('Onboarding', 'Candidate Onboarding'),
#     ]

#     DOCUMENT_CHOICES = [
#         ('employee_contract', 'Employee Contract'),
#         ('code_of_conduct', 'Code of Conduct'),
#         ('privacy_policy', 'Privacy Policy'),
#     ]

#     SIGN_TYPE_CHOICES = [
#         ('electronic', 'Electronic Signature'),
#         ('physical', 'Physical Signature'),
#     ]

#     document_name = models.CharField(max_length=255, choices=DOCUMENT_CHOICES)
#     document_url = models.URLField()
#     form = models.CharField(max_length=255, choices=FORM_TYPE_CHOICES)
#     # form_template = models.ForeignKey(FormTemplate, on_delete=models.SET_NULL, null=True, blank=True)
#     mail_merge_template = models.FileField(upload_to='mail_merge_templates/', null=True, blank=True)
#     applicable_roles = models.ManyToManyField(Role) 
#     sign_type = models.CharField(max_length=20, choices=SIGN_TYPE_CHOICES)
#     description = models.TextField()
#     documents_to_be_read = models.TextField(choices=DOCUMENT_CHOICES)  # Assuming multiple documents can be selected

#     def clean(self):
#         if not self.document_name or not self.document_url or not self.form or not self.sign_type or not self.description:
#             raise ValidationError({'error': 'All fields must be filled.'})

#         if self.documents_to_be_read.count() == 0:
#             raise ValidationError({'documents_to_be_read': 'At least one document must be selected to be read.'})

#         # Additional custom validations as needed

#     def save(self, *args, **kwargs):
#         self.full_clean()  # Run full validation before saving
#         super().save(*args, **kwargs)

#     def __str__(self):
#         return self.document_name
    


#Report#
class Report(models.Model):
    ONBOARDING_STATUS_CHOICES = [
        ('Onboarded', 'Onboarded'),
        ('OnboardingInProgress', 'Onboarding in progress'),
    ]

    onboarding_flow = models.ForeignKey(OnboardingFlow, on_delete=models.CASCADE)
    user = models.OneToOneField(CustomUser, on_delete=models.CASCADE)  
    status = models.CharField(max_length=20, choices=ONBOARDING_STATUS_CHOICES, default='OnboardingInProgress')
    report_date = models.DateField(auto_now_add=True)
    report_text = models.TextField()

    def __str__(self):
        return f"{self.user.username} - {self.status}"

    @classmethod
    def get_successful_onboarded_count(cls):
        return cls.objects.filter(status='Onboarded').count()

    @classmethod
    def get_in_progress_count(cls):
        return cls.objects.filter(status='OnboardingInProgress').count()
