# admin.py

from django.contrib import admin
from .models import Candidate, OnboardingFlow, EmployeeOnboardingFlow, CandidateOnboardingFlow, WelcomeAbroadPage, ProfilePage, FormsPage, ChecklistPage, Report

@admin.register(Candidate)
class CandidateAdmin(admin.ModelAdmin):
    pass

@admin.register(OnboardingFlow)
class OnboardingFlowAdmin(admin.ModelAdmin):
    pass

@admin.register(EmployeeOnboardingFlow)
class EmployeeOnboardingFlowAdmin(admin.ModelAdmin):
    pass

@admin.register(CandidateOnboardingFlow)
class CandidateOnboardingFlowAdmin(admin.ModelAdmin):
    pass

@admin.register(WelcomeAbroadPage)
class WelcomeAbroadPageAdmin(admin.ModelAdmin):
    pass

@admin.register(ProfilePage)
class ProfilePageAdmin(admin.ModelAdmin):
    pass

@admin.register(FormsPage)
class FormsPageAdmin(admin.ModelAdmin):
    pass

@admin.register(ChecklistPage)
class ChecklistPageAdmin(admin.ModelAdmin):
    pass

@admin.register(Report)
class ReportAdmin(admin.ModelAdmin):
    pass
