from rest_framework import viewsets
from rest_framework.permissions import IsAuthenticated
from rest_framework.decorators import action
from rest_framework.response import Response
from .models import Goal,GoalHistory,Feedback,Skill, SkillSet, KRA, KRAGoal,AppraisalCycle
from .serializers import GoalSerializer,GoalHistorySerializer,FeedbackSerializer,SkillSerializer, SkillSetSerializer, KRASerializer, KRAGoalSerializer,AppraisalCycleSerializer

class GoalViewSet(viewsets.ModelViewSet):
    permission_classes = [IsAuthenticated]
    queryset = Goal.objects.all()
    serializer_class = GoalSerializer
    
    @action(detail=False, methods=['get'])
    def search_goals(self, request):
        """
        Custom action to search goals by title.
        """
        title = request.query_params.get('title')
        if title:
            goals = self.queryset.filter(title__icontains=title)
        else:
            goals = self.queryset.all()
        serializer = self.get_serializer(goals, many=True)
        return Response(serializer.data)

    @action(detail=True, methods=['post'])
    def mark_as_completed(self, request, pk=None):
        goal = self.get_object()
        goal.mark_as_completed()
        serializer = self.get_serializer(goal)
        return Response(serializer.data)

    @action(detail=True, methods=['get'])
    def get_progress_percentage(self, request, pk=None):
        goal = self.get_object()
        progress_percentage = goal.get_progress_percentage()
        return Response({'progress_percentage': progress_percentage})

    @action(detail=True, methods=['get'])
    def remaining_days(self, request, pk=None):
        goal = self.get_object()
        remaining_days = goal.remaining_days()
        return Response({'remaining_days': remaining_days})


class GoalHistoryViewSet(viewsets.ModelViewSet):
    permission_classes = [IsAuthenticated]
    queryset = GoalHistory.objects.all()
    serializer_class = GoalHistorySerializer

    @action(detail=False, methods=['get'])
    def search_goals_history(self, request):
        """
        Custom action to search goals by title.
        """
        title = request.query_params.get('title')
        if title:
            goals_history = self.queryset.filter(title__icontains=title)
        else:
            goals = self.queryset.all()
        serializer = self.get_serializer(goals, many=True)
        return Response(serializer.data)


class FeedbackViewSet(viewsets.ModelViewSet):
    permission_classes = [IsAuthenticated]
    queryset = Feedback.objects.all()
    serializer_class = FeedbackSerializer

    @action(detail=False, methods=['get'])
    def search_feedbacks(self, request):
        """
        Custom action to search feedbacks by recipient name.
        """
        recipient_name = request.query_params.get('feedback_receiver')
        if recipient_name:
            feedbacks = self.queryset.filter(recipient_name__icontains=recipient_name)
        else:
            feedbacks = self.queryset.all()
        serializer = self.get_serializer(feedbacks, many=True)
        return Response(serializer.data)

    @action(detail=True, methods=['get'])
    def feedback_age(self, request, pk=None):
        """
        Custom action to retrieve the age of a specific feedback in days.
        """
        feedback = self.get_object()
        age = feedback.get_feedback_age()
        return Response({'feedback_age': age})

    @action(detail=True, methods=['get'])
    def feedback_summary(self, request, pk=None):
        """
        Custom action to retrieve a summary of a specific feedback.
        """
        feedback = self.get_object()
        summary = feedback.get_feedback_summary()
        return Response({'feedback_summary': summary})

    # Add more custom actions as needed for other calculations

    def perform_create(self, serializer):
        """
        Override the default create behavior to set the feedback provider before saving.
        """
        serializer.save(feedback_provider=self.request.user)


class SkillViewSet(viewsets.ModelViewSet):
    permission_classes = [IsAuthenticated]
    queryset = Skill.objects.all()
    serializer_class = SkillSerializer

class SkillSetViewSet(viewsets.ModelViewSet):
    permission_classes = [IsAuthenticated]
    queryset = SkillSet.objects.all()
    serializer_class = SkillSetSerializer

class KRAViewSet(viewsets.ModelViewSet):
    permission_classes = [IsAuthenticated]
    queryset = KRA.objects.all()
    serializer_class = KRASerializer

class KRAGoalViewSet(viewsets.ModelViewSet):
    permission_classes = [IsAuthenticated]
    queryset = KRAGoal.objects.all()
    serializer_class = KRAGoalSerializer

class AppraisalCycleViewSet(viewsets.ModelViewSet):
    permission_classes = [IsAuthenticated]
    queryset = AppraisalCycle.objects.all()
    serializer_class = AppraisalCycleSerializer

    @action(detail=True, methods=['get'])
    def is_appraisal_period_active(self, request, pk=None):
        """
        Custom action to check if the current date is within the appraisal period.
        """
        appraisal_cycle = self.get_object()
        is_active = appraisal_cycle.is_appraisal_period_active()
        return Response({'is_appraisal_period_active': is_active})

    @action(detail=True, methods=['get'])
    def remaining_days_until_end(self, request, pk=None):
        """
        Custom action to retrieve the remaining days until the end of the appraisal period.
        """
        appraisal_cycle = self.get_object()
        remaining_days = appraisal_cycle.remaining_days_until_end()
        return Response({'remaining_days_until_end': remaining_days})