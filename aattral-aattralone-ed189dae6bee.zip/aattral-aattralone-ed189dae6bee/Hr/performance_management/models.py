from django.db import models
from django.utils import timezone
from Hr.employee_information.models import Employee
from Authentication.models import CustomUser

class Goal(models.Model):
    title = models.CharField(max_length=100)
    description = models.TextField()
    specific = models.CharField(max_length=100, blank=True)
    measurable = models.CharField(max_length=100, blank=True)
    achievable = models.CharField(max_length=100, blank=True)
    relevant = models.CharField(max_length=100, blank=True)
    time_bound = models.CharField(max_length=100, blank=True)
    kpis = models.CharField(max_length=100)
    responsibility_assignment = models.CharField(max_length=100, blank=True)
    dependencies = models.CharField(max_length=100, blank=True)
    resources_required = models.CharField(max_length=100, blank=True)
    progress_tracking = models.CharField(max_length=100, blank=True)
    feedback_and_review = models.CharField(max_length=100, blank=True)
    alignment_with_objectives = models.CharField(max_length=100, blank=True)
    risk_assessment = models.CharField(max_length=100, blank=True)
    documentation = models.TextField(blank=True)
    
    target_date = models.DateField()
    user = models.ForeignKey(Employee, on_delete=models.CASCADE)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    is_completed = models.BooleanField(default=False)
    priority = models.CharField(max_length=50, choices=[('High', 'High'), ('Medium', 'Medium'), ('Low', 'Low')])

    def mark_as_completed(self):
        """
        Method to mark the goal as completed.
        """
        self.is_completed = True
        self.save()

        # Save goal history
        progress_percentage = self.get_progress_percentage()
        remaining_days = self.remaining_days()
        GoalHistory.objects.create(
            goal=self,
            completion_date=timezone.now(),
            progress_percentage=progress_percentage,
            remaining_days=remaining_days
        )

    def get_progress_percentage(self):
        """
        Method to calculate and return the progress percentage of the goal.
        """
        # For example, let's assume progress is calculated based on tasks completed
        total_tasks = self.task_set.count()  # Assuming a related Task model
        completed_tasks = self.task_set.filter(is_completed=True).count()
        if total_tasks == 0:
            return 0
        else:
            return (completed_tasks / total_tasks) * 100

    def remaining_days(self):
        """
        Method to calculate and return the remaining days until the target date.
        """
        remaining_days = (self.target_date - timezone.now().date()).days
        return max(remaining_days, 0)

class GoalHistory(models.Model):
    goal = models.ForeignKey(Goal, on_delete=models.CASCADE)
    completion_date = models.DateTimeField(default=timezone.now)
    progress_percentage = models.FloatField()
    remaining_days = models.IntegerField()


class Feedback(models.Model):
    RATERS_CHOICES = [
        ('Peers', 'Peers'),
        ('Subordinates', 'Subordinates'),
        ('Managers', 'Managers'),
        ('External Stakeholders', 'External Stakeholders')
    ]

    FEEDBACK_CATEGORIES_CHOICES = [
        ('Communication Skills', 'Communication Skills'),
        ('Teamwork', 'Teamwork'),
        ('Leadership', 'Leadership'),
        ('Technical Competence', 'Technical Competence')
    ]

    RATING_CHOICES = [
        (1, '1 - Needs Improvement'),
        (2, '2 - Below Expectations'),
        (3, '3 - Meeting Expectations'),
        (4, '4 - Exceeding Expectations'),
        (5, '5 - Outstanding')
    ]

    feedback_provider = models.ForeignKey(CustomUser,on_delete=models.CASCADE)
    feedback_receiver = models.ForeignKey(Employee, related_name='feedback_receiver', on_delete=models.CASCADE)
    feedback_category = models.CharField(max_length=100, choices=FEEDBACK_CATEGORIES_CHOICES)
    rating = models.IntegerField(choices=RATING_CHOICES)
    comments = models.TextField()
    feedback_date = models.DateField(auto_now_add=True)

    def get_feedback_age(self):
        """
        Method to calculate and return the age of the feedback in days.
        """
        current_date = timezone.now().date()
        feedback_age = (current_date - self.feedback_date).days
        return max(feedback_age, 0)

    def is_feedback_recent(self, days_threshold=30):
        """
        Method to check if the feedback is recent based on a given threshold in days.
        """
        feedback_age = self.get_feedback_age()
        return feedback_age <= days_threshold

    def is_feedback_positive(self):
        """
        Method to check if the feedback is positive based on the rating.
        """
        return self.rating >= 3  # Assuming ratings of 3, 4, and 5 are considered positive

    def is_feedback_improvement_needed(self):
        """
        Method to check if improvement is needed based on the rating.
        """
        return self.rating < 3  # Assuming ratings of 1 and 2 indicate improvement is needed

    def get_feedback_provider_role(self):
        """
        Method to get the role of the feedback provider.
        """
        return self.feedback_provider.role  # Assuming there's a 'role' field in the CustomUser model

    def get_feedback_receiver_name(self):
        """
        Method to get the name of the feedback receiver.
        """
        return f"{self.feedback_receiver.first_name} {self.feedback_receiver.last_name}"

    def get_feedback_summary(self):
        """
        Method to get a summary of the feedback.
        """
        return f"{self.get_feedback_receiver_name()} received {self.get_feedback_category_display()} feedback with a rating of {self.rating}."

    def __str__(self):
        return f"{self.feedback_provider} to {self.feedback_receiver}: {self.feedback_category} - Rating: {self.rating}"
    

#Competency Management#
  
class Competency(models.Model):
    FRAMEWORK_CHOICES = [
        ('Technical', 'Technical'),
        ('Behavioral', 'Behavioral'),
        ('Leadership', 'Leadership'),
        ('Functional', 'Functional'),
        ('Strategic', 'Strategic')
    ]

    title = models.CharField(max_length=100)
    description = models.TextField()
    framework = models.CharField(max_length=100, choices=FRAMEWORK_CHOICES)
    is_specific = models.BooleanField(default=True, help_text="Is the competency specific and observable?")
    is_relevant_to_job_performance = models.BooleanField(default=True, help_text="Is the competency relevant to job performance?")
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        verbose_name_plural = "Competencies"

    def __str__(self):
        return self.title

class CompetencyManagement(models.Model):
    competency = models.ForeignKey(Competency, on_delete=models.CASCADE)
    employee = models.ForeignKey(CustomUser, on_delete=models.CASCADE)
    proficiency_level = models.CharField(max_length=100)
    assessment_tool = models.CharField(max_length=100, blank=True, null=True)
    assessment_result = models.CharField(max_length=100, blank=True, null=True)
    feedback = models.ForeignKey('Feedback', on_delete=models.SET_NULL, null=True, blank=True)

    class Meta:
        verbose_name_plural = "Competency Management"

    def __str__(self):
        return f"{self.employee} - {self.competency}"

# Skills and KRA #
class Skill(models.Model):
    name = models.CharField(max_length=255)
    description = models.TextField()
    proficiency_levels = [
        ('Beginner', 'Beginner'),
        ('Intermediate', 'Intermediate'),
        ('Advanced', 'Advanced'),
        ('Expert', 'Expert'),
    ]
    proficiency_level = models.CharField(max_length=50, choices=proficiency_levels)

class SkillSet(models.Model):
    employee = models.ForeignKey(Employee, on_delete=models.CASCADE)
    skill = models.ForeignKey(Skill, on_delete=models.CASCADE)
    proficiency_level = models.CharField(max_length=50)

class KRA(models.Model):
    name = models.CharField(max_length=255)
    description = models.TextField()

class KRAGoal(models.Model):
    kra = models.ForeignKey(KRA, on_delete=models.CASCADE)
    goal = models.ForeignKey(Goal, on_delete=models.CASCADE)

# Appraisal Management #

class AppraisalCycle(models.Model):
    name = models.CharField(max_length=255)
    period_start = models.DateField()
    period_end = models.DateField()
    description = models.TextField()
    guideline_document = models.FileField(upload_to='appraisal_guidelines/', null=True, blank=True)

    def is_appraisal_period_active(self):
        """
        Method to check if the current date is within the appraisal period.
        """
        current_date = timezone.now().date()
        return self.period_start <= current_date <= self.period_end

    def remaining_days_until_end(self):
        """
        Method to calculate and return the remaining days until the end of the appraisal period.
        """
        current_date = timezone.now().date()
        remaining_days = (self.period_end - current_date).days
        return max(remaining_days, 0)