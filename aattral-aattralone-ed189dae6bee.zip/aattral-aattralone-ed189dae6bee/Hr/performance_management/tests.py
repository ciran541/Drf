from django.test import TestCase
from datetime import date
from .models import Goal
from Authentication.models import CustomUser
from Hr.employee_information.models import Employee

class GoalModelTestCase(TestCase):
    @classmethod
    def setUpTestData(cls):
        # Create a sample employee
        cls.user = CustomUser.objects.create(
            id=3,
            username="logesh",
            email="log@gmail.com",
            first_name="Logesh",
            last_name="s",
            role="Hr_manager"
        )
        cls.employee = Employee.objects.create(user=cls.user)

    def setUp(self):
        # Create a sample goal
        self.goal = Goal.objects.create(
            title="Test Goal",
            description="This is a test goal",
            specific="Specific test",
            measurable="Measurable test",
            achievable="Achievable test",
            relevant="Relevant test",
            time_bound="Time bound test",
            kpis="KPI test",
            responsibility_assignment="Responsibility test",
            dependencies="Dependencies test",
            resources_required="Resources test",
            progress_tracking="Progress test",
            feedback_and_review="Feedback test",
            alignment_with_objectives="Alignment test",
            risk_assessment="Risk test",
            documentation="Documentation test",
            target_date=date(2024, 12, 31),
            user=self.employee,
            priority="High",
            is_completed=False
        )

    def test_goal_creation(self):
        self.assertEqual(self.goal.title, "Test Goal")
        self.assertEqual(self.goal.description, "This is a test goal")
        # Add assertions for all fields

    def test_goal_defaults(self):
        self.assertFalse(self.goal.is_completed)
        self.assertEqual(self.goal.priority, "High")

    def test_goal_str_representation(self):
        self.assertEqual(str(self.goal), "Test Goal")
