from rest_framework.routers import DefaultRouter
from .views import GoalViewSet,GoalHistoryViewSet,FeedbackViewSet,SkillViewSet,SkillSetViewSet, KRAViewSet, KRAGoalViewSet,AppraisalCycleViewSet

router = DefaultRouter()
router.register(r'goals', GoalViewSet, basename='goal')
router.register(r'goal-history', GoalHistoryViewSet, basename='goal-history')
router.register(r'feedback', FeedbackViewSet, basename='feedback')
router.register(r'skills', SkillViewSet)
router.register(r'skillsets', SkillSetViewSet)
router.register(r'kras', KRAViewSet)
router.register(r'kragoals', KRAGoalViewSet)
router.register(r'appraisal-cycles', AppraisalCycleViewSet)

urlpatterns = router.urls

""" For Goal """
# POST /api/goals/{id}/mark_as_completed/: Mark a goal as completed.
# GET /api/goals/{id}/get_progress_percentage/: Get the progress percentage of a goal.
# GET /api/goals/{id}/remaining_days/: Get the remaining days until the target date of a goal.

""" For Feedback """
# GET /api/feedback/: Retrieve a list of feedback
# POST /api/feedback/: Create a new feedback
# GET /api/feedback/{id}/: Retrieve details of a specific feedback
# PUT /api/feedback/{id}/: Update a specific feedback
# PATCH /api/feedback/{id}/: Partially update a specific feedback
# DELETE /api/feedback/{id}/: Delete a specific feedback
# GET /api/feedback/{id}/feedback_age/: Retrieve the age of a specific feedback
# GET /api/feedback/{id}/feedback_summary/: Retrieve a summary of a specific feedback

""" For Appraisal """
# GET /api/appraisal-cycles/: Retrieve a list of appraisal cycles
# POST /api/appraisal-cycles/: Create a new appraisal cycle
# GET /api/appraisal-cycles/{id}/: Retrieve details of a specific appraisal cycle
# PUT /api/appraisal-cycles/{id}/: Update a specific appraisal cycle
# PATCH /api/appraisal-cycles/{id}/: Partially update a specific appraisal cycle
# DELETE /api/appraisal-cycles/{id}/: Delete a specific appraisal cycle
# GET /api/appraisal-cycles/{id}/is_appraisal_period_active/: Check if the current date is within the appraisal period
# GET /api/appraisal-cycles/{id}/remaining_days_until_end/: Retrieve the remaining days until the end of the appraisal period