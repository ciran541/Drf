# admin.py

from django.contrib import admin
from .models import Goal, GoalHistory, Feedback, Competency, CompetencyManagement, Skill, SkillSet, KRA, KRAGoal, AppraisalCycle

@admin.register(Goal)
class GoalAdmin(admin.ModelAdmin):
    list_display = ('title', 'user', 'target_date', 'is_completed', 'priority')
    list_filter = ('is_completed', 'priority', 'user')
    search_fields = ('title', 'description')

    def mark_goals_as_completed(self, request, queryset):
        """
        Custom admin action to mark selected goals as completed.
        """
        updated_count = queryset.update(is_completed=True)
        self.message_user(request, f'{updated_count} goals marked as completed.')

    mark_goals_as_completed.short_description = "Mark selected goals as completed"

    actions = [mark_goals_as_completed]

@admin.register(GoalHistory)
class GoalHistoryAdmin(admin.ModelAdmin):
    list_display = ('goal', 'completion_date', 'progress_percentage', 'remaining_days')
    list_filter = ('completion_date',)
    search_fields = ('goal__title',)

@admin.register(Feedback)
class FeedbackAdmin(admin.ModelAdmin):
    list_display = ('feedback_provider', 'feedback_receiver', 'feedback_category', 'rating', 'feedback_date')
    list_filter = ('feedback_category', 'rating', 'feedback_date')
    search_fields = ('feedback_provider__username', 'feedback_receiver__name')

@admin.register(Competency)
class CompetencyAdmin(admin.ModelAdmin):
    list_display = ('title', 'framework', 'is_specific', 'is_relevant_to_job_performance')
    list_filter = ('framework',)
    search_fields = ('title',)

@admin.register(CompetencyManagement)
class CompetencyManagementAdmin(admin.ModelAdmin):
    list_display = ('employee', 'competency', 'proficiency_level', 'assessment_tool', 'assessment_result')
    list_filter = ('competency', 'proficiency_level')
    search_fields = ('employee__username', 'competency__title')

@admin.register(Skill)
class SkillAdmin(admin.ModelAdmin):
    list_display = ('name', 'proficiency_level')
    list_filter = ('proficiency_level',)
    search_fields = ('name',)

@admin.register(SkillSet)
class SkillSetAdmin(admin.ModelAdmin):
    list_display = ('employee', 'skill', 'proficiency_level')
    list_filter = ('skill', 'proficiency_level')
    search_fields = ('employee__username', 'skill__name')

@admin.register(KRA)
class KRAAdmin(admin.ModelAdmin):
    list_display = ('name',)
    search_fields = ('name',)

@admin.register(KRAGoal)
class KRAGoalAdmin(admin.ModelAdmin):
    list_display = ('kra', 'goal')
    list_filter = ('kra', 'goal')
    search_fields = ('kra__name', 'goal__title')

@admin.register(AppraisalCycle)
class AppraisalCycleAdmin(admin.ModelAdmin):
    list_display = ('name', 'period_start', 'period_end', 'is_appraisal_period_active', 'remaining_days_until_end')
    list_filter = ('period_start', 'period_end')
    search_fields = ('name', 'description')
    readonly_fields = ('is_appraisal_period_active', 'remaining_days_until_end')
