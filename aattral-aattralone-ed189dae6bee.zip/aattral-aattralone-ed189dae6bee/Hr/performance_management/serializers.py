from rest_framework import serializers
from .models import Goal,GoalHistory,Feedback,Skill, SkillSet, KRA, KRAGoal,AppraisalCycle

class GoalSerializer(serializers.ModelSerializer):
    class Meta:
        model = Goal
        fields = '__all__'

class GoalHistorySerializer(serializers.ModelSerializer):
    class Meta:
        model = GoalHistory
        fields = '__all__'

class FeedbackSerializer(serializers.ModelSerializer):
    class Meta:
        model = Feedback
        fields = '__all__'


class SkillSerializer(serializers.ModelSerializer):
    class Meta:
        model = Skill
        fields = '__all__'

class SkillSetSerializer(serializers.ModelSerializer):
    class Meta:
        model = SkillSet
        fields = '__all__'

class KRASerializer(serializers.ModelSerializer):
    class Meta:
        model = KRA
        fields = '__all__'

class KRAGoalSerializer(serializers.ModelSerializer):
    class Meta:
        model = KRAGoal
        fields = '__all__'

class AppraisalCycleSerializer(serializers.ModelSerializer):
    class Meta:
        model = AppraisalCycle
        fields = '__all__'