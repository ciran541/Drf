from rest_framework import viewsets
from rest_framework.permissions import IsAuthenticated
from rest_framework.decorators import action
from django.db.models import Q
from rest_framework.response import Response
from datetime import datetime
from django.utils import timezone
from Authentication.models import CustomUser 
from django.utils.timezone import make_aware
from datetime import datetime
from rest_framework import status
from django.core.exceptions import ObjectDoesNotExist
from .models import AttendanceEntry,Shift,AssignShift,ShiftRotation,ShiftSwapRequest,Break,AttendanceRegularization
from .serializers import (AttendanceEntrySerializer,ShiftSerializer,BreakSerializer,AssignShiftSerializer,ShiftRotationSerializer,
                          ShiftSwapRequestSerializer,AttendanceRegularizationSerializer)
from Hr.employee_information.models import Employee
from collections import defaultdict



class AttendanceEntryViewSet(viewsets.ModelViewSet):
    permission_classes = [IsAuthenticated]
    queryset = AttendanceEntry.objects.all()
    serializer_class = AttendanceEntrySerializer
    
# For CheckIn Endoint
    @action(detail=False, methods=['post'])
    def checkin(self, request):
        user_id = request.data.get('user', None)
        user = CustomUser.objects.get(pk=user_id) if user_id else request.user
        entry_date = request.data.get('entry_date', timezone.now().date())
        checkin_time = timezone.now()
        location = request.data.get('location')

        # Check if the user is already checked in
        if AttendanceEntry.objects.filter(user=user, entry_date=entry_date, checkout_time__isnull=True).exists():
            return Response({"error": "User is already checked in. Cannot check in again."}, status=400)

        entry = AttendanceEntry.objects.create(user=user, entry_date=entry_date, checkin_time=checkin_time, location=location)
        serializer = AttendanceEntrySerializer(entry)
        return Response(serializer.data)

# For CheckOut Endoint
    @action(detail=False, methods=['post'])
    def checkout(self, request):
        user_id = request.data.get('user', None)
        user = CustomUser.objects.get(pk=user_id) if user_id else request.user
        entry_date = request.data.get('entry_date', timezone.now().date())
        checkout_time = timezone.now()
        location = request.data.get('location')

        try:
            # Try to get the latest entry for the specified user and entry_date
            entry = AttendanceEntry.objects.filter(user=user, entry_date=entry_date, checkout_time__isnull=True).latest('checkin_time')
            entry.checkout_time = checkout_time
            entry.location = location
            entry.save()

            serializer = AttendanceEntrySerializer(entry)
            return Response(serializer.data)

        except ObjectDoesNotExist:
            # If no entry is found, the user has not checked in yet
            return Response({"error": "User has not checked in. Cannot check out without checking in first."}, status=400)

    @action(detail=False, methods=['get'])
    def entry_details(self, request):
        user = request.user
        entry_date = request.query_params.get('entry_date')

        entries = AttendanceEntry.objects.filter(user=user, entry_date=entry_date)
        serializer = AttendanceEntrySerializer(entries, many=True)
        return Response(serializer.data)
# While getting the details by Userid and date 
        
    @action(detail=False, methods=['get'])
    def entry_details_by_date(self, request):
        user_id = request.query_params.get('user_id')  # Get user_id from query params
        entry_date_str = request.query_params.get('entry_date')

        if not user_id or not entry_date_str:
            return Response({"error": "user_id and entry_date parameters are required."}, status=400)

        try:
            user = CustomUser.objects.get(id=user_id)
        except CustomUser.DoesNotExist:
            return Response({"error": "User not found."}, status=404)

        try:
            entry_date = datetime.strptime(entry_date_str, '%Y-%m-%d').date()
        except ValueError:
            return Response({"error": "Invalid date format. Please use YYYY-MM-DD."}, status=400)

        entries = AttendanceEntry.objects.filter(user=user, entry_date=entry_date)
        if not entries.exists():
            return Response([], status=200)

        serializer = AttendanceEntrySerializer(entries, many=True)
        return Response(serializer.data)
    
    
# Total workerd hours for user each day    
    @action(detail=False, methods=['get'])
    def worked_hours_report(self, request):
        user_id = request.query_params.get('user', None)
        date = request.query_params.get('date', None)

        if not date:
            return Response({"error": "Date parameter is required."}, status=400)

        try:
            user = CustomUser.objects.get(pk=user_id) if user_id else request.user
            entries = AttendanceEntry.objects.filter(user=user, entry_date=date)

            total_worked_hours = round(sum(entry.calculate_work_hours() for entry in entries))

            report = {
                'user': user.username,
                'entry_date': date,
                'total_worked_hours': total_worked_hours,
            }

            return Response(report)

        except ObjectDoesNotExist:
            return Response({"error": "User not found."}, status=400)
# Overall report for user/Dashboard
    @action(detail=False, methods=['get'])
    def generate_report(self, request):
        user = request.user
        start_date = request.query_params.get('start_date')
        end_date = request.query_params.get('end_date')

        entries = AttendanceEntry.objects.filter(user=user, entry_date__range=[start_date, end_date])
        report = []

        for entry in entries:
            report.append({
                'user': entry.user.username,  
                'entry_date': entry.entry_date,
                'checkin_time': entry.checkin_time,
                'checkout_time': entry.checkout_time,
                'work_hours': entry.calculate_work_hours(),
                'overtime': entry.calculate_overtime(),
            })

        return Response(report)

class ShiftViewSet(viewsets.ModelViewSet):
    permission_classes = [IsAuthenticated]
    queryset = Shift.objects.all()
    serializer_class = ShiftSerializer

    
class AssignShiftViewSet(viewsets.ModelViewSet):
    permission_classes = [IsAuthenticated]
    queryset = AssignShift.objects.all()
    serializer_class = AssignShiftSerializer

    @action(detail=False, methods=['get'])
    def filter_by_date(self, request):
        date_query = request.query_params.get('date')

        if date_query:
            try:
                date = make_aware(datetime.strptime(date_query, '%Y-%m-%d'))
            except ValueError:
                return Response({"error": "Invalid date format. Please provide date in 'YYYY-MM-DD' format."}, status=status.HTTP_400_BAD_REQUEST)

            queryset = self.get_queryset().filter(date_from__lte=date, date_to__gte=date)
            serializer = self.get_serializer(queryset, many=True)
            
            # Now, fetch AttendanceEntry data for each AssignShift
            data = serializer.data
            for shift_data in data:
                # Retrieve the applicable employees
                applicable_employees = shift_data.pop('applicable_for')  # Remove applicable employees from main data
                for employee in applicable_employees:
                    attendance_entries = AttendanceEntry.objects.filter(entry_date=date, user_id=employee['id'])
                    attendance_serializer = AttendanceEntrySerializer(attendance_entries, many=True)
                    employee['attendance_entries'] = attendance_serializer.data
                    
                    # Calculate total worked hours for each user
                    total_worked_hours = sum((entry.checkout_time - entry.checkin_time).total_seconds() / 3600
                                             for entry in attendance_entries)
                    employee['total_worked_hours'] = round(total_worked_hours, 2)
                
                shift_data['applicable_for'] = applicable_employees
            
            return Response(data)
        else:
            return Response({"error": "A date parameter is required."}, status=status.HTTP_400_BAD_REQUEST)
        
class ShiftRotationViewSet(viewsets.ModelViewSet):
    permission_classes = [IsAuthenticated]
    queryset = ShiftRotation.objects.all()
    serializer_class = ShiftRotationSerializer

class ShiftSwapRequestViewSet(viewsets.ModelViewSet):
    permission_classes = [IsAuthenticated]
    queryset = ShiftSwapRequest.objects.all()
    serializer_class = ShiftSwapRequestSerializer

class BreakViewSet(viewsets.ModelViewSet):
    permission_classes = [IsAuthenticated]
    queryset = Break.objects.all()
    serializer_class = BreakSerializer

class AttendanceRegularizationViewSet(viewsets.ModelViewSet):
    permission_classes = [IsAuthenticated]
    queryset = AttendanceRegularization.objects.all()
    serializer_class = AttendanceRegularizationSerializer

    def perform_create(self, serializer):
        serializer.save(user=self.request.user)

    @action(detail=True, methods=['post'])
    def approve(self, request, pk=None):
        regularization = self.get_object()
        regularization.is_approved = True
        regularization.save()
        serializer = AttendanceRegularizationSerializer(regularization)
        return Response(serializer.data)

    @action(detail=True, methods=['post'])
    def reject(self, request, pk=None):
        regularization = self.get_object()
        regularization.is_approved = False
        regularization.save()
        serializer = AttendanceRegularizationSerializer(regularization)
        return Response(serializer.data)