from django.test import TestCase
from django.contrib.auth import get_user_model
from rest_framework.test import APIClient
from datetime import date, datetime, timedelta
from django.urls import reverse
from django.utils import timezone
from .models import AttendanceEntry,Shift, AssignShift,ShiftRotation, ShiftSwapRequest, Break,AttendanceRegularization
from Authentication.models import CustomUser 
from datetime import time

class AttendanceEntryTestCase(TestCase):
    def setUp(self):
        self.user = get_user_model().objects.create_user(username='testuser', password='testpassword')
        self.entry_date = date.today()
        self.checkin_time = datetime.now()
        self.checkout_time = self.checkin_time + timedelta(hours=8)
        self.location = 'Test Location'

    def test_attendance_entry_creation(self):
        entry = AttendanceEntry.objects.create(
            user=self.user,
            entry_date=self.entry_date,
            checkin_time=self.checkin_time,
            checkout_time=self.checkout_time,
            location=self.location
        )

        self.assertEqual(str(entry), f"{self.user.username} - {self.entry_date} - Check-In: {self.checkin_time} - Check-Out: {self.checkout_time}")
        self.assertEqual(entry.calculate_work_hours(), 8)
        self.assertEqual(entry.calculate_overtime(), 0)

    def test_attendance_entry_validation(self):
        # Ensure validation is working for check-out time
        with self.assertRaises(Exception):
            AttendanceEntry.objects.create(
                user=self.user,
                entry_date=self.entry_date,
                checkin_time=self.checkout_time,
                checkout_time=self.checkin_time,
                location=self.location
            )

class AttendanceEntryViewSetTestCase(TestCase):
    def setUp(self):
        self.user = get_user_model().objects.create_user(username='testuser', password='testpassword')
        self.client = APIClient()
        self.client.force_authenticate(user=self.user)

    def test_checkout(self):
        entry = AttendanceEntry.objects.create(
            user=self.user,
            entry_date=date.today(),
            checkin_time=timezone.now(),
            location='Test Location'
        )

        url = reverse('attendance-entry-checkout')
        data = {
            'entry_date': str(date.today()),
            'checkout_time': str(timezone.now() + timedelta(hours=8)),
            'location': 'Updated Location'
        }

        response = self.client.post(url, data)
        self.assertEqual(response.status_code, 200)
        self.assertEqual(response.data['location'], 'Updated Location')

    def test_entry_details(self):
        entry = AttendanceEntry.objects.create(
            user=self.user,
            entry_date=date.today(),
            checkin_time=datetime.now(),
            location='Test Location'
        )

        url = reverse('attendance-entry-entry-details') + f'?entry_date={date.today()}'
        response = self.client.get(url)

        self.assertEqual(response.status_code, 200)
        self.assertEqual(len(response.data), 1)
        self.assertIn('checkin_time', response.data[0])
        self.assertEqual(response.data[0]['user'], self.user.id)

    '''def test_generate_report(self):
        entry = AttendanceEntry.objects.create(
            user=self.user,
            entry_date=date.today(),
            checkin_time=timezone.now(),
            checkout_time=timezone.now() + timedelta(hours=8),
            location='Test Location'
        )

        url = reverse('attendance-entry-generate-report') + f'?start_date={date.today()}&end_date={date.today()}'
        response = self.client.get(url)

        self.assertEqual(response.status_code, 200)
        self.assertEqual(len(response.data), 1)
        self.assertIn('checkin_time', response.data[0])
        self.assertEqual(response.data[0]['user'], str(self.user.id))"'''
    
class ShiftModelTestCase(TestCase):
    def setUp(self):
        # Create a sample Shift instance for testing
        self.shift = Shift.objects.create(
            name='Day Shift',
            start_time=timezone.now().time(),
            end_time=(timezone.now() + timezone.timedelta(hours=8)).time(),
            shift_margin='enable',
            weekend='location_based',
            shift_allowance='enable',
            applicable_for='full_time'
        )

    def test_shift_str_method(self):
        
        # Test the __str__ method of the Shift model
        self.assertEqual(str(self.shift), 'Day Shift')

    def test_shift_defaults(self):
    # Test that the default values are set correctly
        default_shift = Shift.objects.create(
        name='Default Shift',
        start_time=time(8, 0, 0),  # Provide a valid start time (e.g., 8:00:00)
        end_time=(timezone.now() + timezone.timedelta(hours=8)).time(),  # Provide a valid end time
    )
        self.assertEqual(default_shift.shift_margin, 'enable')
        self.assertEqual(default_shift.weekend, 'location_based')
        self.assertEqual(default_shift.shift_allowance, 'enable')
        self.assertEqual(default_shift.applicable_for, '')

    def test_shift_creation(self):
        # Test that a Shift instance is created successfully
        shift_count = Shift.objects.count()
        self.assertEqual(shift_count, 1)

class AssignShiftModelTestCase(TestCase):
    def setUp(self):
        # Create a sample Shift instance for testing
        self.shift = Shift.objects.create(
            name='Day Shift',
            start_time=time(8, 0, 0),
            end_time=time(16, 0, 0),
            shift_margin='enable',
            weekend='location_based',
            shift_allowance='enable',
            applicable_for='full_time'
        )

        # Create a sample AssignShift instance for testing
        AssignShift.objects.create(
            shift=self.shift,
            applicable_for='full_time',
            date_from=date(2024, 2, 1),
            date_to=date(2024, 2, 15),
            reason='Vacation'
        )

    def test_assign_shift_creation(self):
        # Test that an AssignShift instance is created successfully
        assign_shift_count = AssignShift.objects.count()
        self.assertEqual(assign_shift_count, 1)

class ShiftRotationModelTestCase(TestCase):
    def setUp(self):
        # Create a sample Shift instance for testing
        self.shift = Shift.objects.create(
            name='Day Shift',
            start_time=datetime.now().time(),
            end_time=(datetime.now() + timedelta(hours=8)).time(),
            shift_margin='enable',
            weekend='location_based',
            shift_allowance='enable',
            applicable_for='full_time'
        )

    def test_shift_rotation_str_method(self):
        # Test the __str__ method of the ShiftRotation model
        shift_rotation = ShiftRotation.objects.create(
            schedule_name='Weekly Rotation',
            schedule_frequency='weekly',
            time_of_schedule=datetime.now().time(),
            applicable_period_from=datetime.now().date(),
            applicable_period_to=(datetime.now() + timedelta(days=7)).date(),
            applicable_for='full_time'
        )
        shift_rotation.shift_rotation.add(self.shift)
        self.assertEqual(str(shift_rotation), 'Weekly Rotation')

    def test_shift_rotation_creation(self):
        # Test that a ShiftRotation instance is created successfully
        shift_rotation = ShiftRotation.objects.create(
            schedule_name='Monthly Rotation',
            schedule_frequency='monthly',
            time_of_schedule=datetime.now().time(),
            applicable_period_from=datetime.now().date(),
            applicable_period_to=(datetime.now() + timedelta(days=30)).date(),
            applicable_for='part_time'
        )
        shift_rotation.shift_rotation.add(self.shift)
        self.assertEqual(ShiftRotation.objects.count(), 1)

    def test_shift_rotation_with_shifts(self):
        # Test adding shifts to the ShiftRotation
        shift_rotation = ShiftRotation.objects.create(
            schedule_name='Weekly Rotation',
            schedule_frequency='weekly',
            time_of_schedule=datetime.now().time(),
            applicable_period_from=datetime.now().date(),
            applicable_period_to=(datetime.now() + timedelta(days=7)).date(),
            applicable_for='full_time'
        )
        shift_rotation.shift_rotation.add(self.shift)
        self.assertEqual(shift_rotation.shift_rotation.count(), 1)
        self.assertEqual(shift_rotation.shift_rotation.first(), self.shift)

class ShiftSwapRequestModelTestCase(TestCase):
    def setUp(self):
        # Create sample Shifts and CustomUser for testing
        self.shift_1 = Shift.objects.create(
            name='Shift 1',
            start_time=timezone.now().time(),
            end_time=(timezone.now() + timezone.timedelta(hours=8)).time(),
            shift_margin='enable',
            weekend='location_based',
            shift_allowance='enable',
            applicable_for='full_time'
        )
        self.shift_2 = Shift.objects.create(
            name='Shift 2',
            start_time=(timezone.now() + timezone.timedelta(hours=8)).time(),
            end_time=(timezone.now() + timezone.timedelta(hours=16)).time(),
            shift_margin='enable',
            weekend='location_based',
            shift_allowance='enable',
            applicable_for='full_time'
        )

        self.user_1 = CustomUser.objects.create(username='user1', email='user1@example.com', password='password123')

    def test_shift_swap_request_creation(self):
        # Test that a ShiftSwapRequest instance is created successfully
        swap_request = ShiftSwapRequest.objects.create(
            requested_employee=self.user_1,
            original_schedule=self.shift_1,
            new_schedule=self.shift_2,
            status=ShiftSwapRequest.PENDING,
            request_time=timezone.now(),
            approval_time=None,
            reason='Vacation'
        )
        self.assertEqual(swap_request.requested_employee, self.user_1)
        self.assertEqual(swap_request.original_schedule, self.shift_1)
        self.assertEqual(swap_request.new_schedule, self.shift_2)
        self.assertEqual(swap_request.status, ShiftSwapRequest.PENDING)
        self.assertIsNotNone(swap_request.request_time)
        self.assertIsNone(swap_request.approval_time)
        self.assertEqual(swap_request.reason, 'Vacation')

    def test_shift_swap_request_default_status(self):
        # Test that the default status is set correctly
        swap_request = ShiftSwapRequest.objects.create(
            requested_employee=self.user_1,
            original_schedule=self.shift_1,
            new_schedule=self.shift_2,
        )
        self.assertEqual(swap_request.status, ShiftSwapRequest.PENDING)

    def test_shift_swap_request_approval(self):
        # Test approving a ShiftSwapRequest
        swap_request = ShiftSwapRequest.objects.create(
            requested_employee=self.user_1,
            original_schedule=self.shift_1,
            new_schedule=self.shift_2,
            status=ShiftSwapRequest.PENDING,
            request_time=timezone.now(),
            approval_time=None,
            reason='Vacation'
        )

        

    def test_shift_swap_request_rejection(self):
        # Test rejecting a ShiftSwapRequest
        swap_request = ShiftSwapRequest.objects.create(
            requested_employee=self.user_1,
            original_schedule=self.shift_1,
            new_schedule=self.shift_2,
            status=ShiftSwapRequest.PENDING,
            request_time=timezone.now(),
            approval_time=None,
            reason='Vacation'
        )

class BreakModelTestCase(TestCase):
    def setUp(self):
        # Create a sample Shift instance for testing
        self.shift = Shift.objects.create(
            name='Day Shift',
            start_time=time(8, 0, 0),
            end_time=time(16, 0, 0),
        )

    def test_break_creation(self):
        # Test that a Break instance is created successfully
        break_instance = Break.objects.create(
            name='Lunch Break',
            icon_change=False,
            pay_type='paid',
            mode='automatic',
            start_time=time(12, 0, 0),
            end_time=time(13, 0, 0),
            auto_mark_based_on_checkin_checkout=False,
            allowed_duration=timedelta(minutes=30),
        )
        break_instance.applicable_shifts.add(self.shift)

        self.assertEqual(Break.objects.count(), 1)
        self.assertEqual(break_instance.name, 'Lunch Break')
        self.assertEqual(break_instance.pay_type, 'paid')
        self.assertEqual(break_instance.mode, 'automatic')
        self.assertEqual(break_instance.start_time, time(12, 0, 0))
        self.assertEqual(break_instance.end_time, time(13, 0, 0))
        self.assertFalse(break_instance.auto_mark_based_on_checkin_checkout)
        self.assertEqual(break_instance.allowed_duration, timedelta(minutes=30))
        self.assertEqual(break_instance.applicable_shifts.count(), 1)
        self.assertEqual(break_instance.applicable_shifts.first(), self.shift)

    def test_break_str_method(self):
        # Test the __str__ method of the Break model
        break_instance = Break.objects.create(
            name='Coffee Break',
            icon_change=True,
            pay_type='unpaid',
            mode='manual',
            start_time=time(10, 0, 0),
            end_time=time(10, 15, 0),
            auto_mark_based_on_checkin_checkout=True,
        )
        break_instance.applicable_shifts.add(self.shift)

        self.assertEqual(str(break_instance), 'Coffee Break')

class AttendanceRegularizationModelTestCase(TestCase):
    def setUp(self):
        # Create a sample CustomUser instance for testing
        self.user = CustomUser.objects.create(
            username='testuser',
            email='testuser@example.com',
            # Add other required fields for CustomUser as needed
        )

    def test_attendance_regularization_creation(self):
        user = CustomUser.objects.create(username='test_user')
        regularization = AttendanceRegularization.objects.create(
        user=user,
        discrepancy_date=datetime(2024, 2, 29).date(),
        explanation='Test explanation',
        supporting_documentation=None,
        is_approved=False,
        request_type='late_arrival'
    )
        self.assertEqual(
            regularization.supporting_documentation, None,
            "Supporting documentation should be None"
        )
        self.assertEqual(
            str(regularization),
            f"test_user - 2024-02-29 - Type: Late Arrival - Approved: False"
        )

    def test_str_method(self):
        # Test the __str__ method of the AttendanceRegularization model
        regularization = AttendanceRegularization.objects.create(
            user=self.user,
            discrepancy_date=timezone.now().date(),
            explanation='Test explanation',
            supporting_documentation=None,
            is_approved=False,
            request_type='late_arrival',
        )
        expected_str = f"{self.user.username} - {timezone.now().date()} - Type: Late Arrival - Approved: False"
        self.assertEqual(str(regularization), expected_str)