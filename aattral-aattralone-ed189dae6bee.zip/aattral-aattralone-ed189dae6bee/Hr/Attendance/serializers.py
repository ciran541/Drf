# serializers.py
from rest_framework import serializers
from .models import AttendanceEntry,Shift,AssignShift,ShiftRotation,ShiftSwapRequest,Break,AttendanceRegularization
from Hr.employee_information.serializers import EmployeeSerializer
class AttendanceEntrySerializer(serializers.ModelSerializer):
    class Meta:
        model = AttendanceEntry
        fields = '__all__'


class ShiftSerializer(serializers.ModelSerializer):

    applicable_for = EmployeeSerializer(many=True, read_only=True)
    class Meta:
        model = Shift
        fields = '__all__'

class ShiftforAssignShiftSerializer(serializers.ModelSerializer):

    class Meta:
        model = Shift
        exclude = ('applicable_for', 'shift_margin', 'weekend', 'shift_allowance')

class AssignShiftSerializer(serializers.ModelSerializer):

    shift=ShiftforAssignShiftSerializer(read_only=True)
    applicable_for = EmployeeSerializer(many=True, read_only=True)
    class Meta:
        model = AssignShift
        fields = '__all__'

class ShiftRotationSerializer(serializers.ModelSerializer):
    class Meta:
        model = ShiftRotation
        fields = '__all__'

class ShiftSwapRequestSerializer(serializers.ModelSerializer):
    class Meta:
        model = ShiftSwapRequest
        fields = '__all__'

class BreakSerializer(serializers.ModelSerializer):
    class Meta:
        model = Break
        fields = '__all__'

class AttendanceRegularizationSerializer(serializers.ModelSerializer):
    class Meta:
        model = AttendanceRegularization
        fields = '__all__'