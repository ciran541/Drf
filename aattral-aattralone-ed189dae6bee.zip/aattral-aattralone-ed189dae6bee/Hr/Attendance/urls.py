from django.urls import path, include
from rest_framework.routers import DefaultRouter
from .views import AttendanceEntryViewSet,ShiftViewSet,AssignShiftViewSet,ShiftRotationViewSet,ShiftSwapRequestViewSet,BreakViewSet,AttendanceRegularizationViewSet

router = DefaultRouter()
router.register(r'attendance', AttendanceEntryViewSet, basename='attendance-entry')
router.register(r'shifts', ShiftViewSet)
router.register(r'assign-shifts', AssignShiftViewSet)
router.register(r'shift-rotations', ShiftRotationViewSet)
router.register(r'shift-swap-requests', ShiftSwapRequestViewSet)
router.register(r'breaks', BreakViewSet)
router.register(r'attendance-regularization', AttendanceRegularizationViewSet, basename='attendance-regularization')
urlpatterns = [
    path('', include(router.urls)),
]

# For Attendance Endpoint # 
'''
POST /api/attendance/checkin/: For checking in.
POST /api/attendance/checkout/: For checking out.
GET /api/attendance/entry-details/: To get entry details for a specific date.
GET /api/attendance/generate-report/: To generate a report for a specified date range.
'''

#GET /api/hr/Attendance/attendance/worked_hours_report/?user=28&date=2024-03-01
