from django.db import models
from Authentication.models import CustomUser 
from django.core.exceptions import ValidationError
from django.utils.translation import gettext_lazy as _
from django.utils import timezone
from Hr.employee_information.models import Employee
APPLICABLE_CHOICES = [
        ('individual', 'Individual'),
        ('department', 'Department'),
        ('location', 'Location'),
    ]
SHIFT_MARGIN_CHOICES = [
        ('enable', 'Enable'),
        ('disable', 'Disable'),
    ]

WEEKEND_CHOICES = [
        ('location_based', 'Location Based'),
        ('shift_based', 'Shift Based'),
    ]

ALLOWANCE_CHOICES = [
        ('enable', 'Enable'),
        ('disable', 'Disable'),
    ]

class Shift(models.Model):
    name = models.CharField(max_length=255)
    start_time = models.TimeField()
    end_time = models.TimeField()
    shift_margin = models.CharField(max_length=10, choices=SHIFT_MARGIN_CHOICES, default='enable')
    weekend = models.CharField(max_length=15, choices=WEEKEND_CHOICES, default='location_based')
    shift_allowance = models.CharField(max_length=10, choices=ALLOWANCE_CHOICES, default='enable')
    applicable_for = models.ManyToManyField(Employee, related_name='Sfit_employee')

    def __str__(self):
        return self.name
    
class AssignShift(models.Model):
    shift = models.ForeignKey(Shift, on_delete=models.CASCADE)
    applicable_for = models.ManyToManyField(Employee, related_name='assignshft_employee')

    date_from = models.DateField()
    date_to = models.DateField()
    reason = models.TextField()

    def __str__(self):
        return f"{self.shift.name} - {self.applicable_for} - {self.date_from} to {self.date_to}"

class ShiftRotation(models.Model):
    FREQUENCY_CHOICES = [
        ('weekly', 'Weekly'),
        ('monthly', 'Monthly'),
        # Add other frequency choices as needed
    ]

    schedule_name = models.CharField(max_length=255)
    schedule_frequency = models.CharField(max_length=10, choices=FREQUENCY_CHOICES, default='weekly')
    time_of_schedule = models.TimeField()

    applicable_period_from = models.DateField()
    applicable_period_to = models.DateField()

    applicable_for = models.CharField(max_length=255)
    shift_rotation = models.ManyToManyField(Shift, related_name='shift_rotations')

    def __str__(self):
        return self.schedule_name
    
class ShiftSwapRequest(models.Model):
    PENDING = 'pending'
    APPROVED = 'approved'
    REJECTED = 'rejected'

    requested_employee = models.ForeignKey(CustomUser, related_name='attendance_received_swaps', on_delete=models.CASCADE)
    original_schedule = models.ForeignKey(Shift, related_name='attendance_original_schedule', on_delete=models.CASCADE)
    new_schedule = models.ForeignKey(Shift, related_name='attendance_new_schedule', on_delete=models.CASCADE)
    status = models.CharField(max_length=20, choices=[(PENDING, 'Pending'), (APPROVED, 'Approved'), (REJECTED, 'Rejected')], default=PENDING)
    request_time = models.DateTimeField(auto_now_add=True)
    approval_time = models.DateTimeField(null=True, blank=True)
    reason = models.TextField(blank=True, null=True)

class Break(models.Model):
    PAY_TYPE_CHOICES = [
        ('paid', 'Paid'),
        ('unpaid', 'Unpaid'),
    ]

    MODE_CHOICES = [
        ('automatic', 'Automatic'),
        ('manual', 'Manual'),
    ]

    name = models.CharField(max_length=255)
    icon_change = models.BooleanField(default=False)
    pay_type = models.CharField(max_length=10, choices=PAY_TYPE_CHOICES)
    mode = models.CharField(max_length=10, choices=MODE_CHOICES)
    start_time = models.TimeField()
    end_time = models.TimeField()
    auto_mark_based_on_checkin_checkout = models.BooleanField(default=False)
    allowed_duration = models.DurationField(null=True, blank=True)
    applicable_shifts = models.ManyToManyField(Shift, related_name='breaks')

    def __str__(self):
        return self.name
    

class AttendanceEntry(models.Model):
    user = models.ForeignKey(CustomUser, on_delete=models.CASCADE)
    entry_date = models.DateField()
    checkin_time = models.DateTimeField(null=True, blank=True)
    checkout_time = models.DateTimeField(null=True, blank=True)
    location = models.CharField(max_length=255, null=True, blank=True)

    def __str__(self):
        return f"{self.user.username} - {self.entry_date} - Check-In: {self.checkin_time} - Check-Out: {self.checkout_time}"

    def clean(self):
        if self.checkin_time and self.checkout_time and self.checkin_time >= self.checkout_time:
            raise ValidationError(_("Check-out time must be later than check-in time."))

    def save(self, *args, **kwargs):
        self.full_clean()
        super().save(*args, **kwargs)

    def calculate_work_hours(self):
        current_time = timezone.now()
        
        if self.checkin_time:
            if self.checkout_time:
                work_seconds = (self.checkout_time - self.checkin_time).total_seconds()
            else:
                work_seconds = (current_time - self.checkin_time).total_seconds()
            
            return max(0, work_seconds)
        
        return 0

    def calculate_overtime(self, standard_hours=8):
        work_hours = self.calculate_work_hours() / 3600.0
        return max(0, work_hours - standard_hours)
    
    @classmethod
    def generate_report(cls, user, start_date, end_date):
        try:
            entries = cls.objects.filter(user=user, entry_date__range=[start_date, end_date])
            report = []

            for entry in entries:
                report.append({
                    'user': entry.user.username,  
                    'entry_date': entry.entry_date,
                    'checkin_time': entry.checkin_time,
                    'checkout_time': entry.checkout_time,
                    'work_hours': entry.calculate_work_hours(),
                    'overtime': entry.calculate_overtime(),
                })

            return report

        except Exception as e:
            # Handle specific exceptions, log, or re-raise as needed
            raise ValidationError(_("Error generating report: {}".format(e)))
        
        
class TimeOffRequest(models.Model):
    PENDING = 'pending'
    APPROVED = 'approved'
    REJECTED = 'rejected'

    employee = models.ForeignKey(CustomUser,related_name='attendance_TimeOff_request', on_delete=models.CASCADE)
    start_date = models.DateField()
    end_date = models.DateField()
    reason = models.TextField()
    status = models.CharField(max_length=20, choices=[(PENDING, 'Pending'), (APPROVED, 'Approved'), (REJECTED, 'Rejected')], default=PENDING)

    def clean(self):
        if self.end_date < self.start_date:
            raise ValidationError("End date must be after or the same as the start date.")
        
class AttendanceRegularization(models.Model):
    # Predefined choices
    REQUEST_TYPES = [
        ('late_arrival', 'Late Arrival'),
        ('early_departure', 'Early Departure'),
        ('missed_punch', 'Missed Punch'),
    ]
    user = models.ForeignKey(CustomUser, on_delete=models.CASCADE)
    request_date = models.DateTimeField(auto_now_add=True)
    discrepancy_date = models.DateField()
    explanation = models.TextField()
    supporting_documentation = models.FileField(upload_to='supporting_docs/', null=True, blank=True)
    is_approved = models.BooleanField(default=False)
    request_type = models.CharField(max_length=20, choices=REQUEST_TYPES)

    def __str__(self):
        return f"{self.user.username} - {self.discrepancy_date} - Type: {self.get_request_type_display()} - Approved: {self.is_approved}"
    

# Settings # 
# class GeneralSettings(models.Model):
#     EFFECTIVE_FROM_CHOICES = [
#         ('immediate', 'Immediate'),
#         ('custom_date', 'Custom Date'),
#     ]

#     DEFAULT_SHIFT_TIME_CHOICES = [
#         ('first_last_checkin_checkout', 'First Check-in & Last Check-out'),
#         ('every_valid_checkin_checkout', 'Every Valid Check-in & Check-out'),
#     ]

#     MINIMUM_HOURS_CALCULATION_CHOICES = [
#         ('strict_mode', 'Strict Mode'),
#         ('lenient_mode', 'Lenient Mode (Expected Hours)'),
#     ]

#     PAY_DAYS_HOURS_CALCULATION_CHOICES = [
#         ('include_weekends', 'Include Weekend(s)'),
#         ('include_holidays', 'Include Holidays'),
#         ('include_leave', 'Include Leave'),
#     ]

#     ROUND_OFF_CHOICES = [
#         ('enable', 'Enable'),
#         ('disable', 'Disable'),
#     ]

#     CARRY_OVER_BALANCE_HOURS_CHOICES = [
#         ('enable', 'Enable'),
#         ('disable', 'Disable'),
#     ]

#     LATE_NIGHT_WORK_HOURS_CHOICES = [
#         ('enable', 'Enable'),
#         ('disable', 'Disable'),
#     ]

#     general_effective_from = models.CharField(max_length=15, choices=EFFECTIVE_FROM_CHOICES)
#     effective_from_date = models.DateField(null=True, blank=True)
#     default_shift_time = models.CharField(max_length=30, choices=DEFAULT_SHIFT_TIME_CHOICES)
#     scale_view_enabled = models.BooleanField(default=False)
#     working_hours_total_hours_calculation = models.CharField(max_length=30, choices=MINIMUM_HOURS_CALCULATION_CHOICES)
#     minimum_hours_required_for_day = models.DurationField()
#     show_overtime_deviation = models.BooleanField(default=False)
#     maximum_hours_required_for_day = models.DurationField()
#     round_off = models.CharField(max_length=10, choices=ROUND_OFF_CHOICES)
#     pay_days_hours_calculation = models.CharField(max_length=30, choices=PAY_DAYS_HOURS_CALCULATION_CHOICES)
#     carry_over_balance_hours_in_overtime_report = models.BooleanField(default=False)
#     late_night_work_hours = models.CharField(max_length=10, choices=LATE_NIGHT_WORK_HOURS_CHOICES)
#     late_night_work_hours_enable_tracking = models.BooleanField(default=False)
#     late_night_work_hours_start_time = models.TimeField(null=True, blank=True)
#     late_night_work_hours_end_time = models.TimeField(null=True, blank=True)

# class PermissionSettings(models.Model):
#     web_checkin_checkout_enabled = models.BooleanField(default=False)
#     mobile_checkin_checkout_enabled = models.BooleanField(default=False)
#     capture_save_photo_web_checkin_checkout = models.BooleanField(default=False)
#     capture_save_photo_mobile_checkin_checkout = models.BooleanField(default=False)
#     capture_verify_photo_web_checkin_checkout = models.BooleanField(default=False)
#     capture_verify_photo_mobile_checkin_checkout = models.BooleanField(default=False)
#     make_location_sharing_mandatory_web_checkin_checkout = models.BooleanField(default=False)
#     make_location_sharing_mandatory_mobile_checkin_checkout = models.BooleanField(default=False)
#     show_all_checkin_checkout_entries = models.BooleanField(default=False)
#     view_reportees_entries = models.BooleanField(default=False)
#     edit_reportees_entries = models.BooleanField(default=False)
#     notify_email = models.EmailField()

# class ShiftSettings(models.Model):
#     view_employee_shift_mapping = models.CharField(max_length=30)
#     edit_employee_shift_mapping = models.CharField(max_length=30)
#     allow_change_shift_for_past_dates_reporting_manager = models.BooleanField(default=False)
#     email_notification_shift_modification = models.BooleanField(default=False)
#     feeds_notification_shift_modification = models.BooleanField(default=False)
#     eligibility_for_shift_allowance = models.DurationField()
#     make_reason_mandatory_for_shift_change = models.BooleanField(default=False)

# class ShiftReminderSettings(models.Model):
#     checkin_reminder_enable = models.BooleanField(default=False)
#     checkin_reminder_custom_email_template = models.TextField()
#     checkin_reminder_hours_before_shift_start = models.DurationField()
#     checkin_reminder_hours_after_shift_start = models.DurationField()
#     checkout_reminder_enable = models.BooleanField(default=False)
#     checkout_reminder_custom_email_template = models.TextField()
#     checkout_reminder_hours_before_shift_end = models.DurationField()
#     checkout_reminder_hours_after_shift_end = models.DurationField()
#     notify_manager_when_reportees_dont_checkin_enable = models.BooleanField(default=False)
#     notify_manager_when_reportees_dont_checkin_custom_email_template = models.TextField()
#     notify_manager_when_reportees_dont_checkin_hours_after_shift_start = models.DurationField()

# class ExportSettings(models.Model):
#     password_protection_enable = models.BooleanField(default=False)

# class OnDutySettings(models.Model):
#     on_duty_enable = models.BooleanField(default=False)

# class RegularizationSettings(models.Model):
#     regularization_for_future_dates_enable = models.BooleanField(default=False)
#     regularization_request_days_from_date = models.PositiveIntegerField()
#     regularization_request_days_a_week = models.PositiveIntegerField()

# class SchedulerDetails(models.Model):
#     schedule_name = models.CharField(max_length=255)
#     schedule_frequency = models.CharField(max_length=30)

# class ShiftRotationDetails(models.Model):
#     applicable_period_from = models.DateField()
#     applicable_period_to = models.DateField()
#     applicable_for = models.CharField(max_length=255)
#     shift_rotation = models.ManyToManyField(Shift, related_name='shift_rotations')

# class OnDutySettings(models.Model):
#     on_duty_enable = models.BooleanField(default=False)

# class RegularizationSettings(models.Model):
#     regularization_for_future_dates_enable = models.BooleanField(default=False)
#     regularization_request_days_from_date = models.PositiveIntegerField()
#     regularization_request_days_a_week = models.PositiveIntegerField()

# class ShiftRotationDetails(models.Model):
#     applicable_period_from = models.DateField()
#     applicable_period_to = models.DateField()
#     applicable_for = models.CharField(max_length=255)
#     shift_rotation = models.ManyToManyField(Shift, related_name='shift_rotations')

# class NotificationSettings(models.Model):
#     email_notification_enable = models.BooleanField(default=False)
#     feeds_notification_enable = models.BooleanField(default=False)
#     email_template = models.TextField()

# class FeedNotificationSettings(models.Model):
#     notification_for_shift_modification_enable = models.BooleanField(default=False)
#     notification_for_shift_modification_email_template = models.TextField()
#     notification_for_shift_modification_hours_after_shift_start = models.DurationField()

# class ShiftAllowanceSettings(models.Model):
#     shift_allowance_enable = models.BooleanField(default=False)
#     shift_allowance_reason_mandatory = models.BooleanField(default=False)