# admin.py

from django.contrib import admin
from .models import Shift, AssignShift, ShiftRotation, ShiftSwapRequest, Break, AttendanceEntry, TimeOffRequest, AttendanceRegularization

@admin.register(Shift)
class ShiftAdmin(admin.ModelAdmin):
    pass

@admin.register(AssignShift)
class AssignShiftAdmin(admin.ModelAdmin):
    pass

@admin.register(ShiftRotation)
class ShiftRotationAdmin(admin.ModelAdmin):
    pass

@admin.register(ShiftSwapRequest)
class ShiftSwapRequestAdmin(admin.ModelAdmin):
    pass

@admin.register(Break)
class BreakAdmin(admin.ModelAdmin):
    pass

@admin.register(AttendanceEntry)
class AttendanceEntryAdmin(admin.ModelAdmin):
    pass

@admin.register(TimeOffRequest)
class TimeOffRequestAdmin(admin.ModelAdmin):
    pass

@admin.register(AttendanceRegularization)
class AttendanceRegularizationAdmin(admin.ModelAdmin):
    pass
