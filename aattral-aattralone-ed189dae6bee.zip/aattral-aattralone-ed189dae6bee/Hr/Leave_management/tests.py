from django.test import TestCase
from rest_framework.test import APIClient
from rest_framework import status
from Authentication.models import CustomUser
from .models import LeaveType,Employee, Department, Designation, Location, Role,LeaveBalance,LeaveRequest
from datetime import date

# class LeaveTypeAPITestCase(TestCase):

#     def setUp(self):
#         # Create a user for authentication
#         self.user = CustomUser.objects.create_user(username='testuser', password='testpassword')
#         self.client = APIClient()
#         self.client.force_authenticate(user=self.user)

#         # Valid data for creating a LeaveType
#         self.valid_data = {
#             'name': 'Vacation',
#             'code': 'VAC',
#             'type': 'paid',
#             'unit': 'days',
#             'balance_based_on': 'fixed_entitlement',
#             'description': 'Paid time off for relaxation',
#             'validity': '2024-12-31',
#             # Include other required fields and their values
#         }

#         # Invalid data for testing error handling
#         self.invalid_data = {
#             'name': 'Invalid Leave Type',  # Missing required fields
#             # Include other missing or invalid fields
#         }

#     def test_create_leave_type_success(self):
#         response = self.client.post('/leave-types/', data=self.valid_data)
#         self.assertEqual(response.status_code, status.HTTP_201_CREATED)
#         self.assertEqual(LeaveType.objects.count(), 1)
#         self.assertEqual(LeaveType.objects.get().name, 'Vacation')

#     def test_create_leave_type_failure(self):
#         response = self.client.post('/leave-types/', data=self.invalid_data)
#         self.assertEqual(response.status_code, status.HTTP_400_BAD_REQUEST)
#         self.assertEqual(LeaveType.objects.count(), 0)

#     def test_create_leave_type_missing_authentication(self):
#         # Test creating a LeaveType without authentication
#         client = APIClient()
#         response = client.post('/leave-types/', data=self.valid_data)
#         self.assertEqual(response.status_code, status.HTTP_401_UNAUTHORIZED)
#         self.assertEqual(LeaveType.objects.count(), 0)

#     def test_create_leave_type_invalid_authentication(self):
#         # Test creating a LeaveType with invalid authentication
#         client = APIClient()
#         client.force_authenticate(user=None)
#         response = client.post('/leave-types/', data=self.valid_data)
#         self.assertEqual(response.status_code, status.HTTP_401_UNAUTHORIZED)
#         self.assertEqual(LeaveType.objects.count(), 0)

class LeaveTypeTestCase(TestCase):
    def setUp(self):
        # Create related models
        self.employee = Employee.objects.create(first_name='John Doe', email_address='john@example.com')
        self.department = Department.objects.create(name='Engineering')
        self.designation = Designation.objects.create(name='Software Engineer')
        self.location = Location.objects.create(name='Head Office')
        self.role = Role.objects.create(name='Developer')

    def test_leave_type_creation(self):
        leave_type = LeaveType.objects.create(
            name='Annual Leave',
            code='AL',
            type='paid',
            unit='days',
            balance_based_on='fixed_entitlement',
            description='Paid annual leave for employees',
            validity=date.today(),
            effective_after=1,
            effective_after_unit='months',
            accrual_period='annually',
            leave_entitlement=20,
            carry_forward_enabled=True,
            carry_forward_type='with_expiry',
            carry_forward_expiry_date=date.today(),
            encashment_enabled=True,
            encashment_type='percentage',
            encashment_percentage=50,
            applicable_gender='male',
            applicable_marital_status='married',
            employee=self.employee,
            assign_to_all_employees=False,
            weekends_leave_period=True,
            holidays_leave_period=True,
            exceed_leave_balance_allow_deny=True,
            duration_allowed='full_day',
            allow_past_dates=True,
            past_days_limit=10,
            allow_future_dates=True,
            future_days_limit=365,
            allow_apply_in_advance=True,
            apply_in_advance_days=7,
            allow_admin_to_apply_on_behalf=True,
            min_leave_per_application=1,
            max_leave_per_application=30,
            max_consecutive_leave_days=15,
            min_gap_between_applications=1,
            enable_file_upload=True,
            file_upload_days_limit=7,
            max_applications_within_period=5,
            leave_can_be_applied_on_holidays=True,
            leave_can_be_applied_on_restricted_holidays=True,
            leave_cannot_be_taken_together=True,
        )

        # Test model fields
        self.assertEqual(leave_type.name, 'Annual Leave')
        self.assertEqual(leave_type.code, 'AL')
        self.assertEqual(leave_type.type, 'paid')
        self.assertEqual(leave_type.unit, 'days')
        self.assertEqual(leave_type.balance_based_on, 'fixed_entitlement')
        self.assertEqual(leave_type.description, 'Paid annual leave for employees')
        self.assertEqual(leave_type.validity, date.today())
        self.assertEqual(leave_type.effective_after, 1)
        self.assertEqual(leave_type.effective_after_unit, 'months')
        self.assertEqual(leave_type.accrual_period, 'annually')
        self.assertEqual(leave_type.leave_entitlement, 20)
        self.assertTrue(leave_type.carry_forward_enabled)
        self.assertEqual(leave_type.carry_forward_type, 'with_expiry')
        self.assertEqual(leave_type.carry_forward_expiry_date, date.today())
        self.assertTrue(leave_type.encashment_enabled)
        self.assertEqual(leave_type.encashment_type, 'percentage')
        self.assertEqual(leave_type.encashment_percentage, 50)
        self.assertEqual(leave_type.applicable_gender, 'male')
        self.assertEqual(leave_type.applicable_marital_status, 'married')
        self.assertEqual(leave_type.employee, self.employee)
        self.assertFalse(leave_type.assign_to_all_employees)
        self.assertTrue(leave_type.weekends_leave_period)
        self.assertTrue(leave_type.holidays_leave_period)
        self.assertTrue(leave_type.exceed_leave_balance_allow_deny)
        self.assertEqual(leave_type.duration_allowed, 'full_day')
        self.assertTrue(leave_type.allow_past_dates)
        self.assertEqual(leave_type.past_days_limit, 10)
        self.assertTrue(leave_type.allow_future_dates)
        self.assertEqual(leave_type.future_days_limit, 365)
        self.assertTrue(leave_type.allow_apply_in_advance)
        self.assertEqual(leave_type.apply_in_advance_days, 7)
        self.assertTrue(leave_type.allow_admin_to_apply_on_behalf)
        self.assertEqual(leave_type.min_leave_per_application, 1)
        self.assertEqual(leave_type.max_leave_per_application, 30)
        self.assertEqual(leave_type.max_consecutive_leave_days, 15)
        self.assertEqual(leave_type.min_gap_between_applications, 1)
        self.assertTrue(leave_type.enable_file_upload)
        self.assertEqual(leave_type.file_upload_days_limit, 7)
        self.assertEqual(leave_type.max_applications_within_period, 5)
        self.assertTrue(leave_type.leave_can_be_applied_on_holidays)
        self.assertTrue(leave_type.leave_can_be_applied_on_restricted_holidays)
        self.assertTrue(leave_type.leave_cannot_be_taken_together)

