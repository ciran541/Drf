from django.db.models.signals import post_save
from django.dispatch import receiver
from .models import LeaveApproval, Notification

@receiver(post_save, sender=LeaveApproval)
def send_leave_notification(sender, instance, created, **kwargs):
    if created:
        if instance.is_approved:
            message = f"Your leave request has been approved."
        else:
            message = f"Your leave request has been rejected."
        Notification.objects.create(user=instance.leave_request.employee, message=message)