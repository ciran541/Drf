from rest_framework import serializers
from .models import LeaveType,LeaveRequest,LeaveBalance,LeaveApproval,Holiday,ProrateAccrualRule,LeaveHistory
from Hr.employee_information.serializers import EmployeeSerializer

class LeaveTypeSerializer(serializers.ModelSerializer):
    class Meta:
        model = LeaveType
        fields = '__all__'

class LeaveTypeSerializerForLeaveRequest(serializers.ModelSerializer):
    class Meta:
        model = LeaveType
        fields = ('id', 'name')

class LeaveRequestCreateSerializer(serializers.ModelSerializer):
    class Meta:
        model = LeaveRequest
        fields = '__all__'

class LeaveRequestSerializer(serializers.ModelSerializer):
    employee = EmployeeSerializer(read_only=True)
    leave_type = LeaveTypeSerializerForLeaveRequest(read_only=True)

    class Meta:
        model = LeaveRequest
        fields = '__all__'

    def create(self, validated_data):
        return LeaveRequest.objects.create(**validated_data)
    
        

class LeaveBalanceSerializer(serializers.ModelSerializer):
    class Meta:
        model = LeaveBalance
        fields = '__all__'
        
class LeaveApprovalSerializer(serializers.ModelSerializer):
    class Meta:
        model = LeaveApproval
        fields = '__all__'

class HolidaySerializer(serializers.ModelSerializer):
    class Meta:
        model = Holiday
        fields = '__all__'

class ProrateAccrualRuleSerializer(serializers.ModelSerializer):
    class Meta:
        model = ProrateAccrualRule
        fields = '__all__'

class LeaveHistorySerializer(serializers.ModelSerializer):
    class Meta:
        model = LeaveHistory
        fields = '__all__'

