# admin.py

from django.contrib import admin
from .models import ProrateAccrualRule, LeaveType, LeaveBalance, LeaveRequest, LeaveHistory, LeaveApproval, Holiday

@admin.register(ProrateAccrualRule)
class ProrateAccrualRuleAdmin(admin.ModelAdmin):
    pass

@admin.register(LeaveType)
class LeaveTypeAdmin(admin.ModelAdmin):
    pass

@admin.register(LeaveBalance)
class LeaveBalanceAdmin(admin.ModelAdmin):
    pass

@admin.register(LeaveRequest)
class LeaveRequestAdmin(admin.ModelAdmin):
    pass

@admin.register(LeaveHistory)
class LeaveHistoryAdmin(admin.ModelAdmin):
    pass

@admin.register(LeaveApproval)
class LeaveApprovalAdmin(admin.ModelAdmin):
    pass

@admin.register(Holiday)
class HolidayAdmin(admin.ModelAdmin):
    pass
