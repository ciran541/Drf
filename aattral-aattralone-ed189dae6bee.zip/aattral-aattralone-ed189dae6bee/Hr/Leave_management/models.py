from django.db import models
from django.db.models.signals import post_save, m2m_changed
from Hr.employee_information.models import Department, Designation, Location, Role, Employee
from Authentication.models import CustomUser
from django.db.models.signals import post_save
from django.dispatch import receiver
from django.core.exceptions import ValidationError
from django.utils.translation import gettext_lazy as _
class ProrateAccrualRule(models.Model):
    from_day = models.PositiveIntegerField()
    to_day = models.PositiveIntegerField()
    count_as_days = models.PositiveIntegerField(default=0)

    def __str__(self):
        return f'{self.from_day} to {self.to_day} - {self.count_as_days}'

class LeaveType(models.Model):
    # Section 1: Generic Parameters - Leave Type Information
    # Predefined rules:
    # 1. Name, type, unit, balance_based_on, description, and validity are required fields.
    # 2. 'type' must be one of 'paid', 'un_paid'.
    # 3. 'unit' must be one of 'days' or 'hours'.
    # 4. 'balance_based_on' must be one of 'fixed_entitlement' or 'leave_grant'.
    # 5. 'validity' refers to the expiration date of the leave type.

    name = models.CharField(max_length=255)
    image = models.ImageField(upload_to='leave_images/', null=True, blank=True)
    code = models.CharField(max_length=50)

    type_choices = [
        ('paid', 'Paid'),
        ('un_paid', 'Unpaid'),
    ]
    type = models.CharField(max_length=20, choices=type_choices)

    unit_choices = [
        ('days', 'Days'),
        ('hours', 'Hours'),
    ]
    unit = models.CharField(max_length=10, choices=unit_choices,null=True, blank=True)

    balance_based_on_choices = [
        ('fixed_entitlement', 'Fixed Entitlement'),
        ('leave_grant', 'Leave Grant'),
    ]
    balance_based_on = models.CharField(max_length=20, choices=balance_based_on_choices,null=True, blank=True)
    description = models.TextField(null=True, blank=True)
    validity = models.DateField(null=True, blank=True)

    # Section 2: Entitlement
    # Predefined rules:
    # 1. 'effective_after' denotes the waiting period before the leave becomes applicable.
    # 2. 'accrual_period' defines how often the leave entitlement accrues.
    # 3. 'reset_enabled' indicates whether leave balances reset periodically.
    # 4. 'carry_forward_enabled' determines if remaining leave can be carried forward to the next period.
    # 5. 'encashment_enabled' allows employees to convert unused leave into cash.

    effective_after = models.PositiveIntegerField()
    effective_after_unit_choices = [
        ('days', 'Days'),
        ('months', 'Months'),
        ('years', 'Years'),
    ]
    effective_after_unit = models.CharField(max_length=10, choices=effective_after_unit_choices,null=True, blank=True)

    accrual_period_choices = [
        ('monthly', 'Monthly'),
        ('quarterly', 'Quarterly'),
        ('half_yearly', 'Half Yearly'),
        ('annually', 'Annually'),
    ]
    accrual_period = models.CharField(max_length=20, choices=accrual_period_choices,null=True, blank=True)

    accrual_values = models.JSONField(null=True, blank=True)
    leave_entitlement = models.PositiveIntegerField(default=0,null=True, blank=True)
    reset_enabled = models.BooleanField(default=False,null=True, blank=True)
    reset_interval_choices = [
        ('monthly', 'Monthly'),
        ('quarterly', 'Quarterly'),
        ('half_yearly', 'Half Yearly'),
        ('annually', 'Annually'),
    ]
    reset_interval = models.CharField(max_length=20, choices=reset_interval_choices,null=True, blank=True)

    carry_forward_enabled = models.BooleanField(default=False,null=True, blank=True)
    carry_forward_type_choices = [
        ('without_expiry', 'Without Expiry'),
        ('with_expiry', 'With Expiry'),
    ]
    carry_forward_type = models.CharField(max_length=20, choices=carry_forward_type_choices,null=True, blank=True)

    carry_forward_expiry_date = models.DateField(null=True, blank=True)

    # Encashment
    encashment_enabled = models.BooleanField(default=False,null=True, blank=True)
    
    encashment_type_choices = [
        ('percentage', 'Percentage'),
        ('maximum_limit', 'Maximum Limit'),
    ]
    encashment_type = models.CharField(max_length=20, choices=encashment_type_choices, default='percentage',null=True, blank=True)
    
    encashment_percentage = models.PositiveIntegerField(null=True, blank=True)
    encashment_maximum_limit = models.PositiveIntegerField(null=True, blank=True)

    # Prorate Accrual
    # Predefined rules:
    # 1. 'prorate_accrual_enabled' determines if prorate accrual is enabled for this leave type.
    # 2. 'prorate_accrual_by' specifies whether proration is based on effective months or days.
    # 3. 'round_off_enabled' enables rounding off prorated values.
    # 4. 'round_off_to_nearest' determines whether rounding off should be to the nearest day or month.
    # 5. 'round_off_value' specifies the rounding off value.
    # 6. 'first_month_rule' specifies the rule for proration in the first month.
    # 7. 'prorate_accrual_rules' contains custom proration rules for the first month if 'first_month_rule' is 'custom'.

    prorate_accrual_enabled = models.BooleanField(default=False,null=True, blank=True)
    prorate_accrual_by_choices = [
        ('effective_months', 'Number of Effective Months'),
        ('effective_days', 'Number of Effective Days'),
    ]
    prorate_accrual_by = models.CharField(max_length=20, choices=prorate_accrual_by_choices, default='effective_months',null=True, blank=True)
    
    round_off_enabled = models.BooleanField(default=False,null=True, blank=True)
    round_off_to_nearest_choices = [
        ('day', 'Day'),
        ('month', 'Month'),
    ]
    round_off_to_nearest = models.CharField(max_length=10, choices=round_off_to_nearest_choices, default='day')
    round_off_value = models.PositiveIntegerField(default=1,null=True, blank=True)

    first_month_rule_choices = [
        ('1st', '1st'),
        ('custom', 'Custom'),
    ]
    first_month_rule = models.CharField(max_length=10, choices=first_month_rule_choices, default='1st',null=True, blank=True)

    prorate_accrual_rules = models.ManyToManyField(ProrateAccrualRule, related_name='leave_type_rules', blank=True)

    # Section 3: Applicability&Exception
    # Predefined rules:
    # 1. 'applicable_gender' specifies who the leave type is applicable to.
    # 2. 'applicable_marital_status' defines the marital status of employees eligible for this leave.
    # 3. 'applicable_departments', 'applicable_designations', 'applicable_locations', and 'applicable_roles'
    #    specify which departments, designations, locations, and roles can avail of this leave type.

    applicable_gender_choices = [
        ('male', 'Male'),
        ('female', 'Female'),
        ('others', 'Others'),
    ]
    applicable_gender = models.CharField(max_length=10, choices=applicable_gender_choices,null=True, blank=True)

    applicable_marital_status_choices = [
        ('single', 'Single'),
        ('married', 'Married'),
    ]
    applicable_marital_status = models.CharField(max_length=10, choices=applicable_marital_status_choices,null=True, blank=True)
    
    applicable_departments = models.ManyToManyField(Department,blank=True)
    applicable_designations = models.ManyToManyField(Designation,blank=True)
    applicable_locations = models.ManyToManyField(Location,blank=True)
    applicable_roles = models.ManyToManyField(Role,blank=True)
    employees = models.ManyToManyField(Employee, blank=True)

    # Assign to all employees
    assign_to_all_employees = models.BooleanField(default=False,null=True, blank=True)

    # Section 4: Restrictions
    # Predefined rules:
    # 1. 'weekends_leave_period' specifies if weekends are included in the leave period.
    # 2. 'holidays_leave_period' specifies if holidays are included in the leave period.
    # 3. 'exceed_leave_balance_allow_deny' determines if leave requests exceeding balance are allowed.
    # 4. 'duration_allowed' defines the granularity of leave duration (full day, half day, etc.).

    weekends_leave_period = models.BooleanField(default=True,null=True, blank=True)
    weekends_count_as_leave = models.BooleanField(default=True,null=True, blank=True)
    weekends_count_after_days = models.PositiveIntegerField(default=0,null=True, blank=True)

    holidays_leave_period = models.BooleanField(default=True,null=True, blank=True)
    holidays_count_as_leave = models.BooleanField(default=True,null=True, blank=True)
    holidays_count_after_days = models.PositiveIntegerField(default=0,null=True, blank=True)

    exceed_leave_balance_allow_deny = models.BooleanField(default=True,null=True, blank=True)
    exceed_leave_balance_limit_choices = [
        ('without_limit', 'Without Limit'),
        ('until_year_end', 'Until Year End Limit'),
        ('without_limit_mark_as_lop', 'Without Limit and Mark as LOP'),
    ]
    exceed_leave_balance_limit = models.CharField(max_length=30, choices=exceed_leave_balance_limit_choices, default='without_limit')

    duration_allowed_choices = [
        ('full_day', 'Full Day'),
        ('half_day', 'Half Day'),
        ('quarter_day', 'Quarter Day'),
        ('hourly', 'Hourly'),
    ]
    duration_allowed = models.CharField(max_length=20, choices=duration_allowed_choices,null=True, blank=True)

    # Report Configuration
    # Predefined rules:
    # 1. 'allow_users_to_view_balance' specifies if users can view their leave balances.
    # 2. 'display_balance_configuration' determines if balance configuration is displayed.

    allow_users_to_view_balance = models.BooleanField(default=True,null=True, blank=True)
    display_balance_configuration = models.BooleanField(default=True,null=True, blank=True)

    # Allow Requests For
    # Predefined rules:
    # 1. 'allow_past_dates', 'allow_future_dates', and 'allow_apply_in_advance' determine if leave requests
    #    for past, future, and advance dates are allowed respectively.
    # 2. 'allow_admin_to_apply_on_behalf' allows admin to apply leave on behalf of others.

    allow_past_dates = models.BooleanField(default=True,null=True, blank=True)
    past_days_limit = models.PositiveIntegerField(default=0)
    
    allow_future_dates = models.BooleanField(default=True)
    future_days_limit = models.PositiveIntegerField(default=0)
    
    allow_apply_in_advance = models.BooleanField(default=True)
    apply_in_advance_days = models.PositiveIntegerField(default=0)

    allow_admin_to_apply_on_behalf = models.BooleanField(default=False)

    min_leave_per_application = models.PositiveIntegerField(default=1)
    max_leave_per_application = models.PositiveIntegerField(default=30)
    
    max_consecutive_leave_days = models.PositiveIntegerField(default=15)
    min_gap_between_applications = models.PositiveIntegerField(default=0)

    enable_file_upload = models.BooleanField(default=False)
    file_upload_days_limit = models.PositiveIntegerField(default=7)

    max_applications_within_period = models.PositiveIntegerField(default=5)

    # Section 5: Leave Application Specifics
    # Predefined rules:
    # 1. 'leave_can_be_applied_on_holidays', 'leave_can_be_applied_on_restricted_holidays',
    #    and 'leave_cannot_be_taken_together' specify the applicability and restrictions on holidays
    #    and taking leaves together.

    leave_can_be_applied_on_holidays = models.BooleanField(default=True,null=True, blank=True)
    leave_can_be_applied_on_restricted_holidays = models.BooleanField(default=True,null=True, blank=True)
    leave_cannot_be_taken_together = models.BooleanField(default=True,null=True, blank=True)


    def is_applicable_to_employee(self, employee):
        if self.assign_to_all_employees:
            return True
        else:
            return employee in self.employee.all()

    def __str__(self):
        return self.name
    
@receiver(post_save, sender=LeaveType)
def update_leave_balance_for_employees(sender, instance, created, **kwargs):
    if created:
        if instance.assign_to_all_employees:
            employees = Employee.objects.all()
        else:
            employees = instance.employees.all()
        
        for employee in employees:
            leave_balance, created = LeaveBalance.objects.get_or_create(
                employee=employee,
                leave_type=instance,
                defaults={'balance': instance.leave_entitlement, 'leave_taken': 0}
            )

            if not created:
                leave_balance.balance = instance.leave_entitlement
                leave_balance.save()


class LeaveBalance(models.Model):
    employee = models.ForeignKey(Employee, on_delete=models.CASCADE)
    leave_type = models.ForeignKey(LeaveType,on_delete=models.CASCADE,null=True, blank=True)
    balance = models.PositiveIntegerField(default=0)
    leave_taken = models.PositiveIntegerField(default=0)

    def update_balance(self):
        # 1. Fetch leave entitlement for the leave type
        leave_entitlement = self.leave_type.leave_entitlement
        
        # 2. Calculate total leave taken by the employee for this leave type
        total_leave_taken = LeaveRequest.objects.filter(
            employee=self.employee,
            leave_type=self.leave_type,
            status='approved'
        ).aggregate(total_leave_taken=models.Sum('duration'))['total_leave_taken'] or 0

        # 3. Calculate accrued leave based on accrual rate and period
        accrued_leave = self.calculate_accrued_leave()

        # 4. Update leave_taken, balance, and save the instance
        self.leave_taken = total_leave_taken
        self.balance = max(0, leave_entitlement + accrued_leave - total_leave_taken)
        self.save()

    def calculate_accrued_leave(self):
        # Assuming LeaveType model has fields like 'accrual_rate' and 'accrual_period'
        accrual_rate = self.leave_type.accrual_rate
        accrual_period = self.leave_type.accrual_period

        # Calculate accrued leave based on accrual rate and period
        if accrual_period == 'yearly':
            accrued_leave = accrual_rate
        elif accrual_period == 'monthly':
            accrued_leave = accrual_rate / 12
        elif accrual_period == 'bi_weekly':
            accrued_leave = accrual_rate / 26
        else:
            accrued_leave = 0
        
        return accrued_leave

    def __str__(self):
        return f'{self.employee} - {self.leave_type}'
    

class LeaveRequest(models.Model):
    employee = models.ForeignKey(Employee, on_delete=models.CASCADE)
    leave_type = models.ForeignKey(LeaveType, on_delete=models.CASCADE)
    start_date = models.DateField()
    end_date = models.DateField()
    duration = models.DecimalField(max_digits=5, decimal_places=2)
    status_choices = [
        ('approved', 'Approved'),
        ('pending', 'Pending'),
        ('rejected', 'Rejected'),
    ]
    status = models.CharField(max_length=10, choices=status_choices, default='pending',blank=True)

    
    def cancel(self):
        if self.status == 'pending':
            self.status = 'cancelled'
            self.save()

    def modify(self, new_start_date, new_end_date, new_duration):
        if self.status == 'pending':
            self.start_date = new_start_date
            self.end_date = new_end_date
            self.duration = new_duration
            self.save()

        # Update the related LeaveBalance instance after saving the LeaveRequest
        if self.status == 'approved':
            # Assuming each LeaveRequest affects only one LeaveBalance entry
            leave_balance = LeaveBalance.objects.get(employee=self.employee, leave_type=self.leave_type)
            leave_balance.update_balance()

    def save(self, *args, **kwargs):
        # Call the superclass's save() method
        super().save(*args, **kwargs)


# Create a LeaveHistory model to store historical leave records
class LeaveHistory(models.Model):
    employee = models.ForeignKey(Employee, on_delete=models.CASCADE)
    leave_type = models.ForeignKey(LeaveType, on_delete=models.CASCADE)
    total_leave_taken = models.DecimalField(max_digits=5, decimal_places=2)
    leave_balance = models.DecimalField(max_digits=5, decimal_places=2)
    timestamp = models.DateTimeField(auto_now_add=True)

# Signal to update leave balance and store in LeaveHistory when a LeaveRequest is saved
@receiver(post_save, sender=LeaveRequest)
def update_leave_balance_and_log(sender, instance, created, **kwargs):
    if created:  # Only execute for newly created instances
        try:
            leave_balance = LeaveBalance.objects.get(employee=instance.employee, leave_type=instance.leave_type)
        except LeaveBalance.DoesNotExist:
            # Handle the case where LeaveBalance doesn't exist
            return

        # Update the leave balance
        leave_balance.update_balance()

        # Create a LeaveHistory entry
        LeaveHistory.objects.create(
            employee=instance.employee,
            leave_type=instance.leave_type,
            total_leave_taken=leave_balance.leave_taken,
            leave_balance=leave_balance.balance
        )
    
class LeaveApproval(models.Model):
    leave_request = models.OneToOneField(LeaveRequest, on_delete=models.CASCADE)
    approved_by = models.ForeignKey(Employee, on_delete=models.CASCADE)
    approved_at = models.DateTimeField(auto_now_add=True)
    is_approved = models.BooleanField(default=False)
    comment = models.TextField(blank=True, null=True)

    def approve(self):
        if self.leave_request.status == 'pending':
            self.leave_request.status = 'approved'
            self.leave_request.save()
            self.is_approved = True
            self.save()
            self.leave_request.leavebalance_set.create(
                employee=self.leave_request.employee,
                leave_type=self.leave_request.leave_type,
                total_leave_taken=self.leave_request.leave_balance.leave_taken,
                leave_balance=self.leave_request.leave_balance.balance
            )
            # Send notification or alert if needed

    def reject(self):
        if self.leave_request.status == 'pending':
            self.leave_request.status = 'rejected'
            self.leave_request.save()
            self.save()
    
    def approve(self):
        if self.leave_request.status == 'pending':
            self.leave_request.status = 'approved'
            self.leave_request.save()
            self.is_approved = True
            self.save()
            
            # Decrease leave balance for the employee
            leave_balance = self.leave_request.employee.leavebalance_set.filter(leave_type=self.leave_request.leave_type).first()
            if leave_balance:
                leave_balance.balance -= self.leave_request.duration
                leave_balance.save()
            else:
                # Create a new leave balance if it doesn't exist for the employee and leave type
                leave_balance = LeaveBalance.objects.create(
                    employee=self.leave_request.employee,
                    leave_type=self.leave_request.leave_type,
                    balance=-self.leave_request.duration,
                    leave_taken=0  # Assuming leave taken is initially 0
                )
            
            # Save leave history
            LeaveHistory.objects.create(
                employee=self.leave_request.employee,
                leave_type=self.leave_request.leave_type,
                total_leave_taken=leave_balance.leave_taken,
                leave_balance=leave_balance.balance
            )
    
@receiver(post_save, sender=LeaveApproval)
def update_leave_balance(sender, instance, created, **kwargs):
    if created:  # Only trigger when a new LeaveApproval is created
        instance.approve_leave()

class Holiday(models.Model):
    name = models.CharField(max_length=255)
    date = models.DateField()
    restricted = models.BooleanField(default=False)
    applicable_for = models.CharField(max_length=255, blank=True, null=True)
    description = models.TextField(blank=True, null=True)
    reminder_days_before = models.IntegerField(default=0)

