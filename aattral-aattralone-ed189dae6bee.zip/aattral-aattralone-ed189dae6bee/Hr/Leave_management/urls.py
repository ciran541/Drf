from rest_framework.routers import DefaultRouter
from .views import LeaveTypeViewSet,LeaveRequestViewSet,LeaveBalanceViewSet,LeaveApprovalViewSet,HolidayViewSet,ProrateAccrualRuleViewSet,LeaveHistoryViewSet


router = DefaultRouter()
router.register(r'leave-types', LeaveTypeViewSet)
router.register(r'leave-requests', LeaveRequestViewSet)
router.register(r'leave-balances', LeaveBalanceViewSet)
router.register(r'leave-approvals', LeaveApprovalViewSet)
router.register(r'holidays', HolidayViewSet)
router.register(r'prorate-accrual-rules', ProrateAccrualRuleViewSet)
router.register(r'leave_history', LeaveHistoryViewSet, basename='leave_history')

urlpatterns = router.urls


# GET request to /api/leave-balances/get_balance/?employee_id=<employee_id>&leave_type_id=<leave_type_id>