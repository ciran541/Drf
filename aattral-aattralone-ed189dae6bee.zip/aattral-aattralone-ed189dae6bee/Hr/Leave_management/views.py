from rest_framework import viewsets
from rest_framework.permissions import IsAuthenticated
from Hr.employee_information.models import Employee
from rest_framework.response import Response
from rest_framework.decorators import action
from rest_framework import status
from .models import LeaveType, LeaveRequest, LeaveBalance, LeaveApproval, Holiday, ProrateAccrualRule
from .serializers import (LeaveTypeSerializer, LeaveRequestSerializer, LeaveApprovalSerializer,
                          HolidaySerializer, ProrateAccrualRuleSerializer, LeaveHistorySerializer,
                          LeaveBalanceSerializer, LeaveRequestCreateSerializer)

class LeaveTypeViewSet(viewsets.ModelViewSet):
    # ViewSet for LeaveType model
    permission_classes = [IsAuthenticated]
    queryset = LeaveType.objects.all()
    serializer_class = LeaveTypeSerializer

class LeaveBalanceViewSet(viewsets.ModelViewSet):
    # ViewSet for LeaveBalance model
    permission_classes = [IsAuthenticated]
    queryset = LeaveBalance.objects.all()
    serializer_class = LeaveBalanceSerializer

    # Action to get leave balances for a specific employee
    @action(detail=False, methods=['get'])
    def get_balances_by_employee(self, request):
        user_id = request.query_params.get('user_id')

        try:
            user = Employee.objects.get(employee_id=user_id)
            leave_balances = LeaveBalance.objects.filter(employee=user)
            leave_types_data = []

            for balance in leave_balances:
                leave_type_data = {
                    "name": balance.leave_type.name,
                    "balance": balance.balance,
                    "taken": balance.leave_taken
                }
                leave_types_data.append(leave_type_data)

            response_data = {
                "id": user_id,
                "employee": user_id,
                "leaveTypes": leave_types_data
            }

            return Response(response_data)
        except Employee.DoesNotExist:
            return Response({'detail': 'Employee not found'}, status=status.HTTP_404_NOT_FOUND)
        
class LeaveRequestViewSet(viewsets.ModelViewSet):
    # ViewSet for LeaveRequest model
    permission_classes = [IsAuthenticated]
    queryset = LeaveRequest.objects.all()
    serializer_class = LeaveRequestSerializer
     
    def get_serializer_class(self):
        if self.request.method == 'POST':
            return LeaveRequestCreateSerializer
        return LeaveRequestSerializer
    
    # Action to cancel a leave request
    @action(detail=True, methods=['post'])
    def cancel(self, request, pk=None):
        leave_request = self.get_object()
        leave_request.cancel()
        return Response({'message': 'Leave request cancelled'})

    # Action to modify a leave request
    @action(detail=True, methods=['post'])
    def modify(self, request, pk=None):
        leave_request = self.get_object()
        new_start_date = request.data.get('new_start_date')
        new_end_date = request.data.get('new_end_date')
        new_duration = request.data.get('new_duration')
        leave_request.modify(new_start_date, new_end_date, new_duration)
        return Response({'message': 'Leave request modified'})
    
    # Action to update the status of a leave request
    @action(detail=True, methods=['put'])
    def update_status(self, request, pk=None):
        try:
            instance = self.get_object()
            status = request.data.get('status')
            if status in ['approved', 'pending', 'rejected']:
                instance.status = status
                instance.save()
                serializer = self.get_serializer(instance)
                return Response(serializer.data)
            else:
                return Response({'detail': 'Invalid status'}, status=status.HTTP_400_BAD_REQUEST)
        except LeaveRequest.DoesNotExist:
            return Response({'detail': 'Leave request not found'}, status=status.HTTP_404_NOT_FOUND)
    
    # Action to get leave requests for a specific user
    @action(detail=False, methods=['get'])
    def get_requests_by_user(self, request):
        user_id = request.query_params.get('user_id')
        
        try:
            leave_requests = LeaveRequest.objects.filter(employee__employee_id=user_id)
            serializer = self.get_serializer(leave_requests, many=True)
            return Response(serializer.data)
        except:
            return Response({'detail': 'User not found or no leave requests for the user'}, status=status.HTTP_404_NOT_FOUND)
        
    # Action to get pending leave requests
    @action(detail=False, methods=['get'])
    def pending_requests(self, request):
        pending_requests = self.queryset.filter(status='pending')
        serializer = self.get_serializer(pending_requests, many=True)
        return Response(serializer.data)

    # Action to get approved leave requests
    @action(detail=False, methods=['get'])
    def approved_requests(self, request):
        approved_requests = self.queryset.filter(status='approved')
        serializer = self.get_serializer(approved_requests, many=True)
        return Response(serializer.data)

    # Action to get rejected leave requests
    @action(detail=False, methods=['get'])
    def rejected_requests(self, request):
        rejected_requests = self.queryset.filter(status='rejected')
        serializer = self.get_serializer(rejected_requests, many=True)
        return Response(serializer.data)

    # Action to get pending leave requests for a specific user
    @action(detail=False, methods=['get'])
    def user_pending_requests(self, request):
        user_id = request.query_params.get('user_id')
        pending_requests = self.queryset.filter(employee=user_id, status='pending')
        serializer = self.get_serializer(pending_requests, many=True)
        return Response(serializer.data)

    # Action to get approved leave requests for a specific user
    @action(detail=False, methods=['get'])
    def user_approved_requests(self, request):
        user_id = request.query_params.get('user_id')
        approved_requests = self.queryset.filter(employee=user_id, status='approved')
        serializer = self.get_serializer(approved_requests, many=True)
        return Response(serializer.data)

    # Action to get rejected leave requests for a specific user
    @action(detail=False, methods=['get'])
    def user_rejected_requests(self, request):
        user_id = request.query_params.get('user_id')
        rejected_requests = self.queryset.filter(employee=user_id, status='rejected')
        serializer = self.get_serializer(rejected_requests, many=True)
        return Response(serializer.data)

class LeaveApprovalViewSet(viewsets.ModelViewSet):
    # ViewSet for LeaveApproval model
    permission_classes = [IsAuthenticated]
    queryset = LeaveApproval.objects.all()
    serializer_class = LeaveApprovalSerializer

    # Action to approve a leave request
    @action(detail=True, methods=['post'])
    def approve(self, request, pk=None):
        leave_approval = self.get_object()
        leave_approval.approve()
        return Response({'message': 'Leave request approved'})

    # Action to reject a leave request
    @action(detail=True, methods=['post'])
    def reject(self, request, pk=None):
        leave_approval = self.get_object()
        leave_approval.reject()
        return Response({'message': 'Leave request rejected'})

class HolidayViewSet(viewsets.ModelViewSet):
    # ViewSet for Holiday model
    permission_classes = [IsAuthenticated]
    queryset = Holiday.objects.all()
    serializer_class = HolidaySerializer

class ProrateAccrualRuleViewSet(viewsets.ModelViewSet):
    # ViewSet for ProrateAccrualRule model
    permission_classes = [IsAuthenticated]
    queryset = ProrateAccrualRule.objects.all()
    serializer_class = ProrateAccrualRuleSerializer

class LeaveHistoryViewSet(viewsets.ViewSet):
    # ViewSet for LeaveHistory
    permission_classes = [IsAuthenticated]
    
    # Action to list all leave history entries
    def list(self, request):
        leave_history = LeaveBalance.objects.all()
        serializer = LeaveHistorySerializer(leave_history, many=True)
        return Response(serializer.data)

    # Action to retrieve leave history for a specific employee
    def retrieve(self, request, pk=None):
        leave_history = LeaveBalance.objects.filter(employee__employee_id=pk)
        serializer = LeaveHistorySerializer(leave_history, many=True)
        return Response(serializer.data)


