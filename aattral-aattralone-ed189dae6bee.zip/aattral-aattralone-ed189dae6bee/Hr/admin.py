from django.contrib.admin import AdminSite, ModelAdmin
from django.contrib import admin
from django.utils import timezone
from Hr.Attendance.models import Shift, AssignShift, ShiftRotation, ShiftSwapRequest, Break, AttendanceEntry, TimeOffRequest, AttendanceRegularization
from Hr.employee_information.models import (Employee, Address, IdentityInformation, Location, Role, Designation, Department, EmployeeSkills, Language, 
                                         EmployeeLanguageProficiency, TechnicalSkill, EmployeeTechnicalSkill, SoftSkill, EmployeeSoftSkill, IndustrySpecificSkill, 
                                         EmployeeIndustrySpecificSkill)

from Hr.Leave_management.models import (ProrateAccrualRule, LeaveType, LeaveBalance, LeaveRequest, LeaveHistory, LeaveApproval, Holiday)
from Hr.Onboarding.models import (Candidate, OnboardingFlow, EmployeeOnboardingFlow, CandidateOnboardingFlow, WelcomeAbroadPage, ProfilePage, FormsPage, ChecklistPage, Report
)
from Hr.performance_management.models import (Goal, GoalHistory, Feedback, Competency, CompetencyManagement, Skill, SkillSet, KRA, KRAGoal, AppraisalCycle
)
from Hr.Timesheet.models import (GeneralSettings,TimesheetSettings,Client,Job, Project, TimeLog, Timesheet
)
from Hr.Task.models import Task


class HRAdminSite(AdminSite):
    site_header = 'HR Administration'
    site_title = 'Welcome To AattralOne HR'

hr_admin_site = HRAdminSite(name='hr_admin')

class HRModelAdmin(ModelAdmin):

  pass

# Register models from Attendance app

hr_admin_site.register(Shift)
hr_admin_site.register(AssignShift)
hr_admin_site.register(ShiftRotation)
hr_admin_site.register(ShiftSwapRequest)
hr_admin_site.register(Break)
hr_admin_site.register(AttendanceEntry)
hr_admin_site.register(TimeOffRequest)
hr_admin_site.register(AttendanceRegularization)

# Register models from Employee_information app

hr_admin_site.register(Employee, HRModelAdmin)
hr_admin_site.register(Address, HRModelAdmin)
hr_admin_site.register(IdentityInformation, HRModelAdmin)
hr_admin_site.register(Location, HRModelAdmin)
hr_admin_site.register(Role, HRModelAdmin)
hr_admin_site.register(Designation, HRModelAdmin)
hr_admin_site.register(Department, HRModelAdmin)
hr_admin_site.register(EmployeeSkills, HRModelAdmin)
hr_admin_site.register(Language, HRModelAdmin)
hr_admin_site.register(EmployeeLanguageProficiency, HRModelAdmin)
hr_admin_site.register(TechnicalSkill, HRModelAdmin)
hr_admin_site.register(EmployeeTechnicalSkill, HRModelAdmin)
hr_admin_site.register(SoftSkill, HRModelAdmin)
hr_admin_site.register(EmployeeSoftSkill, HRModelAdmin)
hr_admin_site.register(IndustrySpecificSkill, HRModelAdmin)
hr_admin_site.register(EmployeeIndustrySpecificSkill, HRModelAdmin)

# Register the models from Leave management


hr_admin_site.register(ProrateAccrualRule)
hr_admin_site.register(LeaveType)
hr_admin_site.register(LeaveBalance)
hr_admin_site.register(LeaveRequest)
hr_admin_site.register(LeaveHistory)
hr_admin_site.register(LeaveApproval)
hr_admin_site.register(Holiday)

# Register the models from Onboarding

hr_admin_site.register(Candidate)
hr_admin_site.register(OnboardingFlow)
hr_admin_site.register(EmployeeOnboardingFlow)
hr_admin_site.register(CandidateOnboardingFlow)
hr_admin_site.register(WelcomeAbroadPage)
hr_admin_site.register(ProfilePage)
hr_admin_site.register(FormsPage)
hr_admin_site.register(ChecklistPage)
hr_admin_site.register(Report)

# Register the models from performance Management


class GoalAdmin(admin.ModelAdmin):
    list_display = ('title', 'user', 'target_date', 'is_completed', 'priority')
    list_filter = ('is_completed', 'priority', 'user')
    search_fields = ('title', 'description')

    def mark_goals_as_completed(self, request, queryset):
        """
        Custom admin action to mark selected goals as completed.
        """
        updated_count = queryset.update(is_completed=True)
        self.message_user(request, f'{updated_count} goals marked as completed.')

    mark_goals_as_completed.short_description = "Mark selected goals as completed"

    actions = [mark_goals_as_completed]

class GoalHistoryAdmin(admin.ModelAdmin):
    list_display = ('goal', 'completion_date', 'progress_percentage', 'remaining_days')
    list_filter = ('completion_date',)
    search_fields = ('goal__title',)

class FeedbackAdmin(admin.ModelAdmin):
    list_display = ('feedback_provider', 'feedback_receiver', 'feedback_category', 'rating', 'feedback_date')
    list_filter = ('feedback_category', 'rating', 'feedback_date')
    search_fields = ('feedback_provider__username', 'feedback_receiver__name')

class CompetencyAdmin(admin.ModelAdmin):
    list_display = ('title', 'framework', 'is_specific', 'is_relevant_to_job_performance')
    list_filter = ('framework',)
    search_fields = ('title',)

class CompetencyManagementAdmin(admin.ModelAdmin):
    list_display = ('employee', 'competency', 'proficiency_level', 'assessment_tool', 'assessment_result')
    list_filter = ('competency', 'proficiency_level')
    search_fields = ('employee__username', 'competency__title')

class SkillAdmin(admin.ModelAdmin):
    list_display = ('name', 'proficiency_level')
    list_filter = ('proficiency_level',)
    search_fields = ('name',)

class SkillSetAdmin(admin.ModelAdmin):
    list_display = ('employee', 'skill', 'proficiency_level')
    list_filter = ('skill', 'proficiency_level')
    search_fields = ('employee__username', 'skill__name')

class KRAAdmin(admin.ModelAdmin):
    list_display = ('name',)
    search_fields = ('name',)

class KRAGoalAdmin(admin.ModelAdmin):
    list_display = ('kra', 'goal')
    list_filter = ('kra', 'goal')
    search_fields = ('kra__name', 'goal__title')

class AppraisalCycleAdmin(admin.ModelAdmin):
    list_display = ('name', 'period_start', 'period_end', 'is_appraisal_period_active', 'remaining_days_until_end')
    list_filter = ('period_start', 'period_end')
    search_fields = ('name', 'description')
    readonly_fields = ('is_appraisal_period_active', 'remaining_days_until_end')

hr_admin_site.register(Goal, GoalAdmin)
hr_admin_site.register(GoalHistory, GoalHistoryAdmin)
hr_admin_site.register(Feedback, FeedbackAdmin)
hr_admin_site.register(Competency, CompetencyAdmin)
hr_admin_site.register(CompetencyManagement, CompetencyManagementAdmin)
hr_admin_site.register(Skill, SkillAdmin)
hr_admin_site.register(SkillSet, SkillSetAdmin)
hr_admin_site.register(KRA, KRAAdmin)
hr_admin_site.register(KRAGoal, KRAGoalAdmin)
hr_admin_site.register(AppraisalCycle, AppraisalCycleAdmin)

# Register each modelfrom Timesheet

hr_admin_site.register(GeneralSettings, HRModelAdmin)
hr_admin_site.register(TimesheetSettings, HRModelAdmin)
hr_admin_site.register(Client, HRModelAdmin)
hr_admin_site.register(Project, HRModelAdmin)
hr_admin_site.register(Job, HRModelAdmin)
hr_admin_site.register(TimeLog, HRModelAdmin)
hr_admin_site.register(Timesheet, HRModelAdmin)


# Custom admin class for Task model in HR admin
class HRTaskAdmin(admin.ModelAdmin):
    list_display = ('task_name', 'task_owner', 'start_date', 'due_date', 'reminder', 'priority', 'status', 'days_until_due', 'is_overdue', 'is_due_soon')
    list_filter = ('priority', 'status')
    search_fields = ('task_name', 'description')
    date_hierarchy = 'due_date'

    def days_until_due(self, obj):
        """
        Method to calculate and return the number of days until the task is due.
        """
        remaining_days = (obj.due_date - timezone.now().date()).days
        return max(remaining_days, 0)
    days_until_due.short_description = 'Days Until Due'

    def is_overdue(self, obj):
        """
        Method to check if the task is overdue.
        """
        return obj.days_until_due() < 0
    is_overdue.boolean = True
    is_overdue.short_description = 'Overdue'

    def is_due_soon(self, obj):
        """
        Method to check if the task is due soon based on a given threshold in days.
        """
        return 0 <= obj.days_until_due() <= 7
    is_due_soon.boolean = True
    is_due_soon.short_description = 'Due Soon'

hr_admin_site.register(Task, HRTaskAdmin)