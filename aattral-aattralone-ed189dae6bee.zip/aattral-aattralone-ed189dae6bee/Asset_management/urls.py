from django.urls import path, include

urlpatterns = [
    path('organization/', include('Asset_management.organization.urls')),
    # path('asset/', include('Asset_management.Asset.urls')),
    path('asset/', include('Asset_management.Assets.urls')),

]
