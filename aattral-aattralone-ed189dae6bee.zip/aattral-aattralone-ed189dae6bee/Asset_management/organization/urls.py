# urls.py
from django.urls import path, include
from rest_framework.routers import DefaultRouter
from .views import (CountryViewSet, CurrencyViewSet, TimezoneViewSet, CompanyViewSet,SiteViewSet,LocationViewSet,
CategoryViewSet,DepartmentsViewSet,PersonViewSet,CustomerViewSet
)


router = DefaultRouter()
router.register(r'countries', CountryViewSet)
router.register(r'currencies', CurrencyViewSet)
router.register(r'timezones', TimezoneViewSet)
router.register(r'companies', CompanyViewSet)
router.register(r'sites', SiteViewSet)
router.register(r'locations', LocationViewSet)
router.register(r'category', CategoryViewSet)
router.register(r'departments', DepartmentsViewSet)
router.register(r'persons', PersonViewSet)
router.register(r'customers', CustomerViewSet)


urlpatterns = [
    path('', include(router.urls)),
]
