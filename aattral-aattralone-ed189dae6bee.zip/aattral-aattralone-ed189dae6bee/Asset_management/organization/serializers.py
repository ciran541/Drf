# serializers.py
from rest_framework import serializers
from .models import Country, Currency, Timezone, Company,Site,Location,Category,Departments,Person,Customer

class CountrySerializer(serializers.ModelSerializer):
    class Meta:
        model = Country
        fields = '__all__'
        ref_name = 'orgcountry'

class CurrencySerializer(serializers.ModelSerializer):
    class Meta:
        model = Currency
        fields = '__all__'

class TimezoneSerializer(serializers.ModelSerializer):
    class Meta:
        model = Timezone
        fields = '__all__'

class CompanySerializer(serializers.ModelSerializer):
    class Meta:
        model = Company
        fields = '__all__'

class SiteSerializer(serializers.ModelSerializer):
    class Meta:
        model = Site
        fields = '__all__'

class LocationSerializer(serializers.ModelSerializer):
    class Meta:
        model = Location
        fields = '__all__'

class LocationdetailSerializer(serializers.ModelSerializer):
    site = SiteSerializer()
    class Meta:
        model = Location
        fields = '__all__'

class CategorySerializer(serializers.ModelSerializer):
    class Meta:
        model = Category
        fields = '__all__'

class DepartmentsSerializer(serializers.ModelSerializer):
    class Meta:
        model = Departments
        fields = '__all__'
        ref_name = 'assetdepartment'

class PersonSerializer(serializers.ModelSerializer):

    site = SiteSerializer()
    location = LocationdetailSerializer()
    department = DepartmentsSerializer()

    class Meta:
        model = Person
        fields = '__all__'

class PersondetailSerializer(serializers.ModelSerializer):

    class Meta:
        model = Person
        fields = '__all__'


class CustomerSerializer(serializers.ModelSerializer):
    class Meta:
        model = Customer
        fields = '__all__'
        ref_name = 'orgcustomer'