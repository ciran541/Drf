# admin.py

from django.contrib import admin
from .models import Country, Currency, Timezone, Company, Site, Location, Category, Departments,Person,Customer

# Register your models here.

@admin.register(Country)
class CountryAdmin(admin.ModelAdmin):
    list_display = ('code', 'name')

@admin.register(Currency)
class CurrencyAdmin(admin.ModelAdmin):
    list_display = ('code', 'name')

@admin.register(Timezone)
class TimezoneAdmin(admin.ModelAdmin):
    list_display = ('name',)

@admin.register(Company)
class CompanyAdmin(admin.ModelAdmin):
    list_display = ('name', 'country', 'city', 'state_province', 'postal_code', 'timezone', 'currency', 'date_format', 'financial_year_month', 'registration_date', 'active')
    list_filter = ('country', 'timezone', 'currency', 'active')
    search_fields = ('name', 'city', 'state', 'postal_code')

@admin.register(Site)
class SiteAdmin(admin.ModelAdmin):
    list_display = ('description', 'address', 'apt_suite', 'city', 'state', 'postal_code', 'country')

@admin.register(Location)
class LocationAdmin(admin.ModelAdmin):
    list_display = ('name', 'site')

@admin.register(Category)
class CategoryAdmin(admin.ModelAdmin):
    list_display = ('name', 'description')

@admin.register(Departments)
class DepartmentsAdmin(admin.ModelAdmin):
    list_display = ('name', 'description')

admin.site.register(Person)
admin.site.register(Customer)