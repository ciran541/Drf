from django.db import models
import pycountry
import pytz
from forex_python.converter import CurrencyCodes


class Country(models.Model):
    code = models.CharField(max_length=3, unique=True)
    name = models.CharField(max_length=255)

    def __str__(self):
        return self.name
    
class Currency(models.Model):
    code = models.CharField(max_length=3, unique=True)
    name = models.CharField(max_length=255)

    def __str__(self):
        return self.name

class Timezone(models.Model):
    name = models.CharField(max_length=255)

    def __str__(self):
        return self.name

# Populate the Country model with data from pycountry
for country in pycountry.countries:
    Country.objects.get_or_create(
        code=country.alpha_3,
        name=country.name
    )

# Populate the Currency model with data from forex-python
def populate_currencies():
    currency_codes = CurrencyCodes()
    currencies = currency_codes.get_symbol()
    for code, name in currencies.items():
        Currency.objects.get_or_create(
            code=code,
            name=name
        )

# Populate the TimeZone model with data 
timezones = [(tz, tz) for tz in pytz.all_timezones]

for timezone_data in timezones:
    Timezone.objects.get_or_create(
        name=timezone_data[0]
    )

class Company(models.Model):
    
    # Choices for date format field
    DATE_FORMAT_CHOICES = (
        ('MM/DD/YYYY', 'MM/DD/YYYY'),
        ('DD/MM/YYYY', 'DD/MM/YYYY'),
        ('YYYY/MM/DD', 'YYYY/MM/DD'),
        # Add more choices as needed
    )

    name = models.CharField(max_length=255)
    country = models.ForeignKey(Country, on_delete=models.SET_NULL, null=True, blank=True)
    street_address = models.CharField(max_length=255)
    apartment_suite_number = models.CharField(max_length=100, blank=True, null=True)
    city = models.CharField(max_length=100)
    state_province = models.CharField(max_length=100)
    postal_code = models.CharField(max_length=20)
    timezone = models.ForeignKey(Timezone, on_delete=models.SET_NULL, null=True, blank=True)
    currency = models.ForeignKey(Currency, on_delete=models.SET_NULL, null=True, blank=True)
    date_format = models.CharField(max_length=20, choices=DATE_FORMAT_CHOICES)
    financial_year_month = models.DateField()  # Month number
    company_logo = models.ImageField(upload_to='company_logos/', null=True, blank=True)
    
    # Additional fields
    registration_date = models.DateField(auto_now_add=True)
    active = models.BooleanField(default=True)


    def __str__(self):
        return self.name

# Model for Site 

'''
The Site may be a building or address. This means that you can better track each asset that is assigned to a given Site. 
A detailed Site makes it easy to find and count each asset.
'''

class Site(models.Model):
    name = models.CharField(max_length=255, blank=True)
    description = models.CharField(max_length=255,blank=True,null=True)
    address = models.CharField(max_length=255,blank=True,null=True)
    apt_suite = models.CharField(max_length=100, blank=True, null=True)
    city = models.CharField(max_length=100,blank=True)
    state = models.CharField(max_length=100,blank=True)
    postal_code = models.CharField(max_length=20,blank=True)
    country = models.ForeignKey(Country, on_delete=models.SET_NULL, related_name='country_for_Site', null=True, blank=True)
   

'''
Locations are a subset of Sites. For example, the Site may be a building or address. 
The Location may be a specific room, office or floor within the Site. Select a Site and add your list of Locations here.
'''

class Location(models.Model):
    site = models.ForeignKey('Site', related_name='locations', on_delete=models.CASCADE)
    name = models.CharField(max_length=255)
    

    def __str__(self):
        return f"{self.name} at {self.site}"
    

'''  
type of groups of assets. To start with, commonly used categories have already been created for you. 
Make them as broad or as specific as you want. Categories can be 'laptops and printers', 'equipment', or 'chairs'. Customize to your particular need.
'''

class Category(models.Model):
    name = models.CharField(max_length=100)
    description = models.CharField(max_length=255,blank=True)

    def __str__(self):
        return self.name
    
'''
Departments that own or house the particular assets. Make them as broad or as specific as you want. 
Departments can be 'Accounting', 'Marketing', or 'Executive'. Customize to your particular need.
'''

class Departments (models.Model):
    name = models.CharField(max_length=100)
    description = models.CharField(max_length=255,blank=True)

    def __str__(self):
        return self.name
    

'''
Manage the persons/employees we want in the database. After we add persons/employees, we can review reports and check assets in and out.
'''

class Person(models.Model):
    name = models.CharField(max_length=255)
    employee_id = models.CharField(max_length=50, unique=True)
    title = models.CharField(max_length=100)
    phone = models.CharField(max_length=20)
    email = models.EmailField(max_length=255)
    site = models.ForeignKey('Site', on_delete=models.CASCADE)
    location = models.ForeignKey('Location', on_delete=models.CASCADE)
    department = models.ForeignKey('Departments', on_delete=models.CASCADE)
    notes = models.TextField(blank=True)

    def __str__(self):
        return self.name

'''
Manage the Customer we want in the database. After we add Customer, we can review reports and check assets in and out.

'''

class Customer(models.Model):
    name = models.CharField(max_length=255,blank=True)
    company = models.CharField(max_length=255, blank=True, null=True)
    address1 = models.CharField(max_length=255,blank=True)
    address2 = models.CharField(max_length=255, blank=True, null=True)
    city = models.CharField(max_length=100,blank=True)
    state = models.CharField(max_length=100,blank=True)
    zip_code = models.CharField(max_length=20,blank=True)
    country = models.CharField(max_length=100,blank=True)
    phone = models.CharField(max_length=20, blank=True, null=True)
    cell = models.CharField(max_length=20, blank=True, null=True)
    email = models.EmailField(max_length=255, blank=True, null=True)
    notes = models.TextField(blank=True, null=True)
    
    def __str__(self):
        return self.name