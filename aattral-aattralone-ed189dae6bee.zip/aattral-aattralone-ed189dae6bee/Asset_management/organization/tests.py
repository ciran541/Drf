from django.test import TestCase
from .models import Customer

class CustomerTestCase(TestCase):
    def setUp(self):
        # Create a test customer
        self.customer = Customer.objects.create(
            name="John Doe",
            company="ABC Inc.",
            address1="123 Main St",
            address2="Apt 101",
            city="Anytown",
            state="CA",
            zip_code="12345",
            country="USA",
            phone="123-456-7890",
            cell="987-654-3210",
            email="johndoe@example.com",
            notes="This is a test customer."
        )

    def test_customer_str(self):
        # Test the string representation (__str__ method) of Customer
        expected_str = "John Doe"
        self.assertEqual(str(self.customer), expected_str)

    def test_customer_fields(self):
        # Test individual fields of the customer object
        self.assertEqual(self.customer.name, "John Doe")
        self.assertEqual(self.customer.company, "ABC Inc.")
        self.assertEqual(self.customer.address1, "123 Main St")
        self.assertEqual(self.customer.address2, "Apt 101")
        self.assertEqual(self.customer.city, "Anytown")
        self.assertEqual(self.customer.state, "CA")
        self.assertEqual(self.customer.zip_code, "12345")
        self.assertEqual(self.customer.country, "USA")
        self.assertEqual(self.customer.phone, "123-456-7890")
        self.assertEqual(self.customer.cell, "987-654-3210")
        self.assertEqual(self.customer.email, "johndoe@example.com")
        self.assertEqual(self.customer.notes, "This is a test customer.")

    def test_customer_blank_fields(self):
        # Test blank fields (null=True fields)
        self.assertIsNone(self.customer.email)  # email field is blank
        self.assertIsNone(self.customer.notes)  # notes field is blank
        # Ensure phone and cell can be blank but not None
        self.assertEqual(self.customer.phone, "123-456-7890")
        self.assertEqual(self.customer.cell, "987-654-3210")
