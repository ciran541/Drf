# views.py
from rest_framework import viewsets
from django.db.models import Q
from rest_framework.response import Response
from rest_framework.decorators import action
from .models import Country, Currency, Timezone, Company,Site,Location,Category,Departments,Person,Customer
from .serializers import (CountrySerializer, CurrencySerializer, TimezoneSerializer, CompanySerializer,SiteSerializer,
LocationSerializer,CategorySerializer,DepartmentsSerializer,PersonSerializer,CustomerSerializer,LocationdetailSerializer,PersondetailSerializer
)


class CountryViewSet(viewsets.ModelViewSet):
    queryset = Country.objects.all()
    serializer_class = CountrySerializer

class CurrencyViewSet(viewsets.ModelViewSet):
    queryset = Currency.objects.all()
    serializer_class = CurrencySerializer

class TimezoneViewSet(viewsets.ModelViewSet):
    queryset = Timezone.objects.all()
    serializer_class = TimezoneSerializer

class CompanyViewSet(viewsets.ModelViewSet):
    queryset = Company.objects.all()
    serializer_class = CompanySerializer

class SiteViewSet(viewsets.ModelViewSet):
    queryset = Site.objects.all()
    serializer_class = SiteSerializer

class LocationViewSet(viewsets.ModelViewSet):
    queryset = Location.objects.all()

    def get_serializer_class(self):
        if self.request.method == 'GET':
            return LocationdetailSerializer
        return LocationSerializer

class CategoryViewSet(viewsets.ModelViewSet):
    queryset = Category.objects.all()
    serializer_class = CategorySerializer

class DepartmentsViewSet(viewsets.ModelViewSet):
    queryset = Departments.objects.all()
    serializer_class = DepartmentsSerializer

class PersonViewSet(viewsets.ModelViewSet):
    queryset = Person.objects.all()
    serializer_class = PersonSerializer

    def get_serializer_class(self):
        if self.request.method == 'GET':
            return PersondetailSerializer
        return PersonSerializer

    @action(detail=False, methods=['get'])
    def filter_persons(self, request):
        name = self.request.query_params.get('name')
        email = self.request.query_params.get('email')
        employee_id = self.request.query_params.get('employee_id')

        filters = Q()

        if name is not None:
            filters &= Q(name__icontains=name)

        if email is not None:
            filters &= Q(email=email)

        if employee_id is not None:
            filters &= Q(employee_id=employee_id)

        queryset = Person.objects.filter(filters)

        serializer = self.get_serializer(queryset, many=True)
        return Response(serializer.data)

class CustomerViewSet(viewsets.ModelViewSet):
    queryset = Customer.objects.all()
    serializer_class = CustomerSerializer

    @action(detail=False, methods=['get'])
    def search(self, request):
        name = request.query_params.get('name')
        company = request.query_params.get('company')
        email = request.query_params.get('email')

        filters = Q()

        if name:
            filters |= Q(name__icontains=name)

        if company:
            filters |= Q(company__icontains=company)

        if email:
            filters |= Q(email__icontains=email)

        queryset = Customer.objects.filter(filters)

        serializer = self.get_serializer(queryset, many=True)
        return Response(serializer.data)