# serializers.py

from rest_framework import serializers
from .models import (Asset,Photo, Doc, AssetWarranty, AssetMaintenance,Reservation,AssetCheckOut,AssetCheckIn,AssetDispose,Lease,Leasereturn,AssetMove,Audit)
from Asset_management.organization.serializers import SiteSerializer,LocationSerializer,CategorySerializer,DepartmentsSerializer,PersonSerializer,CustomerSerializer


class AssetWarrantySerializer(serializers.ModelSerializer):
    class Meta:
        model = AssetWarranty
        fields = '__all__'


class AssetDetailSerializer(serializers.ModelSerializer):
    site = SiteSerializer()
    location = LocationSerializer()
    category = CategorySerializer()
    department = DepartmentsSerializer()
    
    
    class Meta:
        model = Asset
        fields = '__all__'

class AssetCreateSerializer(serializers.ModelSerializer):
    
    class Meta:
        model = Asset
        fields = '__all__'
class PhotoSerializer(serializers.ModelSerializer):
    class Meta:
        model = Photo
        fields = '__all__'

class DocSerializer(serializers.ModelSerializer):
    class Meta:
        model = Doc
        fields = '__all__'



class AssetMaintenanceDetailSerializer(serializers.ModelSerializer):
    asset = AssetCreateSerializer(many=True)
    

    class Meta:
        model = AssetMaintenance
        fields = '__all__'

class AssetMaintenanceCreateSerializer(serializers.ModelSerializer):
    class Meta:
        model = AssetMaintenance
        fields = '__all__'
class ReservationDetailSerializer(serializers.ModelSerializer):
    asset = AssetDetailSerializer()
    person = PersonSerializer()
    site = SiteSerializer()
    location = LocationSerializer()
    customer = CustomerSerializer()

    class Meta:
        model = Reservation
        fields = '__all__'

class ReservationCreateUpdateSerializer(serializers.ModelSerializer):
    class Meta:
        model = Reservation
        fields = '__all__'




class AssetCheckOutDetailSerializer(serializers.ModelSerializer):
    asset = AssetCreateSerializer(many=True, read_only=True)
    assigned_to = PersonSerializer()
    site= SiteSerializer()
    location= LocationSerializer()
    department = DepartmentsSerializer()

    class Meta:
        model = AssetCheckOut
        fields = '__all__'

class AssetCheckOutCreateSerializer(serializers.ModelSerializer):
    class Meta:
        model = AssetCheckOut
        fields = '__all__'

class AssetCheckInDetailSerializer(serializers.ModelSerializer):
    asset = AssetDetailSerializer(many=True)
    site = SiteSerializer()
    location= LocationSerializer()
    department = DepartmentsSerializer()

    class Meta:
        model = AssetCheckIn
        fields = '__all__'

class AssetCheckInCreateSerializer(serializers.ModelSerializer):
    class Meta:
        model = AssetCheckIn
        fields = '__all__'

class AssetDisposeSerializer(serializers.ModelSerializer):
    class Meta:
        model = AssetDispose
        fields = '__all__'

class LeaseDetailSerializer(serializers.ModelSerializer):
    asset = AssetCreateSerializer(many=True, read_only=True)
    # assigned_to = PersonSerializer()
    site = SiteSerializer()
    location = LocationSerializer()
    lease_to = CustomerSerializer()

    class Meta:
        model = Lease
        fields = '__all__'

class LeaseCreateUpdateSerializer(serializers.ModelSerializer):
    class Meta:
        model = Lease
        fields = '__all__'
class LeasereturnDetailSerializer(serializers.ModelSerializer):
    check_out = LeaseCreateUpdateSerializer(many=True,read_only=True)

    class Meta:
        model = Leasereturn
        fields = '__all__'

class LeasereturnCreateSerializer(serializers.ModelSerializer):
    class Meta:
        model = Leasereturn
        fields = '__all__'
class AssetMoveDetailSerializer(serializers.ModelSerializer):
    assets = AssetCreateSerializer(many=True, read_only=True)
    site = SiteSerializer()
    location = LocationSerializer()
    department = DepartmentsSerializer()

    class Meta:
        model = AssetMove
        fields = '__all__'

class AssetMoveCreateUpdateSerializer(serializers.ModelSerializer):
    class Meta:
        model = AssetMove
        fields = '__all__'

class AuditDetailSerializer(serializers.ModelSerializer):
    site = SiteSerializer()
    location = LocationSerializer()
    category = CategorySerializer()
    assets = AssetCreateSerializer(many=True)

    class Meta:
        model = Audit
        fields = '__all__'

class AuditCreateUpdateSerializer(serializers.ModelSerializer):
    class Meta:
        model = Audit
        fields = '__all__'
# class ChangeLogSerializer(serializers.ModelSerializer):
#     class Meta:
#         model = ChangeLog
#         fields = '__all__'


class AssetWarrantydetailSerializer(serializers.ModelSerializer):
    asset = AssetDetailSerializer()
    class Meta:
        model = AssetWarranty
        fields = '__all__'