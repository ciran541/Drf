from rest_framework import viewsets,status
from rest_framework.decorators import action
from rest_framework.response import Response
from datetime import timedelta
from datetime import timezone
from datetime import datetime
from .models import Asset,Photo, Doc, AssetWarranty, AssetMaintenance,Reservation,AssetCheckOut,AssetCheckIn,AssetDispose,Lease,Leasereturn,AssetMove,Audit
from .serializers import (AssetDetailSerializer,AssetCreateSerializer,PhotoSerializer, DocSerializer, AssetWarrantySerializer,
                          AuditDetailSerializer,AuditCreateUpdateSerializer
,AssetDisposeSerializer,LeaseDetailSerializer, LeaseCreateUpdateSerializer,AssetMaintenanceCreateSerializer,
AssetMaintenanceDetailSerializer,ReservationCreateUpdateSerializer,ReservationDetailSerializer,AssetCheckOutCreateSerializer,
AssetCheckOutDetailSerializer,AssetCheckInCreateSerializer,AssetCheckInDetailSerializer,LeasereturnCreateSerializer,LeasereturnDetailSerializer,
AssetMoveCreateUpdateSerializer,AssetMoveDetailSerializer,AssetWarrantydetailSerializer
)

class AssetViewSet(viewsets.ModelViewSet):
    queryset = Asset.objects.all()

    def get_serializer_class(self):
        if self.request.method == 'GET':
            return AssetDetailSerializer
        return AssetCreateSerializer

    @action(detail=False, methods=['put', 'patch'])
    def update_statuses(self, request):
        """
        Custom action to update the status of multiple assets.
        Expects a list of asset IDs and the new status.
        """
        asset_ids = request.data.get('asset_ids', [])
        new_status = request.data.get('status')

        if not asset_ids:
            return Response({'error': 'Asset IDs field is required.'}, status=status.HTTP_400_BAD_REQUEST)
        if not new_status:
            return Response({'error': 'Status field is required.'}, status=status.HTTP_400_BAD_REQUEST)

        assets = Asset.objects.filter(pk__in=asset_ids)
        assets.update(status=new_status)

        serializer = self.get_serializer(assets, many=True)
        return Response(serializer.data)
    
    @action(detail=False, methods=['get'])
    def get_assets_by_status(self, request):
        """
        Custom action to get assets by status.
        """
        status_param = request.query_params.get('status')
        if not status_param:
            return Response({'error': 'Status parameter is required.'}, status=status.HTTP_400_BAD_REQUEST)
        
        assets = Asset.objects.filter(status=status_param)
        serializer = self.get_serializer(assets, many=True)
        return Response(serializer.data)


    @action(detail=False, methods=['get'])
    def search(self, request):
        """
        Custom action to search for assets based on a search query.
        """
        query = request.query_params.get('query', None)
        if query is not None:
            assets = Asset.objects.filter(asset_name__icontains=query)
            serializer = self.get_serializer(assets, many=True)
            return Response(serializer.data)
        else:
            assets = []
            serializer = self.get_serializer(assets, many=True)
            return Response(serializer.data)
        
    @action(detail=True, methods=['get'])
    def sub_assets(self, request, pk=None):
        """
        Custom action to retrieve the sub-assets of a specific asset.
        """
        asset = self.get_object()
        sub_assets = asset.get_sub_assets()
        serializer = self.get_serializer(sub_assets, many=True)
        return Response(serializer.data)
    
    @action(detail=False, methods=['get'])
    def get_assets_by_name(self, request):
        """
        Custom action to retrieve assets by asset_name.
        """
        asset_name = request.query_params.get('asset_name')
        assets = Asset.objects.filter(asset_name__icontains=asset_name)
        serializer = self.get_serializer(assets, many=True)
        return Response(serializer.data)

    @action(detail=False, methods=['get'])
    def get_assets_by_site(self, request):
        """
        Custom action to retrieve assets by site.
        """
        site_id = request.query_params.get('site_id')
        assets = Asset.objects.filter(site_id=site_id)
        serializer = self.get_serializer(assets, many=True)
        return Response(serializer.data)

    @action(detail=False, methods=['get'])
    def get_assets_by_location(self, request):
        """
        Custom action to retrieve assets by location.
        """
        location_id = request.query_params.get('location_id')
        assets = Asset.objects.filter(location_id=location_id)
        serializer = self.get_serializer(assets, many=True)
        return Response(serializer.data)

    @action(detail=False, methods=['get'])
    def get_assets_by_department(self, request):
        """
        Custom action to retrieve assets by department.
        """
        department_id = request.query_params.get('department_id')
        assets = Asset.objects.filter(department_id=department_id)
        serializer = self.get_serializer(assets, many=True)
        return Response(serializer.data)

    @action(detail=False, methods=['get'])
    def get_assets_by_category(self, request):
        """
        Custom action to retrieve assets by category.
        """
        category_id = request.query_params.get('category_id')
        assets = Asset.objects.filter(category_id=category_id)
        serializer = self.get_serializer(assets, many=True)
        return Response(serializer.data)
    
    @action(detail=True, methods=['get'])
    def photos(self, request, pk=None):
        asset = self.get_object()
        photos = Photo.objects.filter(asset=asset)
        serializer = PhotoSerializer(photos, many=True)
        return Response(serializer.data)

    @action(detail=True, methods=['get'])
    def docs(self, request, pk=None):
        asset = self.get_object()
        docs = Doc.objects.filter(asset=asset)
        serializer = DocSerializer(docs, many=True)
        return Response(serializer.data)
    
    # @action(detail=True, methods=['get'])
    # def warranty(self, request, pk=None):
    #     """
    #     Custom action to retrieve asset warranty by asset primary key (pk).
    #     """
    #     try:
    #         asset = self.get_object()
    #         asset_warranty = AssetWarranty.objects.get(asset=asset)
    #         serializer = AssetWarrantydetailSerializer(asset_warranty)
    #         return Response(serializer.data)
    #     except AssetWarranty.DoesNotExist:
    #         return Response({'error': 'Asset warranty not found for this asset'}, status=404)
        
    # @action(detail=True, methods=['get'])
    # def maintenance_asset(self, request, pk=None):
    #     """
    #     Custom action to retrieve asset maintenance tasks by asset primary key (pk).
    #     """
    #     try:
    #         asset = self.get_object()
    #         maintenance_tasks = AssetMaintenance.objects.filter(asset=asset)
    #         serializer = AssetMaintenanceDetailSerializer(maintenance_tasks, many=True)
    #         return Response(serializer.data)
    #     except AssetMaintenance.DoesNotExist:
    #         return Response({'error': 'No maintenance tasks found for this asset'}, status=404)
        
    # @action(detail=True, methods=['get'])
    # def reservations(self, request, pk=None):
    #     """
    #     Custom action to retrieve reservations by asset primary key (pk).
    #     """
    #     try:
    #         asset = self.get_object()
    #         reservations = Reservation.objects.filter(asset=asset)
    #         serializer = ReservationDetailSerializer(reservations, many=True)
    #         return Response(serializer.data)
    #     except Asset.DoesNotExist:
    #         return Response({'error': 'Asset not found'}, status=404)
        
    # @action(detail=True, methods=['get'])
    # def audit(self, request, pk=None):
    #     """
    #     Custom action to retrieve audits by asset primary key (pk).
    #     """
    #     try:
    #         asset = self.get_object()
    #         audits = Audit.objects.filter(asset=asset)  # Filter audits by asset primary key
    #         serializer = AuditDetailSerializer(audits, many=True)
    #         return Response(serializer.data)
    #     except Audit.DoesNotExist:
    #         return Response({'error': 'Audits not found for this asset'}, status=404)

class PhotoViewSet(viewsets.ModelViewSet):
    queryset = Photo.objects.all()
    serializer_class = PhotoSerializer


class DocViewSet(viewsets.ModelViewSet):
    queryset = Doc.objects.all()
    serializer_class = DocSerializer


class AssetWarrantyViewSet(viewsets.ModelViewSet):
    queryset = AssetWarranty.objects.all()
    serializer_class = AssetWarrantySerializer


    def get_serializer_class(self):
        if self.request.method == 'GET':
            return AssetWarrantydetailSerializer
        return AssetWarrantySerializer

    @action(detail=False, methods=['get'])
    def get_by_asset(self, request):
        """
        Custom action to retrieve asset warranty by asset_id.
        """
        asset_id = request.query_params.get('asset_id')
        
        try:
            asset_warranties = AssetWarranty.objects.filter(asset_id=asset_id)
            serializer = self.get_serializer(asset_warranties, many=True)
            return Response(serializer.data)
        except AssetWarranty.DoesNotExist:
            return Response([], status=200)

class AssetMaintenanceViewSet(viewsets.ModelViewSet):
    queryset = AssetMaintenance.objects.all()

    def get_serializer_class(self):
        if self.request.method == 'GET':
            return AssetMaintenanceDetailSerializer
        return AssetMaintenanceCreateSerializer

    @action(detail=False, methods=['get'])
    def get_by_asset(self, request):
        """
        Custom action to retrieve asset maintenance tasks by asset_id.
        """
        asset_id = request.query_params.get('asset_id')
        maintenance_tasks = AssetMaintenance.objects.filter(asset__asset_id=asset_id)
        serializer = self.get_serializer(maintenance_tasks, many=True)
        return Response(serializer.data)

    @action(detail=False, methods=['get'])
    def get_by_maintenance_by(self, request):
        """
        Custom action to retrieve asset maintenance tasks by maintenance_by.
        """
        maintenance_by_id = request.query_params.get('maintenance_by')
        maintenance_tasks = AssetMaintenance.objects.filter(maintenance_by_id=maintenance_by_id)
        serializer = self.get_serializer(maintenance_tasks, many=True)
        return Response(serializer.data)
    
    @action(detail=False, methods=['get'])
    def get_by_due_date(self, request):
        """
        Custom action to retrieve asset maintenance tasks by due date.
        """
        due_date = request.query_params.get('due_date')
        maintenance_tasks = AssetMaintenance.objects.filter(due_date=due_date)
        serializer = self.get_serializer(maintenance_tasks, many=True)
        return Response(serializer.data)

    @action(detail=False, methods=['get'])
    def get_past_due(self, request):
        """
        Custom action to retrieve past due asset maintenance tasks.
        """
        past_due_tasks = AssetMaintenance.objects.filter(due_date__lt=datetime.now().date())
        serializer = self.get_serializer(past_due_tasks, many=True)
        return Response(serializer.data)

    @action(detail=False, methods=['get'])
    def get_within_timeframe(self, request):
        """
        Custom action to retrieve asset maintenance tasks within a specified timeframe.
        """
        start_date = request.query_params.get('start_date')
        end_date = request.query_params.get('end_date')
        maintenance_tasks = AssetMaintenance.objects.filter(due_date__range=[start_date, end_date])
        serializer = self.get_serializer(maintenance_tasks, many=True)
        return Response(serializer.data)

class ReservationViewSet(viewsets.ModelViewSet):
    queryset = Reservation.objects.all()

    def get_serializer_class(self):
        if self.request.method in ['POST', 'PUT', 'PATCH']:
            return ReservationCreateUpdateSerializer
        return ReservationDetailSerializer
    
    @action(detail=False, methods=['get'])
    def get_by_asset(self, request):
        """
        Custom action to retrieve reservations by asset_id.
        """
        asset_id = request.query_params.get('asset_id')
        if not asset_id:
            return Response({'error': 'asset_id parameter is required'}, status=400)
        
        reservations = Reservation.objects.filter(asset__asset_id=asset_id)
        serializer = self.get_serializer(reservations, many=True)
        return Response(serializer.data)

    """
    Here we  using different approch .Here we use to get response in single action 
    to handle filtering by any combination of person, site, location, or customer. 
    """

    def filter_reservations(self, request):
        """
        Action to filter reservations by person, site, location, or customer.
        """
        person_id = request.query_params.get('person_id')
        site_id = request.query_params.get('site_id')
        location_id = request.query_params.get('location_id')
        customer_id = request.query_params.get('customer_id')

        filters = {}
        if person_id:
            filters['person_id'] = person_id
        if site_id:
            filters['site_id'] = site_id
        if location_id:
            filters['location_id'] = location_id
        if customer_id:
            filters['customer_id'] = customer_id

        reservations = Reservation.objects.filter(**filters)
        serializer = self.get_serializer(reservations, many=True)
        return Response(serializer.data)

class AssetCheckOutViewSet(viewsets.ModelViewSet):
    queryset = AssetCheckOut.objects.all()

    def get_serializer_class(self):
        if self.request.method == 'GET':
            return AssetCheckOutDetailSerializer
        elif self.request.method in ['POST', 'PUT', 'PATCH']:
            return AssetCheckOutCreateSerializer
        return AssetCheckOutDetailSerializer
    
    @action(detail=False, methods=['get'])
    def get_latest_by_asset(self, request):
        """
        Custom action to retrieve the latest added AssetCheckOut entry by asset ID.
        """
        asset_id = request.query_params.get('asset_id')
        
        # Get the latest checkout entry for the specified asset
        latest_checkout = AssetCheckOut.objects.filter(asset__asset_id=asset_id).order_by('-check_out_date', '-id').first()
        
        if latest_checkout is not None:
            serializer = self.get_serializer(latest_checkout)
            return Response(serializer.data)
        else:
            return Response([], status=status.HTTP_200_OK)
    
    @action(detail=False, methods=['get'])
    def get_by_person(self, request):
        """
        Custom action to retrieve AssetCheckOut instances assigned to a specific person.
        """
        person_name = request.query_params.get('person_name')
        checkouts = AssetCheckOut.objects.filter(assigned_to=person_name)
        serializer = self.get_serializer(checkouts, many=True)
        return Response(serializer.data)

    @action(detail=False, methods=['get'])
    def get_by_asset(self, request):
        """
        Custom action to retrieve AssetCheckOut instances associated with a specific asset.
        """
        asset_id = request.query_params.get('asset_id')
        checkouts = AssetCheckOut.objects.filter(asset__asset_id=asset_id)
        serializer = self.get_serializer(checkouts, many=True)
        return Response(serializer.data)
    
    @action(detail=False, methods=['get'])
    def get_by_site(self, request):
        """
        Custom action to retrieve AssetCheckOut instances for a specific site.
        """
        site_name = request.query_params.get('site_name')
        checkouts = AssetCheckOut.objects.filter(site=site_name)
        serializer = self.get_serializer(checkouts, many=True)
        return Response(serializer.data)

    @action(detail=False, methods=['get'])
    def get_by_location(self, request):
        """
        Custom action to retrieve AssetCheckOut instances for a specific location.
        """
        location_name = request.query_params.get('location_name')
        checkouts = AssetCheckOut.objects.filter(location=location_name)
        serializer = self.get_serializer(checkouts, many=True)
        return Response(serializer.data)

    @action(detail=False, methods=['get'])
    def get_by_due_date(self, request):
        """
        Custom action to retrieve AssetCheckOut instances with a specific due date.
        """
        due_date = request.query_params.get('due_date')
        checkouts = AssetCheckOut.objects.filter(due_date=due_date)
        serializer = self.get_serializer(checkouts, many=True)
        return Response(serializer.data)

    @action(detail=False, methods=['get'])
    def get_past_due_checkouts(self, request):
        """
        Custom action to retrieve past due AssetCheckOut instances.
        """
        past_due_checkouts = AssetCheckOut.objects.filter(due_date__lt=timezone.now().date())
        serializer = self.get_serializer(past_due_checkouts, many=True)
        return Response(serializer.data)
class AssetCheckInViewSet(viewsets.ModelViewSet):
    queryset = AssetCheckIn.objects.all()

    def get_serializer_class(self):
        if self.request.method in['GET']:
            return AssetCheckInDetailSerializer
        return AssetCheckInCreateSerializer

class AssetDisposeViewSet(viewsets.ModelViewSet):
    queryset = AssetDispose.objects.all()
    serializer_class = AssetDisposeSerializer

    @action(detail=False, methods=['get'])
    def get_latest_by_asset_dispose(self, request):
        """
        Custom action to retrieve the latest added AssetDispose entry by asset ID.
        """
        asset_id = request.query_params.get('asset_id')
        
        # Get the latest dispose entry for the specified asset
        latest_dispose = AssetDispose.objects.filter(asset__asset_id=asset_id).order_by('-dispose_date', '-id').first()
        
        if latest_dispose is not None:
            serializer = self.get_serializer(latest_dispose)
            return Response(serializer.data)
        else:
            return Response([], status=status.HTTP_200_OK)


class LeaseViewSet(viewsets.ModelViewSet):
    queryset = Lease.objects.all()


    def get_serializer_class(self):
        if self.request.method in ['POST', 'PUT', 'PATCH']:
            return LeaseCreateUpdateSerializer
        return LeaseDetailSerializer
    
    @action(detail=False, methods=['get'])
    def get_latest_by_asset(self, request):
        """
        Custom action to retrieve the latest added Lease entry by asset ID.
        """
        asset_id = request.query_params.get('asset_id')
        
        # Get the latest lease entry for the specified asset
        latest_lease = Lease.objects.filter(asset__asset_id=asset_id).order_by('-start_date', '-id').first()
        
        if latest_lease is not None:
            serializer = self.get_serializer(latest_lease)
            return Response(serializer.data)
        else:
            return Response([], status=status.HTTP_200_OK)


    @action(detail=False, methods=['get'])
    def get_assets_by_customer(self, request):
        """
        Custom action to get leased assets by customer.
        """
        lease_to_id = request.query_params.get('lease_to_id')
        leases = Lease.objects.filter(lease_to_id=lease_to_id)
        serialized_data = LeaseDetailSerializer(leases, many=True).data
        return Response(serialized_data)

    @action(detail=False, methods=['get'])
    def get_assets_by_location(self, request):
        """
        Custom action to get leased assets by location.
        """
        location_id = request.query_params.get('location_id')
        leases = Lease.objects.filter(location_id=location_id)
        serialized_data = LeaseDetailSerializer(leases, many=True).data
        return Response(serialized_data)

    @action(detail=False, methods=['get'])
    def get_past_due_assets(self, request):
        """
        Custom action to get past due leased assets.
        """
        past_due_leases = [lease for lease in Lease.objects.all() if lease.is_past_due()]
        serialized_data = LeaseDetailSerializer(past_due_leases, many=True).data
        return Response(serialized_data)
    
    @action(detail=False, methods=['get'])
    def calculate_expiring_leases(self, request):
        """
        Custom action to calculate leases expiring within a specific timeframe and days left for expiration.
        """
        timeframe = int(request.query_params.get('timeframe', 7))  # Default 7 days
        today = timezone.now().date()
        end_date = today + timedelta(days=timeframe)
        expiring_leases = Lease.objects.filter(lease_expires__gte=today, lease_expires__lte=end_date)
        serialized_data = []
        for lease in expiring_leases:
            days_left = (lease.lease_expires - today).days
            lease_data = LeaseDetailSerializer(lease).data
            lease_data['days_left_until_expiry'] = days_left
            serialized_data.append(lease_data)
        return Response(serialized_data)

    @action(detail=False, methods=['get'])
    def get_assets_due_within_timeframe(self, request):
        """
        Custom action to get leased assets due within a specific timeframe.
        """
        timeframe = int(request.query_params.get('timeframe', 7))  # Default 7 days
        leases_within_timeframe = [lease for lease in Lease.objects.all() if lease.days_until_expiration() <= timeframe]
        serialized_data = LeaseDetailSerializer(leases_within_timeframe, many=True).data
        return Response(serialized_data)
    
class LeasereturnViewSet(viewsets.ModelViewSet):
    queryset = Leasereturn.objects.all()


    def get_serializer_class(self):
        if self.request.method in ['POST', 'PUT', 'PATCH']:
            return LeasereturnCreateSerializer
        return LeasereturnDetailSerializer
class AssetMoveViewSet(viewsets.ModelViewSet):
    queryset = AssetMove.objects.all()


    def get_serializer_class(self):
        if self.request.method in ['POST', 'PUT', 'PATCH']:
            return AssetMoveCreateUpdateSerializer
        return AssetMoveDetailSerializer

class AuditViewSet(viewsets.ModelViewSet):
    queryset = Audit.objects.all()


    def get_serializer_class(self):
        if self.request.method in ['POST', 'PUT', 'PATCH']:
            return AuditCreateUpdateSerializer
        return AuditDetailSerializer
    
    @action(detail=False, methods=['get'])
    def get_by_asset(self, request):
        """
        Custom action to retrieve audits by asset_id.
        """
        asset_id = request.query_params.get('asset_id')
        if not asset_id:
            return Response({'error': 'Asset ID is required as a query parameter'}, status=400)

        try:
            audits = Audit.objects.filter(asset__asset_id=asset_id)
            serializer = self.get_serializer(audits, many=True)
            return Response(serializer.data)
        except Audit.DoesNotExist:
            return Response([], status=200)
        

    @action(detail=True, methods=['post'])
    def update_status(self, request, pk=None):
        """
        Custom action to update the status of an audit.
        """
        audit = self.get_object()
        new_status = request.data.get('status')
        if new_status in dict(Audit.ASSET_STATUS_CHOICES).keys():
            audit.status = new_status
            audit.save()
            return Response({'message': 'Status updated successfully'})
        else:
            return Response({'error': 'Invalid status'}, status=400)

# class ChangeLogViewSet(viewsets.ModelViewSet):
#     queryset = ChangeLog.objects.all()
#     serializer_class = ChangeLogSerializer
