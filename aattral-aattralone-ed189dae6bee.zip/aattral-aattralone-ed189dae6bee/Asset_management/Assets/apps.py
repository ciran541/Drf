from django.apps import AppConfig


class AssetsConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'Asset_management.Assets'

    # def ready(self):
    #     import Asset_management.Assets.signal