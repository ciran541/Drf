
'''
This module is responsible for Asset Management 

Asset: Represents tangible items owned by an organization, storing details like name, 
description, purchase information, and location, while also offering methods for managing 
sub-assets and calculating total costs.

Photo: Allows attachment of photos to assets, enhancing visual documentation and identification.

Doc: Enables attachment of documents/files to assets, with additional information like 
description, file type, upload date, and uploader, aiding in comprehensive asset documentation.

AssetWarranty: Tracks warranty information for assets, including length, expiration 
date, and notes, ensuring timely management of warranty-related tasks.

AssetMaintenance: Manages maintenance tasks for assets, including title, status,
due date, and cost, facilitating proactive asset upkeep and longevity.

Reservation: Handles asset reservations for persons, sites/locations, or customers,
ensuring efficient asset utilization and scheduling.

AssetCheckOut: Tracks asset checkouts, recording details like assigned person, location,
and due date, facilitating effective asset tracking and management during temporary transfers.

AssetCheckIn: Records the check-in of assets previously checked out, maintaining 
a comprehensive history of asset movements and usage.

Lease: Manages leasing of assets, including lease duration, status, assigned 
person/customer, etc., enabling efficient management of leased assets.

Leasereturn: Records the return of leased assets, ensuring accurate tracking
and management of leased asset inventory.

AssetDispose: Handles the disposal of assets, including details like disposal date,
recipient, and notes, facilitating proper asset disposal procedures and documentation.

AssetMove: Tracks movements of assets from one site/location to another, including 
move date and destination, ensuring accurate asset location tracking.

Audit: Facilitates auditing of assets, including details like audit date, location, 
audited assets, and audit status, ensuring compliance and accountability in asset management.

ChangeLog: Records changes made to asset data over time, including field changes, 
previous and new values, and the user who made the change, providing a comprehensive 
audit trail for asset management activities.

'''







from django.db import models
from Asset_management.organization.models import Site, Category,Location,Departments
from Authentication.models import CustomUser
from Asset_management.organization.models import Person,Customer
from datetime import datetime
from datetime import date
from simple_history.models import HistoricalRecords



class Asset(models.Model):
    asset_id = models.AutoField(primary_key=True)
    asset_name = models.CharField(max_length=255)
    description = models.CharField(max_length=255, blank=True)
    asset_tag_id = models.CharField(max_length=100, blank=True)
    purchase_date = models.DateField(blank=True)
    cost = models.DecimalField(max_digits=10, decimal_places=2, blank=True)
    purchased_from = models.CharField(max_length=255, blank=True)
    brand = models.CharField(max_length=100, blank=True)
    model = models.CharField(max_length=100, blank=True)
    serial_no = models.CharField(max_length=100, blank=True)
    site = models.ForeignKey(Site, on_delete=models.SET_NULL, related_name='assets_site', null=True, blank=True)
    location = models.ForeignKey(Location, on_delete=models.SET_NULL, related_name='assets_location', null=True, blank=True)
    category = models.ForeignKey(Category, on_delete=models.SET_NULL, related_name='assets_category', null=True, blank=True)
    department = models.ForeignKey(Departments, on_delete=models.SET_NULL, related_name='assets_department', null=True, blank=True)
    asset_photo = models.ImageField(upload_to='asset_photos/', null=True, blank=True)
    ParentAsset = models.ForeignKey('self', on_delete=models.CASCADE, null=True, blank=True)
    status = models.CharField(max_length=20,blank=True, default='Available')
    history = HistoricalRecords()

    def get_sub_assets(self):
        """
        Method to get the sub-assets of the current asset.
        """
        return Asset.objects.filter(ParentAsset=self)
    
    @staticmethod
    def calculate_total_cost():
        """
        Static method to calculate the total cost of all assets.
        """
        total_cost = Asset.objects.aggregate(total_cost=models.Sum('cost'))['total_cost']
        return total_cost if total_cost is not None else 0

    def __str__(self):
        return self.asset_name
    

class Photo(models.Model):
    asset = models.ForeignKey('Asset', on_delete=models.CASCADE, related_name='photos')
    photo = models.ImageField(upload_to='photos/')


class Doc(models.Model):
    asset = models.ForeignKey('Asset', on_delete=models.CASCADE, related_name='docs',blank=True,null=True)
    description = models.CharField(max_length=255,blank=True)
    file_type = models.CharField(max_length=50,blank=True)
    file_name = models.CharField(max_length=255,blank=True)
    upload_date = models.DateTimeField(auto_now_add=True)
    upload_by = models.ForeignKey(CustomUser, on_delete=models.CASCADE,blank=True,null=True)  # Assuming you have a custom user model


class AssetWarranty(models.Model):
    asset = models.ForeignKey('Asset', on_delete=models.CASCADE, related_name='warranty',blank=True,null=True)
    length = models.IntegerField(blank=True,null=True)  # Assuming the length is in months
    expiration_date = models.DateField(blank=True,null=True)
    notes = models.TextField(blank=True, null=True)


class AssetMaintenance(models.Model):

    MAINTENANCE_STATUS_CHOICES = [
        ('Scheduled', 'Scheduled'),
        ('InProgress', 'In Progress'),
        ('Completed', 'Completed'),
        ('Failed', 'Failed'),
    ]

    FREQUENCY_CHOICES = [
        ('Daily', 'Daily'),
        ('Weekly', 'Weekly'),
        ('Monthly', 'Monthly'),
        ('Yearly', 'Yearly'),
    ]

    REPEATING_CHOICES = [
        ('Yes', 'Yes'),
        ('No', 'No'),
    ]

    asset = models.ManyToManyField('Asset')
    title = models.CharField(max_length=255,blank=True)
    details = models.TextField(blank=True)
    due_date = models.DateField(blank=True)
    maintenance_by = models.CharField(blank=True,max_length=255)  
    maintenance_status = models.CharField(max_length=20, choices=MAINTENANCE_STATUS_CHOICES,blank=True)
    date_completed = models.DateField(blank=True, null=True)
    maintenance_cost = models.DecimalField(max_digits=10, decimal_places=2, null=True, blank=True)
    repeating = models.CharField(max_length=3, choices=REPEATING_CHOICES,blank=True,null=True)
    frequency = models.CharField(max_length=10, choices=FREQUENCY_CHOICES,blank=True,null=True)

    def days_until_due(self):
        """
        Method to calculate the number of days until the maintenance is due.
        """
        if self.due_date:
            today = date.today()
            days_until_due = (self.due_date - today).days
            return max(days_until_due, 0)
        else:
            return None

    def is_past_due(self):
        """
        Method to check if the maintenance is past due.
        """
        if self.due_date:
            return self.due_date < date.today()
        else:
            return False
        
    def calculate_total_cost(self):
        """
        Method to calculate the total cost of the maintenance task.
        """
        if self.maintenance_cost:
            return self.maintenance_cost
        else:
            return None


class Reservation(models.Model):
    RESERVE_FOR_CHOICES = [
        ('person', 'Person'),
        ('site_location', 'Site / Location'),
        ('customer', 'Customer'),
    ]

    asset = models.ManyToManyField(Asset)
    schedule_start_date = models.DateField(blank=True)
    schedule_end_date = models.DateField(blank=True)
    number_of_days = models.PositiveIntegerField(blank=True)
    reserve_for = models.CharField(max_length=20, choices=RESERVE_FOR_CHOICES,blank=True)
    person = models.ForeignKey(Person, related_name='reservations', on_delete=models.CASCADE, null=True, blank=True)  
    site = models.ForeignKey(Site, related_name='Site_reservations', on_delete=models.CASCADE, null=True, blank=True)
    location = models.ForeignKey(Location, related_name='location_reservation', on_delete=models.CASCADE, null=True, blank=True)
    customer = models.ForeignKey(Customer, related_name='reservations', on_delete=models.CASCADE, null=True, blank=True) 
    notes = models.TextField(blank=True, null=True)

    
# Models for Check-in/Check-out

# Asset Check-Out

class AssetCheckOut(models.Model):
    
    asset = models.ManyToManyField(Asset)
    description = models.CharField(max_length=255,blank=True)
    assigned_to = models.ForeignKey(Person, related_name= 'AssetCheckOut_person', on_delete=models.CASCADE,null=True, blank=True)
    lease_to = models.CharField(max_length=255, blank=True, null=True)
    check_out_date = models.DateField()
    check_out_to = models.CharField(max_length=255, blank=True, null=True)  
    due_date = models.DateField()
    site = models.ForeignKey(Site, related_name='assetcheckout_site', on_delete=models.CASCADE, null=True, blank=True)
    location = models.ForeignKey(Location, related_name='assetcheckout_location', on_delete=models.CASCADE, null=True, blank=True)
    department = models.ForeignKey(Departments, on_delete=models.SET_NULL, related_name='assetcheckout_department', null=True, blank=True)
    notes = models.TextField(blank=True, null=True)

    def days_until_due(self):
        """
        Method to calculate the number of days until the due date of the checkout.
        """
        from datetime import datetime
        today = datetime.today().date()
        return (self.due_date - today).days

    def is_past_due(self):
        """
        Method to check if the checkout is past due.
        """
        return self.days_until_due() < 0
    
    

    

# Asset Check-Out --- That only can be checkin if already checkedout

class AssetCheckIn(models.Model):
    asset = models.ManyToManyField(Asset)
    check_in_date = models.DateField(blank=True,null=True)
    check_in_notes = models.TextField(blank=True, null=True)
    site = models.ForeignKey(Site, related_name='assetcheckin_site', on_delete=models.CASCADE, null=True, blank=True)
    location = models.ForeignKey(Location, related_name='assetcheckin_location', on_delete=models.CASCADE, null=True, blank=True)
    department = models.ForeignKey(Departments, on_delete=models.SET_NULL, related_name='assetcheckin_department', null=True, blank=True)
    notes = models.TextField(blank=True, null=True)



# Models for managing leaseing Assets 

class Lease(models.Model):

    asset = models.ManyToManyField(Asset)
    description = models.CharField(max_length=255,blank=True,null=True)
    # assigned_to  = models.ForeignKey(Person, related_name= 'lease_person', on_delete=models.CASCADE,null=True, blank=True)  
    site = models.ForeignKey(Site, related_name='Lease_site', on_delete=models.CASCADE, null=True, blank=True)
    location = models.ForeignKey(Location, related_name='Lease_location', on_delete=models.CASCADE, null=True, blank=True)
    lease_to =  models.ForeignKey(Customer, related_name='lease_customer', on_delete=models.CASCADE, null=True, blank=True) 
    lease_begins = models.DateField(blank=True,null=True)
    lease_expires = models.DateField(blank=True, null=True)
    lease_notes = models.TextField(blank=True, null=True)

    def is_past_due(self):
        """
        Method to check if the lease is past due.
        """
        return datetime.today().date() > self.lease_expires

    def days_until_expiration(self):
        """
        Method to calculate the number of days until lease expiration.
        """
        return (self.lease_expires - datetime.today().date()).days


class Leasereturn(models.Model):
    check_out = models.ManyToManyField(Asset)
    return_date = models.DateField(auto_now_add=True)
    return_notes = models.TextField(blank=True, null=True)


# Models for Dispose

class AssetDispose(models.Model):
    asset = models.ManyToManyField(Asset)
    description = models.CharField(max_length=255)
    dispose_date = models.DateField()
    dispose_to = models.CharField(max_length=255)
    dispose_notes = models.TextField(blank=True, null=True)

    def __str__(self):
        return f"{self.asset_tag_id} - {self.description}"

class AssetMove(models.Model):
    assets = models.ManyToManyField(Asset, related_name='moves')
    site = models.ForeignKey(Site, on_delete=models.CASCADE)
    location = models.ForeignKey(Location, on_delete=models.CASCADE)
    department = models.ForeignKey(Departments, on_delete=models.CASCADE, null=True, blank=True)
    move_date = models.DateTimeField(auto_now_add=True)


class Audit(models.Model):

    ASSET_STATUS_CHOICES = [
        ('Lock', 'Lock'),
        ('Unlock', 'Unlock'),
    ]
    name = models.CharField(max_length=255)
    site = models.ForeignKey(Site, on_delete=models.CASCADE)
    location = models.ForeignKey(Location, on_delete=models.CASCADE)
    category = models.ForeignKey(Category, on_delete=models.CASCADE)
    assets = models.ManyToManyField(Asset, related_name='Audit')
    audit_date = models.DateTimeField()
    audit_notes = models.TextField()
    status = models.CharField(max_length=20, choices=ASSET_STATUS_CHOICES, default='Unlock')


# class ChangeLog(models.Model):
#     asset = models.ForeignKey('Asset', on_delete=models.CASCADE)
#     date = models.DateTimeField(default=datetime.now)
#     event = models.CharField(max_length=100)  # e.g., 'Update', 'Delete'
#     field = models.CharField(max_length=100)  # Name of the field that changed
#     changed_from = models.CharField(max_length=255)  # Previous value
#     changed_to = models.CharField(max_length=255)    # New value
#     action_by = models.ForeignKey(CustomUser, on_delete=models.SET_NULL, null=True)  # User who performed the action

#     def __str__(self):
#         return f'{self.asset} - {self.field} - {self.date}'