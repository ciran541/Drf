from rest_framework.decorators import action
from rest_framework.response import Response
from rest_framework import viewsets
from django.db.models import Count
from django.db.models import Sum
from .models import Asset
from .serializers import AssetDetailSerializer,AssetCreateSerializer


# Dashboards endpoints related to Asset model
class AssetdashboardSet(viewsets.ModelViewSet):
    queryset = Asset.objects.all()
    ''' 
    Endpoints for Dashboard - Asset
    '''
    def get_serializer_class(self):
        if self.request.method == 'GET':
            return AssetDetailSerializer
        return AssetCreateSerializer
    
    # Custom action to get available assets.
    @action(detail=False, methods=['get'])
    def available_assets(self, request):
        """
        Retrieve available assets. Dashboard 
        """
        available_assets = Asset.objects.filter(status='Available')
        serializer = self.get_serializer(available_assets, many=True)
        return Response(serializer.data)
    
    @action(detail=False, methods=['get'])
    def assets_by_category(self, request):
        """
        Retrieve count of assets grouped by category.
        """
        assets_by_category = Asset.objects.values('category__name').annotate(count=Count('asset_id'))
        return Response(assets_by_category)

    @action(detail=False, methods=['get'])
    def assets_by_department(self, request):
        """
        Retrieve count of assets grouped by department.Dashboard
        """
        assets_by_department = Asset.objects.values('department__name').annotate(count=Count('asset_id'))
        return Response(assets_by_department)

    @action(detail=False, methods=['get'])
    def assets_by_location(self, request):
        """
        Retrieve count of assets grouped by location.Dashboard
        """
        assets_by_location = Asset.objects.values('location__name').annotate(count=Count('asset_id'))
        return Response(assets_by_location)

    @action(detail=False, methods=['get'])
    def assets_by_status(self, request):
        """
        Retrieve count of assets grouped by status.Dashboard
        """
        assets_by_status = Asset.objects.values('status').annotate(count=Count('asset_id'))
        return Response(assets_by_status)

    @action(detail=False, methods=['get'])
    def recently_added_assets(self, request):
        """
        Retrieve recently added assets.Dashboard
        """
        recently_added_assets = Asset.objects.order_by('-purchase_date')[:5]
        serializer = self.get_serializer(recently_added_assets, many=True)
        return Response(serializer.data)
    
    @action(detail=False, methods=['get'])
    def asset_values_by_category(self, request):
        """
        Retrieve total asset values grouped by category.Dashboard
        """
        asset_values_by_category = Asset.objects.values('category__name').annotate(total_value=Sum('cost'))
        return Response(asset_values_by_category)

    @action(detail=False, methods=['get'])
    def asset_values_by_location(self, request):
        """
        Retrieve total asset values grouped by location.Dashboard
        """
        asset_values_by_location = Asset.objects.values('location__name').annotate(total_value=Sum('cost'))
        return Response(asset_values_by_location)

    @action(detail=False, methods=['get'])
    def asset_values_by_department(self, request):
        """
        Retrieve total asset values grouped by department.Dashboard
        """
        asset_values_by_department = Asset.objects.values('department__name').annotate(total_value=Sum('cost'))
        return Response(asset_values_by_department)
    
    @action(detail=False, methods=['get'])
    def total_cost(self, request):
        """
        Custom action to retrieve the total cost of all assets.  Value of Assets.
        """
        total_cost = Asset.calculate_total_cost()
        return Response({'total_cost': total_cost})