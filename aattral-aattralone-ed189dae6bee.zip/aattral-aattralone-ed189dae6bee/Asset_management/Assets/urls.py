# urls.py

from django.urls import path, include
from rest_framework.routers import DefaultRouter
from .views import (AssetViewSet,PhotoViewSet, DocViewSet, AssetWarrantyViewSet, AssetMaintenanceViewSet,AuditViewSet,
ReservationViewSet,AssetCheckOutViewSet,AssetCheckInViewSet,AssetDisposeViewSet,LeaseViewSet,LeasereturnViewSet,AssetMoveViewSet
)

from .dashboard import AssetdashboardSet

router = DefaultRouter()
router.register(r'assets', AssetViewSet)
router.register(r'photos', PhotoViewSet)
router.register(r'docs', DocViewSet)
router.register(r'asset-warranties', AssetWarrantyViewSet)
router.register(r'asset-maintenances', AssetMaintenanceViewSet)
router.register(r'reservations', ReservationViewSet)
router.register(r'asset-checkout', AssetCheckOutViewSet)
router.register(r'asset-checkin', AssetCheckInViewSet)
router.register(r'asset-dispose', AssetDisposeViewSet)
router.register(r'leases', LeaseViewSet)
router.register(r'leasereturns', LeasereturnViewSet)
router.register(r'asset-moves', AssetMoveViewSet)
router.register(r'audits', AuditViewSet)

router.register(r'dashboards',AssetdashboardSet,basename='assetdashboard')

urlpatterns = [
    path('', include(router.urls)),
]

# For Reservation Filter 
# GET /base-url/filter_reservations/?person_id=1&site_id=2&location_id=3&customer_id=4: Filter reservations by all four parameters.
# GET /base-url/filter_reservations/?person_id=1: Filter reservations by person only.
# GET /base-url/filter_reservations/?customer_id=4: Filter reservations by customer only.