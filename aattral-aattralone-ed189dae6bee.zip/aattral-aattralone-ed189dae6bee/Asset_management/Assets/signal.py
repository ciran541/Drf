# from django.db.models.signals import post_save, post_delete
# from django.dispatch import receiver
# from .models import Asset, AssetCheckOut, Lease,Leasereturn,AssetCheckIn

# @receiver(post_save, sender=AssetCheckOut)
# def update_asset_status_on_checkout(sender, instance, created, **kwargs):
#     """
#     Updates the status of the associated Asset(s) to 'Checkedout' when a new AssetCheckOut instance is saved.

#     Args:
#         sender (AssetCheckOut): The sender of the signal (AssetCheckOut model).
#         instance (AssetCheckOut): The instance of the saved AssetCheckOut.
#         created (bool): Whether a new instance was created or an existing one was updated.
#     """

#     if created:  # Update status only when a new checkout is created
#         assets = instance.asset.all()
#         for asset in assets:
#             asset.status = 'Checkedout'
#             asset.save()

# @receiver(post_save, sender=Lease)
# def update_asset_status_on_lease(sender, instance, created, **kwargs):
#     """
#     Updates the status of the associated Asset(s) to 'Leased' when a new Lease instance is saved.

#     Args:
#         sender (Lease): The sender of the signal (Lease model).
#         instance (Lease): The instance of the saved Lease.
#         created (bool): Whether a new instance was created or an existing one was updated.
#     """

#     if created:  # Update status only when a new lease is created
#         assets = instance.asset.all()
#         for asset in assets:
#             asset.status = 'Leased'
#             asset.save()

# @receiver(post_save, sender=AssetCheckIn)
# def update_asset_status_on_checkin(sender, instance, created, **kwargs):
#     """
#     Updates the status of the associated Asset(s) to 'Available' when a new AssetCheckIn instance is saved,
#     indicating the asset has been returned.

#     Args:
#         sender (AssetCheckIn): The sender of the signal (AssetCheckIn model).
#         instance (AssetCheckIn): The instance of the saved AssetCheckIn.
#         created (bool): Whether a new instance was created or an existing one was updated.
#     """

#     if created:  # Update status only when a new check-in is created
#         checkout = instance.check_out
#         assets = checkout.asset.all()
#         for asset in assets:
#             asset.status = 'Available'
#             asset.save()

# @receiver(post_save, sender=Leasereturn)
# def update_asset_status_on_leasereturn(sender, instance, created, **kwargs):
#     """
#     Updates the status of the associated Asset(s) to 'Available' when a new Leasereturn instance is saved,
#     indicating the leased asset has been returned.

#     Args:
#         sender (Leasereturn): The sender of the signal (Leasereturn model).
#         instance (Leasereturn): The instance of the saved Leasereturn.
#         created (bool): Whether a new instance was created or an existing one was updated.
#     """

#     if created:  # Update status only when a new lease return is created
#         lease = instance.check_out
#         assets = lease.asset.all()
#         for asset in assets:
#             asset.status = 'Available'
#             asset.save()


