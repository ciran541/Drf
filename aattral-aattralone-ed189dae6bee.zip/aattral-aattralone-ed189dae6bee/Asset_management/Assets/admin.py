# Asset_management/admin.py

from django.contrib import admin
from .models import Asset, Photo, Doc, AssetWarranty, AssetMaintenance, Reservation, AssetCheckOut, AssetCheckIn, Lease, Leasereturn, AssetDispose, AssetMove,Audit

admin.site.register(Asset)
admin.site.register(Photo)
admin.site.register(Doc)
admin.site.register(AssetWarranty)
admin.site.register(AssetMaintenance)
admin.site.register(Reservation)
admin.site.register(AssetCheckOut)
admin.site.register(AssetCheckIn)
admin.site.register(Lease)
admin.site.register(Leasereturn)
admin.site.register(AssetDispose)
admin.site.register(AssetMove)
admin.site.register(Audit)