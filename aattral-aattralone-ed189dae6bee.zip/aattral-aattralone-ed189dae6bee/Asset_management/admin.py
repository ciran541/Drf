# Asset_management/admin.py

from django.contrib.admin import AdminSite
from Asset_management.Assets.models import (Asset, Photo, Doc, AssetWarranty, AssetMaintenance, Reservation, AssetCheckOut, AssetCheckIn, 
                                           Lease, Leasereturn, AssetDispose, AssetMove,Audit)
from Asset_management.organization.models import Country, Currency, Timezone, Company, Site, Location, Category, Departments,Person,Customer


class AssetManagementAdminSite(AdminSite):
    site_header = 'Asset Management Admin'
    site_title = 'Asset Management Admin'

asset_management_admin_site = AssetManagementAdminSite(name='asset_management_admin')

# Register models for the Asset Management admin site
asset_management_admin_site.register(Asset)
asset_management_admin_site.register(Photo)
asset_management_admin_site.register(Doc)
asset_management_admin_site.register(AssetWarranty)
asset_management_admin_site.register(AssetMaintenance)
asset_management_admin_site.register(Reservation)
asset_management_admin_site.register(AssetCheckOut)
asset_management_admin_site.register(AssetCheckIn)
asset_management_admin_site.register(Lease)
asset_management_admin_site.register(Leasereturn)
asset_management_admin_site.register(AssetDispose)
asset_management_admin_site.register(AssetMove)
asset_management_admin_site.register(Audit)



# Register models for the Organization admin site
asset_management_admin_site.register(Country)
asset_management_admin_site.register(Currency)
asset_management_admin_site.register(Timezone)
asset_management_admin_site.register(Company)
asset_management_admin_site.register(Site)
asset_management_admin_site.register(Location)
asset_management_admin_site.register(Category)
asset_management_admin_site.register(Departments)
asset_management_admin_site.register(Person)
asset_management_admin_site.register(Customer)


