from django.urls import path, include

urlpatterns = [
    path('production/', include('MES.Production_Planning.urls')),
    path('order-management/', include('MES.order.urls')),
    path('execution/', include('MES.Execution.urls'))
    
]