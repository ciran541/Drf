# urls.py
from django.urls import path, include
from rest_framework.routers import DefaultRouter
from .views import (DepartmentViewSet, SupplierViewSet, MaterialViewSet, 
MaterialShortageViewSet,InstructionViewSet, DeviceViewSet, 
InstructionVersionViewSet, AssemblyStepViewSet, QualityCheckViewSet, 
MaintenanceProcedureViewSet, SafetyInstructionViewSet, VisualAidViewSet, TrainingOnboardingViewSet,
ProductionComponentViewSet, FinishedGoodViewSet, MaterialTransactionViewSet, MaterialIssuanceViewSet,
CapabilityViewSet, WorkstationViewSet, TaskViewSet, LaborEntryViewSet, WorkforcePerformanceViewSet,
InspectionViewSet,QualityDocumentViewSet,NonConformanceViewSet,
BatchViewSet, LotViewSet, TraceabilityRecordViewSet, ComplianceReportViewSet



)


router = DefaultRouter()
router.register(r'departments', DepartmentViewSet)
router.register(r'suppliers', SupplierViewSet)
router.register(r'materials', MaterialViewSet)
router.register(r'material-shortages', MaterialShortageViewSet)

# Work Instruction 
router.register(r'instructions', InstructionViewSet)
router.register(r'devices', DeviceViewSet)
router.register(r'instruction-versions', InstructionVersionViewSet)
router.register(r'assembly-steps', AssemblyStepViewSet)
router.register(r'quality-checks', QualityCheckViewSet)
router.register(r'maintenance-procedures', MaintenanceProcedureViewSet)
router.register(r'safety-instructions', SafetyInstructionViewSet)
router.register(r'visual-aids', VisualAidViewSet)
router.register(r'training-onboardings', TrainingOnboardingViewSet)

# Material Management
router.register(r'production-components', ProductionComponentViewSet)
router.register(r'finished-goods', FinishedGoodViewSet)
router.register(r'material-transactions', MaterialTransactionViewSet)
router.register(r'material-issuances', MaterialIssuanceViewSet)

# Workforce Management 
router.register(r'capabilities', CapabilityViewSet)
router.register(r'workstations', WorkstationViewSet)
router.register(r'tasks', TaskViewSet)
router.register(r'labor_entries', LaborEntryViewSet)
router.register(r'workforce_performances', WorkforcePerformanceViewSet)

# Quality Management
router.register(r'inspections', InspectionViewSet)
router.register(r'nonconformances', NonConformanceViewSet)
router.register(r'qualitydocuments', QualityDocumentViewSet)

# Traceability:
router.register(r'batches', BatchViewSet)
router.register(r'lots', LotViewSet)
router.register(r'traceability-records', TraceabilityRecordViewSet)
router.register(r'compliance-reports', ComplianceReportViewSet)


urlpatterns = [
    path('', include(router.urls)),
]
