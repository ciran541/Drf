# views.py
from rest_framework import viewsets
from .models import( Department, Supplier, Material, MaterialShortage,Instruction, Device, 
InstructionVersion, AssemblyStep, QualityCheck, MaintenanceProcedure, 
SafetyInstruction, VisualAid, TrainingOnboarding,ProductionComponent, FinishedGood,
MaterialTransaction, MaterialIssuance,Capability, Workstation, Task, LaborEntry,
 WorkforcePerformance,Inspection, NonConformance, QualityDocument,
 Batch, Lot, TraceabilityRecord, ComplianceReport)


from .serializers import (DepartmentSerializer, SupplierSerializer, MaterialSerializer, 
MaterialShortageSerializer,InstructionSerializer, DeviceSerializer, 
InstructionVersionSerializer, AssemblyStepSerializer, QualityCheckSerializer,
MaintenanceProcedureSerializer, SafetyInstructionSerializer, VisualAidSerializer,
TrainingOnboardingSerializer,ProductionComponentSerializer, FinishedGoodSerializer, 
MaterialTransactionSerializer, MaterialIssuanceSerializer,CapabilitySerializer, 
WorkstationSerializer, TaskSerializer, LaborEntrySerializer, WorkforcePerformanceSerializer,
InspectionSerializer, NonConformanceSerializer, QualityDocumentSerializer,
BatchSerializer, LotSerializer, TraceabilityRecordSerializer, ComplianceReportSerializer

)


class DepartmentViewSet(viewsets.ModelViewSet):
    queryset = Department.objects.all()
    serializer_class = DepartmentSerializer

class SupplierViewSet(viewsets.ModelViewSet):
    queryset = Supplier.objects.all()
    serializer_class = SupplierSerializer

class MaterialViewSet(viewsets.ModelViewSet):
    queryset = Material.objects.all()
    serializer_class = MaterialSerializer

class MaterialShortageViewSet(viewsets.ModelViewSet):
    queryset = MaterialShortage.objects.all()
    serializer_class = MaterialShortageSerializer

# Work Instruction 


class InstructionViewSet(viewsets.ModelViewSet):
    queryset = Instruction.objects.all()
    serializer_class = InstructionSerializer

class DeviceViewSet(viewsets.ModelViewSet):
    queryset = Device.objects.all()
    serializer_class = DeviceSerializer

class InstructionVersionViewSet(viewsets.ModelViewSet):
    queryset = InstructionVersion.objects.all()
    serializer_class = InstructionVersionSerializer

class AssemblyStepViewSet(viewsets.ModelViewSet):
    queryset = AssemblyStep.objects.all()
    serializer_class = AssemblyStepSerializer

class QualityCheckViewSet(viewsets.ModelViewSet):
    queryset = QualityCheck.objects.all()
    serializer_class = QualityCheckSerializer

class MaintenanceProcedureViewSet(viewsets.ModelViewSet):
    queryset = MaintenanceProcedure.objects.all()
    serializer_class = MaintenanceProcedureSerializer

class SafetyInstructionViewSet(viewsets.ModelViewSet):
    queryset = SafetyInstruction.objects.all()
    serializer_class = SafetyInstructionSerializer

class VisualAidViewSet(viewsets.ModelViewSet):
    queryset = VisualAid.objects.all()
    serializer_class = VisualAidSerializer

class TrainingOnboardingViewSet(viewsets.ModelViewSet):
    queryset = TrainingOnboarding.objects.all()
    serializer_class = TrainingOnboardingSerializer

# Material Management


class ProductionComponentViewSet(viewsets.ModelViewSet):
    queryset = ProductionComponent.objects.all()
    serializer_class = ProductionComponentSerializer

class FinishedGoodViewSet(viewsets.ModelViewSet):
    queryset = FinishedGood.objects.all()
    serializer_class = FinishedGoodSerializer

class MaterialTransactionViewSet(viewsets.ModelViewSet):
    queryset = MaterialTransaction.objects.all()
    serializer_class = MaterialTransactionSerializer

class MaterialIssuanceViewSet(viewsets.ModelViewSet):
    queryset = MaterialIssuance.objects.all()
    serializer_class = MaterialIssuanceSerializer


# Workforce Management 



class CapabilityViewSet(viewsets.ModelViewSet):
    queryset = Capability.objects.all()
    serializer_class = CapabilitySerializer

class WorkstationViewSet(viewsets.ModelViewSet):
    queryset = Workstation.objects.all()
    serializer_class = WorkstationSerializer

class TaskViewSet(viewsets.ModelViewSet):
    queryset = Task.objects.all()
    serializer_class = TaskSerializer

class LaborEntryViewSet(viewsets.ModelViewSet):
    queryset = LaborEntry.objects.all()
    serializer_class = LaborEntrySerializer

class WorkforcePerformanceViewSet(viewsets.ModelViewSet):
    queryset = WorkforcePerformance.objects.all()
    serializer_class = WorkforcePerformanceSerializer



# Quality Management


class InspectionViewSet(viewsets.ModelViewSet):
    queryset = Inspection.objects.all()
    serializer_class = InspectionSerializer

class NonConformanceViewSet(viewsets.ModelViewSet):
    queryset = NonConformance.objects.all()
    serializer_class = NonConformanceSerializer

class QualityDocumentViewSet(viewsets.ModelViewSet):
    queryset = QualityDocument.objects.all()
    serializer_class = QualityDocumentSerializer


# Traceability:

class BatchViewSet(viewsets.ModelViewSet):
    queryset = Batch.objects.all()
    serializer_class = BatchSerializer

class LotViewSet(viewsets.ModelViewSet):
    queryset = Lot.objects.all()
    serializer_class = LotSerializer

class TraceabilityRecordViewSet(viewsets.ModelViewSet):
    queryset = TraceabilityRecord.objects.all()
    serializer_class = TraceabilityRecordSerializer

class ComplianceReportViewSet(viewsets.ModelViewSet):
    queryset = ComplianceReport.objects.all()
    serializer_class = ComplianceReportSerializer