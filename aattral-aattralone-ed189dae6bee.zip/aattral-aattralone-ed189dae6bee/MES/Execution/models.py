from django.db import models
from Authentication.models import CustomUser
from MES.Production_Planning.models import Tool,ProductionOrder,Labor


class Department(models.Model):
    name = models.CharField(max_length=100, blank=True, null=True)
    added_time = models.DateTimeField(auto_now_add=True)
    modified_time = models.DateTimeField(auto_now=True)

class Supplier(models.Model):
    name = models.CharField(max_length=100)
    contact_person = models.CharField(max_length=100, blank=True, null=True)
    phone_number = models.CharField(max_length=20, blank=True, null=True)
    email = models.EmailField(blank=True, null=True)

class Capability(models.Model):  # Define specific capabilities or features of each workstation by associating it with one or more Capability instances
    name = models.CharField(max_length=100)

    def __str__(self):
        return self.name

class Workstation(models.Model):
    name = models.CharField(max_length=100)
    location = models.CharField(max_length=255, blank=True)  # ww can use seprate model for location to store locations 
    description = models.TextField(blank=True)
    capacity = models.IntegerField(default=1)  # Maximum number of workers that can use the workstation simultaneously
    active = models.BooleanField(default=True)  # Indicates if the workstation is currently in use or available
    maintenance_mode = models.BooleanField(default=False)  # Indicates if the workstation is in maintenance mode
    offline = models.BooleanField(default=False)  # Indicates if the workstation is temporarily offline
    capabilities = models.ManyToManyField('Capability', blank=True, related_name='workstations')

    def __str__(self):
        return self.name



'''
Work Instructions:

Creation and Distribution: Detailed instructions are created for each task, specifying procedures, parameters, and safety guidelines.
Delivery to Operators: Instructions are delivered to operators through digital interfaces like tablets, displays, or integrated systems at their workstations.
Version Control: Ensuring that operators always have access to the latest version of work instructions to maintain consistency and accuracy.

'''

# Work Instruction 



class Instruction(models.Model):
    title = models.CharField(max_length=100, blank=True)
    description = models.TextField(blank=True)
    parameters = models.JSONField(blank=True, null=True)
    safety_guidelines = models.TextField(blank=True)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    author = models.ForeignKey(CustomUser, on_delete=models.SET_NULL, null=True, blank=True)  # Author of the instruction
    department = models.ForeignKey(Department, on_delete=models.SET_NULL, blank=True, null=True)  # Department related to the instruction
    category = models.CharField(max_length=100, blank=True)  # Category of the instruction (e.g., maintenance, operation)
    is_active = models.BooleanField(default=True)  # Indicates whether the instruction is active or not
    # Add other relevant fields as needed


class Device(models.Model):
    name = models.CharField(max_length=100)
    device_type = models.CharField(max_length=50)
    location = models.CharField(max_length=100)
    is_active = models.BooleanField(default=True)
    assigned_instructions = models.ManyToManyField(Instruction, blank=True)  # Instructions assigned to this device


class InstructionVersion(models.Model):
    instruction = models.ForeignKey(Instruction, on_delete=models.CASCADE)
    version_number = models.PositiveIntegerField()
    file = models.FileField(upload_to='instruction_versions/')
    uploaded_at = models.DateTimeField(auto_now_add=True)
    notes = models.TextField(blank=True)  # Additional notes related to this version


class AssemblyStep(models.Model):
    work_instruction = models.ForeignKey('Instruction', on_delete=models.CASCADE)
    step_number = models.PositiveIntegerField()
    description = models.TextField(blank=True)
    parts_to_use = models.TextField(blank=True)
    tools_and_equipment = models.ForeignKey(Tool, on_delete=models.CASCADE, null=True, blank=True)
    safety_precautions = models.TextField(blank=True)
    estimated_time = models.DurationField(null=True, blank=True)
    required_certifications = models.CharField(max_length=100, blank=True)
    completed = models.BooleanField(default=False)


class QualityCheck(models.Model):
    work_instruction = models.ForeignKey('Instruction', on_delete=models.CASCADE)
    description = models.TextField(blank=True)
    check_frequency = models.CharField(max_length=50, blank=True)
    pass_fail = models.BooleanField(default=False)
    remarks = models.TextField(blank=True)


class MaintenanceProcedure(models.Model):
    work_instruction = models.ForeignKey('Instruction', on_delete=models.CASCADE)
    description = models.TextField(blank=True)
    category = models.CharField(max_length=50, blank=True)
    maintenance_frequency = models.CharField(max_length=50, blank=True)
    last_maintenance_date = models.DateField(null=True, blank=True)
    technician = models.CharField(max_length=100, blank=True)
    supervisor = models.CharField(max_length=100, blank=True)
    maintenance_cost = models.DecimalField(max_digits=10, decimal_places=2, null=True, blank=True)


class SafetyInstruction(models.Model):
    work_instruction = models.ForeignKey('Instruction', on_delete=models.CASCADE)
    description = models.TextField(blank=True)
    instruction_type = models.CharField(max_length=50, blank=True)
    compliance_status = models.CharField(max_length=20, blank=True)
    incident_reports = models.TextField(blank=True)


class VisualAid(models.Model):
    work_instruction = models.ForeignKey('Instruction', on_delete=models.CASCADE)
    image = models.ImageField(upload_to='visual_aids/')
    description = models.TextField(blank=True)
    target_audience = models.CharField(max_length=100, blank=True)
    language = models.CharField(max_length=50, blank=True)
    version = models.CharField(max_length=20, blank=True)


class TrainingOnboarding(models.Model):
    work_instruction = models.ForeignKey('Instruction', on_delete=models.CASCADE)
    description = models.TextField(blank=True)
    training_type = models.CharField(max_length=50, blank=True)
    training_duration = models.DurationField(null=True, blank=True)
    prerequisites = models.TextField(blank=True)
    instructor = models.CharField(max_length=100, blank=True)
    location = models.CharField(max_length=100, blank=True)


'''
Material Management:

Inventory Control: Managing inventory levels of raw materials, components, and finished goods to ensure availability for production.
Material Tracking: Tracking the movement of materials from receiving through production stages to shipping.
Material Issuing: Issuing materials to the production line based on demand and production schedules, ensuring timely availability without overstocking.

'''

# Material Management

class Material(models.Model):
    name = models.CharField(max_length=100)
    quantity = models.IntegerField(blank=True)  # Current quantity of the material available
    unit = models.CharField(max_length=20)  # Unit of measurement (e.g., kg, liters)
    # Supplier information fields
    supplier_name = models.CharField(max_length=100, null=True, blank=True)  # Supplier name
    supplier_contact_information = models.TextField(null=True, blank=True)  # Supplier contact information
    lead_time = models.CharField(max_length=50, null=True, blank=True)  # Lead time for material procurement
    # Quality control fields
    inspection_date = models.DateField(null=True, blank=True)  # Inspection date
    inspection_result = models.CharField(max_length=100, null=True, blank=True)  # Inspection result
    acceptance_criteria = models.TextField(null=True, blank=True)  # Acceptance criteria
    cost = models.DecimalField(max_digits=10, decimal_places=2)
    reorder_level = models.DecimalField(max_digits=10, decimal_places=2)

    supplier = models.ForeignKey(Supplier, on_delete=models.CASCADE)

class MaterialShortage(models.Model):
    material = models.ForeignKey(Material, on_delete=models.CASCADE)
    shortage_amount = models.IntegerField(blank=True)
    expected_arrival_time = models.DateTimeField(blank=True)

class ProductionComponent(models.Model):
    name = models.CharField(max_length=100)
    description = models.TextField(blank=True, null=True)
    quantity = models.DecimalField(max_digits=10, decimal_places=2)
    unit = models.CharField(max_length=20)
    bom = models.ManyToManyField(Material)
    production_cost = models.DecimalField(max_digits=10, decimal_places=2)
    lead_time = models.IntegerField()

class FinishedGood(models.Model):
    name = models.CharField(max_length=100)
    description = models.TextField(blank=True, null=True)
    quantity = models.DecimalField(max_digits=10, decimal_places=2)
    unit = models.CharField(max_length=20)
    components = models.ManyToManyField(ProductionComponent)
    sale_price = models.DecimalField(max_digits=10, decimal_places=2)
    profit_margin = models.DecimalField(max_digits=5, decimal_places=2)

class MaterialTransaction(models.Model):
    MATERIAL_TRANSACTION_CHOICES = (
        ('IN', 'Incoming'),
        ('OUT', 'Outgoing'),
        ('TRANSFER', 'Transfer'),
    )
    material = models.ForeignKey(Material, on_delete=models.CASCADE)
    transaction_type = models.CharField(max_length=10, choices=MATERIAL_TRANSACTION_CHOICES)
    quantity = models.DecimalField(max_digits=10, decimal_places=2)
    transaction_date = models.DateTimeField(auto_now_add=True)
    transaction_id = models.CharField(max_length=100)
    transaction_reason = models.TextField()
    user = models.ForeignKey(CustomUser, on_delete=models.CASCADE)

class MaterialIssuance(models.Model):
    production_order = models.ForeignKey(ProductionOrder, on_delete=models.CASCADE)
    material = models.ForeignKey(Material, on_delete=models.CASCADE)
    quantity = models.DecimalField(max_digits=10, decimal_places=2)
    issuance_date = models.DateTimeField(auto_now_add=True)
    issued_by = models.ForeignKey(CustomUser, on_delete=models.CASCADE)
    issued_to = models.CharField(max_length=100)
    issuance_reason = models.TextField()


'''
The workforce management module within your MES will be better equipped to handle detailed task tracking, labor analysis, and workforce performance monitoring.

'''

# Workforce Management 

class Task(models.Model):
    name = models.CharField(max_length=100)
    description = models.TextField(blank=True)
    skill_required = models.CharField(max_length=50)
    priority = models.IntegerField(default=1)  # Lower number indicates higher priority
    assigned_to = models.ForeignKey(CustomUser, on_delete=models.SET_NULL, null=True, blank=True)
    start_date = models.DateTimeField(null=True, blank=True)
    end_date = models.DateTimeField(null=True, blank=True)
    status = models.CharField(max_length=20, default='pending')
    deadline = models.DateTimeField(null=True, blank=True)
    scheduled_start = models.DateTimeField(null=True, blank=True)
    actual_start = models.DateTimeField(null=True, blank=True)
    completed = models.BooleanField(default=False)
    
    def __str__(self):
        return self.name
    

class LaborEntry(models.Model):
    task = models.ForeignKey(Task, on_delete=models.CASCADE)
    worker = models.ForeignKey(Labor, on_delete=models.CASCADE)
    hours_worked = models.DecimalField(max_digits=5, decimal_places=2)
    date_worked = models.DateField(auto_now_add=True)
    workstation = models.ForeignKey(Workstation, on_delete=models.SET_NULL, null=True, blank=True)
    cost = models.DecimalField(max_digits=10, decimal_places=2, null=True, blank=True)

    def __str__(self):
        return f"{self.worker} - {self.task.name} - {self.date_worked}"
    
class WorkforcePerformance(models.Model):
    worker = models.ForeignKey(Labor, on_delete=models.CASCADE)
    efficiency_score = models.DecimalField(max_digits=5, decimal_places=2)
    productivity_score = models.DecimalField(max_digits=5, decimal_places=2)
    date_recorded = models.DateField(auto_now_add=True)
    completed_tasks = models.PositiveIntegerField(default=0)
    average_efficiency = models.DecimalField(max_digits=5, decimal_places=2, null=True, blank=True)
    average_productivity = models.DecimalField(max_digits=5, decimal_places=2, null=True, blank=True)

    def __str__(self):
        return f"{self.worker.username} - {self.date_recorded}"
    

'''
Quality management aspects within an MES, including detailed inspection types, test results, severity of non-conformances, 
root cause analysis, and compliance status of documentation.

'''

# Quality Management

class Inspection(models.Model):

    INSPECTION_CHOICES = (
        ('Initial', 'Initial'),
        ('In-process', 'In-process'),
        ('Final', 'Final'),
    )
    product = models.ForeignKey('order.Product', on_delete=models.CASCADE)
    inspected_by = models.ForeignKey(CustomUser, on_delete=models.SET_NULL, null=True)
    inspection_datetime = models.DateTimeField(auto_now_add=True)
    passed = models.BooleanField(default=True)
    remarks = models.TextField(blank=True, null=True)
    inspection_type = models.CharField(max_length=50,blank=True, null=True, choices=INSPECTION_CHOICES)  # e.g., 'Initial', 'In-process', 'Final'
    test_results = models.JSONField(blank=True, null=True)  # Store test results in JSON format

    def __str__(self):
        return f"Inspection for {self.product} ({self.inspection_datetime})"
    

class NonConformance(models.Model):

    SEVERITY_CHOICES = (
        ('Minor', 'Minor'),
        ('Major', 'Major'),
        ('Critical', 'Critical'),
    )
    inspection = models.ForeignKey('Inspection', on_delete=models.CASCADE,blank=True)
    description = models.TextField(blank=True)
    corrective_action = models.TextField(blank=True, null=True)
    is_resolved = models.BooleanField(default=False)
    resolution_date = models.DateTimeField(blank=True, null=True)
    severity = models.CharField(max_length=20,blank=True, null=True, choices=SEVERITY_CHOICES)  # e.g., 'Minor', 'Major', 'Critical'
    root_cause_analysis = models.TextField(blank=True, null=True)

    def __str__(self):
        return f"Non-Conformance: {self.description}"
    

class QualityDocument(models.Model):

    STATUS_CHOICES = (
        ('Valid', 'Valid'),
        ('Expired', 'Expired'),
        ('Pending', 'Pending'),
    )
    document_type = models.CharField(max_length=100,blank=True)
    description = models.TextField(blank=True)
    upload = models.FileField(upload_to='quality_documents/')
    uploaded_by = models.ForeignKey(CustomUser, on_delete=models.SET_NULL, null=True)
    upload_datetime = models.DateTimeField(auto_now_add=True)
    validity_period_start = models.DateField(blank=True, null=True)
    validity_period_end = models.DateField(blank=True, null=True)
    compliance_status = models.CharField(max_length=20, default='Pending', blank=True,null=True,choices=STATUS_CHOICES )  # e.g., 'Valid', 'Expired', 'Pending'

    def __str__(self):
        return f"{self.document_type} - {self.description}"
    

'''
Traceability:
Product Genealogy: Tracking the complete history and lineage of products and materials throughout the production process, including sourcing, manufacturing, and distribution.
Batch and Lot Tracking: Assigning unique identifiers to batches or lots of products and materials for traceability and recall purposes.

'''
    
class Batch(models.Model):
    product = models.ForeignKey('order.Product', on_delete=models.CASCADE)
    batch_number = models.CharField(max_length=50, unique=True)
    manufacturing_date = models.DateField()
    quantity = models.PositiveIntegerField()
    notes = models.TextField(blank=True)
    supervisor = models.CharField(max_length=100, blank=True)
    manufacturing_location = models.CharField(max_length=100, blank=True)
    production_line = models.CharField(max_length=50, blank=True)
    # Add more specific fields related to manufacturing details

    def __str__(self):
        return f"{self.product.name} - Batch {self.batch_number}"
    

class Lot(models.Model):
    batch = models.ForeignKey(Batch, on_delete=models.CASCADE)
    lot_number = models.CharField(max_length=50, unique=True)
    quantity = models.PositiveIntegerField()
    location = models.CharField(max_length=100, blank=True)
    expiration_date = models.DateField(null=True, blank=True)
    quality_status = models.CharField(max_length=20, default='Pending')
    responsible_operator = models.CharField(max_length=100, blank=True)
    inspection_results = models.TextField(blank=True)
    # Add more specific fields for lot details and quality control

    def __str__(self):
        return f"{self.batch} - Lot {self.lot_number}"
    
class TraceabilityRecord(models.Model):
    lot = models.ForeignKey(Lot, on_delete=models.CASCADE)
    action = models.CharField(max_length=100)
    timestamp = models.DateTimeField(auto_now_add=True)
    notes = models.TextField(blank=True)
    performed_by = models.CharField(max_length=100, blank=True)
    equipment_used = models.CharField(max_length=100, blank=True)
    # Add more specific fields for action details and equipment used

    def __str__(self):
        return f"{self.lot} - {self.action} ({self.timestamp})"
    
class ComplianceReport(models.Model):
    batch = models.ForeignKey(Batch, on_delete=models.CASCADE)
    report_type = models.CharField(max_length=100)
    generated_at = models.DateTimeField(auto_now_add=True)
    content = models.TextField(blank=True)
    issuer = models.CharField(max_length=100, blank=True)
    regulatory_standards_met = models.TextField(blank=True)
    inspection_details = models.TextField(blank=True)
    # Add more specific fields related to compliance reporting

    def __str__(self):
        return f"{self.report_type} - {self.generated_at}"
