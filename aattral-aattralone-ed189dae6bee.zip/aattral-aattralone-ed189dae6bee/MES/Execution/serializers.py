# serializers.py
from rest_framework import serializers
from .models import (Department, Supplier, Material, MaterialShortage,Instruction, 
 Device, InstructionVersion, AssemblyStep, QualityCheck, MaintenanceProcedure, 
SafetyInstruction, VisualAid, TrainingOnboarding,ProductionComponent, FinishedGood, 
MaterialTransaction, MaterialIssuance,Capability, Workstation, Task, LaborEntry, 
WorkforcePerformance,Inspection,QualityDocument,NonConformance,Batch, Lot, TraceabilityRecord, ComplianceReport

)

class DepartmentSerializer(serializers.ModelSerializer):
    class Meta:
        model = Department
        fields = '__all__'

class SupplierSerializer(serializers.ModelSerializer):
    class Meta:
        model = Supplier
        fields = '__all__'

class MaterialSerializer(serializers.ModelSerializer):
    class Meta:
        model = Material
        fields = '__all__'

class MaterialShortageSerializer(serializers.ModelSerializer):
    class Meta:
        model = MaterialShortage
        fields = '__all__'

# Work Instruction 


class InstructionSerializer(serializers.ModelSerializer):
    class Meta:
        model = Instruction
        fields = '__all__'

class DeviceSerializer(serializers.ModelSerializer):
    class Meta:
        model = Device
        fields = '__all__'

class InstructionVersionSerializer(serializers.ModelSerializer):
    class Meta:
        model = InstructionVersion
        fields = '__all__'

class AssemblyStepSerializer(serializers.ModelSerializer):
    class Meta:
        model = AssemblyStep
        fields = '__all__'

class QualityCheckSerializer(serializers.ModelSerializer):
    class Meta:
        model = QualityCheck
        fields = '__all__'

class MaintenanceProcedureSerializer(serializers.ModelSerializer):
    class Meta:
        model = MaintenanceProcedure
        fields = '__all__'

class SafetyInstructionSerializer(serializers.ModelSerializer):
    class Meta:
        model = SafetyInstruction
        fields = '__all__'

class VisualAidSerializer(serializers.ModelSerializer):
    class Meta:
        model = VisualAid
        fields = '__all__'

class TrainingOnboardingSerializer(serializers.ModelSerializer):
    class Meta:
        model = TrainingOnboarding
        fields = '__all__'


# Material Management

class ProductionComponentSerializer(serializers.ModelSerializer):
    class Meta:
        model = ProductionComponent
        fields = '__all__'

class FinishedGoodSerializer(serializers.ModelSerializer):
    class Meta:
        model = FinishedGood
        fields = '__all__'

class MaterialTransactionSerializer(serializers.ModelSerializer):
    class Meta:
        model = MaterialTransaction
        fields = '__all__'

class MaterialIssuanceSerializer(serializers.ModelSerializer):
    class Meta:
        model = MaterialIssuance
        fields = '__all__'


class CapabilitySerializer(serializers.ModelSerializer):
    class Meta:
        model = Capability
        fields = '__all__'

# Workforce Management 


class WorkstationSerializer(serializers.ModelSerializer):
    class Meta:
        model = Workstation
        fields = '__all__'

class TaskSerializer(serializers.ModelSerializer):
    class Meta:
        model = Task
        fields = '__all__'

class LaborEntrySerializer(serializers.ModelSerializer):
    class Meta:
        model = LaborEntry
        fields = '__all__'

class WorkforcePerformanceSerializer(serializers.ModelSerializer):
    class Meta:
        model = WorkforcePerformance
        fields = '__all__'


# Quality Management

class InspectionSerializer(serializers.ModelSerializer):
    class Meta:
        model = Inspection
        fields = '__all__'

class NonConformanceSerializer(serializers.ModelSerializer):
    class Meta:
        model = NonConformance
        fields = '__all__'

class QualityDocumentSerializer(serializers.ModelSerializer):
    class Meta:
        model = QualityDocument
        fields = '__all__'

# Traceability:


class BatchSerializer(serializers.ModelSerializer):
    class Meta:
        model = Batch
        fields = '__all__'

class LotSerializer(serializers.ModelSerializer):
    class Meta:
        model = Lot
        fields = '__all__'

class TraceabilityRecordSerializer(serializers.ModelSerializer):
    class Meta:
        model = TraceabilityRecord
        fields = '__all__'

class ComplianceReportSerializer(serializers.ModelSerializer):
    class Meta:
        model = ComplianceReport
        fields = '__all__'