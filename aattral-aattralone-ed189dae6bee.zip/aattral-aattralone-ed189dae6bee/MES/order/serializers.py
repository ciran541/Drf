# serializers.py
from rest_framework import serializers
from .models import Customer, Product, Order, WorkOrder, ProductionData, QualityCheck, Shipping, Feedback, ProductionStage, ProductionActivity

class CustomerSerializer(serializers.ModelSerializer):
    class Meta:
        model = Customer
        fields = '__all__'
        ref_name = 'ordercustomer'

class ProductSerializer(serializers.ModelSerializer):
    class Meta:
        model = Product
        fields = '__all__'
        ref_name = 'orderproduct'

class OrderSerializer(serializers.ModelSerializer):
    class Meta:
        model = Order
        fields = '__all__'
        ref_name = 'MESorder'

class WorkOrderSerializer(serializers.ModelSerializer):
    class Meta:
        model = WorkOrder
        fields = '__all__'
        ref_name = 'orderworkorder'

class ProductionDataSerializer(serializers.ModelSerializer):
    class Meta:
        model = ProductionData
        fields = '__all__'
        ref_name = 'orderproductiondata'

class QualityCheckSerializer(serializers.ModelSerializer):
    class Meta:
        model = QualityCheck
        fields = '__all__'
        ref_name = 'orderqualitycheck'

class ShippingSerializer(serializers.ModelSerializer):
    class Meta:
        model = Shipping
        fields = '__all__'
        ref_name = 'ordershipping'

class FeedbackSerializer(serializers.ModelSerializer):
    class Meta:
        model = Feedback
        fields = '__all__'
        ref_name = 'orderfeedback'

class ProductionStageSerializer(serializers.ModelSerializer):
    class Meta:
        model = ProductionStage
        fields = '__all__'
        ref_name = 'orderproductionstage'

class ProductionActivitySerializer(serializers.ModelSerializer):
    class Meta:
        model = ProductionActivity
        fields = '__all__'
        ref_name = 'orderproductionactivity'
