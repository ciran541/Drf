# urls.py
from django.urls import path, include
from rest_framework.routers import DefaultRouter
from .views import CustomerViewSet, ProductViewSet, OrderViewSet, WorkOrderViewSet, ProductionDataViewSet, QualityCheckViewSet, ShippingViewSet, FeedbackViewSet, ProductionStageViewSet, ProductionActivityViewSet

router = DefaultRouter()
router.register(r'customers', CustomerViewSet)
router.register(r'products', ProductViewSet)
router.register(r'orders', OrderViewSet)
router.register(r'work-orders', WorkOrderViewSet)
router.register(r'production-data', ProductionDataViewSet)
router.register(r'quality-checks', QualityCheckViewSet)
router.register(r'shippings', ShippingViewSet)
router.register(r'feedbacks', FeedbackViewSet)
router.register(r'production-stages', ProductionStageViewSet)
router.register(r'production-activities', ProductionActivityViewSet)

urlpatterns = [
    path('', include(router.urls)),
]
