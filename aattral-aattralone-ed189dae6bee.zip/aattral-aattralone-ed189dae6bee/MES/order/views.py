# views.py
from rest_framework import viewsets
from .models import Customer, Product, Order, WorkOrder, ProductionData, QualityCheck, Shipping, Feedback, ProductionStage, ProductionActivity
from .serializers import CustomerSerializer, ProductSerializer, OrderSerializer, WorkOrderSerializer, ProductionDataSerializer, QualityCheckSerializer, ShippingSerializer, FeedbackSerializer, ProductionStageSerializer, ProductionActivitySerializer

class CustomerViewSet(viewsets.ModelViewSet):
    queryset = Customer.objects.all()
    serializer_class = CustomerSerializer

class ProductViewSet(viewsets.ModelViewSet):
    queryset = Product.objects.all()
    serializer_class = ProductSerializer

class OrderViewSet(viewsets.ModelViewSet):
    queryset = Order.objects.all()
    serializer_class = OrderSerializer

class WorkOrderViewSet(viewsets.ModelViewSet):
    queryset = WorkOrder.objects.all()
    serializer_class = WorkOrderSerializer

class ProductionDataViewSet(viewsets.ModelViewSet):
    queryset = ProductionData.objects.all()
    serializer_class = ProductionDataSerializer

class QualityCheckViewSet(viewsets.ModelViewSet):
    queryset = QualityCheck.objects.all()
    serializer_class = QualityCheckSerializer

class ShippingViewSet(viewsets.ModelViewSet):
    queryset = Shipping.objects.all()
    serializer_class = ShippingSerializer

class FeedbackViewSet(viewsets.ModelViewSet):
    queryset = Feedback.objects.all()
    serializer_class = FeedbackSerializer

class ProductionStageViewSet(viewsets.ModelViewSet):
    queryset = ProductionStage.objects.all()
    serializer_class = ProductionStageSerializer

class ProductionActivityViewSet(viewsets.ModelViewSet):
    queryset = ProductionActivity.objects.all()
    serializer_class = ProductionActivitySerializer
