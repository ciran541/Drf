from django.db import models
from Authentication.models import CustomUser
from MES.Production_Planning.models import ProductionPlan,Machine
from MES.Execution.models import Material


class Customer(models.Model):
    name = models.CharField(max_length=100)
    email = models.EmailField()
    phone = models.CharField(max_length=20)
    address = models.JSONField()
    account_number = models.CharField(max_length=50, blank=True)
    # Add other customer details as needed

    def __str__(self):
        return self.name
    

class Product(models.Model):


    STATUS_CHOICES = [
        ('active', 'Active'),
        ('inactive', 'Inactive'),
    ]


    name = models.CharField(max_length=100)
    description = models.TextField()
    dimensions = models.CharField(max_length=50, blank=True)
    weight = models.DecimalField(max_digits=10, decimal_places=2, blank=True)
    category = models.CharField(max_length=100)
    sku = models.CharField(max_length=50)
    price = models.DecimalField(max_digits=10, decimal_places=2)
    status = models.CharField(max_length=10, choices=STATUS_CHOICES, default='active',blank=True)
    # Add other product details as needed

    def __str__(self):
        return self.name
    

    
class Order(models.Model):
    status_choices = [
        ('pending', 'Pending'),
        ('in_progress', 'In Progress'),
        ('completed', 'Completed'),
    ]
    order_number = models.CharField(max_length=50, unique=True)
    customer = models.ForeignKey(Customer, on_delete=models.CASCADE)
    product = models.ForeignKey(Product, on_delete=models.CASCADE)
    quantity = models.PositiveIntegerField()
    delivery_date = models.DateField()
    special_instructions = models.TextField(blank=True)
    order_receipt_channel = models.CharField(max_length=50, choices=[
        ('online_portal', 'Online Portal'),
        ('email', 'Email'),
        ('phone', 'Phone'),
        ('edi', 'Electronic Data Interchange (EDI)'),
    ])

    status = models.CharField(max_length=20, choices=status_choices, default='pending')
    production_start_date = models.DateField(null=True, blank=True)
    production_end_date = models.DateField(null=True, blank=True)
    production_notes = models.TextField(blank=True)
    shipment_carrier = models.CharField(max_length=100, blank=True)
    tracking_number = models.CharField(max_length=100, blank=True)
    delivery_status = models.CharField(max_length=50, blank=True)
    # Add other fields for shipment and production tracking
    total_cost = models.DecimalField(max_digits=10, decimal_places=2, blank=True, null=True)
    taxes = models.DecimalField(max_digits=10, decimal_places=2, blank=True, null=True)
    payment_status = models.CharField(max_length=20, choices=[('pending', 'Pending'), ('paid', 'Paid')], default='pending')

class WorkOrder(models.Model):
    STATUS_CHOICES = [
        ('active', 'Active'),
        ('inactive', 'Inactive'),
    ]
    order = models.ForeignKey(Order, on_delete=models.CASCADE)
    production_plan = models.ForeignKey(ProductionPlan, on_delete=models.CASCADE)
    start_date = models.DateTimeField(null=True, blank=True)
    end_date = models.DateTimeField(null=True, blank=True)
    assigned_to = models.ForeignKey(CustomUser, on_delete=models.SET_NULL, null=True, blank=True)  
    status = models.CharField(max_length=20, choices=STATUS_CHOICES, default='Pending')
    # Other fields such as actual start date, actual end date, quantity produced, etc.

    def __str__(self):
        return f"Work Order for Order #{self.order.id}"
    
class ProductionData(models.Model):
    work_order = models.ForeignKey(WorkOrder, on_delete=models.CASCADE)
    cycle_time = models.FloatField()
    yield_rate = models.FloatField()
    resource_type = models.CharField(max_length=50)
    resource_id = models.PositiveIntegerField()
    defect_count = models.IntegerField()
    reject_rate = models.FloatField()
    start_time = models.DateTimeField()
    end_time = models.DateTimeField()

class QualityCheck(models.Model):
    order = models.ForeignKey(Order, on_delete=models.CASCADE)
    stage = models.CharField(max_length=50)
    passed = models.BooleanField()
    defect_type = models.CharField(max_length=100, blank=True, null=True)
    inspection_notes = models.TextField(blank=True, null=True)
    check_timestamp = models.DateTimeField(auto_now_add=True)

class Shipping(models.Model):
    order = models.ForeignKey(Order, on_delete=models.CASCADE)
    shipping_date = models.DateField()
    shipping_method = models.CharField(max_length=100)
    tracking_number = models.CharField(max_length=100, blank=True, null=True)
    delivery_status = models.CharField(max_length=50, blank=True, null=True)
    carrier = models.CharField(max_length=100, blank=True, null=True)
    expected_delivery_date = models.DateField(blank=True, null=True)

class Feedback(models.Model):
    order = models.ForeignKey(Order, on_delete=models.CASCADE)
    feedback_text = models.TextField()
    feedback_source = models.CharField(max_length=100)
    timestamp = models.DateTimeField(auto_now_add=True)
    rating = models.IntegerField(default=0)

class ProductionStage(models.Model):
    name = models.CharField(max_length=100, unique=True)
    description = models.TextField(blank=True)  # Added

class ProductionActivity(models.Model):
    order = models.ForeignKey(Order, related_name='activities', on_delete=models.CASCADE)
    stage = models.ForeignKey(ProductionStage, related_name='activities', on_delete=models.CASCADE)
    start_time = models.DateTimeField(auto_now_add=True)
    end_time = models.DateTimeField(null=True, blank=True)
    status = models.CharField(max_length=20, choices=[('pending', 'Pending'), ('in_progress', 'In Progress'), ('completed', 'Completed')])
    actual_duration = models.DurationField(null=True, blank=True)  # Added
    responsible_person = models.CharField(max_length=100, blank=True)  # Added
    notes = models.TextField(blank=True)
    materials_used = models.ManyToManyField(Material, blank=True)
    machines_involved = models.ManyToManyField(Machine,blank=True)