# urls.py
from django.urls import path, include
from rest_framework.routers import DefaultRouter
from .views import (MachineViewSet, LaborViewSet, MachineMaintenanceViewSet,
ProductionOrderViewSet, ProductionScheduleViewSet, MaterialUsageViewSet, 
CapacityViewSet, LeadTimeViewSet, OrderPriorityViewSet, OperationViewSet, 
ManufacturingFacilityViewSet, ProductionRequirementsViewSet, 
ToolViewSet, ChangeoverViewSet, SetupTimeViewSet, 
WorkflowViewSet, MachineBreakdownViewSet, RushOrderViewSet, ChangeRequestViewSet,
DowntimeRecordViewSet,ConditionMonitoringViewSet,MaintenanceScheduleViewSet,
LaborAvailabilityViewSet,SensorReadingViewSet,ProductionAnalysisViewSet,ProductionDataViewSet,
SensorViewSet,ManualInputViewSet,ScanViewSet
)

router = DefaultRouter()
router.register(r'maintenance', MachineMaintenanceViewSet)
router.register(r'machines', MachineViewSet)

router.register(r'sensors', SensorViewSet)
router.register(r'manual-inputs', ManualInputViewSet)
router.register(r'scans', ScanViewSet)


router.register(r'downtime-records', DowntimeRecordViewSet)
router.register(r'condition-monitoring', ConditionMonitoringViewSet)
router.register(r'maintenance-schedule', MaintenanceScheduleViewSet)
router.register(r'sensorreading', SensorReadingViewSet)

router.register(r'labors', LaborViewSet)
router.register(r'labors-availability', LaborAvailabilityViewSet)


router.register(r'production-orders', ProductionOrderViewSet)
router.register(r'production-schedules', ProductionScheduleViewSet)
router.register(r'material-usages', MaterialUsageViewSet)
router.register(r'capacities', CapacityViewSet)
router.register(r'lead-times', LeadTimeViewSet)
router.register(r'order-priorities', OrderPriorityViewSet)
router.register(r'operations', OperationViewSet)
router.register(r'manufacturing-facilities', ManufacturingFacilityViewSet)
router.register(r'production-requirements', ProductionRequirementsViewSet)
# router.register(r'production-plans', ProductionPlanViewSet)
router.register(r'tools', ToolViewSet)
router.register(r'changeovers', ChangeoverViewSet)
router.register(r'setup-times', SetupTimeViewSet)
router.register(r'workflows', WorkflowViewSet)
router.register(r'machine-breakdowns', MachineBreakdownViewSet)
router.register(r'rush-orders', RushOrderViewSet)
router.register(r'change-requests', ChangeRequestViewSet)

router.register(r'production-data', ProductionDataViewSet)
router.register(r'production-analysis', ProductionAnalysisViewSet)

urlpatterns = [
    path('', include(router.urls)),
]
