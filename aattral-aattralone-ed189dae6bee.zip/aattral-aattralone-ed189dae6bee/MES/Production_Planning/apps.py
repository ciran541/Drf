from django.apps import AppConfig


class ProductionPlanningConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'MES.Production_Planning'
