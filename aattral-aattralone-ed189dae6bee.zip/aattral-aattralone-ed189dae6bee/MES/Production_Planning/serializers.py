from rest_framework import serializers
from .models import (Machine, MachineMaintenance, Labor, LaborAvailability, ProductionOrder, ProductionSchedule, 
                     MaterialUsage, Capacity, LeadTime, OrderPriority, Operation, ManufacturingFacility, 
                     ProductionRequirements, ProductionPlan, Tool, Changeover, SetupTime, Workflow, 
                     MachineBreakdown, RushOrder, ChangeRequest, Downtime, ConditionMonitoring, MaintenanceSchedule, 
                     SensorReading, ProductionAnalysis, ProductionData, Sensor, ManualInput, Scan)


# Serializers

class MachineMaintenanceSerializer(serializers.ModelSerializer):
    class Meta:
        model = MachineMaintenance
        fields = '__all__'
        ref_name = 'MachineMaintenance'


class SensorSerializer(serializers.ModelSerializer):
    class Meta:
        model = Sensor
        fields = '__all__'
        ref_name = 'Sensor'


class ManualInputSerializer(serializers.ModelSerializer):
    class Meta:
        model = ManualInput
        fields = '__all__'
        ref_name = 'ManualInput'


class ScanSerializer(serializers.ModelSerializer):
    class Meta:
        model = Scan
        fields = '__all__'
        ref_name = 'Scan'


class DowntimeRecordSerializer(serializers.ModelSerializer):
    class Meta:
        model = Downtime
        fields = '__all__'
        ref_name = 'DowntimeRecord'


class ConditionMonitoringSerializer(serializers.ModelSerializer):
    class Meta:
        model = ConditionMonitoring
        fields = '__all__'
        ref_name = 'ConditionMonitoring'


class MaintenanceScheduleSerializer(serializers.ModelSerializer):
    class Meta:
        model = MaintenanceSchedule
        fields = '__all__'
        ref_name = 'MaintenanceSchedule'


class MachineDetailSerializer(serializers.ModelSerializer):
    maintenances = MachineMaintenanceSerializer(many=True, read_only=True)

    class Meta:
        model = Machine
        fields = '__all__'
        ref_name = 'MachineDetail'


class MachineCreateUpdateSerializer(serializers.ModelSerializer):
    class Meta:
        model = Machine
        fields = '__all__'
        ref_name = 'MachineCreateUpdate'


class SensorReadingSerializer(serializers.ModelSerializer):
    class Meta:
        model = SensorReading
        fields = '__all__'
        ref_name = 'SensorReading'


class LaborAvailabilitySerializer(serializers.ModelSerializer):
    class Meta:
        model = LaborAvailability
        fields = '__all__'
        ref_name = 'LaborAvailability'


class LaborDetailSerializer(serializers.ModelSerializer):
    availabilities = LaborAvailabilitySerializer(many=True, read_only=True)

    class Meta:
        model = Labor
        fields = '__all__'
        ref_name = 'LaborDetail'


class LaborCreateUpdateSerializer(serializers.ModelSerializer):
    class Meta:
        model = Labor
        fields = '__all__'
        ref_name = 'LaborCreateUpdate'


class ProductionOrderDetailSerializer(serializers.ModelSerializer):
    class Meta:
        model = ProductionOrder
        fields = '__all__'
        ref_name = 'ProductionOrderDetail'


class ProductionOrderCreateUpdateSerializer(serializers.ModelSerializer):
    class Meta:
        model = ProductionOrder
        fields = '__all__'
        ref_name = 'ProductionOrderCreateUpdate'


class ProductionScheduleSerializer(serializers.ModelSerializer):
    class Meta:
        model = ProductionSchedule
        fields = '__all__'
        ref_name = 'ProductionSchedule'


class MaterialUsageSerializer(serializers.ModelSerializer):
    class Meta:
        model = MaterialUsage
        fields = '__all__'
        ref_name = 'MaterialUsage'


class CapacitySerializer(serializers.ModelSerializer):
    class Meta:
        model = Capacity
        fields = '__all__'
        ref_name = 'Capacity'


class LeadTimeSerializer(serializers.ModelSerializer):
    class Meta:
        model = LeadTime
        fields = '__all__'
        ref_name = 'LeadTime'


class OrderPrioritySerializer(serializers.ModelSerializer):
    class Meta:
        model = OrderPriority
        fields = '__all__'
        ref_name = 'OrderPriority'


class OperationSerializer(serializers.ModelSerializer):
    class Meta:
        model = Operation
        fields = '__all__'
        ref_name = 'Operation'


class ManufacturingFacilitySerializer(serializers.ModelSerializer):
    class Meta:
        model = ManufacturingFacility
        fields = '__all__'
        ref_name = 'ManufacturingFacility'


class ProductionRequirementsSerializer(serializers.ModelSerializer):
    class Meta:
        model = ProductionRequirements
        fields = '__all__'
        ref_name = 'ProductionRequirements'


# class ProductionPlanSerializer(serializers.ModelSerializer):
#     class Meta:
#         model = ProductionPlan
#         fields = '__all__'
#         ref_name = 'ProductionPlan'


class ToolSerializer(serializers.ModelSerializer):
    class Meta:
        model = Tool
        fields = '__all__'
        ref_name = 'Tool'


class ChangeoverSerializer(serializers.ModelSerializer):
    class Meta:
        model = Changeover
        fields = '__all__'
        ref_name = 'Changeover'


class SetupTimeSerializer(serializers.ModelSerializer):
    class Meta:
        model = SetupTime
        fields = '__all__'
        ref_name = 'SetupTime'


class WorkflowSerializer(serializers.ModelSerializer):
    class Meta:
        model = Workflow
        fields = '__all__'
        ref_name = 'Workflow'


class MachineBreakdownSerializer(serializers.ModelSerializer):
    class Meta:
        model = MachineBreakdown
        fields = '__all__'
        ref_name = 'MachineBreakdown'


class RushOrderSerializer(serializers.ModelSerializer):
    class Meta:
        model = RushOrder
        fields = '__all__'
        ref_name = 'RushOrder'


class ChangeRequestSerializer(serializers.ModelSerializer):
    class Meta:
        model = ChangeRequest
        fields = '__all__'
        ref_name = 'ChangeRequest'


class ProductionDataSerializer(serializers.ModelSerializer):
    class Meta:
        model = ProductionData
        fields = '__all__'
        ref_name = 'ProductionData'


class ProductionAnalysisSerializer(serializers.ModelSerializer):
    class Meta:
        model = ProductionAnalysis
        fields = '__all__'
        ref_name = 'ProductionAnalysis'
