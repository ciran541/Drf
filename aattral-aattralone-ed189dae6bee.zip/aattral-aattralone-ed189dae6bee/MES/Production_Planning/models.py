from django.db import models
from Authentication.models import CustomUser



'''
These models represent entities and their attributes within a Manufacturing Execution System (MES) for production planning and scheduling. 
They allow for the tracking of machines, labor, materials, production orders, schedules, capacities, lead times, and order priorities, providing 
comprehensive data for managing production processes effectively.
'''


# Machine/Equipment Management 

class Machine(models.Model):
    name = models.CharField(max_length=100)
    asset_tag = models.CharField(max_length=20,null=True, blank=True) # specific types (e.g., CNC Machine, Conveyor, Robot)
    capacity = models.IntegerField(blank=True, null=True)  # Capacity of the machine (e.g., units produced per hour)
    last_maintenance_date = models.DateField(null=True, blank=True)  # Last maintenance date
    next_maintenance_due_date = models.DateField(null=True, blank=True)  # Next maintenance due date
    maintenance_type = models.CharField(max_length=50, null=True, blank=True)  # Maintenance type (e.g., preventive, corrective)
    serial_number = models.CharField(max_length=50, unique=True)
    manufacturer_name = models.CharField(max_length=100,null=True, blank=True)
    model_number = models.CharField(max_length=50,null=True, blank=True)
    manufacture_date = models.DateField(null=True, blank=True)
    category = models.CharField(max_length=50,null=True, blank=True)
    maintenance_cost = models.DecimalField(max_digits=10, decimal_places=2, default=0,null=True, blank=True)

    location = models.CharField(max_length=100)
    # Downtime tracking fields
    downtime_start_time = models.DateTimeField(null=True, blank=True)  # Start time of downtime event
    downtime_end_time = models.DateTimeField(null=True, blank=True)  # End time of downtime event
    downtime_reason = models.TextField(null=True, blank=True)  # Reason for downtime
    # Additional fields for condition monitoring
    current_temperature = models.DecimalField(max_digits=5, decimal_places=2, null=True, blank=True)
    current_pressure = models.DecimalField(max_digits=7, decimal_places=2, null=True, blank=True)
    current_vibration = models.DecimalField(max_digits=8, decimal_places=2, null=True, blank=True)


'''

MES collects data from multiple sources to provide a comprehensive view of production operations.

'''

# Sensor: Represents sensors attached to machines.

class Sensor(models.Model):
    name = models.CharField(max_length=100)
    machine = models.ForeignKey(Machine, on_delete=models.CASCADE, related_name='sensors')
    parameter = models.CharField(max_length=100)
    unit = models.CharField(max_length=50)


# ManualInput: Represents manual inputs recorded by operators.


class ManualInput(models.Model):
    operator_name = models.CharField(max_length=100)
    description = models.TextField()
    timestamp = models.DateTimeField(auto_now_add=True)
    machine = models.ForeignKey(Machine, on_delete=models.CASCADE)


# Scan: Represents barcode or RFID scans.

class Scan(models.Model):
    type_choices = [
        ('BARCODE', 'Barcode'),
        ('RFID', 'RFID')
    ]
    scan_type = models.CharField(max_length=10, choices=type_choices)
    code = models.CharField(max_length=100)
    description = models.TextField()
    timestamp = models.DateTimeField(auto_now_add=True)
    machine = models.ForeignKey(Machine, on_delete=models.CASCADE)

class MachineMaintenance(models.Model):
    machine = models.ForeignKey(Machine, on_delete=models.CASCADE)
    maintenance_date = models.DateField(blank=True)
    maintenance_type = models.CharField(max_length=100, blank=True)  # Type of maintenance (e.g., routine, breakdown)
    notes = models.TextField(blank=True, null=True)
    # Additional fields for maintenance completion tracking
    completed = models.BooleanField(default=False)  # Indicates whether maintenance is completed
    completion_date = models.DateField(null=True, blank=True)  # Date when maintenance was completed


    '''
    Downtime Management: Recording and analyzing equipment downtime to identify root causes and implement corrective actions for improved uptime.
    
    '''
class Downtime(models.Model):
    equipment = models.ForeignKey(Machine, on_delete=models.CASCADE)
    start_time = models.DateTimeField()
    end_time = models.DateTimeField()
    reason = models.TextField()
    production_loss = models.DecimalField(max_digits=10, decimal_places=2, null=True, blank=True)
    product_quality_affected = models.BooleanField(default=False)
    recovery_time = models.DurationField(null=True, blank=True)

    def duration(self):
        return self.end_time - self.start_time

    class Meta:
        ordering = ['-start_time']
    

    '''
    Condition Monitoring: Monitoring the operational status and performance of equipment in real-time to detect issues early and prevent downtime.
    
    '''
class ConditionMonitoring(models.Model):
    equipment = models.ForeignKey(Machine, on_delete=models.CASCADE)
    timestamp = models.DateTimeField(auto_now_add=True)
    temperature = models.DecimalField(max_digits=5, decimal_places=2)
    pressure = models.DecimalField(max_digits=7, decimal_places=2)
    vibration = models.DecimalField(max_digits=8, decimal_places=2)
    humidity = models.DecimalField(max_digits=5, decimal_places=2, null=True, blank=True)
    flow_rate = models.DecimalField(max_digits=8, decimal_places=2, null=True, blank=True)
    power_consumption = models.DecimalField(max_digits=10, decimal_places=2, null=True, blank=True)
    status = models.CharField(max_length=20)

    class Meta:
        ordering = ['-timestamp']


    '''
    Maintenance Scheduling: Scheduling preventive maintenance tasks based on equipment usage, performance data, and manufacturer recommendations.
    
    '''
class MaintenanceSchedule(models.Model):
    equipment = models.ForeignKey(Machine, on_delete=models.CASCADE)
    task_description = models.TextField()
    scheduled_date = models.DateField()
    completed = models.BooleanField(default=False)
    completion_date = models.DateField(null=True, blank=True)
    priority = models.CharField(max_length=20)
    technician = models.ForeignKey(CustomUser, on_delete=models.SET_NULL, null=True, blank=True)

    def __str__(self):
        return f"{self.equipment.name} - {self.task_description}"
    

    '''
    The SensorReading model will represent individual sensor readings captured at specific timestamps for a given equipment
    
    '''
class SensorReading(models.Model):
    equipment = models.ForeignKey(Machine, on_delete=models.CASCADE)
    timestamp = models.DateTimeField(auto_now_add=True)
    sensor_type = models.CharField(max_length=50)
    sensor_values = models.JSONField()

    class Meta:
        ordering = ['-timestamp']

    def __str__(self):
        return f"{self.equipment.name} - {self.timestamp}"

    def set_sensor_value(self, sensor_type, value):
        """
        Add or update a sensor value in the sensor_values JSON field.
        """
        if not self.sensor_values:
            self.sensor_values = {}

        self.sensor_values[sensor_type] = value
        self.save()

    def get_sensor_value(self, sensor_type):
        """
        Retrieve a sensor value from the sensor_values JSON field.
        """
        if self.sensor_values and sensor_type in self.sensor_values:
            return self.sensor_values[sensor_type]
        return None




# Labour Management

class Labor(models.Model):
    name = models.CharField(max_length=100)
    skill_level = models.IntegerField(blank=True)  # Skill level of the labor (e.g., 1 to 5, where 5 is highly skilled)
    # Availability fields
    vacation_schedule = models.TextField(null=True, blank=True)  # Vacation schedule
    shift_schedule = models.TextField(null=True, blank=True)  # Shift schedule
    working_hours = models.CharField(max_length=50, null=True, blank=True)  # Working hours
    # Training records fields
    training_courses_completed = models.TextField(null=True, blank=True)  # Training courses completed
    certifications = models.TextField(null=True, blank=True)  # Certifications obtained
    skills_acquired = models.TextField(null=True, blank=True)  # Skills acquired

class LaborAvailability(models.Model):
    labor = models.ForeignKey(Labor, on_delete=models.CASCADE)
    availability_date = models.DateField(blank=True)
    available_hours = models.FloatField(blank=True)




# Production planning/Management

class ProductionOrder(models.Model):
    order_number = models.CharField(max_length=100)
    priority = models.IntegerField(blank=True)  # Priority of the order (e.g., 1 for highest priority)
    deadline = models.DateTimeField()  # Deadline for completing the order
    quantity = models.IntegerField(blank=True)  # Quantity of the product to be produced
    status = models.CharField(max_length=20, default='Pending')  # Status of the order (e.g., Pending, In Progress, Completed)
    # Product details fields
    product_name = models.CharField(max_length=100, null=True, blank=True)  # Product name
    product_description = models.TextField(null=True, blank=True)  # Product description
    product_specifications = models.TextField(null=True, blank=True)  # Product specifications
    # Customer information fields
    customer_name = models.CharField(max_length=100, null=True, blank=True)  # Customer name
    customer_contact_information = models.TextField(null=True, blank=True)  # Customer contact information
    shipping_address = models.TextField(null=True, blank=True)  # Shipping address
    # Order tracking fields
    start_date = models.DateField(null=True, blank=True)  # Start date of the order
    end_date = models.DateField(null=True, blank=True)  # End date of the order
    completion_status = models.CharField(max_length=20, null=True, blank=True)  # Completion status of the order

class ProductionSchedule(models.Model):
    machine = models.ForeignKey(Machine, on_delete=models.CASCADE)
    labor = models.ForeignKey(Labor, on_delete=models.CASCADE)
    material = models.ForeignKey('Execution.Material', on_delete=models.CASCADE)
    production_order = models.ForeignKey(ProductionOrder, on_delete=models.CASCADE)
    start_time = models.DateTimeField(blank=True)
    end_time = models.DateTimeField(blank=True)
    status = models.CharField(max_length=20, default='Scheduled')  # Status of the production schedule (e.g., Scheduled, In Progress, Completed)
    work_shift = models.CharField(max_length=50, null=True, blank=True)  # Work shift
    production_output = models.IntegerField(null=True, blank=True)  # Actual quantity produced during the schedule
    scrap_generated = models.IntegerField(null=True, blank=True)  # Scrap or waste generated during production

class MaterialUsage(models.Model):
    material = models.ForeignKey('Execution.Material', on_delete=models.CASCADE)
    production_schedule = models.ForeignKey(ProductionSchedule, on_delete=models.CASCADE)
    quantity_used = models.IntegerField(blank=True)  # Quantity of material used for the production
    usage_timestamp = models.DateTimeField(auto_now_add=True) 

class Capacity(models.Model):
    capacity_date = models.DateField()
    capacity_value = models.IntegerField(blank=True)  # Capacity value for the date (e.g., units that can be produced on that date)
    # Resource allocation fields
    resource_allocation = models.TextField(null=True, blank=True)  # Resource allocation to machines or production lines
    # Capacity utilization fields
    utilization_percentage = models.FloatField(null=True, blank=True)  # Utilization percentage
    idle_time = models.FloatField(null=True, blank=True)  # Idle time

class LeadTime(models.Model):
    production_order = models.OneToOneField(ProductionOrder, on_delete=models.CASCADE)
    setup_time = models.FloatField(blank=True)  # Setup time required for the order
    processing_time = models.FloatField(blank=True)  # Processing time required for the order
    transit_time = models.FloatField(blank=True)  # Transit time for delivering the order to the customer
    # Order tracking fields
    order_status = models.CharField(max_length=20, null=True, blank=True)  # Status of the order during processing

class OrderPriority(models.Model):
    production_order = models.OneToOneField(ProductionOrder, on_delete=models.CASCADE)
    customer_preference = models.IntegerField(blank=True)  # Customer preference value (e.g., 1 for low, 5 for high)
    # Customer feedback fields
    customer_feedback = models.TextField(null=True, blank=True)  # Customer feedback or ratings
    # Priority adjustment fields
    priority_adjustment = models.IntegerField(null=True, blank=True)  # Priority adjustment based on dynamic factors

class Operation(models.Model):
    order = models.ForeignKey(ProductionOrder, on_delete=models.CASCADE)
    operation_number = models.IntegerField()
    machine = models.ForeignKey('Machine', on_delete=models.CASCADE)
    labor = models.ForeignKey('Labor', on_delete=models.CASCADE)
    material = models.ForeignKey('Execution.Material', on_delete=models.CASCADE)
    start_time = models.DateTimeField(blank=True)
    end_time = models.DateTimeField(blank=True)

class ManufacturingFacility(models.Model):
    facility_name = models.CharField(max_length=100)
    location = models.CharField(max_length=100)
    capacity = models.IntegerField(blank=True)  # Capacity units per day/week/month
    current_utilization = models.FloatField(default=0, blank=True)  # Percentage
    # You can add other relevant fields like available resources, downtime, etc.

    def __str__(self):
        return self.facility_name


class ProductionRequirements(models.Model):
    product = models.ForeignKey('order.Product', on_delete=models.CASCADE)
    manufacturing_facility = models.ForeignKey(ManufacturingFacility, on_delete=models.CASCADE)
    quantity = models.IntegerField(blank=True)
    deadline = models.DateField()

    def __str__(self):
        return f"{self.product} - {self.manufacturing_facility}"



class ProductionPlan(models.Model):
    PLAN_TYPES = (
        ('Long-term', 'Long-term'),
        ('Short-term', 'Short-term'),
    )
    plan_type = models.CharField(max_length=20, choices=PLAN_TYPES,blank=True)
    timeframe = models.CharField(max_length=100,blank=True)
    planned_quantity = models.IntegerField(blank=True)
    production_orders = models.ManyToManyField(ProductionOrder,blank=True)
    machines = models.ManyToManyField(Machine,blank=True)
    labors = models.ManyToManyField(Labor,blank=True)
    materials = models.ManyToManyField('Execution.Material',blank=True)
    planned_downtime = models.ManyToManyField(Downtime,blank=True)
    scheduled_start_date = models.DateTimeField()
    scheduled_end_date = models.DateTimeField()

class Tool(models.Model):
    name = models.CharField(max_length=100)
    description = models.TextField(blank=True)
    status = models.CharField(max_length=20, choices=[('available', 'Available'), ('in_use', 'In Use'), ('maintenance', 'Maintenance')], blank=True)
    last_calibration_date = models.DateTimeField(null=True, blank=True)

class Changeover(models.Model):
    from_operation = models.ForeignKey(Operation, related_name='changeover_from', on_delete=models.CASCADE)
    to_operation = models.ForeignKey(Operation, related_name='changeover_to', on_delete=models.CASCADE)
    time_taken = models.DurationField(blank=True)

class SetupTime(models.Model):
    operation = models.ForeignKey(Operation, on_delete=models.CASCADE)
    setup_time = models.DurationField(blank=True)

class Workflow(models.Model):
    operations = models.ManyToManyField(Operation, related_name='workflows')

class MachineBreakdown(models.Model):
    machine = models.ForeignKey(Machine, on_delete=models.CASCADE)
    breakdown_start_time = models.DateTimeField(blank=True)
    estimated_repair_time = models.DurationField(blank=True)



class RushOrder(models.Model):
    order = models.ForeignKey(ProductionOrder, on_delete=models.CASCADE)
    priority_level = models.IntegerField(blank=True)

class ChangeRequest(models.Model):
    requested_by = models.ForeignKey(CustomUser, on_delete=models.CASCADE)
    timestamp = models.DateTimeField(auto_now_add=True)
    reason_for_change = models.TextField(blank=True)
    affected_products = models.ManyToManyField('order.Product')
    new_quantity = models.IntegerField(blank=True)

    def __str__(self):
        return f"{self.requested_by} - {self.timestamp}"
    

# Production Monitoring


class ProductionData(models.Model):
    timestamp = models.DateTimeField(auto_now_add=True)
    machine_id = models.CharField(max_length=50)
    cycle_time = models.FloatField()  # Time taken for each production cycle
    throughput = models.IntegerField()  # Number of units produced per unit of time
    scrap_rate = models.FloatField()  # Percentage of defective or scrapped units
    yield_rate = models.FloatField()  # Percentage of good quality units produced
    downtime_reason = models.CharField(max_length=100, blank=True, null=True)  # Reason for production downtime
    operator_id = models.ForeignKey(CustomUser, on_delete=models.CASCADE, blank=True, null=True)
    equipment_status = models.CharField(max_length=20, choices=[('ON', 'On'), ('OFF', 'Off')])
    # Additional fields based on specific requirements (e.g., quality measurements)
    quality_check_passed = models.BooleanField(default=True)
    defect_type = models.CharField(max_length=50, blank=True)
    class Meta:
        ordering = ['-timestamp']

class ProductionAnalysis(models.Model):
    start_date = models.DateField()
    end_date = models.DateField()
    average_cycle_time = models.FloatField()
    average_throughput = models.IntegerField()
    average_scrap_rate = models.FloatField()
    average_yield_rate = models.FloatField()
    total_production_time = models.FloatField()  # Total time the machine was in production
    total_downtime = models.FloatField()  # Total downtime during the analyzed period
    most_common_downtime_reason = models.CharField(max_length=100, blank=True, null=True)  # Most frequent downtime reason
    # Add other relevant fields for analysis and trends

    class Meta:
        verbose_name_plural = "Production Analyses"

'''
These models provide a foundation for capturing essential information related to products, demand forecasts, 
production orders, resources, and production schedules. 

'''

# class DemandForecast(models.Model):
#     product = models.ForeignKey('order.Product', on_delete=models.CASCADE)
#     forecast_date = models.DateField()
#     forecast_quantity = models.IntegerField()
#     source = models.CharField(max_length=100)  # Source of the demand forecast (e.g., historical data, customer orders)
#     confidence_level = models.FloatField(default=1.0)  # Confidence level of the forecast
#     forecast_type = models.CharField(max_length=50, blank=True)  # Type of forecast (e.g., short-term, long-term)



# class DemandHistory(models.Model):
#     product = models.ForeignKey('order.Product', on_delete=models.CASCADE)
#     demand_date = models.DateField()
#     actual_quantity = models.IntegerField()
#     variance_reason = models.TextField(blank=True)  # Reason for variance between forecast and actual demand

# class DemandPlan(models.Model):
#     product = models.ForeignKey('order.Product', on_delete=models.CASCADE)
#     plan_date = models.DateField()
#     planned_quantity = models.IntegerField()
#     planning_horizon = models.CharField(max_length=50, blank=True)  # Planning horizon (e.g., weekly, monthly)
#     production_line = models.CharField(max_length=50, blank=True)  # Production line where the plan applies
#     production_schedule = models.TextField(blank=True)  # Production schedule details
#     capacity_constraints = models.TextField(blank=True)  # Production capacity constraints