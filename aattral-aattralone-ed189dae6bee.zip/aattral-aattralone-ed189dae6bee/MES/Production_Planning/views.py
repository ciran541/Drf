# views.py
from rest_framework import viewsets
from rest_framework.decorators import action
from rest_framework.response import Response
from .models import (Machine, Labor,MachineMaintenance,ProductionOrder, 
ProductionSchedule, MaterialUsage, Capacity, LeadTime, 
OrderPriority, Operation, ManufacturingFacility, ProductionRequirements, 
ProductionPlan, Tool, Changeover, SetupTime,
Workflow, MachineBreakdown, RushOrder, ChangeRequest,Downtime,
ConditionMonitoring, MaintenanceSchedule, LaborAvailability,SensorReading,
ProductionData,ProductionAnalysis,Sensor, ManualInput, Scan
)

from .serializers import (MachineMaintenanceSerializer, MachineDetailSerializer, MachineCreateUpdateSerializer, 
LaborDetailSerializer, LaborCreateUpdateSerializer,
ProductionOrderDetailSerializer, ProductionOrderCreateUpdateSerializer, ProductionScheduleSerializer, 
MaterialUsageSerializer, CapacitySerializer, LeadTimeSerializer, OrderPrioritySerializer, OperationSerializer,
ManufacturingFacilitySerializer, ProductionRequirementsSerializer, 
ToolSerializer, ChangeoverSerializer, SetupTimeSerializer, WorkflowSerializer, MachineBreakdownSerializer,
RushOrderSerializer, ChangeRequestSerializer,ProductionOrderDetailSerializer, ProductionOrderCreateUpdateSerializer, 
ProductionScheduleSerializer, MaterialUsageSerializer, CapacitySerializer, LeadTimeSerializer, OrderPrioritySerializer, 
OperationSerializer, ManufacturingFacilitySerializer, ProductionRequirementsSerializer
, ToolSerializer, ChangeoverSerializer, SetupTimeSerializer, 
WorkflowSerializer, MachineBreakdownSerializer, RushOrderSerializer, ChangeRequestSerializer,DowntimeRecordSerializer, 
ConditionMonitoringSerializer, MaintenanceScheduleSerializer, LaborAvailabilitySerializer,SensorReadingSerializer,
ProductionAnalysisSerializer,ProductionDataSerializer,SensorSerializer, ManualInputSerializer, ScanSerializer

)


class MachineMaintenanceViewSet(viewsets.ModelViewSet):
    queryset = MachineMaintenance.objects.all()

    def get_serializer_class(self):
        if self.request.method in ['POST', 'PUT', 'PATCH']:
            return MachineMaintenanceSerializer
        return MachineMaintenanceSerializer

class MachineViewSet(viewsets.ModelViewSet):
    queryset = Machine.objects.all()

    def get_serializer_class(self):
        if self.request.method in ['POST', 'PUT', 'PATCH']:
            return MachineCreateUpdateSerializer
        return MachineDetailSerializer
    
class SensorViewSet(viewsets.ModelViewSet):
    queryset = Sensor.objects.all()
    serializer_class = SensorSerializer

class ManualInputViewSet(viewsets.ModelViewSet):
    queryset = ManualInput.objects.all()
    serializer_class = ManualInputSerializer

class ScanViewSet(viewsets.ModelViewSet):
    queryset = Scan.objects.all()
    serializer_class = ScanSerializer
    
class DowntimeRecordViewSet(viewsets.ModelViewSet):
    queryset = Downtime.objects.all()
    serializer_class = DowntimeRecordSerializer

class ConditionMonitoringViewSet(viewsets.ModelViewSet):
    queryset = ConditionMonitoring.objects.all()
    serializer_class = ConditionMonitoringSerializer

class MaintenanceScheduleViewSet(viewsets.ModelViewSet):
    queryset = MaintenanceSchedule.objects.all()
    serializer_class = MaintenanceScheduleSerializer


class SensorReadingViewSet(viewsets.ModelViewSet):
    queryset = SensorReading.objects.all()
    serializer_class = SensorReadingSerializer

    @action(detail=True, methods=['post'])
    def set_sensor_value(self, request, pk=None):
        """
        Custom action to set a sensor value for a specific sensor type.
        Expects 'sensor_type' and 'value' in the request data.
        """
        sensor_reading = self.get_object()
        sensor_type = request.data.get('sensor_type')
        value = request.data.get('value')

        if sensor_type and value is not None:
            sensor_reading.set_sensor_value(sensor_type, value)
            return Response({'detail': 'Sensor value set successfully'})
        else:
            return Response({'error': 'Invalid request parameters'}, status=400)

    @action(detail=True, methods=['get'])
    def get_sensor_value(self, request, pk=None):
        """
        Custom action to retrieve a sensor value for a specific sensor type.
        Expects 'sensor_type' in the query parameters.
        """
        sensor_reading = self.get_object()
        sensor_type = request.query_params.get('sensor_type')

        if sensor_type:
            value = sensor_reading.get_sensor_value(sensor_type)
            if value is not None:
                return Response({'sensor_type': sensor_type, 'sensor_value': value})
            else:
                return Response({'detail': f"Sensor type '{sensor_type}' not found"}, status=404)
        else:
            return Response({'error': 'Missing sensor_type parameter'}, status=400)

class LaborViewSet(viewsets.ModelViewSet):
    queryset = Labor.objects.all()

    def get_serializer_class(self):
        if self.request.method in ['POST', 'PUT', 'PATCH']:
            return LaborCreateUpdateSerializer
        return LaborDetailSerializer

class LaborAvailabilityViewSet(viewsets.ModelViewSet):
    queryset = LaborAvailability.objects.all()

    def get_serializer_class(self):
        if self.request.method in ['POST', 'PUT', 'PATCH']:
            return LaborAvailabilitySerializer
        return LaborAvailabilitySerializer

class ProductionOrderViewSet(viewsets.ModelViewSet):
    queryset = ProductionOrder.objects.all()

    def get_serializer_class(self):
        if self.request.method in ['POST', 'PUT', 'PATCH']:
            return ProductionOrderCreateUpdateSerializer
        return ProductionOrderDetailSerializer

class ProductionScheduleViewSet(viewsets.ModelViewSet):
    queryset = ProductionSchedule.objects.all()
    serializer_class = ProductionScheduleSerializer

class MaterialUsageViewSet(viewsets.ModelViewSet):
    queryset = MaterialUsage.objects.all()
    serializer_class = MaterialUsageSerializer

class CapacityViewSet(viewsets.ModelViewSet):
    queryset = Capacity.objects.all()
    serializer_class = CapacitySerializer

class LeadTimeViewSet(viewsets.ModelViewSet):
    queryset = LeadTime.objects.all()
    serializer_class = LeadTimeSerializer

class OrderPriorityViewSet(viewsets.ModelViewSet):
    queryset = OrderPriority.objects.all()
    serializer_class = OrderPrioritySerializer

class OperationViewSet(viewsets.ModelViewSet):
    queryset = Operation.objects.all()
    serializer_class = OperationSerializer

class ManufacturingFacilityViewSet(viewsets.ModelViewSet):
    queryset = ManufacturingFacility.objects.all()
    serializer_class = ManufacturingFacilitySerializer

class ProductionRequirementsViewSet(viewsets.ModelViewSet):
    queryset = ProductionRequirements.objects.all()
    serializer_class = ProductionRequirementsSerializer

# class ProductionPlanViewSet(viewsets.ModelViewSet):
#     queryset = ProductionPlan.objects.all()
#     serializer_class = ProductionPlanSerializer

class ToolViewSet(viewsets.ModelViewSet):
    queryset = Tool.objects.all()
    serializer_class = ToolSerializer

class ChangeoverViewSet(viewsets.ModelViewSet):
    queryset = Changeover.objects.all()
    serializer_class = ChangeoverSerializer

class SetupTimeViewSet(viewsets.ModelViewSet):
    queryset = SetupTime.objects.all()
    serializer_class = SetupTimeSerializer

class WorkflowViewSet(viewsets.ModelViewSet):
    queryset = Workflow.objects.all()
    serializer_class = WorkflowSerializer

class MachineBreakdownViewSet(viewsets.ModelViewSet):
    queryset = MachineBreakdown.objects.all()
    serializer_class = MachineBreakdownSerializer


class RushOrderViewSet(viewsets.ModelViewSet):
    queryset = RushOrder.objects.all()
    serializer_class = RushOrderSerializer

class ChangeRequestViewSet(viewsets.ModelViewSet):
    queryset = ChangeRequest.objects.all()
    serializer_class = ChangeRequestSerializer

class ProductionDataViewSet(viewsets.ModelViewSet):
    queryset = ProductionData.objects.all()
    serializer_class = ProductionDataSerializer

class ProductionAnalysisViewSet(viewsets.ModelViewSet):
    queryset = ProductionAnalysis.objects.all()
    serializer_class = ProductionAnalysisSerializer